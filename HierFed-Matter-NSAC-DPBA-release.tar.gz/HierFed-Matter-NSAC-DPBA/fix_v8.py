#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v8.py  --  HierFed: repair the silent-failure bugs found in the 2026-10-06 batch.

Run from the project root:      python fix_v8.py
Idempotent: safe to run twice.  Backups: <file>.bak_v8 (created once).

Root causes fixed
-----------------
R1  baselines/runner.py : `config.get('feature_dim', 80).to(DEVICE)` -> int has no .to()
                          Crashes run_safeliot / run_dpfed6g / run_fedprox_dp in ~6 s.
R2  run_baselines.py    : the per-run `except` swallowed the exception WITHOUT a
                          non-zero exit code -> the driver saw rc==0 and printed "ok"
                          while nothing was written.  <-- the real "fake ok".
R3  run_parallel.py     : "ok" was decided by exit code only, never by the presence of
                          results.json -> silent failure was indistinguishable from success.
R4  run_parallel.py     : EPSILONS hard-coded to the obsolete grid [0.5 .. 10.0],
                          unrelated to run_epsilon_sweep.py's [100 .. 1500].
R5  run_parallel.py / run_baselines.py : `topk_qsgd` and `fedprox_dp` exist in
                          baselines/runner.py::METHOD_MAP but are missing from the
                          driver lists -> the compression baseline was never run.
R6  run_safeliot / run_dpfed6g : their "adaptive" sigma schedules inject far more total
                          noise than the nominal epsilon implies (mean(sigma^2) >>
                          sigma_base^2) -> unfair to the baselines.  Rescaled to be
                          budget-neutral; the rescale factor is printed.
"""
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BAK = ".bak_v8"

NEW_EPS = [20, 50, 100, 200, 400, 800, 1600]
WANT_METHODS = ["fedavg", "fedprox", "dpfedavg", "hierfed", "hierfed_dp",
                "topk_qsgd", "safeliot", "dpfed6g", "fedprox_dp",
                "adaptive_clip_dp", "layer_adaptive_dp"]

report = []


def note(tag, status, detail=""):
    report.append((tag, status, detail))
    mark = {"ok": "  [ok]  ", "skip": " [skip] ", "FAIL": " [FAIL] "}[status]
    print(f"{mark}{tag}  {detail}")


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def backup(rel):
    src = os.path.join(ROOT, rel)
    dst = src + BAK
    if not os.path.exists(dst):
        shutil.copy2(src, dst)


def write(rel, text):
    backup(rel)
    with open(os.path.join(ROOT, rel), "w", encoding="utf-8") as f:
        f.write(text)


def sub(rel, pattern, repl, tag, count=1, flags=0, required=True):
    """Regex substitution with idempotency check and loud reporting."""
    src = read(rel)
    hits = re.findall(pattern, src, flags)
    if not hits:
        # already patched?  (idempotency probe)
        if repl.strip() and repl.strip()[:60] in src:
            note(tag, "skip", "already applied")
        else:
            note(tag, "FAIL" if required else "skip", "anchor not found -- CHECK MANUALLY")
        return False
    new, n = re.subn(pattern, repl, src, count=count, flags=flags)
    write(rel, new)
    note(tag, "ok", f"{n} site(s) patched")
    return True


# ----------------------------------------------------------------------------
# R1 -- the int/.to(DEVICE) crash
# ----------------------------------------------------------------------------
def fix_r1():
    rel = "baselines/runner.py"
    pat = re.compile(
        r"config\.get\(\s*(['\"][A-Za-z_]\w*['\"]\s*,\s*\d+)\s*\)\s*\.to\(DEVICE\)")
    src = read(rel)
    hits = pat.findall(src)
    if not hits:
        note("R1 int/.to(DEVICE)", "skip", "no remaining site (already fixed)")
        return
    new, n = pat.subn(lambda m: f"int(config.get({m.group(1)}))", src)
    write(rel, new)
    # belt and braces: also catch a bare `config['x']` int key used with .to()
    src = read(rel)
    pat2 = re.compile(r"config\[\s*'(feature_dim|N|T|E_local|batch_size|K|M)'\s*\]\s*\.to\(DEVICE\)")
    new2, n2 = pat2.subn(lambda m: f"int(config['{m.group(1)}'])", src)
    if n2:
        write(rel, new2)
    note("R1 int/.to(DEVICE)", "ok", f"{n + n2} site(s) fixed: {sorted(set(hits))}")


# ----------------------------------------------------------------------------
# R4 -- epsilon grid
# ----------------------------------------------------------------------------
def fix_r4():
    want = "EPSILONS = [" + ", ".join(repr(float(e)) for e in NEW_EPS) + "]"
    if want in read("run_parallel.py"):
        note("R4 EPSILONS grid", "skip", "already applied")
        return
    sub("run_parallel.py",
        r"EPSILONS\s*=\s*\[[^\]]*\]",
        want,
        "R4 EPSILONS grid")


# ----------------------------------------------------------------------------
# R5 -- method lists
# ----------------------------------------------------------------------------
def fix_r5():
    rel = "run_parallel.py"
    src = read(rel)
    m = re.search(r"BASELINE_METHODS\s*=\s*\[[^\]]*\]", src, flags=re.S)
    if not m:
        note("R5 BASELINE_METHODS", "FAIL", "list not found")
    else:
        cur = re.findall(r"['\"](\w+)['\"]", m.group(0))
        if cur == WANT_METHODS:
            note("R5 BASELINE_METHODS", "skip", "already correct")
        else:
            block = "BASELINE_METHODS = [\n" + "".join(
                f'    "{x}",\n' for x in WANT_METHODS) + "]"
            write(rel, src[:m.start()] + block + src[m.end():])
            note("R5 BASELINE_METHODS", "ok",
                 f"{len(cur)} -> {len(WANT_METHODS)} methods (+topk_qsgd, +fedprox_dp)")

    # the two `methods = ['fedavg', ...]` literals inside run_baselines.py
    rel2 = "run_baselines.py"
    src2 = read(rel2)
    pat = re.compile(r"\[\s*'fedavg',\s*'fedprox',(?:(?!\]).)*?\]", flags=re.S)
    found = pat.findall(src2)
    if not found:
        note("R5 run_baselines lists", "skip", "no 'fedavg'-anchored literal found")
    elif all("topk_qsgd" in f for f in found):
        note("R5 run_baselines lists", "skip", "already correct")
    else:
        block = "[\n" + "".join(f"                   '{x}',\n" for x in WANT_METHODS) + "                   ]"
        src2n, n = pat.subn(block, src2)
        write(rel2, src2n)
        note("R5 run_baselines lists", "ok", f"{n} literal(s) extended")


# ----------------------------------------------------------------------------
# R2 -- run_baselines.py must fail loudly
# ----------------------------------------------------------------------------
def fix_r2():
    rel = "run_baselines.py"
    src0 = read(rel)

    # (a) declare the flag
    if "_failed = False" in src0:
        note("R2a flag init", "skip", "already applied")
    else:
        sub(rel,
            r"(\n    if not args\.aggregate_only:\n)",
            "\n    _failed = False\n\\1",
            "R2a flag init")

    # (b) mark it inside the except block
    old_exc = re.compile(r"(except Exception as e:\n)")
    src = read(rel)
    if "raise_on_fail" in src or "_failed = True" in src:
        note("R2b except block", "skip", "already applied")
    elif old_exc.search(src):
        src_n, n = old_exc.subn(
            lambda m: m.group(1) + "                        _failed = True\n", src)
        write(rel, src_n)
        note("R2b except block", "ok", "exception now recorded")
    else:
        note("R2b except block", "FAIL", "except block not found -- CHECK MANUALLY")

    # (c) exit non-zero after the triples
    if "at least one baseline run FAILED" in read(rel):
        note("R2c exit code", "skip", "already applied")
    else:
        sub(rel,
            r"(\n    # Aggregate\n)",
            r"\n    if _failed:\n"
            r"        print('!! at least one baseline run FAILED -> exiting non-zero')\n"
            r"        sys.exit(1)\n\1",
            "R2c exit code")


# ----------------------------------------------------------------------------
# R3 -- run_parallel.py must verify the artefact, and print the child log tail
# ----------------------------------------------------------------------------
def fix_r3():
    rel = "run_parallel.py"

    src = read(rel)
    if "wrote nothing" in src:
        note("R3a artefact check", "skip", "already applied")
    else:
        old = re.compile(
            r"(        except Exception as e:  # noqa: BLE001\n"
            r"            rc = -1\n"
            r"            print\(f\"  !! launch failed for \{name\}: \{e\}\"\)\n)")
        if old.search(src):
            src_n = old.sub(
                lambda m: m.group(1) +
                "        if rc == 0 and not os.path.exists(os.path.join(ROOT, done_path)):\n"
                "            rc = -2  # exited 0 but wrote nothing -> silent failure\n",
                src)
            write(rel, src_n)
            note("R3a artefact check", "ok", "rc=-2 when results.json is missing")
        else:
            note("R3a artefact check", "FAIL", "run_job tail not found -- CHECK MANUALLY")

    src = read(rel)
    if "child log tail" in src:
        note("R3b log tail", "skip", "already applied")
    else:
        old2 = re.compile(r"(            if rc != 0:\n                print\(f\"         -> see \{log\}\"\)\n)")
        if old2.search(src):
            tail = (
                "            if rc != 0:\n"
                "                print(f\"         -> see {log}\")\n"
                "                try:  # child log tail\n"
                "                    _t = open(log, encoding='utf-8', errors='replace').read()\n"
                "                    for _l in _t.strip().splitlines()[-12:]:\n"
                "                        print(f\"            | {_l}\")\n"
                "                except Exception:\n"
                "                    pass\n")
            src_n = old2.sub(lambda m: tail, src)
            write(rel, src_n)
            note("R3b log tail", "ok", "failures now print their stderr inline")
        else:
            note("R3b log tail", "FAIL", "report block not found -- CHECK MANUALLY")


# ----------------------------------------------------------------------------
# R6 -- budget-neutral sigma schedules for safeliot / dpfed6g
# ----------------------------------------------------------------------------
def fix_r6():
    rel = "baselines/runner.py"
    src = read(rel)

    # --- dpfed6g schedule -------------------------------------------------
    if "_sigma_sched" in src:
        note("R6 dpfed6g schedule", "skip", "already applied")
    else:
        anchor_dp = (r"(    sigma_base = compute_noise_scale_rdp\("
                     r"float\(eps\), T, float\(delta\), float\(C\)\)\n"
                     r"    round_metrics = \[\]\n)")
        sched_dp = r"""\1
    # --- budget-neutral convergence-aware schedule -----------------------
    # raw weight w_t = 1/decay(t), rescaled so mean(w_t^2) == 1, i.e. the total
    # RDP budget is the same as the flat sigma_base this nominal epsilon implies.
    _raw = []
    for _t in range(1, T + 1):
        _dec = max(1e-3, min(1.0, _t / (T * 0.3)))
        _raw.append(1.0 / _dec)
    _scale = (sum(_x * _x for _x in _raw) / len(_raw)) ** 0.5
    _sigma_sched = [sigma_base * (_x / _scale) for _x in _raw]
    print(f"[DP-Fed6G] sigma_base={sigma_base:.4f} schedule_rescale={_scale:.2f} "
          f"sigma[1]={_sigma_sched[0]:.4f} sigma[T]={_sigma_sched[-1]:.4f}")
    # --------------------------------------------------------------------
"""
        src2, n1 = re.subn(anchor_dp, sched_dp, src, count=1)
        if n1:
            src = src2
            note("R6 dpfed6g schedule", "ok", "budget-neutral schedule inserted")
        else:
            note("R6 dpfed6g schedule", "FAIL", "anchor not found -- CHECK MANUALLY")

        # replace the in-loop computation
        pat_loop = re.compile(
            r"[ \t]*decay_factor\s*=\s*min\(1\.0, t / \(T \* 0\.3\)\).*?"
            r"device_sigma\s*=\s*sigma_base / decay_factor if decay_factor > 0 else sigma_base\n",
            flags=re.S)
        if pat_loop.search(src):
            src, n2 = pat_loop.subn("        device_sigma = _sigma_sched[t - 1]\n", src)
            note("R6 dpfed6g loop", "ok", "per-round sigma now from the schedule")
            write(rel, src)
        else:
            note("R6 dpfed6g loop", "FAIL", "in-loop block not found")

    # --- safeliot rescale -------------------------------------------------
    src = read(rel)
    if "_sens_rescale" in src:
        note("R6 safeliot rescale", "skip", "already applied")
    else:
        anchor_safe = (r"(    sigma_base = compute_noise_scale_rdp\("
                       r"float\(eps\), T, float\(delta\), float\(C\)\)\n"
                       r"\n    round_metrics = \[\]\n)")
        resc = r"""\1
    # --- budget-neutral sensitivity rescale -------------------------------
    _fac = []
    for _d in range(N):
        _n = len(partitions.get(str(_d), []))
        _fac.append(1.0 - 0.5 * min(_n, 200) / 200.0)
    _rms = (sum(_f * _f for _f in _fac) / max(1, len(_fac))) ** 0.5
    _sens_rescale = (1.0 / _rms) if _rms > 0 else 1.0
    print(f"[SAFEL-IoT] sigma_base={sigma_base:.4f} sens_rescale={_sens_rescale:.3f} "
          f"(mean sigma^2 normalised to sigma_base^2)")
    # ---------------------------------------------------------------------
"""
        src2, n = re.subn(anchor_safe, resc, src, count=1)
        if n:
            src = src2
            note("R6 safeliot rescale", "ok", "rescale factor inserted")
        else:
            note("R6 safeliot rescale", "FAIL", "anchor not found -- CHECK MANUALLY")

        src, n = re.subn(r"device_sigma = sigma_base \* sensitivity_factor\b(?! \*)",
                         "device_sigma = sigma_base * sensitivity_factor * _sens_rescale",
                         src)
        if n:
            note("R6 safeliot loop", "ok", "per-device sigma rescaled")
        else:
            note("R6 safeliot loop", "FAIL", "usage site not found")
        write(rel, src)


# ----------------------------------------------------------------------------
def main():
    print(f"[fix_v8] project root = {ROOT}")
    for must in ("run_parallel.py", "run_baselines.py", "baselines/runner.py"):
        if not os.path.exists(os.path.join(ROOT, must)):
            print(f"[fix_v8] !! {must} not found -- run me from the project root")
            sys.exit(1)

    fix_r1()
    fix_r2()
    fix_r3()
    fix_r4()
    fix_r5()
    fix_r6()

    # syntax gate
    print("\n[fix_v8] py_compile ...")
    bad = 0
    for f in ("run_parallel.py", "run_baselines.py", "baselines/runner.py"):
        r = subprocess.run([sys.executable, "-m", "py_compile", os.path.join(ROOT, f)],
                           capture_output=True, text=True)
        if r.returncode == 0:
            print(f"  [ok]   {f}")
        else:
            bad += 1
            print(f"  [FAIL] {f}\n{r.stderr}")
    if bad:
        print("\n!! syntax error -- restore from *.bak_v8 and tell Mihiro")
        sys.exit(1)

    # residual audit
    print("\n[fix_v8] residual audit ...")
    src = read("baselines/runner.py")
    left = re.findall(r"config\.get\(\s*'[A-Za-z_]\w*'\s*,\s*\d+\s*\)\s*\.to\(DEVICE\)", src)
    print(f"  remaining int/.to(DEVICE) sites : {len(left)}")
    srcp = read("run_parallel.py")
    m_eps = re.search(r"EPSILONS\s*=\s*\[[^\]]*\]", srcp)
    print("  EPSILONS now                    : "
          + (m_eps.group(0) if m_eps else "<not found>"))
    m_bm = re.search(r"BASELINE_METHODS\s*=\s*\[[^\]]*\]", srcp, flags=re.S)
    methods = re.findall(r"[\"'](\w+)[\"']", m_bm.group(0)) if m_bm else []
    print(f"  BASELINE_METHODS now            : {methods}")

    n_fail = sum(1 for _t, s, _d in report if s == "FAIL")
    print(f"\n[fix_v8] {'ALL PATCHES OK' if not n_fail else f'{n_fail} PATCH(ES) FAILED'}"
          f" -- backups: <file>{BAK}")
    if n_fail:
        sys.exit(1)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
