#!/usr/bin/env python3
"""
apply_fixes_v3.py -- third patch (on top of v1 + v2): legitimate client
                     subsampling + a self-consistent (epsilon, sigma) pair.

Prerequisite: apply_fixes.py (v1) and apply_fixes_v2.py (v2) already applied.

Why
---
The RDP accountant only gets subsampling amplification if the *protocol*
really samples clients each round.  The simulator trained all N=20 devices
every round, so q was effectively 1.0 and the honest eps for the noise we
actually use would be ~400, not 27.  v3 makes the sampling real.

What v3 changes
  W1  core/simulator.py : new `client_sample_rate` (fraction of devices that
                          participate per round, 1.0 = all).  Sampled once per
                          round with np.random (already seeded), so runs stay
                          reproducible.
  W2  core/simulator.py : warns if client_sample_rate != dp_subsampling_rate
                          (the accountant and the protocol must agree).
  W3  core/simulator.py : DP-DEBUG line now also prints n_part.
  W4  core/hierfed.py   : edge_aggregate normalises by the number of devices
                          that ACTUALLY participated; otherwise subsampling
                          silently scaled the update down by m/K.
  W5  configs/base.yaml : client_sample_rate: 0.2, epsilon_total: 27.0,
                          dp_noise_scale: 1.0 (sigma now derives from eps).

Usage:  python apply_fixes_v3.py [root]     (idempotent, writes *.bak_v3)
"""
import os
import sys
import shutil
import argparse

P = []

# ---- W1 + W2 : client sampling knob -----------------------------------------
P.append(("core/simulator.py",
"""        self.dp_noise_scale = float(config.get('dp_noise_scale', 1.0))""",
"""        self.dp_noise_scale = float(config.get('dp_noise_scale', 1.0))
        # [v3] fraction of devices sampled per round (1.0 = everybody).
        # The RDP accountant only earns its subsampling amplification if the
        # protocol REALLY samples clients, so this must equal
        # dp_subsampling_rate.
        self.client_sample_rate = float(config.get('client_sample_rate', 1.0))
        if abs(self.client_sample_rate - self.dp_subsampling_rate) > 1e-9:
            print(f"[WARN] client_sample_rate={self.client_sample_rate} != "
                  f"dp_subsampling_rate={self.dp_subsampling_rate}: the RDP "
                  f"amplification term would be unjustified.")"""))

# ---- W1b : do the sampling --------------------------------------------------
P.append(("core/simulator.py",
"""            # --- Step 1: Device local training + DP noise injection ---
            device_gradients = {}
            _dbg_dw, _dbg_noise, _dbg_sig = [], [], []
            for dev_id in range(self.N):
                idx_list = self.partitions.get(str(dev_id), [])""",
"""            # --- [v3] client subsampling ---
            # Only a random subset of devices participates this round.  This is
            # what makes a subsampling rate q < 1 (and the resulting privacy
            # amplification) legitimate rather than decorative.
            if self.client_sample_rate < 1.0:
                _m = max(1, int(round(self.client_sample_rate * self.N)))
                self._participants = set(
                    np.random.choice(self.N, size=_m, replace=False).tolist())
            else:
                self._participants = set(range(self.N))

            # --- Step 1: Device local training + DP noise injection ---
            device_gradients = {}
            _dbg_dw, _dbg_noise, _dbg_sig = [], [], []
            for dev_id in range(self.N):
                if dev_id not in self._participants:
                    continue
                idx_list = self.partitions.get(str(dev_id), [])"""))

# ---- W3 : show n_part in the debug line -------------------------------------
P.append(("core/simulator.py",
"""                      f"SNR={_dw / (_nz + 1e-12):.3e}  "
                      f"noise_scale={self.dp_noise_scale}")""",
"""                      f"SNR={_dw / (_nz + 1e-12):.3e}  "
                      f"noise_scale={self.dp_noise_scale}  "
                      f"n_part={len(self._participants)}/{self.N}")"""))

# ---- W4 : hierarchical aggregation must normalise by participants ------------
P.append(("core/hierfed.py",
"""        # Sum device gradients
        avg_grad = torch.zeros_like(global_model_params)
        for dev_id in device_ids:
            if dev_id in device_gradients:
                avg_grad += device_gradients[dev_id]
        avg_grad /= K_m""",
"""        # Sum device gradients
        # [v3] normalise by the number of devices that ACTUALLY participated.
        # With client subsampling, dividing by the full cluster size K_m would
        # silently scale the update down by m/K_m (an accidental lr change).
        avg_grad = torch.zeros_like(global_model_params)
        n_present = 0
        for dev_id in device_ids:
            if dev_id in device_gradients:
                avg_grad += device_gradients[dev_id]
                n_present += 1
        if n_present == 0:
            continue                      # whole cluster idle this round
        avg_grad /= n_present
        K_m = n_present"""))

# ---- W5 : yaml ---------------------------------------------------------------
P.append(("configs/base.yaml",
"""epsilon_total: 3.0       # v6: 回退v0值；ε=3.0噪声经FL聚合稀释后防collapse，v0实测AUC=0.67""",
"""epsilon_total: 27.0      # [v3] 真实可达 ε（隐私-效用曲线拐点）。ε=3 在本设置下必然 collapse，
                         #      见 README_FIX.md；改这里即改 σ（dp_noise_scale 保持 1.0）"""))

P.append(("configs/base.yaml",
"""dp_noise_scale: 1.0       # [v2] 已注入噪声的额外缩放（1.0=不改）。见 run_noise_sweep.sh""",
"""dp_noise_scale: 1.0       # [v3] 归位：σ 由 epsilon_total 自洽推出，不要再外挂缩放
client_sample_rate: 0.2   # [v3] 每轮随机采样参与的设备比例 m/N（=0.2 → 4/20）
                          #      ⚠ 必须与 dp_subsampling_rate 相等，否则隐私放大不成立"""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root)

    per_file = {}
    for rel, old, new in P:
        per_file.setdefault(rel, []).append((old, new))

    n_ok = n_skip = n_fail = 0
    for rel in sorted(per_file):
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            print(f"  [MISSING] {rel}")
            n_fail += 1
            continue
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        todo = []
        for old, new in per_file[rel]:
            if new in src:
                continue
            if old not in src:
                print(f"  [FAIL] {rel}: pattern not found (v1/v2 applied?) -> "
                      f"{old.splitlines()[0].strip()[:60]!r}")
                n_fail += 1
                todo = None
                break
            todo.append((old, new))
        if todo is None:
            continue
        if not todo:
            print(f"  [SKIP] {rel}: already patched (v3)")
            n_skip += 1
            continue
        out = src
        for old, new in todo:
            out = out.replace(old, new)
        if args.dry_run:
            print(f"  [DRY ] {rel}: {len(todo)} hunk(s)")
            continue
        bak = path + ".bak_v3"
        if not os.path.exists(bak):
            shutil.copy2(path, bak)
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"  [ OK ] {rel}: {len(todo)} hunk(s) applied")
        n_ok += 1

    print(f"\napply_fixes_v3: files_patched={n_ok}  already_ok={n_skip}  failed={n_fail}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
