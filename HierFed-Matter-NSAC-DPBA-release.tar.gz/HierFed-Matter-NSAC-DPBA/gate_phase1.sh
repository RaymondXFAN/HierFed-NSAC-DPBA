#!/usr/bin/env bash
# =============================================================================
# gate_phase1.sh -- 方向A · Phase 1 跨数据集可行性闸门  (v2)
# EN: gate_phase1.sh -- Direction A - Phase 1 cross-dataset feasibility gate  (v2)
#
#   bash gate_phase1.sh                       # gotham25 + tii23 × {proposed, fedavg, topk_qsgd}
#   DS_LIST="gotham25" bash gate_phase1.sh    # 只验一个数据集 | EN: validate a single dataset only
#   CLEAN=0 bash gate_phase1.sh               # 不清理 results_gate（默认会清） | EN: do not clean results_gate (cleaned by default)
#
# v2 变更：默认先清 results_gate；结束后校验"目录名里必须带对的数据集名"。
# EN: v2 change: clean results_gate first by default; after finishing, verify that "the directory name carries the correct dataset name".
#          （v1 就是靠这条发现了 run_baselines.py 把结果写进 *_iotid20_* 的 bug）
# EN: (v1 caught via this rule the bug where run_baselines.py wrote the results into *_iotid20_*)
#
# 前置：python fix_v17.py --apply  &&  python fix_v18.py --apply
# EN: Prerequisite: python fix_v17.py --apply  &&  python fix_v18.py --apply
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
DS_LIST=${DS_LIST:-"gotham25 tii23"}
METHODS_BASE=${METHODS_BASE:-"fedavg topk_qsgd"}
ALPHA=${ALPHA:-0.5}
SEED=${SEED:-1}
T=${T:-2}
OUT=${OUT:-results_gate}
LOG=${LOG:-logs/gate_phase1}
TIMEOUT=${TIMEOUT:-1800}
CLEAN=${CLEAN:-1}

cd "$PROJ" || { echo "ERROR: 项目目录不存在: $PROJ"; exit 1; }
mkdir -p "$LOG"
[ "$CLEAN" = "1" ] && { rm -rf "$OUT"; echo "[clean] 已清空 $OUT"; }
mkdir -p "$OUT"

echo "================================================================"
echo " Phase 1 gate v2  datasets=[$DS_LIST]  alpha=$ALPHA  seed=$SEED  T=$T"
echo " out=$OUT   log=$LOG"
echo "================================================================"

# ---------------------------------------------------- preflight
pre=0
grep -q "'gotham25'" run_experiment.py 2>/dev/null || { echo "[!!] run_experiment.py --dataset 未含 gotham25 -> python fix_v17.py --apply"; pre=1; }
grep -q "\[fix_v17\]" core/simulator.py 2>/dev/null || { echo "[!!] core/simulator.py prefix 未修 -> python fix_v17.py --apply"; pre=1; }
grep -q "HIERFED_DATASET" run_baselines.py 2>/dev/null || { echo "[!!] run_baselines.py 未接 HIERFED_DATASET -> python fix_v17.py --apply"; pre=1; }
grep -q "\[fix_v18\]" run_baselines.py 2>/dev/null || { echo "[!!] run_baselines.py 结果名仍写死 iotid20 -> python fix_v18.py --apply"; pre=1; }
for ds in $DS_LIST; do
  [ -f "data/processed/${ds}_train.npz" ] || { echo "[!!] 缺 data/processed/${ds}_train.npz"; pre=1; }
  [ -f "data/processed/${ds}_test.npz" ]  || { echo "[!!] 缺 data/processed/${ds}_test.npz"; pre=1; }
done
if [ "$pre" -eq 0 ]; then echo "[preflight] OK"; else echo "[abort] preflight 未通过，闸门未启动。"; exit 1; fi

PASS=0; FAIL=0

run_it(){                                 # run_it <label> <command...>
  local label="$1"; shift
  local before after rc
  before=$(find "$OUT" -name results.json 2>/dev/null | wc -l)
  echo "----------------------------------------------------------------"
  echo "[run] $label"
  timeout "$TIMEOUT" "$@" > "$LOG/${label}.log" 2>&1
  rc=$?
  after=$(find "$OUT" -name results.json 2>/dev/null | wc -l)
  if [ "$rc" -eq 0 ] && [ "$after" -gt "$before" ]; then
    echo "  [PASS] $label   rc=0   (+$((after - before)) results.json)"
    PASS=$((PASS + 1))
  else
    echo "  [FAIL] $label   rc=$rc   (+$((after - before)) results.json)"
    echo "         log: $LOG/${label}.log"
    tail -n 14 "$LOG/${label}.log" 2>/dev/null | sed 's/^/     | /'
    FAIL=$((FAIL + 1))
  fi
}

for DS in $DS_LIST; do
  run_it "${DS}_proposed" "$PY" -u run_experiment.py \
      --dataset "$DS" --alpha "$ALPHA" --seed "$SEED" --method proposed \
      --T "$T" --e_local 1 --output_dir "$OUT"
  for M in $METHODS_BASE; do
    run_it "${DS}_${M}" env HIERFED_DATASET="$DS" "$PY" -u run_baselines.py \
        --method "$M" --alpha "$ALPHA" --seeds "$SEED" --T "$T" --output_dir "$OUT"
  done
done

# ---------------------------------------------------- 目录名一致性校验
# EN: Directory-name consistency check
echo "----------------------------------------------------------------"
echo " 产出目录（每个数据集名必须出现）:"
for DS in $DS_LIST; do
  n=$(ls -1 "$OUT" 2>/dev/null | grep -c "$DS")
  printf "   %-10s %s 个目录含该名\n" "$DS" "$n"
done
ls -1 "$OUT" 2>/dev/null | sed 's/^/     /'

mix=0
for DS in $DS_LIST; do
  for M in proposed $METHODS_BASE; do
    ls -1 "$OUT" 2>/dev/null | grep -qE "${M}.*${DS}|${DS}.*${M}" || {
      echo "   [!!] 缺 ${M} × ${DS} 的目录（结果名可能又写死了）"; mix=$((mix + 1)); }
  done
done
[ "$mix" -eq 0 ] || FAIL=$((FAIL + 1))

echo "================================================================"
echo " GATE RESULT : PASS=$PASS   FAIL=$FAIL"
if [ "$FAIL" -eq 0 ]; then
  echo " [OK]  闸门通过 -> 可进入 Phase 2（CR×C 交互，go/no-go）"
else
  echo " [FAIL] 闸门未通过 -> 看 $LOG/*.log，先修再跑"
fi
echo "  提示：$OUT 里是 T=$T 的冒烟结果，绝不能混进论文表格。"
echo "================================================================"
[ "$FAIL" -eq 0 ] && exit 0 || exit 1

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
