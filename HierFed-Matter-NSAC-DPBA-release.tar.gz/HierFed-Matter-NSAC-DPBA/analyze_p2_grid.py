#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_p2_grid.py  (v2)  -- 严格版 P2（CR × C）网格分析

v1 -> v2 修了什么
-----------------
v1 算了 `same_sign` 却**没用它**做判定，于是打出"交互显著"的同时又打印
"d(0.25) 全正=否" —— 自相矛盾。v2 把判定拆成三道独立的闸门，逐条给结论。

三道闸门（回答 go/no-go）
------------------------
  GATE-1 配对 t 检验      : Δd = d(最狠压缩) − d(最轻压缩) 的均值是否显著 ≠ 0
  GATE-2 逐 seed 符号一致 : d(最狠) 每个 seed 都 > 0 且 d(最轻) 每个 seed 都 < 0
                            （比 p 值更硬 —— 对每个 seed 单独成立）
  GATE-3 Wilcoxon         : n<6 时理论下限 ≥0.031，n≥8 才能到 0.0078；本脚本会提示
其中 d(scale) = AUC(C=0.5) − AUC(C=0.2)

另外打印 per-seed 明细，方便揪出是哪个 seed 翻转。

用法
    python analyze_p2_grid.py                 # 默认 results_v9_crxC
    python analyze_p2_grid.py <结果目录>

--- EN ---
analyze_p2_grid.py  (v2)  -- strict-version P2 (CR x C) grid analysis

What v1 -> v2 fixed
-------------------
v1 computed `same_sign` but **never used it** in the decision, so it printed
"interaction significant" while also printing "d(0.25) all-positive=no" --
self-contradictory. v2 splits the decision into three independent gates and
gives a verdict for each one.

The three gates (answering go/no-go)
------------------------------------
  GATE-1 paired t-test        : is the mean of Δd = d(harshest compression) − d(mildest compression) significantly ≠ 0
  GATE-2 per-seed sign consistency : d(harshest) > 0 for every seed AND d(mildest) < 0 for every seed
                                (harder than a p-value -- holds for each seed individually)
  GATE-3 Wilcoxon             : when n<6 the theoretical lower bound ≥0.031, only n≥8 can reach 0.0078; this script flags it
where d(scale) = AUC(C=0.5) − AUC(C=0.2)

It also prints the per-seed details, handy for pinpointing which seed flips.

Usage
    python analyze_p2_grid.py                 # default: results_v9_crxC
    python analyze_p2_grid.py <results dir>
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

import numpy as np

try:
    from scipy import stats
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False

ROOT = sys.argv[1] if len(sys.argv) > 1 else "results_v9_crxC"
PAT = re.compile(r"seed(\d+)_crx_s([\d.]+)_C([\d.]+)")

cell = defaultdict(dict)      # (scale, C) -> {seed: auc}
crs = defaultdict(list)       # scale -> [achieved CR]
n_files = 0
for p in glob.glob(os.path.join(ROOT, "*", "results.json")):
    name = os.path.basename(os.path.dirname(p))
    m = PAT.search(name)
    if not m:
        continue
    seed, scale, c = int(m.group(1)), float(m.group(2)), float(m.group(3))
    try:
        d = json.load(open(p, encoding="utf-8"))
    except Exception:
        continue
    auc = (d.get("final_metrics") or {}).get("auc_roc")
    if auc is None:
        continue
    cell[(scale, c)][seed] = auc
    n_files += 1
    rm = d.get("round_metrics") or []
    if rm and rm[0].get("avg_compression_ratio") is not None:
        crs[scale].append(rm[0]["avg_compression_ratio"])

if not cell:
    print(f"[!!] {ROOT} 下没解析到任何 results.json")
    sys.exit(1)

scales = sorted({k[0] for k in cell})
cs = sorted({k[1] for k in cell})
seeds = sorted({s for v in cell.values() for s in v})

print("=" * 78)
print(f" P2 CR x C 网格   parsed {n_files} runs   seeds={seeds}   n_per_cell<= {len(seeds)}")
print("=" * 78)

hdr = "CR_SCALE \\ C |" + "".join(f"{c:>10}" for c in cs)
print(hdr)
print("-" * len(hdr))
for s in scales:
    row = f"{s:<12} |"
    for c in cs:
        v = list(cell.get((s, c), {}).values())
        row += f"{np.mean(v):>10.4f}" if v else f"{'--':>10}"
    print(row)

print()
print("每格 mean±std (n):")
for s in scales:
    parts = []
    for c in cs:
        v = list(cell.get((s, c), {}).values())
        if v:
            sd = np.std(v, ddof=1) if len(v) > 1 else 0.0
            parts.append(f"C={c}: {np.mean(v):.4f}±{sd:.4f}(n={len(v)})")
        else:
            parts.append(f"C={c}: --")
    print(f"  scale={s:<5} " + " | ".join(parts))

print()
print("平均实测压缩率:")
for s in scales:
    if crs[s]:
        mc = float(np.mean(crs[s]))
        print(f"  scale={s:<5} mean CR ≈ {mc:.4f}   CF ≈ {1/mc:.2f}x")

# ------------------------------------------------------------------ GATE-0 ANOVA
print()
print("=" * 78)
print(" GATE-0  两因素 ANOVA（CR x C）交互项 F 检验 —— 审稿人最认的那一个")
print("=" * 78)
anova_ok = None
try:
    a_lv = [s for s in scales if all((s, c) in cell for c in cs)]
    b_lv = [c for c in cs if all((s, c) in cell for s in a_lv)]
    if len(a_lv) >= 2 and len(b_lv) >= 2:
        cs_set = None
        for s in a_lv:
            for c in b_lv:
                ks = set(cell[(s, c)])
                cs_set = ks if cs_set is None else (cs_set & ks)
        cs_set = sorted(cs_set or [])
        N = len(cs_set)
        if N >= 2:
            X = np.array([[[cell[(s, c)][k] for k in cs_set] for c in b_lv] for s in a_lv])
            A, B, _ = X.shape
            gm = X.mean()
            mi, mj, mij = X.mean(axis=(1, 2)), X.mean(axis=(0, 2)), X.mean(axis=2)
            SSA = B * N * ((mi - gm) ** 2).sum()
            SSB = A * N * ((mj - gm) ** 2).sum()
            SSAB = N * ((mij - mi[:, None] - mj[None, :] + gm) ** 2).sum()
            SSE = ((X - mij[:, :, None]) ** 2).sum()
            dfA, dfB, dfAB, dfE = A - 1, B - 1, (A - 1) * (B - 1), A * B * (N - 1)
            FA = (SSA / dfA) / (SSE / dfE)
            FB = (SSB / dfB) / (SSE / dfE)
            FAB = (SSAB / dfAB) / (SSE / dfE)
            print(f"  设计: {A} CR x {B} C x {N} 共同 seeds（平衡）")
            if HAVE_SCIPY:
                print(f"  主效应 CR     F={FA:8.2f}  p={1 - stats.f.cdf(FA, dfA, dfE):.2e}")
                print(f"  主效应 C      F={FB:8.2f}  p={1 - stats.f.cdf(FB, dfB, dfE):.2e}")
                pAB = 1 - stats.f.cdf(FAB, dfAB, dfE)
                print(f"  交互  CRxC    F={FAB:8.2f}  df=({dfAB},{dfE})   p={pAB:.4f}")
                anova_ok = bool(pAB < 0.05)
                print("  -> " + ("交互显著：最优 C 确实依赖压缩率 ✅" if anova_ok
                                else "交互未达显著（可退而用 GATE-1/符号论证）"))
            else:
                print(f"  交互  CRxC    F={FAB:8.2f}  (需要 scipy 才能算 p)")
        else:
            print(f"  ⚠️ 共同 seed 只有 {N} 个，不足以做 ANOVA")
    else:
        print("  ⚠️ 需要 >=2 CR x >=2 C 才能做 ANOVA")
except Exception as e:
    print(f"  ⚠️ ANOVA 计算失败: {e}")

# ------------------------------------------------------------------ Q1
print()
print("=" * 78)
print(" Q1  每行最优 C  vs  base.yaml 默认 C=1.0   （按 seed 配对）")
print("=" * 78)
ref = 1.0 if 1.0 in cs else cs[-1]
best_of = {}
for s in scales:
    means = {c: float(np.mean(list(cell[(s, c)].values()))) for c in cs if (s, c) in cell}
    if not means:
        continue
    best_c = max(means, key=means.get)
    best_of[s] = best_c
    a, b = cell.get((s, best_c), {}), cell.get((s, ref), {})
    common = sorted(set(a) & set(b))
    txt = (f"  scale={s:<5} 最优 C={best_c:<4} {means[best_c]:.4f}  "
           f"vs C={ref} {means.get(ref, float('nan')):.4f}")
    if len(common) >= 3 and best_c != ref:
        da = np.array([a[k] for k in common])
        db = np.array([b[k] for k in common])
        diff = da - db
        txt += f"   配对差 {diff.mean():+.4f} (n={len(common)})"
        if HAVE_SCIPY:
            try:
                txt += f"   t-p={stats.ttest_rel(da, db).pvalue:.4f}"
                if np.any(diff):
                    txt += f"  wilcoxon-p={stats.wilcoxon(da, db).pvalue:.4f}"
            except Exception:
                pass
        txt += f"   逐seed全正={'是' if np.all(diff > 0) else '否'}"
    print(txt)

# ------------------------------------------------------------------ Q2
print()
print("=" * 78)
print(" Q2  交互检验:  d(scale) = AUC(C=0.5) - AUC(C=0.2)")
print("=" * 78)
C_HI, C_LO = 0.5, 0.2
dmap = {}
if C_HI in cs and C_LO in cs:
    for s in scales:
        a, b = cell.get((s, C_HI), {}), cell.get((s, C_LO), {})
        common = sorted(set(a) & set(b))
        if common:
            darr = {k: a[k] - b[k] for k in common}
            dmap[s] = darr
            vals = np.array([darr[k] for k in common])
            sd = np.std(vals, ddof=1) if len(vals) > 1 else 0.0
            print(f"  scale={s:<5} d = {vals.mean():+.4f} ± {sd:.4f} (n={len(vals)})   "
                  f"逐seed: " + " ".join(f"s{k}{darr[k]:+.3f}" for k in common))
else:
    print(f"  ⚠️ 网格里缺少 C={C_HI} 或 C={C_LO}")

verdicts = []
if len(dmap) >= 2:
    ks = sorted(dmap)
    k_aggr, k_mild = ks[0], ks[-1]
    da = dmap[k_aggr]
    db = dmap[k_mild]
    common = sorted(set(da) & set(db))
    A = np.array([da[k] for k in common])
    B = np.array([db[k] for k in common])
    DD = A - B
    n = len(common)
    print()
    print(f"  交互量 Δd = d(scale={k_aggr}) − d(scale={k_mild}) = {DD.mean():+.4f} (n={n})")

    # GATE-1
    if HAVE_SCIPY and n >= 3:
        tp = stats.ttest_rel(A, B).pvalue
        wp = stats.wilcoxon(A, B).pvalue if np.any(DD) else float("nan")
        print(f"  GATE-1 配对 t 检验 : t-p={tp:.4f}    wilcoxon-p={wp:.4f}")
        if n < 6:
            print(f"         ⚠️ n={n} < 6：Wilcoxon 双尾理论下限 "
                  f"= {2/(2**n):.4f}，出不了更小；要 Wilcoxon 也显著需 n≥6~8")
        verdicts.append(("GATE-1", tp < 0.05))
    else:
        print("  GATE-1 需要 scipy 且 n>=3")

    # GATE-2 符号一致（最硬的证据）
    # EN: GATE-2 per-seed sign consistency (the strongest evidence)
    a_pos = bool(np.all(A > 0))
    b_neg = bool(np.all(B < 0))
    print(f"  GATE-2 逐 seed 符号 : d(scale={k_aggr}) 全正={a_pos}   "
          f"d(scale={k_mild}) 全负={b_neg}")
    verdicts.append(("GATE-2", a_pos and b_neg))

    n_fail = sum(1 for k in common if not (da[k] > 0 and db[k] < 0))
    if n_fail:
        bad = [k for k in common if not (da[k] > 0 and db[k] < 0)]
        print(f"         不一致的 seed: {bad}")

    print()
    print("  ------------------ 判词 ------------------")
    g1 = dict(verdicts).get("GATE-1", False)
    g2 = dict(verdicts).get("GATE-2", False)
    g0 = bool(anova_ok)
    if g0 and g1 and g2:
        print("  ✅ 交互坐实：ANOVA 交互项 + 配对 t + 逐 seed 符号 三重通过 —— 直接进论文")
    elif g0 and g1:
        print("  ✅ 交互成立：ANOVA 交互项显著 + 配对 t 显著。符号未全票属噪声，以 ANOVA 为准")
    elif g1 or g2:
        print("  🟡 交互方向一致但证据不够硬（ANOVA 未显著）—— 补 seed 或用符号/区间论证")
    else:
        print("  ❌ 证据不足：交互未能确证 —— 退为方案B（系统性权衡测量研究）")
    print("  ------------------------------------------")

print()
print(" 参考: 自适应裁剪(per_device) 主结果 AUC ≈ 0.9735 —— 应 ≥ 任何固定 C 的最优值")
print("=" * 78)

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
