#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
内存友好的 IoTID20 预处理（等价于 data/preprocess.py 的 chunk 版）。
原理：逐块读取 → 每块立刻丢掉字符串列 → float32 → 累积。
峰值内存 ≈ 单块(100k×86) + 累积(625k×79×4B) ≈ 300MB，比原版省 5~10 倍。
用法：
  python preprocess_iotid20_fast.py --chunk_dir data/chunks --alpha 0.5 --N 20
  python preprocess_iotid20_fast.py --chunk_dir data/chunks --alpha 0.1 --N 20

--- EN ---
Memory-friendly IoTID20 preprocessing (the chunked version equivalent to data/preprocess.py).
Principle: read chunk by chunk -> discard the string columns immediately per chunk -> float32 -> accumulate.
Peak memory ≈ a single chunk (100k×86) + the accumulated array (625k×79×4B) ≈ 300MB, 5~10x less than the original.
Usage:
  python preprocess_iotid20_fast.py --chunk_dir data/chunks --alpha 0.5 --N 20
  python preprocess_iotid20_fast.py --chunk_dir data/chunks --alpha 0.1 --N 20
"""
import os, json, argparse, glob
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

LABEL_NAMES = ['label', 'attack_type', 'class', 'cat', 'subcategory']


def dirichlet_partition(labels, N, alpha, seed):
    np.random.seed(seed)
    num_classes = len(np.unique(labels))
    device_indices = {i: [] for i in range(N)}
    for c in range(num_classes):
        class_idx = np.where(labels == c)[0]
        n_class = len(class_idx)
        proportions = np.random.dirichlet([alpha] * N)
        splits = (proportions * n_class).astype(int)
        remainder = n_class - splits.sum()
        for r in range(remainder):
            splits[r % N] += 1
        perm = np.random.permutation(class_idx)
        start = 0
        for i in range(N):
            end = start + splits[i]
            device_indices[i].extend(perm[start:end].tolist())
            start = end
    for i in range(N):
        device_indices[i] = sorted(device_indices[i])
    sizes = [len(device_indices[i]) for i in range(N)]
    print(f"[Dirichlet] N={N}, a={alpha}: min={min(sizes)}, max={max(sizes)}, mean={np.mean(sizes):.0f}")
    return device_indices


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--chunk_dir', default='data/chunks')
    ap.add_argument('--output_dir', default='data/processed')
    ap.add_argument('--alpha', type=float, default=0.5)
    ap.add_argument('--N', type=int, default=20)
    ap.add_argument('--test_ratio', type=float, default=0.2)
    ap.add_argument('--seed', type=int, default=1)
    args = ap.parse_args()

    files = sorted(glob.glob(os.path.join(args.chunk_dir, 'processed_chunk_*.csv.gz')))
    if not files:
        raise SystemExit(f"[ERR] 在 {args.chunk_dir} 找不到 processed_chunk_*.csv.gz")
    print(f"[IoTID20] Found {len(files)} chunk files")

    # ---- 1) 用首块前 2000 行推断列角色（省内存）----
    # EN: (1) Infer column roles from the first 2000 rows of the first chunk (to save memory).
    head = pd.read_csv(files[0], nrows=2000)
    label_cols = [c for c in head.columns if c.lower() in LABEL_NAMES]
    if not label_cols:
        label_cols = list(head.columns[-3:])
    feat_cols = [c for c in head.columns if c not in label_cols]
    non_numeric = head[feat_cols].select_dtypes(exclude=[np.number]).columns.tolist()
    feat_cols = [c for c in feat_cols if c not in non_numeric]
    label_col = [c for c in label_cols if c.lower() == 'label'] or label_cols[:1]
    label_col = label_col[0]
    print(f"[IoTID20] label_cols={label_cols}  non_numeric(dropped)={non_numeric}")
    print(f"[IoTID20] keep {len(feat_cols)} numeric features + label '{label_col}'")

    dt = {c: np.float32 for c in feat_cols}
    dt[label_col] = np.int8
    keep = feat_cols + [label_col]

    # ---- 2) 逐块读取并立即瘦身 ----
    # EN: (2) Read chunk by chunk and slim each chunk down immediately.
    parts = []
    for f in files:
        d = pd.read_csv(f, usecols=keep, dtype=dt)
        print(f"  {os.path.basename(f)}: {len(d)} rows")
        parts.append(d)
    df = pd.concat(parts, ignore_index=True, copy=False)
    del parts
    print(f"[IoTID20] Combined: {df.shape[0]} rows x {len(feat_cols)} features")

    X = df[feat_cols].to_numpy(dtype=np.float32)
    y = df[label_col].to_numpy(dtype=np.int64)
    del df
    print(f"[IoTID20] Final feature dim: {X.shape[1]}")
    if X.shape[1] == 79:
        print("[IoTID20] ✅ feature dim = 79，与论文一致")
    else:
        print(f"[IoTID20] ⚠ feature dim = {X.shape[1]}（论文为 79）。"
              f"若非 79，请把上面 non_numeric(dropped) 那行发给 Mihiro 核对。")
    print(f"[IoTID20] Label raw counts: 0 -> {int((y==0).sum())}, 1 -> {int((y==1).sum())}")
    print(f"[IoTID20] (data already Z-scored -> skip_scaler=True)")

    # ---- 3) 划分 + Dirichlet 分区（与论文脚本一致）----
    # EN: (3) Train/test split + Dirichlet partitioning (consistent with the paper's script).
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=args.test_ratio, random_state=args.seed, stratify=y)
    partitions = dirichlet_partition(y_train, args.N, args.alpha, args.seed)

    # ---- 4) 保存 ----
    # EN: (4) Save.
    os.makedirs(args.output_dir, exist_ok=True)
    np.savez(os.path.join(args.output_dir, 'iotid20_train.npz'), X=X_train, y=y_train)
    np.savez(os.path.join(args.output_dir, 'iotid20_test.npz'), X=X_test, y=y_test)
    meta = {
        'N': args.N, 'alpha': args.alpha, 'seed': args.seed,
        'feature_dim': int(X.shape[1]),
        'num_train': int(len(y_train)), 'num_test': int(len(y_test)),
        'normal_train': int((y_train == 0).sum()),
        'attack_train': int((y_train == 1).sum()),
        'device_indices': partitions,
    }
    for fn in (f'iotid20_partitions_alpha{args.alpha}.json', 'iotid20_partitions.json'):
        with open(os.path.join(args.output_dir, fn), 'w', encoding='utf-8') as f:
            json.dump(meta, f, indent=2)
    print(f"[IoTID20] Saved to {args.output_dir} (alpha={args.alpha})")
    print("[Done]")


if __name__ == '__main__':
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
