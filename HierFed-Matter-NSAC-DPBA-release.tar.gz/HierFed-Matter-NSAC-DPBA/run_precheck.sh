#!/usr/bin/env bash
# =============================================================================
# run_precheck.sh -- 5-minute-class gate BEFORE committing to ~20h of full runs
#
#   bash run_precheck.sh            # launch 3 runs in background
#   bash run_precheck.sh --wait     # launch and wait, then print a summary
#
# Three configs, 1 seed each, alpha=0.5, T=50 (realistic):
#   1 nodp_nonsac : no DP, no NSAC        -> sanity, expect AUC ~0.98
#   2 nsac_only   : NSAC on, no DP        -> isolates the B1 (NSAC) fix
#   3 full        : NSAC + DP (proposed)  -> the real target
#
# PASS criteria:  full >= 0.85  AND  nsac_only >= 0.85  AND  nodp_nonsac ~ 0.98
# (before the patch: nodp_nonsac~0.98, nsac_only~0.46, full~0.54)
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}

cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }
mkdir -p logs results_precheck

launch () {
  local tag=$1; shift
  echo "[precheck] launch $tag  (extra flags: $*)"
  nohup $PY -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
        --output_dir results_precheck --tag "$tag" "$@" \
        > "logs/precheck_${tag}.log" 2>&1 &
}

launch nodp_nonsac --disable_dp --disable_nsac
launch nsac_only   --disable_dp
launch full

cat <<'EOF'

[precheck] 3 tasks launched in the background (T=50, ~20-25 min, 3-way parallel).
  进度    : tail -n 3 logs/precheck_full.log
  SNR     : grep "DP-DEBUG" logs/precheck_full.log | tail -5
  发散告警: grep "WARN" logs/precheck_full.log
  结果    : grep -h "Final:" logs/precheck_*.log
EOF

if [ "${1:-}" = "--wait" ]; then
  wait
  echo
  echo "======================= PRECHECK SUMMARY ======================="
  for t in nodp_nonsac nsac_only full; do
    printf "%-12s " "$t"
    grep -h "Final:" "logs/precheck_${t}.log" 2>/dev/null | tail -1 || echo "(no output)"
  done
  echo "================================================================"
  echo "PASS if nsac_only>=0.85 and full>=0.85."

  cat <<'EOF'

下一步（只有 PASS 才继续）:
  重新跑全量:
    export OMP_NUM_THREADS=8
    nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 > logs/parallel_fixed.log 2>&1 &
  注意: 先把旧的坏结果挪开，避免幂等跳过:
    mv results_ablation results_ablation_OLD_buggy
    mv results_baseline results_baseline_OLD_buggy
    mv results_eps      results_eps_OLD_buggy
    mv results_scale    results_scale_OLD_buggy
EOF
fi

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
