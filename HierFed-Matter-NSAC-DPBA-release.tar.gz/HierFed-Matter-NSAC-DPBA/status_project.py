#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
status_project.py -- one-command project status + ETA.  Non-blocking, instant.

    python status_project.py                        # default: logs/parallel_s2.log
    python status_project.py logs/parallel_v7.log
    python status_project.py --watch 300            # refresh every 5 min, 300 s total

Reads the driver log, counts finished/queued jobs, measures the true per-job
runtime, and prints the projected completion CLOCK TIME (not just minutes).

Flags anomalies the way the 2026-10-06 post-mortem requires:
  * jobs that finished in < 1 min (silent-failure signature)
  * FAIL lines
  * results.json files that are missing although the job reported ok
"""
import argparse
import datetime as dt
import glob
import os
import re
import subprocess
import sys
import time

LINE = re.compile(
    r"^\[\s*(?P<i>\d+)/(?P<n>\d+)\]\s+(?P<tag>ok|FAIL)\s+"
    r"(?P<dt>[\d.]+)min\s+(?P<name>\S+)\s+"
    r"\(elapsed (?P<elapsed>[\d.]+)min, ETA (?P<eta>[\d.]+)min\)", re.M)
HEAD = re.compile(r"total jobs=(?P<total>\d+)\s+already done=(?P<done>\d+)\s+"
                  r"to run=(?P<torun>\d+)")


def suite_of(name):
    if name.startswith("epsweep"):
        return "eps"
    if name.startswith("proposed") and "_full" in name:
        return "abl"
    if name.startswith("scale_"):
        return "scale"
    return "base"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("log", nargs="?", default="logs/parallel_s2.log")
    ap.add_argument("--watch", type=int, default=0,
                    help="refresh every --watch/6 seconds for this many seconds")
    ap.add_argument("--out-dir", default=".", help="where results_* live")
    a = ap.parse_args()

    def once():
        if not os.path.exists(a.log):
            print(f"!! {a.log} not found (run from the project root)")
            return None
        txt = open(a.log, encoding="utf-8", errors="replace").read()
        m = HEAD.search(txt)
        jobs = [m2.groupdict() for m2 in LINE.finditer(txt)]
        seen = {}
        for j in jobs:                       # keep the last report per job
            seen[j["name"]] = j
        jobs = list(seen.values())
        ok = [j for j in jobs if j["tag"] == "ok"]
        fail = [j for j in jobs if j["tag"] == "FAIL"]
        fast = [j for j in ok if float(j["dt"]) < 1.0]

        print("=" * 78)
        print(f"  HierFed status   {dt.datetime.now():%Y-%m-%d %H:%M:%S}")
        print("=" * 78)
        if m:
            tot, done0, torun = (int(m.group("total")), int(m.group("done")),
                                 int(m.group("torun")))
            print(f"  plan : total={tot}  pre-existing={done0}  to run={torun}")
        else:
            torun = len(jobs)
        print(f"  log  : {a.log}  ({os.path.getsize(a.log)/1024:.0f} KB)")
        print(f"  done : {len(ok)} ok   |   {len(fail)} FAIL   "
              f"|   remaining ≈ {max(0, torun - len(jobs))}")

        # per-suite
        by = {}
        for j in jobs:
            s = suite_of(j["name"])
            d = by.setdefault(s, {"ok": 0, "FAIL": 0, "min": 0.0})
            d[j["tag"].lower()] = d.get(j["tag"].lower(), 0) + 1
            d["min"] += float(j["dt"])
        if by:
            print("  suites:")
            for s, d in sorted(by.items()):
                print(f"    {s:6s} ok={d.get('ok',0):3d} FAIL={d.get('FAIL',0):2d}  "
                      f"cumulative {d['min']/60:.1f} h of single-slot work")

        # anomalies
        if fail:
            print(f"  !! FAILURES ({len(fail)}): last one -> "
                  f"{fail[-1]['name']} ({fail[-1]['dt']}min)")
        if fast:
            print(f"  !! {len(fast)} job(s) finished in <1 min -- silent-failure "
                  f"signature: {[j['name'] for j in fast[-3:]]}")

        # ETA from the log's own elapsed clock
        if jobs:
            last = jobs[-1]
            el = float(last["elapsed"])
            rem_jobs = max(1, torun - len(jobs))
            rate = el / max(1, len(jobs))          # min of wall clock per job
            eta_min = rate * rem_jobs
            finish = dt.datetime.now() + dt.timedelta(minutes=eta_min)
            print(f"  speed: {rate:.2f} min wall-clock per job "
                  f"({len(jobs)} done in {el:.0f} min)")
            print(f"  ETA  : {eta_min/60:.1f} h  ->  ~{finish:%Y-%m-%d %H:%M}")

        # is the driver still alive?
        ps = subprocess.run("pgrep -af 'run_parallel.py|run_experiment.py|"
                            "run_baselines.py|run_epsilon_sweep.py'",
                            shell=True, capture_output=True, text=True).stdout
        nproc = len([l for l in ps.splitlines()
                     if l.strip() and "pgrep" not in l])
        print(f"  procs: {nproc} running" +
              ("  -> 已结束" if nproc == 0 else ""))
        if nproc:
            for l in ps.splitlines()[:5]:
                print("    " + l[:110])

        # artefact check for the methods that used to fail silently
        roots = ["results_baseline", "results_eps", "results_ablation"]
        miss = []
        for j in ok:
            nm = j["name"]
            for r in roots:
                p = os.path.join(a.out_dir, r, nm, "results.json")
                if os.path.isdir(os.path.join(a.out_dir, r, nm)) and not os.path.exists(p):
                    miss.append(nm)
        if miss:
            print(f"  !! {len(miss)} job(s) reported ok but results.json missing: {miss[:3]}")
        print("=" * 78)
        return nproc, len(jobs), torun

    if a.watch:
        end = time.time() + a.watch
        while time.time() < end:
            os.system("clear")
            once()
            if time.time() + a.watch / 6 < end:
                time.sleep(a.watch / 6)
        return 0

    r = once()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
