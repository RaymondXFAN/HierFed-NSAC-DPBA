#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v11.py -- repairs the REMAINING half of the NSAC compression bug.

    python fix_v11.py            # DRY RUN: source + before/after gain table (no writes)
    python fix_v11.py --apply    # set the decompression scale to 1.0 (backup .bak_v11)
    python fix_v11.py --revert   # restore from .bak_v11

The story
---------
`[FIX B1]` (already on the server) repaired the *compressor*: q_values is now at
the natural scale, i.e.  q_values ~= g_S  (the kept top-k entries).

But the *decompressor* was never updated, and it still multiplies by

        scale = ||g_S|| / sqrt(k)

So the vector that actually reaches the aggregator is

        recon = q_values * ||g_S|| / sqrt(k)  ~=  g_S * ||g_S|| / sqrt(k)

The gain is therefore

        ||recon|| / ||g||  =  ||g_S||^2 / (sqrt(k) * ||g||)

which is (a) NOT 1, (b) PROPORTIONAL TO THE GRADIENT SCALE, and (c) depends on
k.  Since ||Dw|| shrinks during training, the effective step size shrinks with
it -- an unintended quadratic brake.  And slices with different k get different
gains (embb sqrt(k)=48.4 vs mmtc sqrt(k)=19.8 -> 2.4x apart), so the "per-slice
compression" ablation is confounded with a per-slice step-size change.

The correct scale is exactly 1.0: with q_values ~= g_S, the best L2
approximation of g supported on the top-k set IS g_S itself, so

        recon = q_values * 1.0 = g_S,   gain = ||g_S||/||g||  (~0.5-0.9)

which is the honest, scale-independent top-k energy loss.

DO NOT apply blindly: this changes every existing result.  Measure first
(python probe_nsac.py --real), then gate (see the command this script prints).
"""
import argparse
import os
import py_compile
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
NSAC = os.path.join(HERE, "core", "nsac.py")
MARK = "[fix_v11]"

OLD = "    scale = norm / np.sqrt(k) if k > 0 else 1.0"
NEW = ("    # [fix_v11] q_values is already at the natural scale (see [FIX B1]),\n"
       "    # so the reconstruction must NOT be rescaled again.  The old\n"
       "    # `norm/sqrt(k)` made the applied update track ||g||^2, i.e. an\n"
       "    # unintended, gradient- and k-dependent gain.\n"
       "    scale = 1.0")


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def show_current():
    bar("1. current decompressor")
    if not os.path.exists(NSAC):
        print("  !! core/nsac.py not found -- run me from the project root")
        return
    src = open(NSAC, encoding="utf-8").read()
    m = re.search(r"def nsac_decompress\(.*?(?=^def |\Z)", src, re.S | re.M)
    if not m:
        print("  !! nsac_decompress not found")
        return
    body = m.group(0)
    print(f"  patched already : {MARK in body}")
    for l in body.splitlines():
        print("    " + l[:140])


def gain_table():
    """numpy re-implementation of the SERVER compressor + each decompressor."""
    import numpy as np
    bar("2. gain ||recon||/||g|| : current (norm/sqrt(k))  vs  fixed (1.0)")
    scales = (0.5, 1, 10, 50, 100)
    print("  %-8s %-3s %-6s | %s" % ("k_ratio", "b", "state",
          " ".join(f"{'||g||=' + f'{s:g}':>11}" for s in scales)))
    print("  " + "-" * 84)
    for kr, b in ((0.30, 16), (0.10, 8), (0.05, 8)):
        rng = np.random.default_rng(1)
        rows = {"current": [], "fixed": []}
        for ng_target in scales:
            g = rng.normal(0, 1, 7826)
            g *= ng_target / np.linalg.norm(g)
            k = max(1, int(kr * g.size))
            L = 2 ** (b - 1) - 1
            idx = np.argsort(-np.abs(g))[:k]
            sg = g[idx]
            nrm = float(np.linalg.norm(sg))
            scaled = sg * L / nrm
            q = np.sign(scaled) * np.floor(np.abs(scaled)) * nrm / L   # [FIX B1]
            r_cur = np.zeros_like(g); r_cur[idx] = q * (nrm / np.sqrt(k))
            r_fix = np.zeros_like(g); r_fix[idx] = q * 1.0
            rows["current"].append(np.linalg.norm(r_cur) / ng_target)
            rows["fixed"].append(np.linalg.norm(r_fix) / ng_target)
        for state in ("current", "fixed"):
            print("  %-8.2f %-3d %-6s | %s" % (kr, b, state,
                  " ".join(f"{v:11.4g}" for v in rows[state])))
        print("  " + "-" * 84)
    print("\n  reads: 'fixed' rows are scale-independent (0.5-0.9 = the honest top-k")
    print("  energy loss).  'current' rows grow WITH ||g|| -> the compressed update")
    print("  is multiplied by ||g_S||/sqrt(k) instead of 1.")


def apply_patch():
    bar("3. applying [fix_v11]")
    if not os.path.exists(NSAC):
        print("  !! core/nsac.py not found")
        return 1
    src = open(NSAC, encoding="utf-8").read()
    if MARK in src:
        print(f"  [skip] {MARK} already applied")
        return 0
    if OLD not in src:
        print("  !! anchor not found verbatim.  Expected exactly:")
        print(f"       {OLD!r}")
        print("     The line may differ on your server -- send me the real one.")
        return 1
    bak = NSAC + ".bak_v11"
    if not os.path.exists(bak):
        shutil.copy2(NSAC, bak)
        print(f"  backup -> {os.path.relpath(bak, HERE)}")
    else:
        print(f"  backup already exists -> {os.path.relpath(bak, HERE)}")
    with open(NSAC, "w", encoding="utf-8") as f:
        f.write(src.replace(OLD, NEW, 1))
    try:
        py_compile.compile(NSAC, doraise=True)
        print("  [ok] py_compile core/nsac.py")
    except Exception as e:
        print(f"  !! py_compile FAILED: {e}\n  restoring")
        shutil.copy2(bak, NSAC)
        return 1
    chk = open(NSAC, encoding="utf-8").read()
    print("  residual audit:")
    print("    marker present :", MARK in chk)
    print("    stale scale gone:", "norm / np.sqrt(k)" not in chk)
    bar("4. NEXT -- re-measure, then GATE, then decide")
    print("  a) re-measure (1 min, no side effects):")
    print("       python probe_nsac.py --real")
    print("     expect: applied scale = 1.0  /  gain ~0.5-0.9 per slice, flat in ||g||")
    print("\n  b) GATE: one proposed run, compare AUC against the current 0.928")
    print("       python run_experiment.py --dataset iotid20 --alpha 0.5 --seed 1 \\")
    print("            --method proposed --tag v11gate --output_dir results_v11gate --T 50")
    print("       # ~18 min.  Then inspect:")
    print("       python -c \"import json,glob;\\")
    print("         f=glob.glob('results_v11gate/**/results.json',recursive=True)[0];\\")
    print("         d=json.load(open(f));print(d['final_metrics']['auc_roc'],"
          "d.get('communication_stats'))\"")
    print("\n  c) if the gate AUC >= 0.928 -> full re-run (I will ship the batch")
    print("     script).  If it collapses -> python fix_v11.py --revert and stop.")
    return 0


def revert():
    bar("revert")
    bak = NSAC + ".bak_v11"
    if not os.path.exists(bak):
        print("  !! no .bak_v11 found")
        return 1
    shutil.copy2(bak, NSAC)
    print(f"  restored core/nsac.py from {os.path.relpath(bak, HERE)}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  NSAC decompression-scale repair   (the other half of [FIX B1])")
    print("=" * 78)
    if a.revert:
        return revert()
    if a.apply:
        return apply_patch()
    show_current()
    gain_table()
    print("\n  (dry run -- nothing written.  --apply to patch, --revert to undo)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
