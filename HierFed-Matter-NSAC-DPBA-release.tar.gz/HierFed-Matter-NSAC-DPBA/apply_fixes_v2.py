#!/usr/bin/env python3
"""
apply_fixes_v2.py -- second patch (on top of apply_fixes_v1).

Prerequisite: apply_fixes.py (v1) has already been applied.

What v2 adds
  V1  core/simulator.py : new config knob `dp_noise_scale` (multiplies the
                          injected DP noise) so the noise magnitude can be
                          calibrated empirically instead of guessed.
  V2  core/simulator.py : per-round print now also shows ||w|| and the scale,
                          so an exploding model is visible BEFORE it NaNs.
  V3  core/simulator.py : the divergence guard no longer `continue`s (which
                          also skipped evaluation).  It now keeps the last
                          finite model and still evaluates -> the failure
                          trajectory stays visible.  Adds an explosion guard
                          (||params|| > 1e3).
  V4  configs/base.yaml : `dp_noise_scale: 1.0` (= current behaviour).

Usage:  python apply_fixes_v2.py [root]   (idempotent, writes *.bak_v2)
"""
import os
import sys
import shutil
import argparse

P = []

# ---- V1 + V2: noise scale knob + richer DP-DEBUG ----
P.append(("core/simulator.py",
"""                device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])
                clipped = clip_gradient(gradient, self.clip_norm)
                noise = torch.randn_like(clipped) * device_sigma
                device_gradients[dev_id] = clipped + noise""",
"""                device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])
                clipped = clip_gradient(gradient, self.clip_norm)
                # [v2] `dp_noise_scale` calibrates the noise magnitude.  The
                # update returned by local_train ALREADY contains the learning
                # rate, so the DP noise has to be brought to the same order of
                # magnitude (standard DP-FL adds it *before* the lr is applied).
                # Use run_noise_sweep.sh to pick it empirically.
                noise = (torch.randn_like(clipped)
                         * device_sigma * self.dp_noise_scale)
                device_gradients[dev_id] = clipped + noise"""))

P.append(("core/simulator.py",
"""            if (not self.disable_dp) and self.dp_debug and _dbg_dw:
                import statistics as _st
                _dw = _st.mean(_dbg_dw)
                _nz = _st.mean(_dbg_noise)
                print(f"[DP-DEBUG] round {t}: ||dw||={_dw:.4f}  "
                      f"sigma_i~{_st.mean(_dbg_sig):.4f}  ||noise||={_nz:.2f}  "
                      f"SNR=||dw||/||noise||={_dw / (_nz + 1e-12):.3e}")""",
"""            if (not self.disable_dp) and self.dp_debug and _dbg_dw:
                import statistics as _st
                _dw = _st.mean(_dbg_dw)
                _nz = _st.mean(_dbg_noise)
                _wn = float(torch.cat([p.data.flatten()
                                       for p in self.model.parameters()]).norm())
                print(f"[DP-DEBUG] round {t}: ||dw||={_dw:.4f}  ||w||={_wn:.3f}  "
                      f"sigma_i~{_st.mean(_dbg_sig):.4f}  ||noise||={_nz:.2f}  "
                      f"SNR={_dw / (_nz + 1e-12):.3e}  "
                      f"noise_scale={self.dp_noise_scale}")"""))

# ---- V3: guard must not swallow the evaluation ----
P.append(("core/simulator.py",
"""            if not torch.isfinite(new_params).all():
                _nbad = int((~torch.isfinite(new_params)).sum().item())
                print(f"[WARN] round {t}: {_nbad}/{new_params.numel()} non-finite "
                      f"params -> skipping update (DP noise too large?)")
                continue""",
"""            if not torch.isfinite(new_params).all():
                _nbad = int((~torch.isfinite(new_params)).sum().item())
                print(f"[WARN] round {t}: {_nbad}/{new_params.numel()} non-finite "
                      f"params -> keeping last finite model")
                new_params = global_params          # keep the last finite model
            elif float(new_params.norm()) > 1e3:
                print(f"[WARN] round {t}: ||params||={float(new_params.norm()):.1f} "
                      f"-> explosion, keeping last finite model")
                new_params = global_params"""))

# ---- V1b: config knob in __init__ ----
P.append(("core/simulator.py",
"""        # [FIX B2] print ||dw|| vs ||noise|| each round so the SNR is visible.
        self.dp_debug = bool(config.get('dp_debug', False))""",
"""        # [FIX B2] print ||dw|| vs ||noise|| each round so the SNR is visible.
        self.dp_debug = bool(config.get('dp_debug', False))
        # [v2] empirical multiplier on the injected DP noise (1.0 = no change).
        self.dp_noise_scale = float(config.get('dp_noise_scale', 1.0))"""))

# ---- V4: yaml ----
P.append(("configs/base.yaml",
"""dp_subsampling_rate: 0.2""",
"""dp_noise_scale: 1.0       # [v2] 已注入噪声的额外缩放（1.0=不改）。见 run_noise_sweep.sh
dp_subsampling_rate: 0.2"""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root)

    per_file = {}
    for rel, old, new in P:
        per_file.setdefault(rel, []).append((old, new))

    n_ok = n_skip = n_fail = 0
    for rel in sorted(per_file):
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            print(f"  [MISSING] {rel}")
            n_fail += 1
            continue
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        todo = []
        for old, new in per_file[rel]:
            if new in src:            # idempotent (checked FIRST)
                continue
            if old not in src:
                print(f"  [FAIL] {rel}: pattern not found (is v1 applied?) -> "
                      f"{old.splitlines()[0].strip()[:60]!r}")
                n_fail += 1
                todo = None
                break
            todo.append((old, new))
        if todo is None:
            continue
        if not todo:
            print(f"  [SKIP] {rel}: already patched (v2)")
            n_skip += 1
            continue
        out = src
        for old, new in todo:
            out = out.replace(old, new)
        if args.dry_run:
            print(f"  [DRY ] {rel}: {len(todo)} hunk(s)")
            continue
        bak = path + ".bak_v2"
        if not os.path.exists(bak):
            shutil.copy2(path, bak)
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"  [ OK ] {rel}: {len(todo)} hunk(s) applied")
        n_ok += 1

    print(f"\napply_fixes_v2: files_patched={n_ok}  already_ok={n_skip}  failed={n_fail}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
