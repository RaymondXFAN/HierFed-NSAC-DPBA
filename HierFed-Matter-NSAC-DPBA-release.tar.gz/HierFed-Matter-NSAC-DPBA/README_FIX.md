# HierFed 补实验 —— Bug 修复包（B1–B4）

> 生成于 2026-10-03。对应诊断：`results_summary/TABLES.md` 中
> 8 行 `0.000±0.000`、`proposed n=60`、`hierfed_nsac=0.46` 等异常。

## 一、四个 Bug（全部有代码 + 数值双向证据）

| # | 文件 | 问题 | 证据 | 影响 |
|---|---|---|---|---|
| **B1** | `core/nsac.py` | QSGD 量化把 `levels` 除了**两次** | 往返增益 `‖rec‖/‖g‖ = 0.0097`（应≈1）= **104× 衰减** | 只开 NSAC（无 DP）时 AUC 从 **0.981 → 0.462** |
| **B2** | `core/simulator.py` | `compute_noise_scale_rdp()` 漏传 `subsampling_rate`，默认 q=1.0（应 M/N=0.2）；且模型更新已含 η 而噪声未随 η 缩放 | σ 实测：ε=0.5→**68.6**、1→34.7、2→17.7、3→**12.0**、10→4.0；崩溃率与 σ 完全对应 | σ≥17.7（ε≤2）→ 权重出 NaN；ε=3 也接近随机 |
| **B3** | 6 个文件 | `except ValueError: auc = 0.0` | 实测 `roc_auc_score` 对**常数**返回 0.5，**只有 NaN/inf** 才抛 ValueError | 8 行假 AUC；`f1=0 / acc=0.936 / macro-F1=0.4835` 全是「全 NaN 输出」的假象 |
| **B4** | `aggregate_supp.py` | 基线表只按 `method` 分组、忽略 `tag` | 12 个消融配置 × 5 seed = **60** | `proposed` 被混池成 `n=60`，AUC `0.472±0.255` 是假的（真值 = `full` = 0.537±0.070） |

「全 NaN」连锁推演（已逐一验证）：
`softmax(NaN)` → `argmax=0` → 全预测类 0（=attack，占 93.6%）
→ `accuracy = 0.936`、`f1 = 0`、`macro-F1 = 0.483`、阈值卡 `0.5`、`auc → ValueError → 哨兵 0.0`。
**八个数字全部对上。**

## 二、文件清单

| 文件 | 作用 |
|---|---|
| `apply_fixes.py` | 一次性打补丁（带断言、幂等、自动 `.bak` 备份） |
| `selftest_fix.py` | 纯 numpy / 不依赖 torch 的自检（B1 往返增益、B2 σ、B3 哨兵、B4 混池） |
| `run_precheck.sh` | 预检闸门：3 配置 × 1 seed × T=50，约 20–25 分钟 |
| `README_FIX.md` | 本文件 |

## 三、使用步骤（在项目根目录执行）

```bash
cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA

# 1) 打补丁（自动备份 *.bak）
python apply_fixes.py

# 2) 自检 —— 必须看到 "ALL CHECKS PASSED"
python selftest_fix.py

# 3) 预检（3 路并行，约 20-25 分钟）
bash run_precheck.sh --wait
```

**预检通过标准**：`nsac_only ≥ 0.85` 且 `full ≥ 0.85`（`nodp_nonsac` 应 ≈ 0.98）。
对照（打补丁前）：`nodp_nonsac ≈ 0.98`、`nsac_only ≈ 0.46`、`full ≈ 0.54`。

## 四、预检通过后再跑全量（务必先挪走旧结果）

```bash
mv results_ablation results_ablation_OLD_buggy
mv results_baseline results_baseline_OLD_buggy
mv results_eps      results_eps_OLD_buggy
mv results_scale    results_scale_OLD_buggy

export OMP_NUM_THREADS=8
nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 \
      > logs/parallel_fixed.log 2>&1 &
```

> ⚠️ `run_parallel.py` 是**幂等**的（按 `results.json` 是否存在跳过）。
> 不挪走旧目录 = 全部被判为「已完成」= 一秒跑完却毫无变化。

## 五、仍需你决策的两点

1. **`dp_subsampling_rate`**：补丁默认 `0.2`（= M/N，修正漏传）。若论文的隐私模型
   定义为「每轮全量查询」，可改回 `1.0`（σ 回到 12.0）。**这会改变 ε=3 的效用结论。**
2. **n=5 的显著性**：Wilcoxon 双尾、n=5 时 p 值下限恒为 `0.0625`，永远到不了
   `p<0.05`。若要显著性结论，需 **n≥10**（成本翻倍）。

## 六、回滚

```bash
for f in $(find . -name "*.bak"); do mv "$f" "${f%.bak}"; done
```
