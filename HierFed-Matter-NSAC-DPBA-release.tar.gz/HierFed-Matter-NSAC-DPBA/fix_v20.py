#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v20.py -- 把 C-2 / C-3 接进 core/simulator.py（方向A 的 4 臂开关）

前开后兼容：不加 config 键时，行为与现在**逐位一致**
    slice_map   = random      (默认)  -> 原 assign_device_types(N, seed)
    epsilon_mode= adaptive    (默认)  -> 原 sigma_mult[dev_id]
所以已有的 140 个 ablation + 75 个 P2 结果**不受影响**。

三个锚点（取自服务器 simulator.py 的原文，2026-10-14 核对）
  P1 :207   self.device_types = assign_device_types(N, config.get('seed', 1))
  P2 :274   self._dev_clip = {}                       <- 在其后插入 C-2 的初始化块
  P3 :544   device_sigma = (sigma_base * float(sigma_mult[dev_id]) ...)

新增 config 键
  slice_map            : random | datadriven        (C-3)
  slice_map_criterion  : size | attack_ratio | entropy   (C-3)
  epsilon_mode         : adaptive | uniform | slice      (C-2)
  slice_weight_rule    : equal | bw | k_ratio | inv_k_ratio (C-2)

用法
    python fix_v20.py --diagnose   # 只定位并打印三个锚点，不改文件
    python fix_v20.py --check
    python fix_v20.py --apply
    python fix_v20.py --revert

--- EN ---
fix_v20.py -- wire C-2 / C-3 into core/simulator.py (the 4-arm switch of Direction A)

Backward compatible: without adding config keys, the behavior is **bit-for-bit identical** to the current one
    slice_map   = random      (default)  -> the original assign_device_types(N, seed)
    epsilon_mode= adaptive    (default)  -> the original sigma_mult[dev_id]
so the existing 140 ablations + 75 P2 results are **unaffected**.

Three anchors (taken from the original text of simulator.py on the server, verified on 2026-10-14)
  P1 :207   self.device_types = assign_device_types(N, config.get('seed', 1))
  P2 :274   self._dev_clip = {}                       <- insert the C-2 initialization block after it
  P3 :544   device_sigma = (sigma_base * float(sigma_mult[dev_id]) ...)

New config keys
  slice_map            : random | datadriven        (C-3)
  slice_map_criterion  : size | attack_ratio | entropy   (C-3)
  epsilon_mode         : adaptive | uniform | slice      (C-2)
  slice_weight_rule    : equal | bw | k_ratio | inv_k_ratio (C-2)

Usage
    python fix_v20.py --diagnose   # only locate and print the three anchors, without changing the file
    python fix_v20.py --check
    python fix_v20.py --apply
    python fix_v20.py --revert
"""
import argparse
import py_compile
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
BAK = ".bak_v20"
TARGET = "core/simulator.py"

A_DEV = "        self.device_types = assign_device_types(N, config.get('seed', 1))"
N_DEV = """        _smap = (os.environ.get('SLICE_MAP') or config.get('slice_map', 'random')).lower()
        if _smap in ('datadriven', 'data'):
            from core.slice_alloc import assign_device_types_datadriven as _add   # [fix_v20]
            self.device_types, _sm_info = _add(
                N, self.partitions, self.y_train,
                criterion=(os.environ.get('SLICE_MAP_CRITERION')
                           or config.get('slice_map_criterion', 'size')))
            print(f"[fix_v20] slice_map=datadriven criterion={_sm_info['criterion']} "
                  f"slices={_sm_info['slice_counts']}")
        else:
            self.device_types = assign_device_types(N, config.get('seed', 1))"""

A_CLIP = "        self._dev_clip = {}"
N_CLIP = """        self._dev_clip = {}

        # [fix_v20] C-2  epsilon allocation mode: adaptive | uniform | slice
        #   adaptive = 现行为（逐设备敏感度调制）；uniform/slice = 方向A 的两个对照臂。
        #   两种新模式都归一化到"sigma_mult 均值 = 1"，即总噪声量级不变（预算中立），
        #   只有【切片/设备之间】的分配不同 —— 否则对比不成立。
        self.epsilon_mode = str(os.environ.get('EPSILON_MODE')
                                or config.get('epsilon_mode', 'adaptive')).lower()
        if self.epsilon_mode not in ('adaptive', 'uniform', 'slice'):
            raise ValueError("epsilon_mode must be adaptive|uniform|slice, got %r"
                             % self.epsilon_mode)
        self._slice_sigma_mult = None
        if self.epsilon_mode in ('slice', 'uniform'):
            try:
                from core.slice_alloc import allocate_privacy_budget_mode as _apbm
                _K = max(int(K), 1)
                _sod = [self.slice_assignments[min(dev_id // _K, M - 1)]
                        for dev_id in range(N)]
                # T 传 1 即可：权重随后按均值归一化，eps_r 因子会约掉（不依赖 self.T）
                _bud = _apbm(self.epsilon_total, 1, np.ones(1),
                             np.asarray(self.device_sensitivity, dtype=float),
                             N, 1, epsilon_mode=self.epsilon_mode,
                             slice_of_device=_sod,
                             slice_weight_rule=(os.environ.get('SLICE_WEIGHT_RULE')
                                                or config.get('slice_weight_rule', 'equal')))
                _w = np.asarray(_bud, dtype=float)[:, 0]
                _w = _w / max(float(_w.mean()), 1e-12)          # 归一化到均值 1
                self._slice_sigma_mult = _w.tolist()
                _span = float(_w.max() - _w.min())
                print(f"[fix_v20] epsilon_mode={self.epsilon_mode} "
                      f"rule={os.environ.get('SLICE_WEIGHT_RULE') or config.get('slice_weight_rule', 'equal')} "
                      f"sigma_mult=[{_w.min():.3f},{_w.max():.3f}] span={_span:.3f} "
                      f"slices={sorted(set(_sod))}")
                if self.epsilon_mode == 'slice' and _span < 1e-9:
                    _ns = len(set(_sod))
                    if _ns < 2:
                        raise ValueError(
                            "[fix_v20] 切片映射只产生 1 个切片 (slices=%s) —— eps=slice 臂会与 "
                            "uniform 臂逐位相同，对比无效。请设 SLICE_MAP=ranked"
                            "（ranked 在 M>=3 时保证三切片都出现），或检查设备->切片映射。"
                            % sorted(set(_sod)))
                    raise ValueError(
                        "[fix_v20] slice 分配退化为 uniform（切片权重全等）。请改 "
                        "SLICE_WEIGHT_RULE=k_ratio 或 inv_k_ratio（bw 在切片规模相等时也可能全等），"
                        " 或检查各切片规模是否恰好相等。")
            except Exception as _e:
                if '[fix_v20]' in str(_e):
                    raise                      # 退化必须硬失败，绝不静默降级成 adaptive
                print(f"[fix_v20] !! epsilon_mode={self.epsilon_mode} init failed ({_e});"
                      f" falling back to adaptive")
                self.epsilon_mode = 'adaptive'"""

A_SIG = ("                device_sigma = (sigma_base * float(sigma_mult[dev_id])\n"
         "                                * (_C_i / max(self.clip_norm, 1e-12)))")
N_SIG = """                if self.epsilon_mode == 'slice':
                    _sm = float(self._slice_sigma_mult[dev_id])
                elif self.epsilon_mode == 'uniform':
                    _sm = 1.0
                else:
                    _sm = float(sigma_mult[dev_id])          # adaptive (默认 = 原行为)
                device_sigma = (sigma_base * _sm
                                * (_C_i / max(self.clip_norm, 1e-12)))"""

A_GW = ("        self.slice_assignments = assign_slice_to_gateways(\n"
        "            M, self.device_types, self.cluster_map\n"
        "        )")
N_GW = """        _gwm = (os.environ.get('SLICE_MAP') or config.get('slice_map', 'random')).lower()
        if _gwm in ('ranked', 'datadriven', 'data'):
            from core.slice_alloc import assign_slice_to_gateways_ranked as _asg   # [fix_v20]
            _dm = [len(self.partitions.get(str(_i), [])) for _i in range(N)]
            self.slice_assignments = _asg(M, self.device_types, self.cluster_map,
                                          device_metric=_dm)
        else:
            self.slice_assignments = assign_slice_to_gateways(
                M, self.device_types, self.cluster_map
            )
        print(f"[fix_v20] slice_assignments={self.slice_assignments} "
              f"coverage={len(set(self.slice_assignments.values()))}")"""

PATCHES = [(A_DEV, N_DEV, "P1 C-3 device->slice 映射"),
           (A_GW, N_GW, "P4 C-3b 网关->切片(保证覆盖)"),
           (A_CLIP, N_CLIP, "P2 C-2 预算模式初始化"),
           (A_SIG, N_SIG, "P3 C-2 噪声分配生效点")]


def log(m):
    print("  " + m)


def _find_lines(text, anchor):
    """返回 anchor 首行出现的所有行号(1-based)。

--- EN ---
Return all line numbers (1-based) where the first line of anchor occurs."""
    first = anchor.split("\n")[0]
    return [i + 1 for i, ln in enumerate(text.splitlines()) if ln == first]


def diagnose():
    p = ROOT / TARGET
    if not p.exists():
        log(f"[!!] 找不到 {TARGET} (cwd={ROOT})")
        return 1
    t = p.read_text(encoding="utf-8")
    log(f"{TARGET}: {len(t.splitlines())} 行")
    for a, _n, lab in PATCHES:
        hits = _find_lines(t, a)
        state = "已打补丁" if "# [fix_v20]" in t and a not in t else ("命中" if hits else "**未命中**")
        log(f"{lab:24s} {state:8s} 行号={hits}")
    if "slice_alloc" in t:
        log("[ok] 已 import slice_alloc")
    log(f"提示: 若 P3 未命中，请把 {TARGET} 里 'device_sigma = (sigma_base' 那 3 行贴回来")
    return 0


def apply():
    p = ROOT / TARGET
    if not p.exists():
        log(f"[!!] 找不到 {TARGET}")
        return 1
    t = p.read_text(encoding="utf-8")
    if "# [fix_v20]" in t:
        log("[ok] fix_v20 已应用（幂等跳过）")
        return _verify()
    if "\nimport numpy as np" not in t:
        log("[!!] simulator.py 没有 `import numpy as np`（补丁需要）")
        return 1
    miss = [lab for a, _n, lab in PATCHES if a not in t]
    if miss:
        log("[!!] 下列锚点未命中，**未做任何改动**：")
        for m in miss:
            log(f"     - {m}")
        log("     请跑 python fix_v20.py --diagnose 并把输出贴回")
        return 1
    shutil.copy2(p, p.with_name(p.name + BAK))
    log(f"backup  {p.name} -> {p.name}{BAK}")
    for a, n, lab in PATCHES:
        t = t.replace(a, n, 1)
        log(f"[done] {lab}")
    p.write_text(t, encoding="utf-8")
    return _verify()


def _verify():
    p = ROOT / TARGET
    try:
        py_compile.compile(str(p), doraise=True)
        log("[ok] 编译通过")
    except Exception as e:
        log(f"[!!] 编译失败: {e}")
        return 1
    t = p.read_text(encoding="utf-8")
    ok = True
    for probe in ("# [fix_v20]", "self.epsilon_mode", "_slice_sigma_mult",
                  "slice_map", "from core.slice_alloc import"):
        if probe in t:
            log(f"[ok] 含 {probe}")
        else:
            log(f"[!!] 缺 {probe}")
            ok = False
    if (ROOT / "core" / "slice_alloc.py").exists():
        log("[ok] core/slice_alloc.py 已就位")
    else:
        log("[!!] 缺 core/slice_alloc.py —— 请先把 slice_alloc.py 放进 core/")
        ok = False
    log(f"[verify] {'ALL PASS' if ok else 'FAILED'}")
    return 0 if ok else 1


def check():
    p = ROOT / TARGET
    if not p.exists():
        log(f"[!!] 找不到 {TARGET}")
        return 1
    t = p.read_text(encoding="utf-8")
    for a, _n, lab in PATCHES:
        log(f"{lab:24s} 锚点{'命中' if a in t else '**未命中**'}")
    return 0


def revert():
    p = ROOT / TARGET
    b = p.with_name(p.name + BAK)
    if b.exists():
        shutil.copy2(b, p)
        log(f"[revert] {TARGET} 已还原")
    else:
        log(f"[--] 无 {p.name}{BAK}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    for flag in ("--diagnose", "--check", "--apply", "--revert"):
        g.add_argument(flag, action="store_true")
    a = ap.parse_args()
    return (diagnose() if a.diagnose else check() if a.check
            else apply() if a.apply else revert())


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
