#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
probe_nsac.py -- READ-ONLY forensic probe of the NSAC compress/decompress pair.

    python probe_nsac.py           # math sweep + live source + config (instant, CPU)
    python probe_nsac.py --real    # additionally uses the real model/data (GPU, ~1 min)

It answers one question that decides whether the compression axis of the paper
is defensible:

    does  nsac_decompress(nsac_compress(g))  preserve the DIRECTION and the
    MAGNITUDE of g ?

Direction (cosine similarity) is what learning needs; magnitude decides whether
the update is actually applied.  Reading nsac_compress(), the quantiser emits
    q_i  = sign(g_i) * floor(|g_i|*L/||g||) / L  * ||g|| / L        (L = 2^(b-1)-1)
and nsac_decompress() rescales by  ||g|| / sqrt(k).  Composing the two gives

    recon_i  ~=  g_i * ||g_sparse|| / (L * sqrt(k))

so the round-trip gain is  g = ||g_sparse|| / (L*sqrt(k)) -- it depends on the
gradient scale AND grows with b_bits, i.e. the 16-bit eMBB slice attenuates
~258x harder than the 8-bit uRLLC/mMTC slices.  This script measures it instead
of arguing about it.  Nothing is written; no file is modified.
"""
import argparse
import inspect
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def show_source():
    bar("1. live source of the two functions + where they are called from")
    try:
        from core import nsac
        for fn in ("nsac_compress", "nsac_decompress"):
            src = inspect.getsource(getattr(nsac, fn))
            print(f"\n  ------ {fn}  ({os.path.relpath(nsac.__file__, HERE)}) ------")
            print("\n".join("    " + l for l in src.splitlines()))
    except Exception as e:
        print(f"  !! cannot import core.nsac: {type(e).__name__}: {e}")


def show_config():
    bar("2. is the compression actually switched on?")
    p = os.path.join(HERE, "configs", "base.yaml")
    if os.path.exists(p):
        for i, l in enumerate(open(p, encoding="utf-8").read().splitlines(), 1):
            if re.search(r"nsac|compress|slice|k_ratio|b_bits|enable|mode", l, re.I):
                print(f"    base.yaml:{i}: {l}")
    else:
        print("    !! configs/base.yaml not found")
    import glob
    import json
    hits = sorted(glob.glob(os.path.join(HERE, "results_baseline", "hierfed*",
                                         "results.json")))[:2]
    hits += sorted(glob.glob(os.path.join(HERE, "results_ablation", "*",
                                          "results.json")))[:2]
    for h in hits[:3]:
        try:
            d = json.load(open(h, encoding="utf-8"))
        except Exception:
            continue
        print(f"\n    --- {os.path.relpath(h, HERE)} ---")
        print(f"      top-level keys : {sorted(d)}")
        cf = d.get("config")
        if cf:
            print(f"      config         : {json.dumps(cf, ensure_ascii=False)[:300]}")
        rm = d.get("round_metrics") or []
        if rm:
            k0 = rm[0]
            print(f"      round_metrics[0] keys : {sorted(k0)}")
            keys = [k for k in k0 if re.search(r"compress|bytes|latenc|ratio|"
                                               r"slice|nsac|cr_", k, re.I)]
            print(f"      compression fields    : "
                  f"{ {k: k0[k] for k in keys} }")
        for key in ("round_stats", "compression", "compression_ratios"):
            if key in d:
                print(f"      {key} : {json.dumps(d[key], ensure_ascii=False)[:300]}")


class _NpShim:
    """numpy stand-in so the sweep can be validated off-server (no torch)."""
    class _Cfg:
        def __init__(self, k_ratio, b_bits):
            self.k_ratio, self.b_bits = k_ratio, b_bits

    def __init__(self):
        import numpy as np
        self.np = np
        self.SLICE_CONFIGS = {"urllc": self._Cfg(0.1, 8), "embb": self._Cfg(0.3, 16),
                              "mmtc": self._Cfg(0.05, 8)}

    def randn(self, d, sigma):
        return self.np.random.default_rng(0).normal(0, sigma, d)

    def compress(self, g, cfg, adaptive_down=False):
        np = self.np
        k = max(1, int(cfg.k_ratio * g.size))
        L = 2 ** (cfg.b_bits - 1) - 1
        idx = np.argsort(-np.abs(g))[:k]
        sg = g[idx]
        norm = float(np.linalg.norm(sg)) or 1.0
        scaled = sg * L / norm
        quant = np.sign(scaled) * np.floor(np.abs(scaled)) / L
        return {"idx": idx, "q": quant * norm / L, "norm": norm, "k": k, "L": L}

    def decompress(self, c, d):
        np = self.np
        r = np.zeros(d)
        r[c["idx"]] = c["q"] * (c["norm"] / np.sqrt(c["k"]))
        return r

    def norm(self, v):
        return float(self.np.linalg.norm(v))

    def dot(self, a, b):
        return float(self.np.dot(a, b))


def who_compresses():
    """Static check: which code paths actually CALL the compressor?"""
    bar("2b. who actually calls nsac_compress / nsac_decompress ?")
    import ast
    for rel in ("baselines/runner.py", "core/hierfed.py", "core/simulator.py",
                "run_experiment.py", "run_baselines.py"):
        p = os.path.join(HERE, rel)
        if not os.path.exists(p):
            print(f"\n  --- {rel}: not found")
            continue
        try:
            tree = ast.parse(open(p, encoding="utf-8").read())
        except Exception as e:
            print(f"\n  --- {rel}: parse error {e}")
            continue
        print(f"\n  --- {rel} ---")
        hits = 0
        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            called = {n.func.id for n in ast.walk(node)
                      if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}
            touched = called & {"nsac_compress", "nsac_decompress", "local_train",
                                "hierfed_round", "inject_dp_noise",
                                "inject_dp_noise_rdp", "edge_aggregate",
                                "core_aggregate", "star_aggregate"}
            if "nsac_compress" in called or "nsac_decompress" in called:
                hits += 1
                doc = (ast.get_docstring(node) or "").splitlines()
                doc = doc[0] if doc else ""
                print(f"    [{node.lineno:>4}] {node.name:<28} "
                      f"calls nsac_*  | doc: {doc[:70]}")
        if not hits:
            print("    (no function in this file calls nsac_compress/decompress)")
    # does the hierarchical proposed path opt out?
    p = os.path.join(HERE, "core", "hierfed.py")
    if os.path.exists(p):
        src = open(p, encoding="utf-8").read()
        m = re.search(r"def (hierfed\w*round|hierfed_round)\(([^)]*)\)", src, re.S)
        if m:
            sig = " ".join(m.group(2).split())
            print(f"\n    {m.group(1)} signature: ({sig[:220]})")
            en = re.search(r"enable_nsac[^,)\n]*", sig)
            print(f"    -> enable_nsac default : {en.group(0) if en else 'ABSENT'}")
    print("\n    IF a baseline's docstring says 'no NSAC compression' while the")
    print("    table compares it as a compression method, that row means nothing.")


def math_sweep():
    bar("3. round-trip gain / direction vs gradient scale, per slice")
    shim = None
    try:
        import torch
        from core.nsac import SLICE_CONFIGS, nsac_compress, nsac_decompress
    except Exception:
        torch = None
        shim = _NpShim()
        SLICE_CONFIGS = shim.SLICE_CONFIGS
        print("  [note] torch not importable here -> using an exact numpy "
              "re-implementation of the same maths")
    d = 7826
    print(f"  d = {d}")
    print(f"  {'slice':7} {'b':>3} {'k_r':>6} | " +
          " ".join(f"{'||g||='+f'{s:g}':>16}" for s in
                   (1e-2, 1e0, 1e2, 1e4, 1e6)))
    print(f"  {'':7} {'':>3} {'':>6} |  (gain = ||recon||/||g|| ,  cos)")
    print("  " + "-" * 100)
    g0 = torch.Generator().manual_seed(0) if torch is not None else None
    for name, cfg in SLICE_CONFIGS.items():
        row = f"  {name:7} {cfg.b_bits:>3} {cfg.k_ratio:>6.3g} |"
        for sigma in (1e-2, 1e0, 1e2, 1e4, 1e6):
            if torch is not None:
                g = torch.randn(d, generator=g0) * sigma
                c = nsac_compress(g, cfg, adaptive_down=False)  # isolate quantiser
                r = nsac_decompress(c, d)
                ng, nr = float(g.norm()), float(r.norm())
                dot = float(r @ g)
            else:                                               # numpy path
                g = shim.randn(d, sigma)
                c = shim.compress(g, cfg)
                r = shim.decompress(c, d)
                ng, nr = shim.norm(g), shim.norm(r)
                dot = shim.dot(r, g)
            gain = nr / ng if ng else float("nan")
            cos = dot / (nr * ng) if ng * nr else float("nan")
            row += f"  {gain:7.2e}/{cos:5.3f}"
        print(row)
    print("\n  READ THIS: if the gain is not ~1.0 anywhere in the band your real")
    print("  gradients live in, the compressed update is not what the paper says.")


def real_grads():
    bar("4. same measurement on REAL gradients (needs data + GPU)")
    import numpy as _np
    global np
    np = _np
    try:
        import yaml
        import torch
        from core.nsac import SLICE_CONFIGS, nsac_compress, nsac_decompress
        sys.path.insert(0, os.path.join(HERE, "baselines"))
        import baselines.runner as R
    except Exception as e:
        print(f"  skipped ({type(e).__name__}: {e})")
        return
    try:
        cfg = yaml.safe_load(open(os.path.join(HERE, "configs", "base.yaml"),
                                  encoding="utf-8"))
    except Exception as e:
        print(f"  cannot read configs/base.yaml ({e})")
        return
    cfg["processed_dir"] = os.path.join(HERE, "data", "processed")
    cfg["dataset_name"] = "iotid20"
    cfg["alpha"] = 0.5
    cfg["N"], cfg["M"], cfg["K"] = 20, 4, 5
    try:
        Xtr, ytr, parts = R._load_partitioned_data(cfg)
        Xte, yte = R._load_test_data(cfg)
        model = R.build_model(Xtr.shape[1]).to(R.DEVICE)
        print(f"  data ok: X_train={Xtr.shape}, devices={len(parts)}")
    except Exception as e:
        print(f"  cannot load data ({type(e).__name__}: {e}) -- run without --real")
        return
    for name, sl in SLICE_CONFIGS.items():
        g = R._local_train(model, Xtr[parts["0"]], ytr[parts["0"]], 5, 32, 0.01)
        c = nsac_compress(g, sl, adaptive_down=False)
        r = nsac_decompress(c, d=g.numel(), device=g.device)
        ng, nr = float(g.norm()), float(r.norm())
        k = len(c["indices"])
        qn = float(np.linalg.norm(np.asarray(c["q_values"])))
        applied = nr / qn if qn else float("nan")    # the scale the decompressor used
        ideal_gain = qn / ng if ng else float("nan")  # correct answer = ||g_S||/||g||
        print(f"  {name:7} ||g||={ng:11.4g} ||g_S||={qn:11.4g} ||recon||={nr:11.4g} "
              f"gain={nr/ng:9.3e} cos={float((r@g)/(nr*ng)):6.3f} "
              f"k_ratio={c['k_ratio_actual']:.3f} CR={c['CR_actual']:.4f} "
              f"bytes={c['compressed_bytes']}")
        print(f"          applied scale = {applied:.4g}   (IDEAL = 1.0)   "
              f"-> update multiplied by {applied:.4g} "
              f"({'OK' if 0.8 < applied < 1.25 else 'WRONG'})")
        print(f"          correct gain would be {ideal_gain:.4g}; "
              f"current gain {nr/ng:.4g} = {ideal_gain:.4g} x {applied:.4g}")
    print("\n  -> this is the 'compression fidelity' number the paper needs anyway.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--real", action="store_true", help="also use real data/GPU")
    a = ap.parse_args()
    print("=" * 78)
    print("  NSAC compress/decompress forensic probe  (read-only)")
    print(f"  project root : {HERE}")
    print("=" * 78)
    show_source()
    show_config()
    who_compresses()
    math_sweep()
    if a.real:
        real_grads()
    else:
        print("\n  (run again with --real to repeat on the actual gradients)")
    print("\n" + "=" * 78)
    print("  -> upload this whole output to Mihiro")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
