==============================================================================
  NSAC compress/decompress forensic probe  (read-only)
  project root : /root/autodl-tmp/HierFed-Matter-NSAC-DPBA
==============================================================================

==============================================================================
  1. live source of the two functions + where they are called from
==============================================================================
[GPU] Using NVIDIA GeForce RTX 4090 | VRAM=25.3GB

  ------ nsac_compress  (core/nsac.py) ------
    def nsac_compress(
        gradient: torch.Tensor,
        slice_config: SliceConfig,
        model_size_bytes: int = 31304,  # |w| ≈ 30.6 KB (d=7826 × 4 bytes, lightweight)
        adaptive_down: bool = True,
        min_k_ratio: float = 0.01,
        k_step: float = 0.01,
    ) -> Dict:
        """
        NSAC compression: Top-k sparsification + QSGD-style quantization.
    
        Args:
            gradient: Full gradient vector (1D tensor of length d).
            slice_config: Per-slice configuration.
            model_size_bytes: Full model size in bytes (for latency estimation).
            adaptive_down: If True, reduce k when latency exceeds L_max.
    
        Returns:
            Dict with: indices, q_values, b_bits, k_ratio_actual, CR_actual,
                       latency_ms, compressed_bytes.
        """
        d = gradient.numel()
        k = int(slice_config.k_ratio * d)
        if k < 1:
            k = 1
        b = slice_config.b_bits
        levels = 2 ** (b - 1) - 1  # quantization levels
    
        # --- Adaptive k adjustment for latency ---
        k_ratio_actual = slice_config.k_ratio
        while adaptive_down and k_ratio_actual > min_k_ratio:
            CR_actual = k_ratio_actual * b / 32.0
            # Model size in bytes: d × 4 (float32)
            payload_bytes = int(CR_actual * d * 4)  # compressed payload
            BW_bytes_per_ms = slice_config.BW_mbps * 1e6 / 8 / 1000  # bytes/ms
            latency_est = payload_bytes / BW_bytes_per_ms + slice_config.proc_ms
            if latency_est <= slice_config.L_max_ms:
                break
            k_ratio_actual -= k_step
            k = int(k_ratio_actual * d)
            if k < 1:
                k = 1
    
        # --- Top-k sparsification ---
        abs_grad = gradient.abs()
        topk_values, topk_indices = torch.topk(abs_grad, k)
        sparse_grad = gradient[topk_indices]
    
        # --- QSGD-style quantization ---
        # q_val = sign(val) × floor(|val| × levels / ‖val‖) / levels
        # Normalize by the norm of selected values for unbiasedness
        norm = sparse_grad.norm()
        if norm < 1e-10:
            norm = torch.tensor(1.0, device=gradient.device)
    
        # [FIX B1] Standard QSGD: q_i = sign(g_i)*floor(|g_i|*L/||g||)*||g||/L
        # The previous version divided by `levels` TWICE (once inside `quantized`,
        # then again in `q_values`), so compress->decompress returned only ~0.0097
        # of the original norm (104x attenuation). Every NSAC-enabled run was
        # silently frozen near AUC 0.5. Verified by selftest_fix.py.
        scaled = sparse_grad * levels / norm
        q_values = torch.sign(scaled) * torch.floor(scaled.abs()) * norm / levels
    
        # --- Pack result ---
        CR_actual = k_ratio_actual * b / 32.0
        # Actual compressed bytes: indices (4 bytes each) + values (b/8 bytes each)
        compressed_bytes = k * 4 + k * (b // 8)
        # More accurate latency estimation
        BW_bytes_per_ms = slice_config.BW_mbps * 1e6 / 8 / 1000
        latency_ms = compressed_bytes / BW_bytes_per_ms + slice_config.proc_ms
    
        return {
            'indices': topk_indices.cpu().numpy(),
            'q_values': q_values.cpu().numpy(),
            'b_bits': b,
            'k_ratio_actual': k_ratio_actual,
            'CR_actual': CR_actual,
            'compression_factor': 1.0 / CR_actual if CR_actual > 0 else float('inf'),
            'latency_ms': latency_ms,
            'compressed_bytes': compressed_bytes,
            'norm': norm.item(),  # for decompression
        }

  ------ nsac_decompress  (core/nsac.py) ------
    def nsac_decompress(
        compressed: Dict,
        d: int,
        device=None,
    ) -> torch.Tensor:
        """
        Decompress NSAC-compressed gradient back to full d-dimensional vector.
    
        Reconstruction: Δw[idx] = q_val × ‖g‖ / sqrt(k), others = 0.
        (Unbiased reconstruction using norm preservation)
        """
        indices = compressed['indices']
        q_values = compressed['q_values']
        norm = compressed['norm']
        k = len(indices)
    
        # Reconstruct: place quantized values at selected indices, 0 elsewhere
        _dev = device if device is not None else torch.device('cpu')
        reconstructed = torch.zeros(d, dtype=torch.float32, device=_dev)
        # Scale factor for unbiasedness: norm / sqrt(k)
        scale = norm / np.sqrt(k) if k > 0 else 1.0
        reconstructed[indices] = torch.as_tensor(
            q_values, dtype=torch.float32, device=reconstructed.device) * scale
    
        return reconstructed

==============================================================================
  2. is the compression actually switched on?
==============================================================================
    base.yaml:2: # HierFed-Matter-NSAC-DPBA 实验超参数配置
    base.yaml:36: dp_clip_mode: per_device      # [v7] global | per_device
    base.yaml:59: disable_nsac: false       # true -> 不做压缩

    --- results_baseline/hierfed_dp_iotid20_alpha0.1_seed1/results.json ---
      top-level keys : ['config', 'elapsed_seconds', 'final_metrics', 'round_metrics']
      config         : {"method": "hierfed_dp", "alpha": 0.1, "seed": 1, "oversample": false, "T": 50, "N": 20}
      round_metrics[0] keys : ['accuracy', 'accuracy_default', 'auc_roc', 'f1', 'f1_default', 'f1_macro', 'optimal_threshold', 'round']
      compression fields    : {'f1_macro': 0.413913969585635}

    --- results_baseline/hierfed_dp_iotid20_alpha0.1_seed2/results.json ---
      top-level keys : ['config', 'elapsed_seconds', 'final_metrics', 'round_metrics']
      config         : {"method": "hierfed_dp", "alpha": 0.1, "seed": 2, "oversample": false, "T": 50, "N": 20}
      round_metrics[0] keys : ['accuracy', 'accuracy_default', 'auc_roc', 'f1', 'f1_default', 'f1_macro', 'optimal_threshold', 'round']
      compression fields    : {'f1_macro': 0.520153016251157}

    --- results_ablation/proposed_iotid20_alpha0.1_seed1_full/results.json ---
      top-level keys : ['communication_stats', 'config', 'final_metrics', 'round_metrics']
      config         : {"T": 50, "eta": 0.01, "E_local": 5, "batch_size": 256, "eval_every": 25, "N": 20, "M": 4, "K": 5, "input_dim_iotid20": 79, "input_dim_cicids": 76, "hidden_dims": [64, 32, 16], "output_dim": 2, "alpha": 0.1, "num_seeds": 5, "seed_range": [1, 2, 3, 4, 5], "epsilon_total": 399.0, "delta": 1e-05, "clip
      round_metrics[0] keys : ['accuracy', 'accuracy_default', 'auc_roc', 'avg_compression_ratio', 'avg_latency_ms', 'f1', 'f1_default', 'f1_macro', 'optimal_threshold', 'round', 'total_compressed_bytes']
      compression fields    : {'f1_macro': 0.07186570683185925, 'avg_compression_ratio': 0.0875, 'avg_latency_ms': 12.11072, 'total_compressed_bytes': 35696}

==============================================================================
  3. round-trip gain / direction vs gradient scale, per slice
==============================================================================
  d = 7826
  slice     b    k_r |       ||g||=0.01          ||g||=1        ||g||=100      ||g||=10000      ||g||=1e+06
                     |  (gain = ||recon||/||g|| ,  cos)
  ----------------------------------------------------------------------------------------------------
  urllc     8    0.1 |  1.25e-02/0.665  1.24e+00/0.659  1.23e+02/0.655  1.23e+04/0.659  1.21e+06/0.659
  embb     16    0.3 |  1.42e-02/0.885  1.42e+00/0.885  1.41e+02/0.884  1.43e+04/0.884  1.43e+06/0.885
  mmtc      8   0.05 |  1.14e-02/0.526  1.16e+00/0.529  1.14e+02/0.530  1.15e+04/0.525  1.16e+06/0.529

  READ THIS: if the gain is not ~1.0 anywhere in the band your real
  gradients live in, the compressed update is not what the paper says.

==============================================================================
  4. same measurement on REAL gradients (needs data + GPU)
==============================================================================
[GPU] Using NVIDIA GeForce RTX 4090 | VRAM=25.3GB
[Partition] Loaded per-α file: α=0.5
[Model] input_dim=79, hidden_dims=[64, 32, 16], d=7762
  data ok: X_train=(500626, 79), devices=20
[transformers] Disabling PyTorch because PyTorch >= 2.4 is required but found 2.2.0+cu121
[transformers] PyTorch was not found. Models won't be available and only tokenizers, configuration and file/data utilities can be used.
  urllc   ||g||=       1.801 ||recon||=     0.09795 gain= 5.44e-02 cos= 0.950 k_ratio=0.100 CR=0.0250 bytes=3880
  embb    ||g||=         1.8 ||recon||=     0.06643 gain= 3.69e-02 cos= 0.995 k_ratio=0.300 CR=0.1500 bytes=13968
  mmtc    ||g||=       1.796 ||recon||=      0.1279 gain= 7.12e-02 cos= 0.909 k_ratio=0.050 CR=0.0125 bytes=1940

  -> this is the 'compression fidelity' number the paper needs anyway.

==============================================================================
  -> upload this whole output to Mihiro
==============================================================================
