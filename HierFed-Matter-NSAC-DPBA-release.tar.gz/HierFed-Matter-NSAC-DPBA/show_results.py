#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
show_results.py -- ONE command that prints everything you need to read after the
sweeps finish.  Read-only: it never writes into a result directory.

    python show_results.py              # everything
    python show_results.py --section abl    # only the ablation tables
    python show_results.py --section eps    # only the DP family x epsilon table
    python show_results.py --section cr     # only the matched-compression (G-1) table

Sections
    1 inventory        what is on disk, how many runs each tree holds
    2 run summary      logs/REST_SUMMARY.txt  (written by run_rest_all.sh)
    3 TABLES.md        results_summary/TABLES.md -- the paper-ready tables
    4 ablation         component + weight-sensitivity tables, formatted
    5 dp family        AUC vs epsilon, the two clusters (reuses plot_dp_clusters)
    6 G-1              matched-compression comparison vs topk_qsgd
    7 checklist        anything still missing / still [TBD]
"""
import argparse
import glob
import json
import os
import re
import sys
from collections import defaultdict
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

ABL = "results_ablation"
CR_OUT = "results_crsweep"


def head(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def n_json(root):
    return len(glob.glob(os.path.join(HERE, root, "**", "results.json"), recursive=True))


def exists(p):
    return os.path.exists(os.path.join(HERE, p))


# ------------------------------------------------------------------ 1 inventory
def s_inventory():
    head("[1] inventory")
    trees = [("results_baseline", "baselines (11 methods, alpha 0.5/0.1)"),
             ("results_epsgrid", "baseline epsilon grid (100/200/400)"),
             ("results_eps", "ours, epsilon sweep (20..1600)"),
             (ABL, "ablation (component + weights)"),
             (CR_OUT, "ours, matched compression (G-1)"),
             ("results_scale", "scaling test"),
             ("results_v11gate", "gate runs")]
    for t, what in trees:
        n = n_json(t)
        flag = "ok " if n else "-- "
        print(f"  [{flag}] {t:<18} {n:>4} runs   {what}")
    for f in ("logs/REST_SUMMARY.txt", "results_summary/TABLES.md",
              os.path.join(ABL, "ablation_table_component.json"),
              os.path.join(ABL, "ablation_table_weights.json"), "logs/rest/crmatch.log"):
        print(f"  [{'ok ' if exists(f) else '-- '}] {f}")


# ---------------------------------------------------------------- 2 run summary
def s_summary():
    head("[2] run summary -- logs/REST_SUMMARY.txt")
    p = os.path.join(HERE, "logs/REST_SUMMARY.txt")
    if not os.path.exists(p):
        print("  not found.  Either run_rest_all.sh has not finished, or it was")
        print("  never launched.  Check:  bash run_rest_all.sh status")
        return
    print(open(p, encoding="utf-8", errors="replace").read())


# ------------------------------------------------------------------ 3 TABLES.md
def s_tables():
    head("[3] results_summary/TABLES.md  -- paper-ready tables")
    p = os.path.join(HERE, "results_summary", "TABLES.md")
    if not os.path.exists(p):
        print("  not found.  Rebuild it with:")
        print("    python aggregate_supp.py --roots results_ablation results_baseline \\")
        print("           results_eps results_scale results --out_dir results_summary")
        return
    txt = open(p, encoding="utf-8", errors="replace").read()
    print(txt)
    cells = txt.count("[TBD]")
    rows = sum(1 for ln in txt.splitlines() if "[TBD]" in ln)
    print(f"\n  >>> [TBD]: {rows} table row(s) / {cells} cell(s) still empty")
    if rows:
        print("      one empty row = one configuration whose runs never landed"
              " -- see section 7")


# ------------------------------------------------------------------ 4 ablation
def _load_arm_tags():
    """authoritative arm list from ablation_configs.py (falls back to the 6)"""
    import importlib.util
    fp = os.path.join(HERE, "ablation_configs.py")
    if os.path.exists(fp):
        try:
            spec = importlib.util.spec_from_file_location("ac_sr", fp)
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            return list(m.COMPONENT_CONFIGS), list(m.WEIGHT_CONFIGS)
        except Exception:
            pass
    return (["full", "hierfed_only", "hierfed_nsac", "hierfed_dpba",
             "hierfed_uni_dp", "hierfed_nsac_uni_dp"],
            ["w_full", "w_fim_only", "w_type_only", "w_size_only",
             "w_het_only", "w_no_fim"])


COMPONENT_TAGS, WEIGHT_TAGS = _load_arm_tags()


def _disk_table(tags):
    """{(tag, alpha): (n, mean, sd, oldest_mtime)} straight from the per-seed files.

    Reading the raw runs (not the aggregate json) means the numbers here cannot
    disagree with the underlying data, and we get the mtime for free.
    """
    acc = defaultdict(list)
    old = {}
    tags = set(tags)
    for p in glob.glob(os.path.join(HERE, ABL, "*", "results.json")):
        name = os.path.basename(os.path.dirname(p))
        m = re.match(r".+_alpha([\d.]+)_seed(\d+)_(.+)$", name)
        if not m or m.group(3) not in tags:      # exact tag: never let _full eat _w_full
            continue
        tg, al = m.group(3), float(m.group(1))
        d = json.load(open(p, encoding="utf-8"))
        auc = (d.get("final_metrics") or {}).get("auc_roc")
        f1m = (d.get("final_metrics") or {}).get("f1_macro")
        if auc is None:
            continue
        acc[(tg, al)].append((auc, f1m))
        old[(tg, al)] = max(old.get((tg, al), 0), os.path.getmtime(p))
    return acc, old


def _abl_from_disk(tags, title, tagcol):
    acc, old = _disk_table(tags)
    if not acc:
        print(f"\n  {title}: no per-seed files under {ABL}/")
        return
    print(f"\n  {title}")
    for alpha in sorted({k[1] for k in acc}, reverse=True):
        print(f"\n    --- alpha = {alpha:g} ---")
        print(f"    {tagcol:<22} {'AUC (mean±sd)':>19} {'macroF1':>9} {'n':>3}  {'oldest file':>16}")
        print("    " + "-" * 76)
        base = None
        for tag in tags:
            v = acc.get((tag, alpha))
            if not v:
                continue
            aucs = [x[0] for x in v]
            f1s = [x[1] for x in v if x[1] is not None]
            mu = sum(aucs) / len(aucs)
            sdv = (sum((x - mu) ** 2 for x in aucs) / (len(aucs) - 1)) ** 0.5 \
                if len(aucs) > 1 else 0.0
            if tag in ("full", "w_full"):
                base = mu
            mark = ""
            if base is not None and tag not in ("full", "w_full"):
                mark = f"   ({mu - base:+.4f} vs full)"
            mt = old.get((tag, alpha), 0)
            print(f"    {tag:<22} {mu:>10.4f}±{sdv:<7.4f} "
                  f"{(sum(f1s) / len(f1s) if f1s else float('nan')):>9.4f} {len(aucs):>3}  "
                  f"{datetime.fromtimestamp(mt).strftime('%m-%d %H:%M') if mt else '?':>16}"
                  f"{mark}")
    print("\n    NOTE: a row whose 'oldest file' predates the fix_v* patches was")
    print("    KEPT by run_ablation.py's skip_existing=True.  Run diag_ablation.py.")


def s_abl():
    head("[4] ablation tables -- rebuilt from the per-seed files on disk")
    _abl_from_disk(COMPONENT_TAGS, "Table 8 -- component ablation", "configuration")
    _abl_from_disk(WEIGHT_TAGS, "Table B.2.2 -- Eq.7 sensitivity weights", "weights")
    print("\n  KEY CONTRAST -- the two numbers the paper needs "
          "(arm list from ablation_configs.py)")
    acc, _ = _disk_table(COMPONENT_TAGS)
    for alpha in (0.5, 0.1):
        def mu(tag):
            v = acc.get((tag, alpha))
            return (sum(x[0] for x in v) / len(v)) if v else None
        f_ = mu("full")
        print(f"\n    --- alpha = {alpha:g} ---")
        if f_ is None:
            print("      full: no data")
            continue
        print(f"    full (NSAC + ADAPTIVE DPBA)      {f_:>8.4f}")
        for tag, why in (("hierfed_nsac_uni_dp_true",
                          "TRUE uniform C  -- this IS the DPBA-FIM gain"),
                         ("hierfed_nsac_uni_dp",
                          "old mislabelled arm (actually adaptive)"),
                         ("hierfed_dpba", "adaptive, no NSAC"),
                         ("hierfed_uni_dp_true", "TRUE uniform, no NSAC"),
                         ("hierfed_nsac", "no DP at all (utility ceiling)")):
            v = mu(tag)
            if v is None:
                print(f"    {tag:<30}    n/a   ({why})")
            else:
                print(f"    {tag:<30} {v:>8.4f}   ({v - f_:+.4f} vs full; {why})")
    per = len(glob.glob(os.path.join(HERE, ABL, "proposed_*", "results.json")))
    print(f"\n  per-seed runs on disk: {per}")
    if per == 0:
        print("  -> results_ablation/ is empty.  The ablation never ran.")
        print("     bash run_rest_all.sh all      (see run_rest_all.sh header)")


# ------------------------------------------------------------------ 5 dp family
def s_eps():
    head("[5] DP family: AUC vs epsilon   (the two clusters)")
    try:
        import plot_dp_clusters as pdc
    except Exception as e:
        print(f"  cannot import plot_dp_clusters.py ({e})")
        return
    res = pdc.collect()
    if len(res) == 4:
        tab, merged, src, base_reps = res
    else:                      # older plot_dp_clusters.py
        tab, merged, src = res[0], {}, {}
        print("  !! your plot_dp_clusters.py is OUTDATED (collect() returns"
              f" {len(res)} values, need 4).")
        print("     Re-copy it from hierfed_post_s2.tar.gz, or ignore this section.")
    print("  sources: " + " | ".join(f"{k}={v}" for k, v in sorted(src.items())))
    if merged:
        print("  eps snapped together: " + ", ".join(f"{k} x{v}" for k, v in sorted(merged.items())))
    pdc.print_table(tab)
    pdc.print_diagnosis(tab)


# ------------------------------------------------------------------ 6 G-1
def s_cr():
    head("[6] G-1 matched-compression comparison")
    n = n_json(CR_OUT)
    print(f"  {CR_OUT}/ runs on disk: {n}")
    log = os.path.join(HERE, "logs", "rest", "crmatch.log")
    if not os.path.exists(log):
        log = os.path.join(HERE, "logs", "crmatch.log")
    if os.path.exists(log):
        txt = open(log, encoding="utf-8", errors="replace").read()
        i = txt.find("[crmatch] the matched-compression comparison")
        print("\n  --- from " + os.path.relpath(log, HERE) + " ---")
        print(txt[i:] if i >= 0 else txt[-2500:])
    elif n:
        print("  (log not found, but runs exist -- rerun: bash run_cr_match.sh)")
    else:
        print("  NOT RUN.  G-1 is the fairness anchor of the main table -- run:")
        print("    PAR=4 bash run_cr_match.sh")


# ------------------------------------------------------------------ 7 checklist
def s_check():
    head("[7] checklist -- what is still missing")
    todos = []
    if n_json("results_epsgrid") < 210:
        todos.append(f"epsgrid incomplete: {n_json('results_epsgrid')}/210")
    if n_json(ABL) < 120:
        todos.append(f"ablation incomplete: {n_json(ABL)}/120")
    if n_json(CR_OUT) < 20:
        todos.append(f"G-1 incomplete: {n_json(CR_OUT)}/20")
    for f in ("results_summary/TABLES.md", "logs/REST_SUMMARY.txt"):
        if not exists(f):
            todos.append(f"missing {f}")
    tab = os.path.join(HERE, "results_summary", "TABLES.md")
    if os.path.exists(tab):
        t = open(tab, encoding="utf-8", errors="replace").read()
        if "[TBD]" in t:
            rows = sum(1 for ln in t.splitlines() if "[TBD]" in ln)
            todos.append(f"TABLES.md still has {rows} empty table row(s)")
    if not todos:
        print("  nothing outstanding -- all trees complete, TABLES.md fully populated.")
    for t in todos:
        print("   * " + t)
    head("next")
    print("  1. read section 3 (TABLES.md)  -> that IS the paper's result tables")
    print("  2. read section 5              -> the two-cluster DP story")
    print("  3. read section 6              -> the fair comparison vs topk_qsgd")
    print("  4. figures:")
    print("       python plot_dp_clusters.py --with-slice --outdir figs_dp")
    print("       python plot_results.py --figure all")
    print("     then send me the PNGs (or just paste this whole output)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--section", default="all",
                    choices=["all", "inv", "sum", "tables", "abl", "eps", "cr", "check"])
    a = ap.parse_args()
    print("=" * 78)
    print("  HierFed-Matter-NSAC-DPBA  --  results viewer")
    print("  " + HERE)
    print("=" * 78)
    order = [("inv", s_inventory), ("sum", s_summary), ("tables", s_tables),
             ("abl", s_abl), ("eps", s_eps), ("cr", s_cr), ("check", s_check)]
    for name, fn in order:
        if a.section in ("all", name):
            try:
                fn()
            except Exception as e:
                print(f"\n  !! section '{name}' failed: {e}")
                import traceback
                traceback.print_exc()
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
