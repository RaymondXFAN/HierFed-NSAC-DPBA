#!/usr/bin/env bash
# run_baseline_eps_sweep.sh -- PLAN A: give the DP baselines more than one
# epsilon point, so the main table is not a single-epsilon comparison.
#
#   bash run_baseline_eps_sweep.sh                 # launch now
#   bash run_baseline_eps_sweep.sh --wait          # wait for run_parallel.py first
#   METHODS="hierfed_dp dpfed6g" bash run_baseline_eps_sweep.sh
#   EPS_LIST="100 200" PAR=3 bash run_baseline_eps_sweep.sh
#
# Defaults: METHODS="hierfed_dp dpfed6g adaptive_clip_dp"
#           EPS_LIST="100 200 400"   ALPHAS="0.5 0.1"   SEEDS="1 2 3 4 5"
#           -> 3 x 3 x 2 x 5 = 90 jobs, ~4 h at PAR=4
#
# Requires fix_v14.py to have been applied (run_baselines.py --epsilon).
# Reads configs/base.yaml only; never edits it.
set -u
cd "$(dirname "$0")" || exit 1

METHODS="${METHODS:-hierfed_dp dpfed6g adaptive_clip_dp}"
EPS_LIST="${EPS_LIST:-100 200 400}"
ALPHAS="${ALPHAS:-0.5 0.1}"
SEEDS="${SEEDS:-1 2 3 4 5}"
PAR="${PAR:-4}"
PY="${PY:-python}"
OUT_ROOT="${OUT_ROOT:-results_epsgrid}"
LOG_DIR="logs/epsgrid"
mkdir -p "$LOG_DIR"

WAIT=0
[ "${1:-}" = "--wait" ] && WAIT=1

bar() { printf '%s\n' "-------------------------------------------------------------------------------"; }

bar
echo "[planA] preflight"
[ -f run_baselines.py ] || { echo "  !! run_baselines.py not found -- wrong dir"; exit 1; }
grep -q -- "--epsilon" run_baselines.py || {
  echo "  !! run_baselines.py has no --epsilon -- run: python fix_v14.py --apply"
  exit 1
}
echo "  [ok] run_baselines.py supports --epsilon"

N=$(( $(echo $METHODS | wc -w) * $(echo $EPS_LIST | wc -w) \
      * $(echo $ALPHAS | wc -w) * $(echo $SEEDS | wc -w) ))
echo "  plan: $N jobs  (${METHODS// /,} | eps ${EPS_LIST// /,} | alpha ${ALPHAS// /,} | seeds ${SEEDS// /,})"
echo "  out : $OUT_ROOT/eps<EPS>/    par=$PAR   est ~$(( N * 11 / PAR / 60 ))h"

if [ "$WAIT" = "1" ]; then
  bar
  echo "[planA] waiting for the running batch (run_parallel.py) to finish ..."
  while pgrep -f run_parallel.py >/dev/null 2>&1; do sleep 60; done
  echo "  [ok] the batch has finished -- starting plan A"
fi

# ---------------------------------------------------------------- preflight gate
bar
GATE_EPS="$(echo $EPS_LIST | awk '{print $1}')"
echo "[planA] GATE: one T=2 job at eps=$GATE_EPS to prove --epsilon takes effect"
GLOG="$LOG_DIR/gate_eps100.log"
timeout 900 $PY -u run_baselines.py --method "$(echo $METHODS | awk '{print $1}')" \
        --alpha 0.5 --seeds 1 --epsilon "$GATE_EPS" --T 2 \
        --output_dir "$OUT_ROOT/_gate" --skip_aggregate > "$GLOG" 2>&1
# the printed line is "[[fix_v14]] <exp_name> epsilon_total=<eps> clip_norm=..."
# so match the epsilon token only -- do NOT anchor on the tag
if ! grep -q "epsilon_total=${GATE_EPS}" "$GLOG"; then
  echo "  !! GATE FAILED -- the log does not show epsilon_total=${GATE_EPS}"
  echo "  !! tail of $GLOG:"; tail -n 12 "$GLOG" | sed 's/^/     /'
  echo "  !! the sweep was NOT started."
  exit 1
fi
if ! ls "$OUT_ROOT/_gate"/*/results.json >/dev/null 2>&1; then
  echo "  !! GATE FAILED -- no results.json written"
  tail -n 12 "$GLOG" | sed 's/^/     /'
  exit 1
fi
echo "  [ok] GATE PASSED (epsilon override honoured, results.json written)"
rm -rf "$OUT_ROOT/_gate"

# ---------------------------------------------------------------- launch
bar
echo "[planA] launching $N jobs (throttled to $PAR) ..."
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PAR" ]; do sleep 10; done; }

for eps in $EPS_LIST; do
  for m in $METHODS; do
    for a in $ALPHAS; do
      for s in $SEEDS; do
        throttle
        tag="${m}_eps${eps}_a${a}_s${s}"
        nohup $PY -u run_baselines.py --method "$m" --alpha "$a" --seeds "$s" \
              --epsilon "$eps" --output_dir "$OUT_ROOT/eps$eps" \
              --skip_aggregate > "$LOG_DIR/$tag.log" 2>&1 &
      done
    done
  done
done
echo "  launched; waiting for completion ..."
wait
echo "  [planA] all $N jobs finished"

# ---------------------------------------------------------------- verify
bar
echo "[planA] verification (must see FAIL=0 and one epsilon per tree)"
$PY - "$OUT_ROOT" "$EPS_LIST" <<'PYEOF'
import glob, json, os, re, sys
root, epsl = sys.argv[1], sys.argv[2].split()
for eps in epsl:
    d = os.path.join(root, f"eps{eps}")
    got = glob.glob(os.path.join(d, "*", "results.json"))
    eps_seen = set()
    for p in got:
        try:
            c = (json.load(open(p, encoding="utf-8")).get("config") or {})
        except Exception:
            continue
        if c.get("epsilon_total") is not None:
            eps_seen.add(str(c["epsilon_total"]))
    print(f"  eps={eps:<5} {len(got):>3} results   recorded epsilon: "
          f"{sorted(eps_seen) or '(none -- fix_v14 missing?)'}")
PYEOF
grep -l -i "traceback" "$LOG_DIR"/*.log 2>/dev/null | head -5 \
  && echo "  !! the logs above contain tracebacks" \
  || echo "  [ok] no tracebacks"
cat <<'EOF'

  next: I will extend check_eps_table.py to read results_epsgrid/ and print the
  (epsilon, AUC) table alongside the epsilon=399 column.
EOF
exit 0

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
