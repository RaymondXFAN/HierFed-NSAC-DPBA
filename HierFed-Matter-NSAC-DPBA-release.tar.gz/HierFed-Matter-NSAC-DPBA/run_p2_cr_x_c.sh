#!/usr/bin/env bash
# =============================================================================
# run_p2_cr_x_c.sh -- P2: the CR x C grid (the go/no-go experiment)
#
# Question: does the OPTIMAL clipping threshold C shift with the compression rate?
#   yes -> compression re-opens the clipping lever  -> Direction A gets a 2nd leg
#   no  -> fall back to the "systematic trade-off study" framing
#
# 3 CR levels x 5 C values x 2 seeds = 30 runs (~3.5 h at 4-way parallelism)
#
# Usage
#   bash run_p2_cr_x_c.sh                 # gate, then launch in the background
#   PAR=4 SEEDS="1 2 3" bash run_p2_cr_x_c.sh
#
# Requires fix_v9.py to have been applied (NSAC_CR_SCALE is read by the simulator).
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1

PY=${PY:-python}
PAR=${PAR:-4}
SEEDS=${SEEDS:-"1 2"}
OUT=${OUT:-results_v9_crxC}
CR_SCALES=${CR_SCALES:-"0.25 1.0 4.0"}     # multiplies every slice's k_ratio -> scales CR
CS=${CS:-"0.05 0.1 0.2 0.5 1.0"}           # global clipping bound
ALPHA=${ALPHA:-0.5}
# run_experiment.py's flag for the clipping bound (check with --help if it differs)
CLIP_FLAG=${CLIP_FLAG:---clip_norm}
DP_CLIP_MODE=${DP_CLIP_MODE:-global}   # [fix_v19] C 只有在 global 模式才生效 | EN: [fix_v19] C takes effect only in global mode

mkdir -p logs/v9 "$OUT"

bar() { printf '%s\n' "-------------------------------------------------------------------------------"; }

# ---------------------------------------------------------------------------
bar
printf '[P2] CR x C grid\n'
printf '     CR_SCALE = %s   (NSAC_CR_SCALE env var)\n' "$CR_SCALES"
printf '     C        = %s   (%s)\n' "$CS" "$CLIP_FLAG"
printf '     seeds    = %s   alpha = %s   parallel = %s\n' "$SEEDS" "$ALPHA" "$PAR"
bar

# 0) preflight -------------------------------------------------------------
if ! grep -q "NSAC_CR_SCALE" core/nsac.py 2>/dev/null; then
  printf '  !! fix_v9.py has not been applied (core/nsac.py has no slices_from_env)\n'
  exit 1
fi
if ! $PY run_experiment.py --help 2>&1 | grep -q -- "$CLIP_FLAG"; then
  printf '  !! run_experiment.py does not accept %s\n' "$CLIP_FLAG"
  printf '     check the real flag name:  python run_experiment.py --help | grep -i clip\n'
  exit 1
fi
printf '  [ok] fix_v9 present, %s accepted\n' "$CLIP_FLAG"

# 1) gate: one config at T=2 into a throw-away dir -------------------------
bar
printf '[P2] GATE: one config at T=2 (a few minutes)\n'
SMOKE="smoke_v9_$(date +%Y%m%d_%H%M)"
mkdir -p "$SMOKE"
if NSAC_CR_SCALE=1.0 timeout 900 $PY -u run_experiment.py --method proposed \
     --alpha "$ALPHA" --seed 1 --tag gate --output_dir "$SMOKE" \
     --T 2 "$CLIP_FLAG" 0.2 --dp_clip_mode "$DP_CLIP_MODE" > "$SMOKE/gate.log" 2>&1 \
   && [ -f "$SMOKE/proposed_iotid20_alpha${ALPHA}_seed1_gate/results.json" ]; then
  printf '  [ok] GATE PASSED (results.json written)\n'
else
  printf '  !! GATE FAILED -- batch not started. Last 12 lines:\n'
  tail -n 12 "$SMOKE/gate.log" | sed 's/^/  | /'
  exit 1
fi
rm -rf "$SMOKE"

# 2) build the job list ----------------------------------------------------
JOBS=0
for scale in $CR_SCALES; do
  for c in $CS; do
    for s in $SEEDS; do
      TAG="crx_s${scale}_C${c}"
      NAME="proposed_iotid20_alpha${ALPHA}_seed${s}_${TAG}"
      [ -f "$OUT/$NAME/results.json" ] || JOBS=$((JOBS + 1))
    done
  done
done
printf '\n[P2] jobs to run: %s   (already done: %s)\n' "$JOBS" \
  "$(( $(echo "$CR_SCALES" | wc -w) * $(echo "$CS" | wc -w) * $(echo "$SEEDS" | wc -w) - JOBS ))"
[ "$JOBS" = "0" ] && { printf '[P2] nothing to do\n'; exit 0; }

# 3) launch ----------------------------------------------------------------
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PAR" ]; do sleep 10; done; }

for scale in $CR_SCALES; do
  for c in $CS; do
    for s in $SEEDS; do
      TAG="crx_s${scale}_C${c}"
      NAME="proposed_iotid20_alpha${ALPHA}_seed${s}_${TAG}"
      [ -f "$OUT/$NAME/results.json" ] && continue
      throttle
      NSAC_CR_SCALE="$scale" nohup $PY -u run_experiment.py --method proposed \
        --alpha "$ALPHA" --seed "$s" --tag "$TAG" --output_dir "$OUT" \
        "$CLIP_FLAG" "$c" --dp_clip_mode "$DP_CLIP_MODE" > "logs/v9/${NAME}.log" 2>&1 &
    done
  done
done

printf '\n[P2] launched %s jobs in the background.\n' "$JOBS"
bar
cat <<EOF
  Monitor (non-blocking):
    ls $OUT | wc -l
    find $OUT -name results.json | wc -l
    tail -n 5 logs/v9/*.log | tail -40

  When finished:
    python analyze_crxC.py $OUT        # <- prints the go/no-go verdict
EOF

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
