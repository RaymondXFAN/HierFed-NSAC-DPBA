#!/bin/bash
# ============================================================
# IoTID20 数据集获取脚本（无卡模式可用）
# EN: IoTID20 dataset fetch script (usable in CPU-only / no-GPU mode)
# 目标路径: <PROJ>/data/raw/IoTID20.csv
# EN: Target path: <PROJ>/data/raw/IoTID20.csv
# ============================================================
set -u
PROJ=/root/autodl-tmp/HierFed-Matter-NSAC-DPBA
RAW="$PROJ/data/raw"
mkdir -p "$RAW"
cd "$PROJ" || exit 1

echo "=============================================="
echo "  IoTID20 数据集获取"
echo "=============================================="

FULL_OK=0

# ---------- 方案 A（首选）：Kaggle 全量 625,783 行 ----------
# EN: ---------- Option A (preferred): Kaggle full set, 625,783 rows ----------
if [ -f ~/.kaggle/kaggle.json ]; then
  echo "[A] 检测到 Kaggle 凭证 → 下载全量数据集 (625,783 行)"
  pip install -q kaggle 2>/dev/null
  kaggle datasets download -d rohulaminlabid/iotid20-dataset -p "$RAW" --unzip || true
  F=$(find "$RAW" -maxdepth 2 -iname "*.csv" ! -name "IoTID20.csv" | head -1)
  if [ -n "$F" ]; then
    # 统一标签列名 -> Label（预处理脚本按此识别）
    # EN: normalize the label column name -> Label (the preprocessing script detects it this way)
    if head -1 "$F" | grep -qi "Target"; then
      sed -i '1s/[Tt]arget$/Label/' "$F"
    fi
    mv "$F" "$RAW/IoTID20.csv"
    echo "  ✅ 已保存: $RAW/IoTID20.csv ($(wc -l < "$RAW/IoTID20.csv") 行)"
    FULL_OK=1
  fi
else
  echo "[A] 未找到 ~/.kaggle/kaggle.json —— 跳过全量方案"
  echo "    （全量 625,783 行是复现论文数值的唯一正确数据源，强烈建议配一下）"
fi

# ---------- 方案 B（兜底）：HuggingFace 子集 261,538 行 ----------
# EN: ---------- Option B (fallback): HuggingFace subset, 261,538 rows ----------
if [ "$FULL_OK" -ne 1 ]; then
  echo ""
  echo "[B] 兜底：从 HuggingFace 镜像下载（子集 261,538 行，免登录）"
  echo "    ⚠ 行数与论文(625,783)不同，仅用于『跑通流程/调试』，不能用于论文最终数值"
  wget -q --show-progress -O "$RAW/IoTID20.csv" \
    "https://hf-mirror.com/datasets/Ben11304/IoT-ID20-DiFL/resolve/main/original_iotid20.csv" || \
  curl -fL -o "$RAW/IoTID20.csv" \
    "https://hf-mirror.com/datasets/Ben11304/IoT-ID20-DiFL/resolve/main/original_iotid20.csv"
  if [ -s "$RAW/IoTID20.csv" ]; then
    sed -i '1s/[Tt]arget$/Label/' "$RAW/IoTID20.csv"
    echo "  ✅ 已保存子集: $RAW/IoTID20.csv ($(wc -l < "$RAW/IoTID20.csv") 行)"
  fi
fi

# ---------- 方案 C（备选）：figshare 全量 294MB ----------
# EN: ---------- Option C (alternative): figshare full set, 294MB ----------
echo ""
echo "[C] 若 A/B 都不满意，可在服务器上试 figshare 全量："
echo '    wget -O iotid20.zip "https://figshare.com/ndownloader/articles/29143829/versions/2" && unzip iotid20.zip'

# ---------- 验证 ----------
# EN: ---------- verify ----------
echo ""
echo "=============== 验证 ==============="
if [ -s "$RAW/IoTID20.csv" ]; then
  echo "文件: $RAW/IoTID20.csv"
  echo "行数: $(wc -l < "$RAW/IoTID20.csv")"
  echo "列数: $(head -1 "$RAW/IoTID20.csv" | tr ',' '\n' | wc -l)"
  echo "末列: $(head -1 "$RAW/IoTID20.csv" | tr ',' '\n' | tail -1)"
else
  echo "❌ 未取得数据。请手动上传 IoTID20.csv 到 $RAW/ 后重跑。"
fi
echo ""
echo "数据就绪后即可预处理："
echo "  cd $PROJ && python data/preprocess.py --dataset iotid20 --alpha 0.5 --N 20 --raw_dir data/raw --output_dir data/processed"
echo "  cd $PROJ && python data/preprocess.py --dataset iotid20 --alpha 0.1 --N 20 --raw_dir data/raw --output_dir data/processed"

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
