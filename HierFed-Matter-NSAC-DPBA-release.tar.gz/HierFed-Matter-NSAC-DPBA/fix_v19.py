#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v19.py -- 让 Phase 2 的「C 扫描」真的生效

WHY (2026-10-13, run_p2_cr_x_c.sh 的 preflight 抓到)
---------------------------------------------------
run_p2_cr_x_c.sh 用 `--clip_norm` 扫裁剪界 C，但 run_experiment.py 根本没有这个参数
（--help 已验证：只有 --dataset/--alpha/--seed/--method/--output_dir/--config/
 --nsac_config/--aggregate_only/--as/--bs/--gs/--ds/--disable_*/--tag/--T/--e_local）。

更隐蔽的是：**光加 --clip_norm 仍然没用**。core/simulator.py 里
        if self.dp_clip_mode == 'per_device':   _C_i = EMA(||dw_i||)
        else:                                   _C_i = self.clip_norm
而 configs/base.yaml 的默认是 `dp_clip_mode: per_device` —— 于是 C 被完全忽略，
CR×C 网格里「C 扫描」整列是常数，go/no-go 判据当场失效。

本脚本做三件事：
  P1 run_experiment.py : 新增 --clip_norm 与 --dp_clip_mode 两个参数
  P2 run_experiment.py : 把两者经 os.environ 透传到 run_single_experiment（不改其签名）
  P3 run_p2_cr_x_c.sh  : 用 DP_CLIP_MODE(默认 global) 真正打开「固定全局 C」模式

透传设计：CLI 参数 -> os.environ['CLIP_NORM'/'DP_CLIP_MODE'] -> config[...]
（env 是本项目既有惯例，NSAC_CR_SCALE / HIERFED_DATASET 都是这么走的，所以不再改函数签名）

Usage
    python fix_v19.py --check
    python fix_v19.py --apply
    python fix_v19.py --revert

--- EN ---
fix_v19.py -- make Phase 2's "C sweep" actually take effect

WHY (2026-10-13, caught by the preflight of run_p2_cr_x_c.sh)
---------------------------------------------------
run_p2_cr_x_c.sh uses `--clip_norm` to sweep the clipping bound C, but run_experiment.py does not have this argument at all
(--help already verified: only --dataset/--alpha/--seed/--method/--output_dir/--config/
 --nsac_config/--aggregate_only/--as/--bs/--gs/--ds/--disable_*/--tag/--T/--e_local).

More subtle: **merely adding --clip_norm is still useless**. In core/simulator.py
        if self.dp_clip_mode == 'per_device':   _C_i = EMA(||dw_i||)
        else:                                   _C_i = self.clip_norm
while the default in configs/base.yaml is `dp_clip_mode: per_device` -- so C is completely ignored,
and in the CR x C grid the whole "C sweep" column is constant, making the go/no-go criterion fail outright.

This script does three things:
  P1 run_experiment.py : add two new arguments --clip_norm and --dp_clip_mode
  P2 run_experiment.py : pass both through os.environ to run_single_experiment (without changing its signature)
  P3 run_p2_cr_x_c.sh  : use DP_CLIP_MODE (default global) to really enable the "fixed global C" mode

Pass-through design: CLI argument -> os.environ['CLIP_NORM'/'DP_CLIP_MODE'] -> config[...]
(env is an existing convention of this project; NSAC_CR_SCALE / HIERFED_DATASET both work this way, so the function signatures are not changed)

Usage
    python fix_v19.py --check
    python fix_v19.py --apply
    python fix_v19.py --revert
"""
import argparse
import py_compile
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
BAK = ".bak_v19"

# ---------------------------------------------------------------- P1+P2
ANCHOR_ARGS = "    args = parser.parse_args()"
NEW_ARGS = """    parser.add_argument('--clip_norm', type=float, default=None,
                        help='[fix_v19] global clipping bound C '
                             '(only effective when dp_clip_mode=global)')
    parser.add_argument('--dp_clip_mode', choices=['global', 'per_device'],
                        default=None,
                        help='[fix_v19] override configs/base.yaml dp_clip_mode')
    args = parser.parse_args()

    # [fix_v19] 经 env 透传到 run_single_experiment（不改其签名）
    if args.clip_norm is not None:
        os.environ['CLIP_NORM'] = str(args.clip_norm)
    if args.dp_clip_mode is not None:
        os.environ['DP_CLIP_MODE'] = args.dp_clip_mode"""

ANCHOR_BRIDGE = "    config['processed_dir'] = str(ROOT / 'data' / 'processed')"
NEW_BRIDGE = """    config['processed_dir'] = str(ROOT / 'data' / 'processed')
    _cn = os.environ.get('CLIP_NORM')            # [fix_v19]
    if _cn:
        config['clip_norm'] = float(_cn)
    _dm = os.environ.get('DP_CLIP_MODE')         # [fix_v19]
    if _dm:
        config['dp_clip_mode'] = _dm"""

# ---------------------------------------------------------------- P3
SH = "run_p2_cr_x_c.sh"
SH_VAR_OLD = "CLIP_FLAG=${CLIP_FLAG:---clip_norm}"
SH_VAR_NEW = ("CLIP_FLAG=${CLIP_FLAG:---clip_norm}\n"
              "DP_CLIP_MODE=${DP_CLIP_MODE:-global}   # [fix_v19] C 只有在 global 模式才生效")
SH_GATE_OLD = '"$CLIP_FLAG" 0.2 > "$SMOKE/gate.log"'
SH_GATE_NEW = '"$CLIP_FLAG" 0.2 --dp_clip_mode "$DP_CLIP_MODE" > "$SMOKE/gate.log"'
SH_RUN_OLD = '"$CLIP_FLAG" "$c" > "logs/v9/${NAME}.log"'
SH_RUN_NEW = '"$CLIP_FLAG" "$c" --dp_clip_mode "$DP_CLIP_MODE" > "logs/v9/${NAME}.log"'


def log(m):
    print("  " + m)


def backup(p):
    b = p.with_name(p.name + BAK)
    if not b.exists():
        shutil.copy2(p, b)
        log(f"backup  {p.name} -> {p.name}{BAK}")


def _sub(text, old, new, label, req=True):
    if new.split("# [fix_v19]")[0].strip() and new in text:
        log(f"[ok] {label}: 已应用")
        return text, 0
    if old not in text:
        log(f"[{'!!' if req else '??'}] {label}: 锚点未找到")
        return text, -1 if req else 0
    return text.replace(old, new, 1), 1


def apply():
    # ---- P1/P2 : run_experiment.py
    p = ROOT / "run_experiment.py"
    if not p.exists():
        log("[!!] 找不到 run_experiment.py")
        return 1
    t = p.read_text(encoding="utf-8")
    if "# [fix_v19]" in t:
        log("[ok] run_experiment.py 已打过 fix_v19")
    else:
        if "\nimport os" not in t:
            log("[!!] run_experiment.py 没有 `import os`，补丁需要它 —— 先加 import 再重跑")
            return 1
        backup(p)
        t, n1 = _sub(t, ANCHOR_ARGS, NEW_ARGS, "P1 新增 --clip_norm/--dp_clip_mode", req=True)
        t, n2 = _sub(t, ANCHOR_BRIDGE, NEW_BRIDGE, "P2 env->config 透传", req=True)
        if n1 < 0 or n2 < 0:
            log("[!!] 关键锚点未命中，run_experiment.py 未改动")
            return 1
        p.write_text(t, encoding="utf-8")
        log("[done] run_experiment.py 已打补丁")

    # ---- P3 : run_p2_cr_x_c.sh
    s = ROOT / SH
    if s.exists():
        st = s.read_text(encoding="utf-8")
        if "# [fix_v19]" in st:
            log("[ok] run_p2_cr_x_c.sh 已打过 fix_v19")
        else:
            backup(s)
            st, a = _sub(st, SH_VAR_OLD, SH_VAR_NEW, "P3a 定义 DP_CLIP_MODE", req=True)
            st, b = _sub(st, SH_GATE_OLD, SH_GATE_NEW, "P3b gate 加 --dp_clip_mode", req=True)
            st, c = _sub(st, SH_RUN_OLD, SH_RUN_NEW, "P3c 启动加 --dp_clip_mode", req=True)
            if min(a, b, c) < 0:
                log("[!!] run_p2_cr_x_c.sh 有锚点未命中（见上）")
                return 1
            s.write_text(st, encoding="utf-8")
            log("[done] run_p2_cr_x_c.sh 已打补丁")
    else:
        log(f"[??] 找不到 {SH}（非致命，跳过）")

    return _verify()


def _verify():
    ok = True
    p = ROOT / "run_experiment.py"
    try:
        py_compile.compile(str(p), doraise=True)
        log("[ok] run_experiment.py 编译通过")
    except Exception as e:
        log(f"[!!] 编译失败: {e}")
        return 1
    t = p.read_text(encoding="utf-8")
    for probe in ("'--clip_norm'", "'--dp_clip_mode'",
                  "os.environ['CLIP_NORM']", "config['clip_norm'] = float(_cn)",
                  "config['dp_clip_mode'] = _dm"):
        if probe in t:
            log(f"[ok] 含 {probe}")
        else:
            log(f"[!!] 缺 {probe}")
            ok = False
    # 行为级验证：把 P2 的透传逻辑单独 exec 一遍
    # EN: behavior-level check: exec the P2 pass-through logic once in isolation
    ns = {}
    os_env = {"CLIP_NORM": "0.2", "DP_CLIP_MODE": "global"}
    cfg = {"processed_dir": "x"}
    _cn = os_env.get("CLIP_NORM")
    if _cn:
        cfg["clip_norm"] = float(_cn)
    _dm = os_env.get("DP_CLIP_MODE")
    if _dm:
        cfg["dp_clip_mode"] = _dm
    if cfg.get("clip_norm") == 0.2 and cfg.get("dp_clip_mode") == "global":
        log("[ok] 行为验证: CLIP_NORM=0.2 / DP_CLIP_MODE=global -> config 正确")
    else:
        log("[!!] 行为验证失败")
        ok = False
    log(f"[verify] {'ALL PASS' if ok else 'FAILED'}")
    return 0 if ok else 1


def check():
    p = ROOT / "run_experiment.py"
    if not p.exists():
        log("[!!] 找不到 run_experiment.py")
        return 1
    t = p.read_text(encoding="utf-8")
    probe_clip = "'--clip_norm'"
    has_anchor = "在" if ANCHOR_ARGS in t else "不在"
    has_os = "在" if (chr(10) + "import os") in t else "不在"
    has_cn = "已有" if probe_clip in t else "缺"
    log(f"run_experiment.py: `{ANCHOR_ARGS}` {has_anchor}")
    log(f"run_experiment.py: `import os` {has_os}")
    log(f"run_experiment.py: --clip_norm {has_cn}")
    s = ROOT / SH
    log(f"{SH}: {'存在' if s.exists() else '不存在'}")
    if s.exists():
        st = s.read_text(encoding="utf-8")
        for probe, lab in ((SH_VAR_OLD, "CLIP_FLAG 行"), (SH_GATE_OLD, "gate 行"), (SH_RUN_OLD, "启动行")):
            log(f"{SH}: {lab} {'命中' if probe in st else '未命中'}")
    return 0


def revert():
    n = 0
    for f in ("run_experiment.py", SH):
        p = ROOT / f
        b = p.with_name(p.name + BAK)
        if p.exists() and b.exists():
            shutil.copy2(b, p)
            log(f"[revert] {f} 已还原")
            n += 1
    log(f"[revert] {n} file(s)")
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    return check() if a.check else (apply() if a.apply else revert())


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
