#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_v11_gate.py -- reads the two gate outputs and compares them with the
PRE-fix values, then prints a verdict.

    python check_v11_gate.py

New (post-fix) results live in  results_v11gate*/   (written by gate_v11.sh)
Old (pre-fix) references are read from the existing result trees / logs.
Nothing is modified.
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def auc_of(path):
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return None
    v = (d.get("final_metrics") or {}).get("auc_roc")
    return float(v) if isinstance(v, (int, float)) else None


def find(pat):
    hits = sorted(glob.glob(os.path.join(HERE, pat), recursive=True))
    for h in hits:
        a = auc_of(h)
        if a is not None:
            return h, a
    return (hits[0] if hits else None), None


def from_log(pat, label):
    """fall back to the 'AUC = 0.xxxx' line printed at the end of a run log."""
    for p in sorted(glob.glob(os.path.join(HERE, pat))):
        m = re.findall(r"AUC\s*=\s*([\d.]+)", open(p, encoding="utf-8",
                                                   errors="replace").read())
        if m:
            return float(m[-1]), p
    return None, None


def main():
    print("=" * 78)
    print("  [fix_v11] gate: did repairing the decompression scale help?")
    print("=" * 78)

    if not any(glob.glob(os.path.join(HERE, "results_v11gate*"))):
        print("\n  !! no results_v11gate* found -- run gate_v11.sh first.")
        return 1

    rows = []
    # ---------------- proposed ----------------
    np_, na = find("results_v11gate/**/proposed_*_seed1_*/results.json")
    np_ = np_ or find("results_v11gate/**/results.json")[0]
    op_, oa = find("results_ablation/proposed_iotid20_alpha0.5_seed1_*/results.json")
    if oa is None:                       # ablation only has alpha=0.1 -> use the log
        oa, src = from_log("logs/*proposed*alpha0.5*seed1*.log", "proposed")
        op_ = src or "(log)"
    rows.append(("proposed  (alpha=0.5, seed=1)", oa, na, op_, np_))

    # ---------------- topk_qsgd ----------------
    nt_, nta = find("results_v11gate_base/topk_qsgd_iotid20_alpha0.5_seed1/results.json")
    ot_, ota = find("results_baseline/topk_qsgd_iotid20_alpha0.5_seed1/results.json")
    if ota is None:
        ota, src = from_log("logs/jobs/topk_qsgd_iotid20_alpha0.5_seed1.log", "topk")
    rows.append(("topk_qsgd (alpha=0.5, seed=1)", ota, nta, ot_, nt_))

    bar("old (gain ~0.037-0.071)   vs   new (gain ~0.88-0.99)")
    print(f"  {'method':<32} {'old AUC':>9} {'new AUC':>9} {'delta':>9}  {'status':<12}")
    print("  " + "-" * 78)
    ok = True
    improved = 0
    for name, old, new, opath, npath in rows:
        if new is None:
            print(f"  {name:<32} {('%.4f' % old) if old else '  --':>9} "
                  f"{'missing':>9} {'--':>9}  {'NOT DONE':<12}")
            ok = False
            continue
        if old is None:
            print(f"  {name:<32} {'  --':>9} {new:>9.4f} {'--':>9}  {'no baseline':<12}")
            continue
        d = new - old
        if d > 0.02:
            st, improved = "IMPROVED", improved + 1
        elif d < -0.02:
            st, ok = "WORSE", False
        else:
            st = "flat"
        print(f"  {name:<32} {old:>9.4f} {new:>9.4f} {d:>+9.4f}  {st:<12}")
        print(f"      new : {os.path.relpath(npath, HERE) if npath else '-'}")
        print(f"      old : {os.path.relpath(opath, HERE) if opath else '-'}")

    bar("compression statistics recorded by the new proposed run")
    if np_:
        try:
            d = json.load(open(np_, encoding="utf-8"))
            print("  communication_stats:",
                  json.dumps(d.get("communication_stats"), ensure_ascii=False)[:400])
            rm = d.get("round_metrics") or []
            if rm:
                print("  round 1 :", {k: rm[0][k] for k in rm[0]
                                      if re.search(r"compress|bytes|latenc", k, re.I)})
        except Exception as e:
            print(f"  ({e})")

    # margin between our method and the DP CONTROL (NOT topk_qsgd: that one has
    # no DP at all, so it is not a competitor -- comparing against it is
    # meaningless and was misleading.)
    bar("context: the DP family vs the no-DP ceiling")
    fam = defaultdict(list)
    for p in glob.glob(os.path.join(HERE, "results_baseline", "*",
                                    "results.json")):
        m = re.match(r"(.+)_iotid20_alpha([\d.]+)_seed(\d+)$",
                     os.path.basename(os.path.dirname(p)))
        if not m or float(m.group(2)) != 0.5:
            continue
        a = auc_of(p)
        if a is not None:
            fam[m.group(1)].append((int(m.group(3)), a))
    for meth in sorted(fam, key=lambda k: -max(x[1] for x in fam[k])):
        s1 = next((a for s, a in fam[meth] if s == 1), None)
        mean = sum(a for _, a in fam[meth]) / len(fam[meth])
        tag = "  <- DP control" if meth == "hierfed_dp" else ""
        print(f"    {meth:<22} seed1={('%.4f' % s1) if s1 else '  --  '}  "
              f"mean={mean:.4f} (n={len(fam[meth])}){tag}")

    d = {n.split()[0]: (o, w) for n, o, w, _, _ in rows}
    ctrl = next((x[1] for x in fam.get("hierfed_dp", []) if x[0] == 1), None)
    if ctrl is None and fam.get("hierfed_dp"):
        ctrl = sum(a for _, a in fam["hierfed_dp"]) / len(fam["hierfed_dp"])
    if "proposed" in d and ctrl is not None:
        pw = d["proposed"][1]
        po = d["proposed"][0]
        print(f"\n  margin vs the DP control (hierfed_dp = hierarchical + DP, "
              f"NO compression):")
        print(f"    hierfed_dp (seed1) : {ctrl:.4f}")
        if pw is not None:
            print(f"    proposed  (seed1)  : {pw:.4f}   ->  {pw - ctrl:+.4f}")
            if pw - ctrl > 0.03:
                print("    the compressed+DP method beats the uncompressed+DP one.")
            elif pw - ctrl > 0:
                print("    improvement is positive but small.")
            else:
                print("    !! proposed is BELOW the uncompressed DP control --")
                print("       check the epsilon budgets (python probe_eps_audit.py)")
        if po is not None:
            print(f"    (pre-fix proposed reference was {po:.4f})")

    bar("VERDICT")
    if not ok:
        print("  one or more gate jobs are missing, or a method got worse.")
        if improved == 0:
            print("  -> REVERT:  python fix_v11.py --revert")
        else:
            print("  -> inspect the logs before deciding.")
        return 1

    # margin between our method and the strongest compressed competitor
    d = {n.split()[0]: (o, w) for n, o, w, _, _ in rows}
    if "proposed" in d and "topk_qsgd" in d:
        po, pw = d["proposed"]
        to, tw = d["topk_qsgd"]
        if pw is not None and tw is not None:
            print(f"\n  margin (proposed - topk_qsgd):")
            if po is not None and to is not None:
                print(f"    before : {po - to:+.4f}   (0.9280 - 0.8668)")
            print(f"    after  : {pw - tw:+.4f}   ({pw:.4f} - {tw:.4f})")
            if po is not None and to is not None and (pw - tw) < (po - to) - 0.01:
                print("    !! careful: the OTHER method gained more than ours --")
                print("       the compression advantage SHRINKS.  Still a valid")
                print("       result, but the paper's framing must change from")
                print("       'compression beats X' to 'compression is ~free'.")

    if improved == len(rows):
        print("\n  both compressed methods improved -> PROCEED to the full re-run.")
        print("  (next step: I ship the batch script; S2 + eps + ablation all re-run)")
    else:
        print("\n  partial improvement -- send me this output before deciding.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
