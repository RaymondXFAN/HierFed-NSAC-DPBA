#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v15.py -- make the three code paths agree on PREPROCESSING, and let the
ablation run at a chosen epsilon.

WHY (measured, 2026-10-10)
--------------------------
The paper (P272) says the ONLY preprocessing is z-score normalisation:
    "The class distribution is imbalanced (93.6% attack, 6.4% normal). We apply
     z-score normalization and partition the data across N = 20 devices ..."
It never mentions minority oversampling.  But the three drivers disagree:

    run_baselines.py        -> config['oversample_minority'] = False   (hard)
    run_epsilon_sweep.py    -> config['oversample_minority'] = False   (hard)
    run_experiment.py       -> inherits configs/base.yaml
    configs/base.yaml       -> oversample_minority: true   (apply_config_A.sh, Route A)

So every ablation run (run_ablation -> run_experiment) used oversampling=True
while every baseline used False.  That alone accounts for the cross-tree gaps:

    hierfed_only 0.9968 (true)  vs  hierfed     0.9809 (false)   +0.0159
    hierfed_uni_dp 0.9282 (true) vs  hierfed_dp 0.8501 (false)   +0.0781

and for the mystery that 'full' (0.9654) != the epsilon sweep's own eps=400 point
(0.9705) at the SAME seed.  The simulator is bit-for-bit reproducible (two runs
of the same command gave 0.9795555421733675 twice), so that gap must be config.

WHAT THIS SCRIPT DOES
  1. configs/base.yaml : oversample_minority -> false   (matches the paper and
     the other two drivers; keeps every tree comparable)
  2. configs/base.yaml : drop the duplicated client_sample_rate line
  3. ablation_configs.py : relabel the two *_uni_dp arms, which claim
     "uniform DP C=1.0" but actually keep alpha_s/beta_s_coeff/gamma_s = 0.3/0.3/0.2
     and adaptive_clip in [0.05, 3.0] -> they are ADAPTIVE, not uniform
  4. run_ablation.py : add --epsilon, and print a [[fix_v15]] line proving it
     took effect (so a gate can assert on it, like fix_v14 did for baselines)

NOT done here (needs the DP consumer code, which is not in this repo copy):
  a genuine uniform-clip arm.  Do NOT guess the flags -- see README_V15.md.

Usage
    python fix_v15.py --check      # show what would change
    python fix_v15.py --apply      # apply (idempotent, makes .bak_v15 backups)
    python fix_v15.py --revert     # restore from .bak_v15
"""
import argparse
import os
import re
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / "configs" / "base.yaml"
ABLC = ROOT / "ablation_configs.py"
ABLR = ROOT / "run_ablation.py"
BAK = ".bak_v15"


def log(m):
    print("  " + m)


def backup(p):
    b = p.with_name(p.name + BAK)
    if not b.exists():
        shutil.copy2(p, b)
        log(f"backup  {p.name} -> {p.name}{BAK}")


def check_files():
    missing = [p.name for p in (BASE, ABLC, ABLR) if not p.exists()]
    if missing:
        print(f"[abort] not a project root -- missing {missing}")
        print(f"        cwd = {ROOT}")
        return False
    return True


# ------------------------------------------------------------------ 1 base.yaml
def base_edits(text):
    out = text
    # drop duplicate client_sample_rate lines (keep the first)
    lines = out.split("\n")
    seen, keep = set(), []
    dups = 0
    for ln in lines:
        m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*):", ln)
        if m and m.group(1) in seen and not ln.startswith("#"):
            dups += 1
            log(f"drop duplicate key: {ln.strip()[:60]}")
            continue
        if m:
            seen.add(m.group(1))
        keep.append(ln)
    out = "\n".join(keep)
    # oversample_minority -> false
    out, n = re.subn(
        r"^oversample_minority:\s*\S+.*$",
        "oversample_minority: false  # [fix_v15] paper P272 specifies z-score only;"
        " run_baselines.py/run_epsilon_sweep.py already hard-set false -- this makes"
        " run_experiment.py agree",
        out, flags=re.M)
    return out, n, dups


# ------------------------------------------- 3 ablation_configs.py relabelling
RELABLE_KEYS = ["hierfed_uni_dp", "hierfed_nsac_uni_dp"]
NEW_LABEL = {
    "hierfed_uni_dp":
        "HierFed + ADAPTIVE DP, FIM term removed (no NSAC) -- NOT uniform C=1.0"
        " [relabelled by fix_v15]",
    "hierfed_nsac_uni_dp":
        "HierFed + NSAC + ADAPTIVE DP, FIM term removed -- NOT uniform C=1.0"
        " [relabelled by fix_v15]",
}


def abl_edits(text):
    """relabel by KEY (regex, case-insensitive) -- the server copy spells the label
    differently ("UNIFORM DP C=1.0") than this repo's copy, so matching on the old
    label text silently failed.  Returns (text, n_relabelled, keys_present)."""
    n = 0
    present = 0
    for key, newlab in NEW_LABEL.items():
        if f'"{key}"' not in text:
            continue
        present += 1
        if f'"{newlab}"' in text:
            continue                                   # already relabelled
        pat = re.compile(
            r'("%s"\s*:\s*\(\s*)((?:"(?:[^"\\]|\\.)*"\s*)+)' % re.escape(key))
        m = pat.search(text)
        if not m:
            continue
        text = text[:m.start(2)] + f'"{newlab}"' + text[m.end(2):]
        n += 1
    return text, n, present


# --------------------------------------------------- 4 run_ablation.py --epsilon
EPS_ARG = '''    p.add_argument("--epsilon", type=float, default=None,
                   help="[fix_v15] override epsilon_total (run an ablation at a"
                        " chosen privacy budget)")
'''
EPS_APPLY = '''    if args.epsilon is not None:                     # [fix_v15]
        config_base["epsilon_total"] = args.epsilon
    print(f"[[fix_v15]] output_dir={args.output_dir} "
          f"epsilon_total={config_base.get('epsilon_total')} "
          f"oversample_minority={config_base.get('oversample_minority')} "
          f"T={config_base.get('T')}", flush=True)
'''


def ablr_edits(text):
    out, n = text, 0
    anchor = '    p.add_argument("--e_local", type=int, default=None,\n' \
             '                   help="override local epochs per round")\n'
    if "--epsilon" in out:
        pass
    elif anchor in out:
        out = out.replace(anchor, anchor + EPS_ARG)
        n += 1
    else:
        return text, 0, "anchor for --epsilon not found"
    anchor2 = "    os.makedirs(args.output_dir, exist_ok=True)\n"
    if "[[fix_v15]]" not in out:
        if anchor2 in out:
            out = out.replace(anchor2, anchor2 + EPS_APPLY)
            n += 1
        else:
            return text, 0, "anchor for the [[fix_v15]] print not found"
    return out, n, None


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  fix_v15 -- unify preprocessing across drivers + ablation epsilon")
    print("=" * 78)
    if not check_files():
        return 1

    if a.revert:
        for p in (BASE, ABLC, ABLR):
            b = p.with_name(p.name + BAK)
            if b.exists():
                shutil.copy2(b, p)
                log(f"restored {p.name}")
            else:
                log(f"no backup for {p.name} -- skipped")
        return 0

    # 1/2 base.yaml
    t = BASE.read_text(encoding="utf-8")
    nt, n1, n2 = base_edits(t)
    log(f"base.yaml        : oversample_minority edits={n1}, duplicate keys dropped={n2}")
    if n1 == 0:
        log("  !! could not find oversample_minority in configs/base.yaml")
        print("[abort] this check is fatal -- wrong file or wrong project root")
        return 1
    # 3 labels
    t2 = ABLC.read_text(encoding="utf-8")
    nt2, n3, n_present = abl_edits(t2)
    log(f"ablation_configs : labels relabelled={n3} (keys found={n_present}/2)")
    # 4 --epsilon
    t3 = ABLR.read_text(encoding="utf-8")
    nt3, n4, err = ablr_edits(t3)
    log(f"run_ablation.py  : --epsilon edits={n4}" + (f"  ERROR: {err}" if err else ""))
    if err:
        print("\n[abort] refusing to write run_ablation.py")
        return 1

    if a.check:
        print("\n  (check only -- nothing written)")
        return 0

    for p, new in ((BASE, nt), (ABLC, nt2), (ABLR, nt3)):
        if p.read_text(encoding="utf-8") != new:
            backup(p)
            p.write_text(new, encoding="utf-8")
            log(f"written  {p.name}")

    # ---------------------------------------------------------------- verify
    print("\n" + "=" * 78)
    print("  verify")
    print("=" * 78)
    ok = True
    bt = BASE.read_text(encoding="utf-8")
    m = re.search(r"^oversample_minority:\s*(\S+)", bt, flags=re.M)
    got = (m.group(1) if m else "?").rstrip(":")
    if got.lower().startswith("false"):
        log(f"[ok] base.yaml oversample_minority = {got}")
    else:
        log(f"[FAIL] base.yaml oversample_minority = {got}"); ok = False
    keys = re.findall(r"^([A-Za-z_][A-Za-z0-9_]*):", bt, flags=re.M)
    dup = {k for k in keys if keys.count(k) > 1}
    if dup:
        log(f"[FAIL] duplicate keys remain: {dup}"); ok = False
    else:
        log("[ok] no duplicate top-level keys in base.yaml")
    if "NOT uniform C=1.0" in ABLC.read_text(encoding="utf-8"):
        log("[ok] *_uni_dp arms are relabelled")
    else:
        log("[advise] *_uni_dp NOT relabelled -- cosmetic only, does NOT block."
            " (fix_v16 will still add the TRUE-uniform arms)")
    if "--epsilon" in ABLR.read_text(encoding="utf-8"):
        log("[ok] run_ablation.py accepts --epsilon")
    else:
        log("[FAIL] --epsilon missing"); ok = False
    # compile check
    import py_compile
    for p in (ABLC, ABLR):
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as e:
            log(f"[FAIL] {p.name} does not compile: {e}"); ok = False
    log("[ok] ablation_configs.py and run_ablation.py compile" if ok else "[FAIL] compile")
    print("\n  " + ("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED"))
    if ok:
        print("""
  next (after moving the old tree away so nothing is skipped):
     mv results_ablation results_ablation_cfgA_bak
     ABL_EPS=399 SKIP_WAIT=1 SUITES="component" bash run_rest_all.sh all
""")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
