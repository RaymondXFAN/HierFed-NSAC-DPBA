#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
diag_s2.py -- post-S2 diagnostics.  Non-blocking, no GPU.

    python diag_s2.py            # prints everything below, or:
    python diag_s2.py > diag.md  # then upload diag.md

Answers four questions:
  1. WHY did topk_qsgd_iotid20_alpha0.1_seed1..5 fail?   (child log tails)
  2. What compression budget does topk_qsgd actually use? (fairness of the C1 claim)
  3. The epsilon curve SPLIT BY ALPHA (the pooled n=10 hides the slope)
  4. The baseline table SPLIT BY ALPHA
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))
FAILED = "topk_qsgd"


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def load(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def auc(d):
    v = ((d or {}).get("final_metrics") or {}).get("auc_roc")
    return float(v) if isinstance(v, (int, float)) else None


def mean(v):
    v = [x for x in v if x is not None]
    return (sum(v) / len(v), len(v)) if v else (float("nan"), 0)


# ---------------------------------------------------------------- 1
def failed_logs():
    bar(f"1. why did {FAILED} alpha=0.1 fail?  (logs/jobs/)")
    pats = sorted(glob.glob(os.path.join(ROOT, "logs", "jobs", f"{FAILED}*.log")))
    print(f"  found {len(pats)} child logs for '{FAILED}'")
    for p in pats:
        txt = open(p, encoding="utf-8", errors="replace").read()
        err = [l for l in txt.splitlines()
               if re.search(r"Error|error:|Exception|Traceback|assert|RuntimeError|"
                            r"IndexError|ValueError|KeyError|shapes cannot", l)]
        print(f"\n  --- {os.path.basename(p)}  ({len(txt)} B) ---")
        if err:
            for l in err[-3:]:
                print("    ! " + l.strip()[:150])
        else:
            print("    (no error keyword; raw tail below)")
        for l in txt.strip().splitlines()[-8:]:
            print("      " + l[:150])


# ---------------------------------------------------------------- 2
def topk_budget():
    bar("2. what compression budget does topk_qsgd use?  (fairness check)")
    # (a) config recorded in its own results.json
    for p in sorted(glob.glob(os.path.join(ROOT, "results_baseline",
                                           f"{FAILED}_*/results.json")))[:1]:
        d = load(p) or {}
        print(f"  {os.path.relpath(p, ROOT)}")
        print(f"    config         : {json.dumps(d.get('config'), ensure_ascii=False)}")
        fm = d.get("final_metrics") or {}
        comp = {k: v for k, v in fm.items()
                if any(t in k.lower() for t in
                       ("compress", "bytes", "cr_", "ratio", "k_", "top", "empty",
                        "slice", "b_bits", "n_devices"))}
        print(f"    final_metrics compression-ish : {comp or '(none)'}")
        rm = d.get("round_metrics") or []
        if rm and isinstance(rm[-1], dict):
            print(f"    round_metrics keys: {sorted(rm[-1])}")
    # (b) the source
    try:
        src = open(os.path.join(ROOT, "baselines", "runner.py"), encoding="utf-8").read()
    except Exception:
        src = ""
    m = re.search(r"^def run_topk_qsgd\(.*?(?=^def |^# ={10,})", src, re.S | re.M)
    print("\n  --- run_topk_qsgd source (first 40 lines) ---")
    if m:
        for l in m.group(0).splitlines()[:40]:
            print("    " + l[:150])
    else:
        print("    !! run_topk_qsgd not found in baselines/runner.py")


# ---------------------------------------------------------------- 3
def eps_curve():
    bar("3. epsilon curve SPLIT BY ALPHA")
    tab = defaultdict(lambda: defaultdict(list))
    for p in sorted(glob.glob(os.path.join(ROOT, "results_eps", "*", "results.json"))):
        base = os.path.basename(os.path.dirname(p))
        m = re.match(r"epsweep_eps([\d.]+)_alpha([\d.]+)_seed(\d+)$", base)
        if not m:
            continue
        tab[float(m.group(2))][float(m.group(1))].append(auc(load(p)))
    alphas = sorted(tab)
    epsl = sorted({e for a in tab.values() for e in a})
    if not epsl:
        print("  (no results_eps found)")
        return
    hdr = "  eps   |" + "".join(f"{a:>14}" for a in alphas) + "   |  pooled"
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))
    for e in epsl:
        row = f"  {e:<6g}|"
        pooled = []
        for a in alphas:
            mu, n = mean(tab[a].get(e, []))
            pooled += tab[a].get(e, [])
            row += f"  {mu:.4f}(n={n})" if n else f"{'--':>14}"
        pmu, _ = mean(pooled)
        print(row + f"   |  {pmu:.4f}")
    for a in alphas:
        best = max(((mean(v)[0], e) for e, v in tab[a].items() if mean(v)[1]), default=None)
        if best:
            print(f"  alpha={a}: peak AUC {best[0]:.4f} at eps={best[1]:g}")


# ---------------------------------------------------------------- 4
def baseline_table():
    bar("4. baseline table SPLIT BY ALPHA")
    tab = defaultdict(lambda: defaultdict(list))
    for dname in sorted(glob.glob(os.path.join(ROOT, "results_baseline", "*"))):
        base = os.path.basename(dname)
        m = re.match(r"(.+)_iotid20_alpha([\d.]+)_seed(\d+)$", base)
        if not m:
            continue
        p = os.path.join(dname, "results.json")
        if os.path.exists(p):
            tab[float(m.group(2))][m.group(1)].append(auc(load(p)))
    alphas = sorted(tab)
    meths = sorted({m for a in tab.values() for m in a},
                   key=lambda m: -mean(tab[max(alphas, key=lambda x: len(tab[x]) == len(tab[max(alphas)]))][m])[0])
    print("  method                |" + "".join(f"{a:>16}" for a in alphas))
    print("  " + "-" * 66)
    for m in meths:
        row = f"  {m:<21} |"
        for a in alphas:
            mu, n = mean(tab[a].get(m, []))
            row += f"  {mu:.4f}(n={n})" if n else f"{'--':>16}"
        print(row)
    # also show raw ablation dir naming so we can confirm the convention
    print("\n  --- results_ablation dir names (first 15, for naming check) ---")
    adirs = sorted(os.path.basename(d) for d in glob.glob(os.path.join(ROOT, "results_ablation", "*")))
    for d in adirs[:15]:
        print("    " + d)
    print(f"    ... ({len(adirs)} total)")


def main():
    print("=" * 78)
    print("  HierFed post-S2 diagnostics")
    print("=" * 78)
    failed_logs()
    topk_budget()
    eps_curve()
    baseline_table()
    print("\n" + "=" * 78)
    print("  -> upload this whole output to Mihiro")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
