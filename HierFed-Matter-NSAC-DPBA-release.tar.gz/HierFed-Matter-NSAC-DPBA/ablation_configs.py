"""
ablation_configs.py -- ablation/weight configurations (no heavy imports).

Kept dependency-free so that drivers (run_ablation.py, run_parallel.py) can build
their job lists without importing torch.
"""

# tag: (human label, override dict for run_experiment.py)
COMPONENT_CONFIGS = {
    "full": (
        "HierFed + NSAC + DPBA-FIM (proposed)",
        {},
    ),
    "hierfed_only": (
        "HierFed only (no NSAC, no DP)",
        {"disable_nsac": True, "disable_dp": True},
    ),
    "hierfed_nsac": (
        "HierFed + NSAC (no DP)",
        {"disable_dp": True},
    ),
    "hierfed_dpba": (
        "HierFed + DPBA-FIM (no NSAC)",
        {"disable_nsac": True},
    ),
    "hierfed_uni_dp": (
        "HierFed + ADAPTIVE DP, FIM term removed (no NSAC) -- NOT uniform C=1.0 [relabelled by fix_v15]",
        {"disable_nsac": True, "disable_dpba_fim": True},
    ),
    "hierfed_nsac_uni_dp": (
        "HierFed + NSAC + ADAPTIVE DP, FIM term removed -- NOT uniform C=1.0 [relabelled by fix_v15]",
        {"disable_dpba_fim": True},
    ),
    "hierfed_uni_dp_true": (
        "[CONTROL] HierFed + TRUE uniform DP: C_i = clip_norm for every device"
        " (dp_clip_mode=global), no NSAC, no FIM",
        {"disable_nsac": True, "disable_dpba_fim": True, "dp_clip_mode": "global"},
    ),
    "hierfed_nsac_uni_dp_true": (
        "[CONTROL] HierFed + NSAC + TRUE uniform DP: C_i = clip_norm for every"
        " device (dp_clip_mode=global), no FIM",
        {"disable_dpba_fim": True, "dp_clip_mode": "global"},
    ),
}

# tag: (human label, override dict with explicit Eq.7 sensitivity weights)
WEIGHT_CONFIGS = {
    "w_full": (
        "all terms (0.3,0.3,0.2,0.2)",
        {"alpha_s": 0.3, "beta_s_coeff": 0.3, "gamma_s": 0.2, "delta_s": 0.2},
    ),
    "w_fim_only": (
        "FIM only (0,0,0,1)",
        {"alpha_s": 0.0, "beta_s_coeff": 0.0, "gamma_s": 0.0, "delta_s": 1.0},
    ),
    "w_type_only": (
        "device-type only (1,0,0,0)",
        {"alpha_s": 1.0, "beta_s_coeff": 0.0, "gamma_s": 0.0, "delta_s": 0.0},
    ),
    "w_size_only": (
        "data-volume only (0,1,0,0)",
        {"alpha_s": 0.0, "beta_s_coeff": 1.0, "gamma_s": 0.0, "delta_s": 0.0},
    ),
    "w_het_only": (
        "heterogeneity only (0,0,1,0)",
        {"alpha_s": 0.0, "beta_s_coeff": 0.0, "gamma_s": 1.0, "delta_s": 0.0},
    ),
    "w_no_fim": (
        "no FIM term (0.3,0.3,0.2,0)",
        {"alpha_s": 0.3, "beta_s_coeff": 0.3, "gamma_s": 0.2, "delta_s": 0.0},
    ),
}

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
