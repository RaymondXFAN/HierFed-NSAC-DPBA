#!/bin/bash
# ============================================================
# HierFed-Matter v7 全实验一键运行脚本
# EN: HierFed-Matter v7 one-click script to run all experiments.
# GPU + RDP composition + FedProx fix
# ============================================================
# 使用方式：nohup bash run-all.sh > run-all.log 2>&1 &
# EN: usage: nohup bash run-all.sh > run-all.log 2>&1 &
# 监控进度：tail -f run-all.log
# EN: progress: tail -f run-all.log
# ============================================================

set -e
cd /root/autodl-tmp/hierfed-matter

echo "========================================="
echo "v7 GPU+RDP 全实验开始"
echo "时间: $(date)"
echo "GPU: $(python -c 'import torch; print(torch.cuda.get_device_name() if torch.cuda.is_available() else \"CPU ONLY\")')"
echo "========================================="

# Step 0: 环境验证 (30秒)
# EN: Step 0: environment check (30 s)
echo ""
echo "[Step 0] 环境验证..."
python -c "
import torch
print(f'PyTorch: {torch.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'GPU: {torch.cuda.get_device_name()}')
    print(f'VRAM: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB')
import numpy as np
import sklearn
print(f'NumPy: {np.__version__}')
print(f'Sklearn: {sklearn.__version__}')
print('✅ 环境OK')
"

# Step 1: 数据预处理验证 (1分钟)
# EN: Step 1: data-preprocessing check (1 min)
echo ""
echo "[Step 1] 数据预处理验证..."
python -c "
import numpy as np, os
processed_dir = 'data/processed'
train = np.load(os.path.join(processed_dir, 'iotid20_train.npz'))
test = np.load(os.path.join(processed_dir, 'iotid20_test.npz'))
print(f'Train: X={train[\"X\"].shape}, y={train[\"y\"].shape}')
print(f'Test: X={test[\"X\"].shape}, y={test[\"y\"].shape}')
print(f'Class dist: attack={np.sum(train[\"y\"]==0)}, normal={np.sum(train[\"y\"]==1)}')
print('✅ 数据OK')
"

# Step 2: GPU快速测试 (5分钟)
# EN: Step 2: quick GPU test (5 min)
echo ""
echo "[Step 2] GPU快速测试 — FedAvg 1 seed, 10 rounds..."
python run_baselines.py --method fedavg --alpha 0.5 --seeds 1 --output_dir results_test
echo "✅ GPU测试完成（检查results_test目录）"

# Step 3: Table 4 Baselines (40 runs, ~4-6小时)
# EN: Step 3: Table 4 Baselines (40 runs, ~4-6 h)
echo ""
echo "[Step 3] Table 4 Baselines — 40 runs..."
echo "预计耗时: 4-6小时 (RTX 4090 GPU加速)"
python -u run_baselines.py --method all --alpha 0.5 0.1 --seeds 1 2 3 4 5 --output_dir results
echo "✅ Baselines完成"

# Step 4: Baseline结果聚合
# EN: Step 4: aggregate baseline results
echo ""
echo "[Step 4] Baseline结果聚合..."
python run_baselines.py --aggregate_only --output_dir results
echo "✅ Baselines聚合完成"

# Step 5: ε-sweep实验 (70 runs, ~7-10小时)
# EN: Step 5: ε-sweep experiment (70 runs, ~7-10 h)
echo ""
echo "[Step 5] ε-sweep — 7个ε × 2α × 5seeds = 70 runs..."
echo "预计耗时: 7-10小时"
python -u run_epsilon_sweep.py --alpha 0.5 0.1 --seeds 1 2 3 4 5 --output_dir results
echo "✅ ε-sweep完成"

# Step 6: ε-sweep结果聚合
# EN: Step 6: aggregate ε-sweep results
echo ""
echo "[Step 6] ε-sweep结果聚合..."
python run_epsilon_sweep.py --aggregate_only --output_dir results
echo "✅ ε-sweep聚合完成"

# Step 7: Focal Loss实验 (最关键！AUC≥0.75目标)
# EN: Step 7: Focal Loss experiment (the most critical! target AUC >= 0.75)
echo ""
echo "[Step 7] Focal Loss — centralized + FedAvg + proposed..."
echo "预计耗时: 2-4小时"
python -u run_focal_loss.py --mode all --gamma 0.5 1.0 2.0 --seeds 1 2 3 4 5 --output_dir results
echo "✅ Focal Loss完成"

# Step 8: 最终汇总
# EN: Step 8: final summary
echo ""
echo "[Step 8] 最终汇总..."
echo "========================================="
echo "所有实验完成！"
echo "时间: $(date)"
echo ""
echo "结果文件位置:"
echo "  Baselines: results/table4_baselines.json"
echo "  ε-sweep:   results/privacy_utility_curve.json"
echo "  Focal:     results/focal_loss_summary.json"
echo ""
echo "请用以下命令查看结果:"
echo "  python run_baselines.py --aggregate_only"
echo "  python run_epsilon_sweep.py --aggregate_only"
echo "========================================="

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
