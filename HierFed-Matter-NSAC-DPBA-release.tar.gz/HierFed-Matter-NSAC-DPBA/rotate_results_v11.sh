#!/usr/bin/env bash
# rotate_results_v11.sh -- archive the pre-[fix_v11] result trees.
#
# run_parallel.py decides "already done" by looking for the per-run output file,
# so the old results MUST be moved aside or the whole batch is skipped.
#
#     bash rotate_results_v11.sh
#     PAR=4 bash run_s2.sh                      # base + eps   (~7-8 h)
#   or a fuller sweep:
#     nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 \
#           --suites abl base eps > logs/parallel_v11.log 2>&1 &
#
# Nothing is deleted: everything goes to archive_pre_v11_<timestamp>/.
set -u
cd "$(dirname "$0")" || exit 1

[ -f run_parallel.py ] || {
  echo "!! run_parallel.py not found.  Copy this script into the project root:"
  echo "   cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA"
  echo "   cp /tmp/hierfed_post_s2/rotate_results_v11.sh ."
  exit 1
}

STAMP="$(date +%Y%m%d_%H%M)"
DEST="archive_pre_v11_${STAMP}"
mkdir -p "$DEST" || exit 1

echo "== archiving pre-v11 results -> $DEST =="
n=0
for d in results results_baseline results_ablation results_eps results_scale results_summary; do
  if [ -e "$d" ]; then
    mv "$d" "$DEST/" && { echo "   moved  $d"; n=$((n + 1)); }
  else
    echo "   skip   $d (absent)"
  fi
done
echo "   $n item(s) archived."
echo
echo "== how to get them back (if you need to roll back) =="
echo "   for d in $DEST/*; do mv \"\$d\" . ; done"
echo
echo "== then relaunch =="
echo "   PAR=4 bash run_s2.sh"
echo "   # monitor (non-blocking):"
echo "   tail -n 8 logs/parallel_s2.log"
echo "   grep -c '] ok ' logs/parallel_s2.log ; grep -c 'FAIL' logs/parallel_s2.log"
echo "   ls logs/jobs | wc -l"
exit 0

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
