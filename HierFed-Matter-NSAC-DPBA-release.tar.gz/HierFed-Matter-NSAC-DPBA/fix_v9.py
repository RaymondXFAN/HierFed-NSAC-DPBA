#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v9.py -- Direction-A patches for HierFed-NSAC.

Design rule (zero plumbing risk)
--------------------------------
Every new feature is activated by an **environment variable, falling back to a
config key**. Defaults reproduce the current behaviour exactly, so nothing that
is already running can change. No change to run_experiment.py's argparse is
needed -- the grid driver just exports env vars per run.

Three modes
-----------
    python fix_v9.py --probe      # print the code regions still needed for C-2/C-3
    python fix_v9.py --selftest   # pure-python check of the allocation maths (no torch)
    python fix_v9.py              # apply the patches (idempotent)

What it patches
---------------
C-5  baselines/runner.py : dataset npz prefix hard-coded to 'iotid20'/'cicids'
                           -> gotham25 / tii23 look for cicids_test.npz and fail.
C-1a core/hierfed.py     : hierfed_matter_round() gains `uniform_slice=None`
                           -> all gateways use ONE slice config (uniform-allocation arm)
C-1b core/nsac.py        : make_uniform_slice() -- byte-matched uniform config
C-4  core/nsac.py        : configure_slices() + slices_from_env()  (CR scan entry)
C-1c core/simulator.py   : read nsac_mode / cr_scale / k_* overrides, build the
                           uniform config once d is known, pass it into the round

Still pending (needs `--probe` output; these touch the v7-modified DP block)
--------------------------------------------------------------------------
C-2  per-slice DP budget allocation      (epsilon_mode)
C-3  data-driven device -> slice mapping (slice_map_mode)
"""
import argparse
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BAK = ".bak_v9"
report = []


def note(tag, status, detail=""):
    report.append((tag, status, detail))
    mark = {"ok": "  [ok]  ", "skip": " [skip] ", "FAIL": " [FAIL] ", "todo": " [todo] "}[status]
    print(f"{mark}{tag}  {detail}")


def read(rel):
    with open(os.path.join(ROOT, rel), encoding="utf-8") as f:
        return f.read()


def backup(rel):
    src = os.path.join(ROOT, rel)
    if not os.path.exists(src + BAK):
        shutil.copy2(src, src + BAK)


def write(rel, text):
    backup(rel)
    with open(os.path.join(ROOT, rel), "w", encoding="utf-8") as f:
        f.write(text)


def sub(rel, pattern, repl, tag, count=0, flags=0, already=None, required=True):
    src = read(rel)
    if already and already in src:
        note(tag, "skip", "already applied")
        return False
    if not re.search(pattern, src, flags):
        note(tag, "FAIL" if required else "skip", "anchor not found -- CHECK MANUALLY")
        return False
    new, n = re.subn(pattern, repl, src, count=count, flags=flags)
    write(rel, new)
    note(tag, "ok", f"{n} site(s) patched")
    return True


# ============================================================================
# C-5 : dataset npz prefix
# ============================================================================
HELPER_C5 = '''

def _resolve_prefix(processed_dir, ds):
    """Map a dataset name to the prefix of its npz files.

    The historical code used `'iotid20' if ds == 'iotid20' else 'cicids'`, which
    sends every other dataset (gotham25, tii23, ...) looking for cicids_*.npz.
    Prefer the dataset's own name when such a file exists.
    """
    if os.path.exists(os.path.join(processed_dir, f'{ds}_test.npz')):
        return ds
    if os.path.exists(os.path.join(processed_dir, f'{ds}_train.npz')):
        return ds
    return 'iotid20' if ds == 'iotid20' else 'cicids'
'''


def fix_c5():
    rel = "baselines/runner.py"
    if "_resolve_prefix" in read(rel):
        note("C-5 npz prefix", "skip", "already applied")
        return
    pat = re.compile(r"^(\s*)prefix = 'iotid20' if ds == 'iotid20' else 'cicids'\s*$", re.M)
    src = read(rel)
    n = len(pat.findall(src))
    if n == 0:
        note("C-5 npz prefix", "FAIL", "prefix line not found in baselines/runner.py")
        return
    new = pat.sub(lambda m: f"{m.group(1)}prefix = _resolve_prefix(processed_dir, ds)", src)
    # insert the helper right before _load_partitioned_data
    anchor = "def _load_partitioned_data(config):"
    if anchor in new:
        new = new.replace(anchor, HELPER_C5.strip() + "\n\n\n" + anchor, 1)
    else:
        note("C-5 npz prefix", "FAIL", "helper insertion anchor not found")
        return
    write(rel, new)
    note("C-5 npz prefix", "ok", f"{n} call site(s) + helper inserted")


# ============================================================================
# C-1b / C-4 : nsac.py helpers
# ============================================================================
NSAC_HELPERS = '''

# ============================================================
# v9: allocation modes (Direction A)
# ============================================================
def make_uniform_slice(slice_names, d, b_bits=8, name='uniform'):
    """Byte-matched *uniform* SliceConfig (the control arm).

    `slice_names` = the slice names actually assigned to the gateways in the
    slice-aware arm.  The returned config uses a single (k, b) for every client
    and is solved so that the per-client payload equals the slice-aware arm's
    MEAN payload, i.e. the total uplink budget is preserved.  This makes
    "uniform vs slice-aware" an apples-to-apples comparison.

    payload(k, b) = k*4 + k*(b//8)      (indices 4 B each + quantised values)
    """
    tot = 0.0
    for s in slice_names:
        cfg = SLICE_CONFIGS[s]
        k = max(1, int(cfg.k_ratio * d))
        tot += k * 4 + k * (cfg.b_bits // 8)
    mean_bytes = tot / max(1, len(slice_names))
    k_u = mean_bytes / (4.0 + b_bits / 8.0)
    k_ratio = max(1e-6, min(1.0, k_u / float(d)))
    bw = sum(SLICE_CONFIGS[s].BW_mbps for s in slice_names) / max(1, len(slice_names))
    return SliceConfig(name=name, k_ratio=k_ratio, b_bits=b_bits,
                       BW_mbps=bw, L_max_ms=1000.0, proc_ms=8.0)


def configure_slices(cr_scale=1.0, k_overrides=None, bits_overrides=None,
                     verbose=True):
    """v9: scale / override the per-slice compression settings in place.

    CR_s = k_ratio * b_bits / 32, so scaling k_ratio scales CR.
    Used by the CR x C grid (P2) and by the CR-scan driver.
    """
    cr_scale = float(cr_scale)
    for key, cfg in SLICE_CONFIGS.items():
        if k_overrides and str(key) in k_overrides and k_overrides[str(key)] is not None:
            cfg.k_ratio = float(k_overrides[str(key)])
        elif cr_scale != 1.0:
            cfg.k_ratio = max(1e-6, min(1.0, cfg.k_ratio * cr_scale))
        if bits_overrides and str(key) in bits_overrides and bits_overrides[str(key)] is not None:
            cfg.b_bits = int(bits_overrides[str(key)])
    if verbose:
        print("[NSAC] slice configs (v9): " + ", ".join(
            f"{k}: k={c.k_ratio:.4f}, b={c.b_bits}, CR={c.CR:.4f}"
            for k, c in SLICE_CONFIGS.items()))


def slices_from_env(env=None):
    """Build the configure_slices() kwargs from the environment."""
    e = os.environ if env is None else env

    def _f(name):
        v = e.get(name)
        try:
            return float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    return dict(
        cr_scale=(_f('NSAC_CR_SCALE') if _f('NSAC_CR_SCALE') is not None else 1.0),
        k_overrides={'urllc': _f('NSAC_K_URLLC'), 'embb': _f('NSAC_K_EMBB'),
                     'mmtc': _f('NSAC_K_MMTC')},
        bits_overrides={'urllc': _f('NSAC_BITS_URLLC'), 'embb': _f('NSAC_BITS_EMBB'),
                        'mmtc': _f('NSAC_BITS_MMTC')},
    )
'''


def fix_c1b():
    rel = "core/nsac.py"
    if "def make_uniform_slice" in read(rel):
        note("C-1b make_uniform_slice", "skip", "already applied")
        return
    src = read(rel)
    m = re.search(r"^def nsac_compress\(", src, flags=re.M)
    if not m:
        note("C-1b make_uniform_slice", "FAIL", "nsac_compress anchor not found")
        return
    write(rel, src[:m.start()] + NSAC_HELPERS.strip() + "\n\n\n" + src[m.start():])
    note("C-1b make_uniform_slice", "ok", "helpers inserted before nsac_compress")


# ============================================================================
# C-1a : hierfed.py -- uniform_slice parameter
# ============================================================================
def fix_c1a():
    rel = "core/hierfed.py"
    sub(rel,
        r"(def hierfed_matter_round\(\n(?:.*\n)*?    enable_nsac: bool = True,\n)",
        r"\1    uniform_slice=None,          # v9: byte-matched uniform-allocation arm\n",
        "C-1a hierfed signature", already="uniform_slice=None,")

    sub(rel,
        r"        if enable_nsac:\n"
        r"            slice_name = slice_assignments\.get\(gw_id, 'embb'\)\n"
        r"            slice_config = SLICE_CONFIGS\[slice_name\]\n",
        r"""        if enable_nsac:
            if uniform_slice is not None:   # v9: uniform-allocation arm
                slice_config = uniform_slice
            else:
                slice_name = slice_assignments.get(gw_id, 'embb')
                slice_config = SLICE_CONFIGS[slice_name]
""",
        "C-1a hierfed body", already="if uniform_slice is not None:")


# ============================================================================
# C-1c / C-4b : simulator.py activation
# ============================================================================
def fix_c1c():
    rel = "core/simulator.py"

    # import the new helpers
    sub(rel,
        r"from core\.nsac import SLICE_CONFIGS, compute_communication_stats",
        "from core.nsac import (SLICE_CONFIGS, compute_communication_stats,\n"
        "                       make_uniform_slice, configure_slices, slices_from_env)",
        "C-1c import helpers", already="make_uniform_slice, configure_slices")

    # read the mode + apply the CR scan config, right after enable_nsac is set
    sub(rel,
        r"(\n        self\.enable_nsac = bool\(config\.get\('enable_nsac',\n"
        r"                                           not config\.get\('disable_nsac', False\)\)\)\n)",
        r"""\1
        # --- v9 (Direction A): allocation modes, env-first, config fallback ---
        self.nsac_mode = str(os.environ.get(
            'NSAC_MODE', config.get('nsac_mode', 'slice'))).lower()
        if self.nsac_mode not in ('slice', 'uniform'):
            raise ValueError("nsac_mode must be 'slice' or 'uniform', got %r" % self.nsac_mode)
        self.uniform_bits = int(os.environ.get(
            'NSAC_UNIFORM_BITS', config.get('nsac_uniform_bits', 8)))
        _sv = slices_from_env()
        _use = (abs(_sv['cr_scale'] - 1.0) > 1e-12
                or any(v is not None for v in _sv['k_overrides'].values())
                or any(v is not None for v in _sv['bits_overrides'].values()))
        if _use:
            configure_slices(**_sv)
        print("[v9] nsac_mode=%s, uniform_bits=%d" % (self.nsac_mode, self.uniform_bits))
""",
        "C-1c mode reads", already="self.nsac_mode = str(")

    # build the uniform config once d is known (inside run(), before the round loop)
    sub(rel,
        r"(        print\(f\"\{'='\*60\}\\n\"\)\n\n        all_results = \[\]\n)",
        r"""        # --- v9: build the byte-matched uniform config once d is known ---
        uniform_slice = None
        if self.enable_nsac and self.nsac_mode == 'uniform':
            uniform_slice = make_uniform_slice(
                list(self.slice_assignments.values()), self.d,
                b_bits=self.uniform_bits)
            _names = list(self.slice_assignments.values())
            _slice_bytes = sum(
                max(1, int(SLICE_CONFIGS[s].k_ratio * self.d)) *
                (4 + SLICE_CONFIGS[s].b_bits // 8) for s in _names)
            _uni_bytes = len(_names) * (
                max(1, int(uniform_slice.k_ratio * self.d)) *
                (4 + uniform_slice.b_bits // 8))
            print("[v9] UNIFORM arm: k_ratio=%.4f CR=%.4f | budget slice=%dB vs "
                  "uniform=%dB (ratio %.4f)"
                  % (uniform_slice.k_ratio, uniform_slice.CR, _slice_bytes,
                     _uni_bytes, _uni_bytes / max(1, _slice_bytes)))

\1""",
        "C-1c uniform build", already="uniform_slice = None")

    # pass it into the round
    sub(rel,
        r"(                    enable_nsac=self\.enable_nsac,\n)(                \))",
        r"\1                    uniform_slice=uniform_slice,\n\2",
        "C-1c pass to round", already="uniform_slice=uniform_slice,")


# ============================================================================
# probe / selftest
# ============================================================================
PROBE = [
    ("core/simulator.py : __init__ around slice assignment + enable_nsac", r"assign_slice_to_gateways|enable_nsac", 12),
    ("core/simulator.py : the per-device DP noise injection (v7 territory)", r"argsort|sigma_i|per_device|clip_grad|noise =", 14),
    ("core/simulator.py : partition construction", r"dirichlet_partition|self\.partitions", 8),
    ("core/nsac.py : compute_communication_stats", r"def compute_communication_stats", 25),
    ("run_experiment.py : argparse + config assembly", r"add_argument|Config\(|config\[", 10),
]


def do_probe():
    print("[probe] printing the regions still needed for C-2 / C-3\n")
    for title, pat, ctx in PROBE:
        p = os.path.join(ROOT, title.split(" : ")[0].strip())
        print("=" * 78)
        print("##", title)
        print("=" * 78)
        if not os.path.exists(p):
            print("  !! file not found:", p)
            continue
        lines = open(p, encoding="utf-8").read().splitlines()
        hits = [i for i, l in enumerate(lines) if re.search(pat, l)]
        if not hits:
            print(f"  !! no line matches /{pat}/")
            continue
        shown = set()
        for h in hits[:6]:
            a, b = max(0, h - ctx), min(len(lines), h + ctx + 1)
            if any(i in shown for i in range(a, b)):
                continue
            shown.update(range(a, b))
            for i in range(a, b):
                print(f"{i + 1:5d}| {lines[i]}")
            print("      ...")
    print("=" * 78)
    print("[probe] paste everything above back to Mihiro")


def do_selftest():
    """Pure-python check of make_uniform_slice's budget matching (no torch needed)."""
    import types
    if "torch" not in sys.modules:
        t = types.ModuleType("torch")
        t.__path__ = []                       # behave like a package

        class _T:
            pass
        t.Tensor = _T
        for _sub in ("nn", "optim", "utils", "cuda"):
            m = types.ModuleType(f"torch.{_sub}")
            m.__path__ = []
            setattr(t, _sub, m)
            sys.modules[f"torch.{_sub}"] = m
        sys.modules["torch"] = t

    p = os.path.join(ROOT, "core", "nsac.py")
    ns = {"__name__": "nsac_selftest", "__file__": p}
    try:
        exec(compile(open(p, encoding="utf-8").read(), p, "exec"), ns)
    except Exception as e:  # noqa: BLE001
        print(f"[selftest] cannot exec core/nsac.py ({e!r})")
        return 1

    SC = ns.get("SLICE_CONFIGS")
    mus = ns.get("make_uniform_slice")
    cfs = ns.get("configure_slices")
    if not (SC and mus and cfs):
        print("[selftest] v9 helpers missing -- run `python fix_v9.py` first")
        return 1

    ok = True
    d = 7762
    for names in (["urllc", "embb", "mmtc", "embb"],
                  ["urllc", "urllc", "urllc"],
                  ["mmtc", "mmtc"],
                  ["embb"]):
        sl = sum(max(1, int(SC[s].k_ratio * d)) * (4 + SC[s].b_bits // 8) for s in names)
        uc = mus(names, d, b_bits=8)
        un = len(names) * (max(1, int(uc.k_ratio * d)) * (4 + uc.b_bits // 8))
        dev = abs(un - sl) / max(1, sl)
        if dev >= 0.02:
            ok = False
        print(f"  [{'ok ' if dev < 0.02 else 'BAD'}] {str(names):38s} "
              f"slice={sl:6d}B uniform={un:6d}B dev={dev * 100:5.2f}%  "
              f"(k_ratio={uc.k_ratio:.4f}, CR={uc.CR:.4f})")

    before = {k: c.k_ratio for k, c in SC.items()}
    cfs(cr_scale=0.5, verbose=False)
    for k, c in SC.items():
        if abs(c.k_ratio - before[k] * 0.5) > 1e-12:
            print(f"  [BAD] configure_slices cr_scale: {k} {c.k_ratio} != {before[k] * 0.5}")
            ok = False
    cfs(cr_scale=2.0, verbose=False)
    for k, c in SC.items():
        if abs(c.k_ratio - before[k]) > 1e-12:
            print(f"  [BAD] configure_slices restore: {k} {c.k_ratio} != {before[k]}")
            ok = False
    print(f"  [{'ok ' if ok else 'BAD'}] configure_slices cr_scale round-trip")
    print(f"\n[selftest] {'PASS' if ok else 'FAIL'}")
    return 0 if ok else 1


# ============================================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    args = ap.parse_args()

    print(f"[fix_v9] project root = {ROOT}")
    for must in ("core/nsac.py", "core/hierfed.py", "core/simulator.py", "baselines/runner.py"):
        if not os.path.exists(os.path.join(ROOT, must)):
            print(f"[fix_v9] !! {must} not found -- run me from the project root")
            sys.exit(1)

    if args.probe:
        do_probe()
        return
    if args.selftest:
        sys.exit(do_selftest())

    fix_c5()
    fix_c1b()
    fix_c1a()
    fix_c1c()

    print("\n[fix_v9] py_compile ...")
    bad = 0
    for f in ("core/nsac.py", "core/hierfed.py", "core/simulator.py", "baselines/runner.py"):
        r = subprocess.run([sys.executable, "-m", "py_compile", os.path.join(ROOT, f)],
                           capture_output=True, text=True)
        print(f"  [{'ok' if r.returncode == 0 else 'FAIL'}] {f}")
        if r.returncode:
            print(r.stderr)
            bad += 1

    print("\n[fix_v9] residual audit")
    print("  make_uniform_slice present :", "def make_uniform_slice" in read("core/nsac.py"))
    print("  uniform_slice wired        :", "uniform_slice=uniform_slice," in read("core/simulator.py"))
    print("  _resolve_prefix present    :", "_resolve_prefix" in read("baselines/runner.py"))

    note("C-2 per-slice DP budget", "todo", "run `python fix_v9.py --probe` and send the output")
    note("C-3 data-driven slice map", "todo", "same -- touches the v7-modified partition/DP block")

    nf = sum(1 for _t, s, _d in report if s == "FAIL")
    print(f"\n[fix_v9] {'ALL PATCHES OK (C-2/C-3 pending probe)' if not nf else f'{nf} PATCH(ES) FAILED'}"
          f"  -- backups: <file>{BAK}")
    if bad or nf:
        sys.exit(1)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
