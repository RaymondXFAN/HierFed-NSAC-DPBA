#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v14.py -- give run_baselines.py a --epsilon override, and make every
baseline run RECORD its epsilon so the table can never be mis-read again.

    python fix_v14.py            # DRY RUN (shows the exact edits)
    python fix_v14.py --apply    # patch (backup .bak_v14)
    python fix_v14.py --revert

WHY
---
1. run_baselines.py has no --epsilon and no --config; every baseline reads
   `config.get('epsilon_total', 3.0)`.  So the epsilon can only be changed by
   editing configs/base.yaml -- which is EXACTLY what must not happen while a
   batch is running, because every job re-reads that file at start-up.

2. run_single() saves `results['config']` without epsilon, which is why the
   audit had to fall back to grepping sigma out of the logs.  Adding the value
   makes every results.json self-describing.

BACKWARD COMPATIBILITY
----------------------
With --epsilon absent, nothing changes: argparse keeps the default and the
config is untouched.  Safe to apply while a batch is in flight.
"""
import argparse
import os
import py_compile
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGET = os.path.join(HERE, "run_baselines.py")
MARK = "[fix_v14]"

ANCHOR_CFG = re.compile(
    r"(?P<i>[ \t]*)results\['config'\]\s*=\s*\{\s*\n"
    r"(?P<body>(?:[ \t]*'[^']+'\s*:[^\n]*\n)+?)(?P<close>[ \t]*\})")
ANCHOR_LOAD = re.compile(r"^(?P<i>[ \t]*)config_base\s*=\s*load_config\([^\n]*\)\s*$",
                         re.M)
ANCHOR_ARGS = re.compile(r"^(?P<i>[ \t]*)args\s*=\s*parser\.parse_args\(\)\s*$", re.M)
ANCHOR_ARGP = re.compile(r"^(?P<i>[ \t]*)parser\.add_argument\('--output_dir'[^\n]*\n",
                         re.M)
ANCHOR_HDR = re.compile(
    r"^(?P<i>[ \t]*)start_time\s*=\s*datetime\.now\(\)\s*$", re.M)


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def show():
    bar("current run_baselines.py -- the three places that get edited")
    src = open(TARGET, encoding="utf-8").read()
    for name, rx in (("results['config'] block", ANCHOR_CFG),
                     ("config_base = load_config()", ANCHOR_LOAD),
                     ("parser.add_argument('--output_dir'...)", ANCHOR_ARGP)):
        m = rx.search(src)
        print(f"\n  [{('FOUND' if m else 'MISSING')}] {name}")
        if m:
            for l in m.group(0).splitlines():
                print("      " + l)
    print(f"\n  already patched: {MARK in src}")


def apply():
    bar("applying [fix_v14]")
    src = open(TARGET, encoding="utf-8").read()
    if MARK in src:
        print(f"  [skip] {MARK} already applied")
        return 0
    edits, notes = src, []

    # 1 -- record epsilon in the saved config ------------------------------
    m = ANCHOR_CFG.search(edits)
    if not m:
        print("  !! results['config'] block not found")
        return 1
    indent = m.group("i") + "    "
    body = m.group("body")
    if body.rstrip().endswith(","):
        newbody = body + f"{indent}'epsilon_total': config.get('epsilon_total'),  "
        newbody += f"# {MARK}\n"
    else:
        newbody = body.rstrip() + ",\n"
        newbody += f"{indent}'epsilon_total': config.get('epsilon_total'),  # {MARK}\n"
    edits = edits[:m.start("body")] + newbody + edits[m.end("body"):]
    notes.append("run_single(): results['config'] now records epsilon_total")

    # 2 -- CLI flag -------------------------------------------------------
    m = ANCHOR_ARGP.search(edits)
    if not m:
        print("  !! --output_dir argument not found")
        return 1
    ind = m.group("i")
    edits = (edits[:m.end()] +
             f"{ind}parser.add_argument('--epsilon', type=float, default=None,\n"
             f"{ind}                    help='override epsilon_total "
             f"({MARK})')\n"
             f"{ind}parser.add_argument('--config', default='configs/base.yaml',\n"
             f"{ind}                    help='base config yaml ({MARK})')\n"
             + edits[m.end():])
    notes.append("main(): added --epsilon / --config")

    # 3 -- apply the override right after load_config ----------------------
    m = ANCHOR_LOAD.search(edits)
    if not m:
        print("  !! 'config_base = load_config()' not found")
        return 1
    ind = m.group("i")
    edits = (edits[:m.end()] +
             f"\n{ind}if getattr(args, 'config', None):\n"
             f"{ind}    config_base = load_config(args.config)\n"
             f"{ind}if getattr(args, 'epsilon', None) is not None:\n"
             f"{ind}    config_base['epsilon_total'] = float(args.epsilon)\n"
             f"{ind}    print(f\"[{MARK}] epsilon_total overridden -> "
             f"{{config_base['epsilon_total']}}\")" +
             edits[m.end():])
    notes.append("main(): --config / --epsilon take effect")

    # 4 -- make every job announce its epsilon ----------------------------
    m = ANCHOR_HDR.search(edits)
    if m:
        ind = m.group("i")
        edits = (edits[:m.end()] +
                 f"\n{ind}print(f\"[{MARK}] {{exp_name}} epsilon_total="
                 f"{{config.get('epsilon_total')}} clip_norm="
                 f"{{config.get('clip_norm')}} delta={{config.get('delta')}}\")" +
                 edits[m.end():])
        notes.append("run_single(): prints the effective epsilon at start-up")

    bak = TARGET + ".bak_v14"
    if not os.path.exists(bak):
        shutil.copy2(TARGET, bak)
        print(f"  backup -> {os.path.relpath(bak, HERE)}")
    # SAFETY: the patch must only ADD lines, never remove them
    if len(edits.splitlines()) < len(src.splitlines()):
        print(f"  !! REFUSING: {len(edits.splitlines())} lines vs src "
              f"{len(src.splitlines())} -- a patch must not delete code")
        return 1
    for tail in ("def aggregate_all", "def main"):
        if tail in src and tail not in edits:
            print(f"  !! REFUSING: '{tail}' disappeared -- aborting")
            return 1
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(edits)
    try:
        py_compile.compile(TARGET, doraise=True)
        print("  [ok] py_compile run_baselines.py")
    except Exception as e:
        print(f"  !! py_compile FAILED: {e}\n  restoring")
        shutil.copy2(bak, TARGET)
        return 1
    for n in notes:
        print(f"    + {n}")
    chk = open(TARGET, encoding="utf-8").read()
    print("  residual audit:")
    print("    marker present      :", MARK in chk)
    print("    --epsilon flag      :", "--epsilon" in chk)
    print("    records epsilon     :", "'epsilon_total': config.get" in chk)
    bar("NEXT")
    print("  smoke test (2 min, one job, epsilon=100):")
    print("    python run_baselines.py --method hierfed_dp --alpha 0.5 --seeds 1 \\")
    print("        --epsilon 100 --output_dir results_epsgrid/eps100 --T 2 "
          "--skip_aggregate")
    print("    grep -m1 'fix_v14' logs/*.log || true")
    print("  then the full sweep:  bash run_baseline_eps_sweep.sh")
    return 0


def revert():
    bar("revert")
    bak = TARGET + ".bak_v14"
    if not os.path.exists(bak):
        print("  !! no .bak_v14 found")
        return 1
    shutil.copy2(bak, TARGET)
    print("  restored run_baselines.py")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  run_baselines.py: --epsilon override + self-describing config")
    print(f"  project root : {HERE}")
    print("=" * 78)
    if not os.path.exists(TARGET):
        print(f"\n  !! {os.path.relpath(TARGET, HERE)} not found -- run me from the "
              f"project root")
        return 1
    if a.revert:
        return revert()
    if a.apply:
        return apply()
    show()
    print("\n  (dry run -- nothing written.  --apply to patch, --revert to undo)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
