#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_alloc.py -- Phase 3「切片感知 CR x ε 联合分配」四臂分析

对每个数据集：
  1 四臂 AUC 表（mean±std, n）
  2 关键配对对比（按 seed 配对 + t/Wilcoxon）
        A2-A1 : 只分配 CR
        A3-A1 : 只分配 ε
        A4-A1 : 联合分配（headline）
        A4-A2, A4-A3 : 联合是否优于单边
  3 若有 PR-AUC(average precision) 一并报告 —— 方向A 主张极端不平衡下用 PR-AUC

用法
    python analyze_alloc.py                    # 默认 results_alloc
    python analyze_alloc.py <目录>

--- EN ---
analyze_alloc.py -- Phase 3 "slice-aware CR x ε joint allocation" four-arm analysis

For each dataset:
  1 Four-arm AUC table (mean±std, n)
  2 Key paired comparisons (paired by seed + t/Wilcoxon)
        A2-A1 : allocate CR only
        A3-A1 : allocate ε only
        A4-A1 : joint allocation (headline)
        A4-A2, A4-A3 : is joint better than one-sided
  3 If PR-AUC (average precision) is available, report it too -- Direction A argues for PR-AUC under extreme imbalance

Usage
    python analyze_alloc.py                    # default: results_alloc
    python analyze_alloc.py <dir>
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

import numpy as np

try:
    from scipy import stats
    HAVE = True
except Exception:
    HAVE = False

ROOT = sys.argv[1] if len(sys.argv) > 1 else "results_alloc"
ARMS = {"cruniform_epsuniform": "A1  uniform CR + uniform eps",
        "crslice_epsuniform": "A2  slice   CR + uniform eps",
        "cruniform_epsslice": "A3  uniform CR + slice   eps",
        "crslice_epsslice": "A4  slice   CR + slice   eps"}
PAT = re.compile(r"alpha([\d.]+)_seed(\d+)_(.+)$")

data = defaultdict(lambda: defaultdict(dict))     # ds -> arm -> {seed: (auc, f1m, pr)}
for p in glob.glob(os.path.join(ROOT, "*", "*", "results.json")):
    ds = os.path.basename(os.path.dirname(os.path.dirname(p)))
    name = os.path.basename(os.path.dirname(p))
    m = PAT.search(name)
    if not m:
        continue
    seed, tag = int(m.group(2)), m.group(3)
    if tag not in ARMS:
        continue
    try:
        d = json.load(open(p, encoding="utf-8"))
    except Exception:
        continue
    fm = d.get("final_metrics") or {}
    auc = fm.get("auc_roc")
    if auc is None:
        continue
    pr = None
    for k in ("pr_auc", "average_precision", "ap", "auc_pr"):
        if fm.get(k) is not None:
            pr = fm[k]
            break
    data[ds][tag][seed] = (float(auc), fm.get("f1_macro"), pr)

if not data:
    print(f"[!!] {ROOT} 下没解析到 Phase 3 的结果（目录名应形如 "
          f"<DS>/proposed_<DS>_alpha0.5_seed1_crslice_epsslice）")
    sys.exit(1)


def paired(a, b):
    """返回 (mean_diff, t_p, wilcoxon_p, n)

--- EN ---
returns (mean_diff, t_p, wilcoxon_p, n)"""
    ks = sorted(set(a) & set(b))
    if len(ks) < 3:
        return None
    x = np.array([a[k][0] for k in ks])
    y = np.array([b[k][0] for k in ks])
    dd = x - y
    tp = wp = float("nan")
    if HAVE and np.any(dd):
        try:
            tp = stats.ttest_rel(x, y).pvalue
            wp = stats.wilcoxon(x, y).pvalue
        except Exception:
            pass
    return float(dd.mean()), tp, wp, len(ks)


for ds in sorted(data):
    print("=" * 78)
    print(f" 数据集 {ds}")
    print("=" * 78)
    print(f" {'arm':<28}{'AUC (mean±std)':>18}{'n':>4}{'macroF1':>11}{'PR-AUC':>10}")
    print(" " + "-" * 70)
    for tag, lab in ARMS.items():
        v = data[ds].get(tag, {})
        if not v:
            print(f" {lab:<28}{'--':>18}")
            continue
        auc = np.array([x[0] for x in v.values()])
        f1m = [x[1] for x in v.values() if x[1] is not None]
        pr = [x[2] for x in v.values() if x[2] is not None]
        sd = auc.std(ddof=1) if len(auc) > 1 else 0.0
        prs = f"{np.mean(pr):.4f}" if pr else "--"
        print(f" {lab:<28}{np.mean(auc):>10.4f}±{sd:<7.4f}{len(auc):>4}"
              f"{(np.mean(f1m) if f1m else float('nan')):>11.4f}{prs:>10}")

    print()
    print(" 关键配对对比（按 seed 配对）:")
    for (ta, tb, why) in (("crslice_epsslice", "cruniform_epsuniform", "A4-A1 联合分配 vs 都不分配 (headline)"),
                          ("crslice_epsuniform", "cruniform_epsuniform", "A2-A1 只分配 CR"),
                          ("cruniform_epsslice", "cruniform_epsuniform", "A3-A1 只分配 ε"),
                          ("crslice_epsslice", "crslice_epsuniform", "A4-A2 联合 vs 单 CR"),
                          ("crslice_epsslice", "cruniform_epsslice", "A4-A3 联合 vs 单 ε")):
        r = paired(data[ds].get(ta, {}), data[ds].get(tb, {}))
        if not r:
            print(f"   {why:<42} 需要 >=3 个共同 seed")
            continue
        md, tp, wp, n = r
        extra = f"  t-p={tp:.4f}" if tp == tp else ""
        extra += f"  wilcoxon-p={wp:.4f}" if wp == wp else ""
        flag = "  *" if (tp == tp and tp < 0.05) else ""
        print(f"   {why:<42} {md:+.4f} (n={n}){extra}{flag}")
    print()
print(" 提示: * 表示配对 t 检验 p<0.05；n<6 时 Wilcoxon 双尾下限 = 2/2^n")
print("=" * 78)

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
