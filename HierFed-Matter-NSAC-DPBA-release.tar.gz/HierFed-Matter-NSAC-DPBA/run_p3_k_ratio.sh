#!/usr/bin/env bash
# =============================================================================
# run_p3_k_ratio.sh -- Phase 3 备选：把 4 臂用 k_ratio 温和档重跑（验证 A4 高方差是 bw 极端造成的）
# EN: run_p3_k_ratio.sh -- Phase 3 alternative: rerun the 4 arms with the milder k_ratio setting (to verify that A4's high variance is caused by the extreme bw setting)
#
# 启动条件：B（seed678.sh）跑完再启动，避免 GPU 抢资源
# EN: Launch condition: start only after B (seed678.sh) has finished, to avoid GPU contention.
#   bash run_p3_k_ratio.sh                # 前台 gate + 40 run
# EN: bash run_p3_k_ratio.sh                # foreground gate + 40 runs
#   nohup bash run_p3_k_ratio.sh > logs/p3kr_boot.log 2>&1 &
#
# 与 run_p3_alloc.sh 的差异（**只这三处**）：
# EN: Differences from run_p3_alloc.sh (**only these three**):
#   SLICE_WEIGHT_RULE=k_ratio  （默认 bw，1:100:1 极端；k_ratio 是 0.1:0.3:0.05 ≈ 1:3:0.5，更温和）
# EN: SLICE_WEIGHT_RULE=k_ratio  (default bw, 1:100:1 extreme; k_ratio is 0.1:0.3:0.05 ≈ 1:3:0.5, milder)
#   OUT=results_alloc_kr       （不覆盖 bw 的结果，方便后续 4 臂 × {bw, k_ratio} 联合分析）
# EN: OUT=results_alloc_kr       (does not overwrite the bw results, convenient for the later joint analysis of the 4 arms x {bw, k_ratio})
#   其余完全相同（4 臂、2 数据集、5 seed、SLICE_MAP=ranked、preflight、gate、按文件核验）
# EN: everything else is identical (4 arms, 2 datasets, 5 seeds, SLICE_MAP=ranked, preflight, gate, per-file verification)
#
# 预期收益：
# EN: Expected benefits:
#   - A4（联合分配）若在 k_ratio 下不再最差 → 证明 P2/3 的"联合分配失败"是 bw 极端造成的
# EN: - If A4 (joint allocation) is no longer the worst under k_ratio -> it proves that the "joint allocation failure" in P2/3 is caused by the extreme bw setting
#   - 若 A4 仍最差 → 确认是联合分配本身的问题，与权重规则无关
# EN: - If A4 is still the worst -> confirms it is a problem of joint allocation itself, unrelated to the weight rule
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
PAR=${PAR:-4}
SEEDS=${SEEDS:-"1 2 3 4 5"}
DS_LIST=${DS_LIST:-"iotid20 gotham25"}
ALPHA=${ALPHA:-0.5}
T=${T:-50}
RULE=${RULE:-k_ratio}                   # ← 与 bw 唯一的差异 | EN: the only difference from bw
SLICE_MAP=${SLICE_MAP:-ranked}
OUT=${OUT:-results_alloc_kr}            # ← 单独目录 | EN: separate directory
LOG=${LOG:-logs/p3_kr}
TIMEOUT=${TIMEOUT:-5400}

cd "$PROJ" || { echo "ERROR: $PROJ 不存在"; exit 1; }
mkdir -p "$OUT" "$LOG"

ARMS="cruniform_epsuniform:uniform:uniform crslice_epsuniform:slice:uniform cruniform_epsslice:uniform:slice crslice_epsslice:slice:slice"

n_run(){ pgrep -f 'run_experiment\.py' 2>/dev/null | wc -l; }
throttle(){ while [ "$(n_run)" -ge "$PAR" ]; do sleep 15; done; }

summary(){
  local n=0 total=0
  for DS in $DS_LIST; do
    for spec in $ARMS; do
      local tag="${spec%%:*}"
      for s in $SEEDS; do
        total=$((total+1))
        [ -f "$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json" ] && n=$((n+1))
      done
    done
  done
  echo "  完成 $n / $total   在跑 $(n_run)"
}

if [ "${1:-run}" = "status" ]; then echo "=== Phase 3 k_ratio 状态 ==="; summary; exit 0; fi

echo "================================================================"
echo " Phase 3 / k_ratio 温和档（4 臂 × 2 数据集 × 5 seed = 40 run）"
echo " SLICE_WEIGHT_RULE=$RULE   SLICE_MAP=$SLICE_MAP   OUT=$OUT"
echo "================================================================"

# --------------------------------------------------------------- preflight
pre=0
grep -q "'gotham25'"           run_experiment.py 2>/dev/null || { echo "[!!] run_experiment.py 未含 gotham25 -> python fix_v17.py --apply"; pre=1; }
grep -q "\[fix_v20\]"          core/simulator.py 2>/dev/null || { echo "[!!] fix_v20 未打 -> python fix_v20.py --apply"; pre=1; }
[ -f core/slice_alloc.py ]                                  || { echo "[!!] 缺 core/slice_alloc.py"; pre=1; }
$PY core/slice_alloc.py >/dev/null 2>&1                     || { echo "[!!] core/slice_alloc.py 自测未过"; pre=1; }
for ds in $DS_LIST; do
  [ -f "data/processed/${ds}_train.npz" ] || { echo "[!!] 缺 data/processed/${ds}_train.npz"; pre=1; }
done
[ "$pre" -eq 0 ] && echo "[preflight] OK" || { echo "[abort] preflight 未过。"; exit 1; }

# 0) 友好提醒：先确认 B 已经收工
# EN: 0) Friendly reminder: first confirm that B has finished
if [ "$(find results_alloc -name results.json 2>/dev/null | grep -E 'seed[678]_' | wc -l)" -gt 0 ]; then
  echo "  [ok] 检测到 results_alloc/ 已有 seed 6-8 的 run（B 阶段已收工）"
else
  echo "  [提醒] results_alloc/ 似乎还没 seed 6-8 的 run —— 你真的想启动 C 吗？"
  echo "          （Ctrl+C 中断；或等 B 跑完再来）"
  sleep 8
fi

# --------------------------------------------------------------- gate（T=2）
echo "[gate] 每个数据集跑 1 个 T=2 的冒烟，验开关 + span + coverage"
for DS in $DS_LIST; do
  g="$LOG/gate_${DS}.log"
  NSAC_MODE=slice EPSILON_MODE=slice SLICE_WEIGHT_RULE=$RULE SLICE_MAP=$SLICE_MAP \
    timeout 1800 $PY -u run_experiment.py --method proposed --dataset "$DS" \
    --alpha "$ALPHA" --seed 1 --tag gateP3kr --T 2 --e_local 1 \
    --output_dir "$OUT/_gate" > "$g" 2>&1
  gj=$(find "$OUT/_gate" -name results.json 2>/dev/null | head -1)
  if [ -z "$gj" ]; then
    echo "  [FAIL] $DS gate 未写出 results.json"; tail -n 12 "$g" | sed 's/^/     | /'; exit 1
  fi
  span=$(grep -oE "span=[0-9.]+" "$g" | head -1)
  nsl=$(grep -oE "slices=\[[^]]*\]" "$g" | head -1 | tr -cd ',' | wc -c)
  echo "  [ok] $DS gate 通过  $span  slices=$((nsl+1))"
  [ "${span#span=}" = "0.000" ] && echo "     [!!] 退化" || true
  [ "$((nsl+1))" -lt 3 ] && echo "     [!!] 切片 <3" || true
done
rm -rf "$OUT/_gate"

# --------------------------------------------------------------- launch
echo "[launch] 启动 (par=$PAR) ..."
for DS in $DS_LIST; do
  for spec in $ARMS; do
    tag="${spec%%:*}"; rest="${spec#*:}"; NSAC="${rest%%:*}"; EPS="${rest#*:}"
    for s in $SEEDS; do
      f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json"
      [ -f "$f" ] && { echo "  [skip] $DS $tag s$s"; continue; }
      throttle
      NSAC_MODE="$NSAC" EPSILON_MODE="$EPS" SLICE_WEIGHT_RULE="$RULE" SLICE_MAP="$SLICE_MAP" \
        timeout "$TIMEOUT" $PY -u run_experiment.py --method proposed \
        --dataset "$DS" --alpha "$ALPHA" --seed "$s" --tag "$tag" --T "$T" \
        --output_dir "$OUT/$DS" > "$LOG/${DS}_${tag}_s${s}.log" 2>&1 &
      echo "  [launch] $DS $tag s$s  (NSAC=$NSAC EPS=$EPS)"
    done
  done
done
wait

echo "[verify] 逐 run 检查产物（以文件为准）"
miss=0
for DS in $DS_LIST; do
  for spec in $ARMS; do
    tag="${spec%%:*}"
    for s in $SEEDS; do
      f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json"
      [ -f "$f" ] || { miss=$((miss+1)); echo "  [MISSING] $f"; tail -n 8 "$LOG/${DS}_${tag}_s${s}.log" 2>/dev/null | sed 's/^/     | /'; }
    done
  done
done
echo "================================================================"
summary
if [ "$miss" -eq 0 ]; then
  echo " [OK] 全部完成 -> python analyze_alloc.py $OUT"
else
  echo " [FAIL] 缺 $miss 个，按上面日志恢复后重跑（幂等）"
fi
echo "================================================================"
# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
