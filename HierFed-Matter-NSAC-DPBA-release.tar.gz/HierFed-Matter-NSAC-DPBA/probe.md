[fix_v9] project root = /root/autodl-tmp/HierFed-Matter-NSAC-DPBA
[probe] printing the regions still needed for C-2 / C-3

==============================================================================
## core/simulator.py : __init__ around slice assignment + enable_nsac
==============================================================================
   47|     types = []
   48|     for i in range(N):
   49|         r = np.random.random()
   50|         if r < 0.4:
   51|             types.append('camera')
   52|         elif r < 0.7:
   53|             types.append('thermostat')
   54|         else:
   55|             types.append('bulb')
   56|     return types
   57| 
   58| 
   59| def assign_slice_to_gateways(
   60|     M: int,
   61|     device_types: List[str],
   62|     cluster_map: Dict[int, List[int]],
   63| ) -> Dict[int, str]:
   64|     """
   65|     Assign slice types to gateways based on dominant device type in cluster.
   66| 
   67|     camera-heavy → uRLLC, thermostat-heavy → eMBB, bulb-heavy → mMTC.
   68|     """
   69|     assignments = {}
   70|     type_to_slice = {'camera': 'urllc', 'thermostat': 'embb', 'bulb': 'mmtc'}
   71| 
      ...
  198| 
  199|         # Cluster map: gateway_id → [device_ids]
  200|         self.cluster_map = {}
  201|         for gw_id in range(M):
  202|             start_dev = gw_id * K
  203|             end_dev = start_dev + K
  204|             self.cluster_map[gw_id] = list(range(start_dev, min(end_dev, N)))
  205| 
  206|         # Device types
  207|         self.device_types = assign_device_types(N, config.get('seed', 1))
  208| 
  209|         # Slice assignments
  210|         self.slice_assignments = assign_slice_to_gateways(
  211|             M, self.device_types, self.cluster_map
  212|         )
  213| 
  214|         # DPBA-FIM components
  215|         num_linear_layers = len([m for m in self.model.net
  216|                                   if isinstance(m, torch.nn.Linear)])
  217|         self.fim_tracker = FIMTracker(num_linear_layers,
  218|                                        beta_F=config.get('beta_F', 0.9))
  219| 
  220|         # --- Sensitivity weights (Eq.7); CLI/config overridable ---
  221|         self.alpha_s = float(config.get('alpha_s', 0.5))
  222|         self.beta_s = float(config.get('beta_s_coeff', 0.3))
      ...
  428|         print(f"d={self.d}, feature_dim={self.feature_dim}")
  429| 
  430|         # Compute base σ via RDP composition ONCE (not per-device per-round)
  431|         if self.disable_dp:
  432|             sigma_base = 0.0
  433|             print("[DP] disabled (ablation) -> no DP noise injected")
  434|         else:
  435|             sigma_base = compute_noise_scale_rdp(
  436|                 self.epsilon_total, self.T, self.delta, self.clip_norm,
  437|                 subsampling_rate=self.dp_subsampling_rate)
  438|             print(f"RDP base σ={sigma_base:.4f} (ε_total={self.epsilon_total}, "
  439|                   f"T={self.T}, q={self.dp_subsampling_rate:.3f})")
  440|         print(f"[Ablation] nsac={self.enable_nsac}, hierfed={not self.disable_hierfed}, "
  441|               f"dpba_fim={not self.disable_dpba_fim}, dp={not self.disable_dp}, "
  442|               f"w=(a={self.alpha_s},b={self.beta_s},g={self.gamma_s},d={self.delta_s})")
  443|         # --- v9: build the byte-matched uniform config once d is known ---
  444|         uniform_slice = None
  445|         if self.enable_nsac and self.nsac_mode == 'uniform':
  446|             uniform_slice = make_uniform_slice(
  447|                 list(self.slice_assignments.values()), self.d,
  448|                 b_bits=self.uniform_bits)
  449|             _names = list(self.slice_assignments.values())
  450|             _slice_bytes = sum(
  451|                 max(1, int(SLICE_CONFIGS[s].k_ratio * self.d)) *
  452|                 (4 + SLICE_CONFIGS[s].b_bits // 8) for s in _names)
      ...
  579|                 n_upd = max(len(device_gradients), 1)
  580|                 round_stats = {
  581|                     'compression_ratios': [1.0] * n_upd,
  582|                     'latencies_ms': [0.0] * n_upd,
  583|                     'total_compressed_bytes': self.d * 4 * n_upd,
  584|                 }
  585|             else:
  586|                 new_params, round_stats = hierfed_matter_round(
  587|                     device_gradients, self.cluster_map,
  588|                     self.slice_assignments, global_params,
  589|                     learning_rate=self.eta, d=self.d,
  590|                     model_size_bytes=self.d * 4,
  591|                     enable_nsac=self.enable_nsac,
  592|                     uniform_slice=uniform_slice,
  593|                 )
  594| 
  595|             # [FIX B2] divergence guard: a single NaN round used to silently
  596|             # poison the model for the remaining rounds (and later faked an
  597|             # AUC of 0.0 via the B3 sentinel).
  598|             if not torch.isfinite(new_params).all():
  599|                 _nbad = int((~torch.isfinite(new_params)).sum().item())
  600|                 print(f"[WARN] round {t}: {_nbad}/{new_params.numel()} non-finite "
  601|                       f"params -> keeping last finite model")
  602|                 new_params = global_params          # keep the last finite model
  603|             elif float(new_params.norm()) > 1e3:
      ...
==============================================================================
## core/simulator.py : the per-device DP noise injection (v7 territory)
==============================================================================
   11| import torch
   12| import torch.nn as nn
   13| from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
   14| import numpy as np
   15| from typing import Dict, List, Tuple, Optional
   16| from pathlib import Path
   17| 
   18| from models.dnn import AnomalyDNN, build_model
   19| from core.hierfed import hierfed_matter_round, star_aggregate, edge_aggregate, core_aggregate
   20| from core.nsac import (SLICE_CONFIGS, compute_communication_stats,
   21|                        make_uniform_slice, configure_slices, slices_from_env)
   22| from data.preprocess import dirichlet_partition
   23| from core.dpba_fim import (
   24|     FIMTracker, compute_device_sensitivity, allocate_privacy_budget,
   25|     compute_heterogeneity_from_partition, clip_gradient, inject_dp_noise,
   26|     inject_dp_noise_rdp, compute_noise_scale_rdp,
   27|     dpba_fim_gradient_processing, compute_noise_scale,
   28| )
   29| 
   30| # ============================================================
   31| # GPU Support
   32| # ============================================================
   33| DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
   34| if torch.cuda.is_available():
   35|     print(f"[GPU] Using {torch.cuda.get_device_name()} | "
   36|           f"VRAM={torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
   37| else:
   38|     print("[GPU] No GPU available, running on CPU")
   39| 
      ...
  515|                 gradient = local_train(
  516|                     self.model, local_data, local_labels,
  517|                     num_epochs=self.config.get('E_local', 5),
  518|                     batch_size=self.config.get('batch_size', 32),
  519|                     learning_rate=self.eta,
  520|                     oversample=self.config.get('oversample_minority', True),
  521|                 )
  522| 
  523|                 if self.disable_dp:
  524|                     # Ablation: no DP -> use the raw local update
  525|                     device_gradients[dev_id] = gradient
  526|                     continue
  527| 
  528|                 # Clip -> per-device Gaussian noise (Eq.14/15).
  529|                 # sigma_i = sigma_base * (1.4 - 0.4*S_rel_i): high-sensitivity
  530|                 # devices receive LESS noise; low-sensitivity devices MORE.
  531|                 # [v7] per-device sensitivity matching
  532|                 if self.dp_clip_mode == 'per_device':
  533|                     _raw_norm = float(gradient.norm())
  534|                     _prev = self._dev_clip.get(dev_id, self.clip_norm)
  535|                     _ema = (1.0 - self.adaptive_clip_beta) * _prev \
  536|                         + self.adaptive_clip_beta * _raw_norm
  537|                     _C_i = float(min(max(_ema, self.adaptive_clip_min),
  538|                                       self.adaptive_clip_max))
  539|                     self._dev_clip[dev_id] = _C_i
  540|                 else:
  541|                     _C_i = self.clip_norm
  542|                 # sigma_base was computed for sensitivity clip_norm -> rescale to C_i
  543|                 device_sigma = (sigma_base * float(sigma_mult[dev_id])
      ...
  554|                 # [FIX B2] instrumentation: the model update returned by
  555|                 # local_train ALREADY contains the learning rate, so the noise
  556|                 # added here must be on the same scale. Track both norms.
  557|                 _dbg_dw.append(float(clipped.norm()))
  558|                 _dbg_noise.append(float(noise.norm()))
  559|                 _dbg_sig.append(float(device_sigma))
  560| 
  561|             if (not self.disable_dp) and self.dp_debug and _dbg_dw:
  562|                 import statistics as _st
  563|                 _dw = _st.mean(_dbg_dw)
  564|                 _nz = _st.mean(_dbg_noise)
  565|                 _wn = float(torch.cat([p.data.flatten()
  566|                                        for p in self.model.parameters()]).norm())
  567|                 print(f"[DP-DEBUG] round {t}: ||dw||={_dw:.4f}  ||w||={_wn:.3f}  "
  568|                       f"sigma_i~{_st.mean(_dbg_sig):.4f}  ||noise||={_nz:.2f}  "
  569|                       f"SNR={_dw / (_nz + 1e-12):.3e}  "
  570|                       f"noise_scale={self.dp_noise_scale}  "
  571|                       f"n_part={len(self._participants)}/{self.N}")
  572| 
  573|             # --- Step 4: HierFed-Matter round ---
  574|             global_params = torch.cat([p.data.clone().flatten()
  575|                                        for p in self.model.parameters()])
  576|             if self.disable_hierfed:
  577|                 # Ablation: flat star topology (no gateway tier)
  578|                 new_params = star_aggregate(device_gradients, global_params, self.eta)
  579|                 n_upd = max(len(device_gradients), 1)
  580|                 round_stats = {
  581|                     'compression_ratios': [1.0] * n_upd,
  582|                     'latencies_ms': [0.0] * n_upd,
      ...
==============================================================================
## core/simulator.py : partition construction
==============================================================================
   14| import numpy as np
   15| from typing import Dict, List, Tuple, Optional
   16| from pathlib import Path
   17| 
   18| from models.dnn import AnomalyDNN, build_model
   19| from core.hierfed import hierfed_matter_round, star_aggregate, edge_aggregate, core_aggregate
   20| from core.nsac import (SLICE_CONFIGS, compute_communication_stats,
   21|                        make_uniform_slice, configure_slices, slices_from_env)
   22| from data.preprocess import dirichlet_partition
   23| from core.dpba_fim import (
   24|     FIMTracker, compute_device_sensitivity, allocate_privacy_budget,
   25|     compute_heterogeneity_from_partition, clip_gradient, inject_dp_noise,
   26|     inject_dp_noise_rdp, compute_noise_scale_rdp,
   27|     dpba_fim_gradient_processing, compute_noise_scale,
   28| )
   29| 
   30| # ============================================================
      ...
  249|             configure_slices(**_sv)
  250|         print("[v9] nsac_mode=%s, uniform_bits=%d" % (self.nsac_mode, self.uniform_bits))
  251| 
  252|         # --- Per-device Fisher information (Eq.7, F_rel,i) ---
  253|         self.fim_every = int(config.get('fim_every', 5))
  254|         self.device_fim_ema = np.ones(N, dtype=np.float64)  # uniform init
  255| 
  256|         # --- Device sensitivity (Eq.7) ---
  257|         self.local_counts = [len(self.partitions.get(str(i), [])) for i in range(N)]
  258|         self.H_scores = compute_heterogeneity_from_partition(
  259|             self.y_train, self.partitions)
  260|         self.device_sensitivity = self._compute_sensitivity()
  261| 
  262|         # Privacy budgets
  263|         # float() 防御：PyYAML 会把 '1e-5' 这种无小数点的写法解析成字符串，
  264|         # 显式转 float 可避免后续做除法时出现 TypeError
  265|         self.epsilon_total = float(config.get('epsilon_total', 3.0))
      ...
  316|             alpha_s=self.alpha_s, beta_s=self.beta_s, gamma_s=self.gamma_s,
  317|             fim_rel_scores=fim_rel, delta_s=self.delta_s,
  318|         )
  319| 
  320|     def _update_device_fim(self):
  321|         """Recompute each device's local FIM trace and update its EMA (Eq.11)."""
  322|         beta_F = self.fim_tracker.beta_F
  323|         for dev_id in range(self.N):
  324|             idx_list = self.partitions.get(str(dev_id), [])
  325|             if len(idx_list) == 0:
  326|                 continue
  327|             d_t = torch.tensor(self.X_train[idx_list],
  328|                                dtype=torch.float32).to(DEVICE)
  329|             l_t = torch.tensor(self.y_train[idx_list],
  330|                                dtype=torch.long).to(DEVICE)
  331|             traces = self.fim_tracker.local_trace(self.model, d_t, l_t)
  332|             scalar = float(traces.sum())
      ...
  363|                                        f'{prefix}_partitions_alpha{alpha}.json')
  364|         generic_file = os.path.join(processed_dir, f'{prefix}_partitions.json')
  365| 
  366|         partition_loaded = False
  367|         # 1) 尝试加载 per-α 分区文件
  368|         if os.path.exists(per_alpha_file):
  369|             with open(per_alpha_file, 'r', encoding='utf-8') as f:
  370|                 part_data = json.load(f)
  371|             self.partitions = part_data['device_indices']
  372|             partition_loaded = True
  373|             print(f"[Partition] Loaded per-α file: {per_alpha_file} (α={alpha})")
  374|         # 2) 尝试加载通用分区文件，检查 α 是否匹配
  375|         elif os.path.exists(generic_file):
  376|             with open(generic_file, 'r', encoding='utf-8') as f:
  377|                 part_data = json.load(f)
  378|             file_alpha = part_data.get('alpha', None)
  379|             if file_alpha == alpha:
      ...
==============================================================================
## core/nsac.py : compute_communication_stats
==============================================================================
  203|     d: int,
  204|     device=None,
  205| ) -> torch.Tensor:
  206|     """
  207|     Decompress NSAC-compressed gradient back to full d-dimensional vector.
  208| 
  209|     Reconstruction: Δw[idx] = q_val × ‖g‖ / sqrt(k), others = 0.
  210|     (Unbiased reconstruction using norm preservation)
  211|     """
  212|     indices = compressed['indices']
  213|     q_values = compressed['q_values']
  214|     norm = compressed['norm']
  215|     k = len(indices)
  216| 
  217|     # Reconstruct: place quantized values at selected indices, 0 elsewhere
  218|     _dev = device if device is not None else torch.device('cpu')
  219|     reconstructed = torch.zeros(d, dtype=torch.float32, device=_dev)
  220|     # Scale factor for unbiasedness: norm / sqrt(k)
  221|     scale = norm / np.sqrt(k) if k > 0 else 1.0
  222|     reconstructed[indices] = torch.as_tensor(
  223|         q_values, dtype=torch.float32, device=reconstructed.device) * scale
  224| 
  225|     return reconstructed
  226| 
  227| 
  228| def compute_communication_stats(
  229|     d: int,
  230|     N: int,
  231|     M: int,
  232|     T: int,
  233|     slice_assignments: Dict[int, str],
  234|     model_size_bytes: int = 31304,  # |w| ≈ 30.6 KB (d=7826 × 4 bytes, lightweight)
  235| ) -> Dict:
  236|     """
  237|     Compute total communication statistics for one experiment run.
  238| 
  239|     Args:
  240|         d: Model dimensionality.
  241|         N: Number of devices.
  242|         M: Number of gateways.
  243|         T: Number of rounds.
  244|         slice_assignments: gateway_id → slice_name mapping.
  245|         model_size_bytes: Full model size.
  246| 
  247|     Returns:
  248|         Dict with total_traffic_star, total_traffic_hierfed, speedup, etc.
  249|     """
  250|     star_traffic = N * model_size_bytes * T  # Eq.(3)
  251| 
  252|     # HierFed-Matter: M gateways, each sends compressed update per round
  253|     total_compressed_bytes_per_round = 0
      ...
==============================================================================
## run_experiment.py : argparse + config assembly
==============================================================================
   49|     and an optional '_tag' used to suffix the experiment folder name.
   50|     """
   51| 
   52|     if config_base is None:
   53|         config_base = load_config(str(ROOT / 'configs' / 'base.yaml'))
   54|     if config_nsac is None:
   55|         config_nsac = load_config(str(ROOT / 'configs' / 'nsac.yaml'))
   56| 
   57|     # Merge configs
   58|     config = {**config_base, **config_nsac}
   59|     config['seed'] = seed
   60|     config['alpha'] = alpha
   61|     config['dataset_name'] = dataset
   62|     config['processed_dir'] = str(ROOT / 'data' / 'processed')
   63| 
   64|     # Apply CLI overrides (sensitivity weights + ablation switches)
   65|     tag = ''
   66|     if overrides:
   67|         for k, v in overrides.items():
   68|             if k == '_tag':
   69|                 tag = str(v)
      ...
  164|     agg_file = os.path.join(output_dir,
  165|         f"aggregate_{method}_{dataset}_alpha{alpha}{tag_suffix}.json")
  166|     with open(agg_file, 'w', encoding='utf-8') as f:
  167|         json.dump(summary, f, indent=2)
  168| 
  169|     return summary
  170| 
  171| 
  172| def main():
  173|     parser = argparse.ArgumentParser(description='Run FL experiments')
  174|     parser.add_argument('--dataset', choices=['iotid20', 'cicids2017', 'both'],
  175|                         default='iotid20')
  176|     parser.add_argument('--alpha', type=float, nargs='+', default=[0.5, 0.1])
  177|     parser.add_argument('--seed', type=int, nargs='+', default=[1, 2, 3, 4, 5])
  178|     parser.add_argument('--method', choices=['proposed', 'fedavg', 'fedprox',
  179|                         'dpfedavg', 'hierfed', 'hierfed_dp', 'topk_qsgd',
  180|                         'safeliot', 'dpfed6g', 'fedprox_dp',
  181|                         'adaptive_clip_dp', 'layer_adaptive_dp', 'all'],
  182|                         default='proposed')
  183|     parser.add_argument('--output_dir', default='results')
  184|     parser.add_argument('--config', default='configs/base.yaml')
      ...
==============================================================================
[probe] paste everything above back to Mihiro
