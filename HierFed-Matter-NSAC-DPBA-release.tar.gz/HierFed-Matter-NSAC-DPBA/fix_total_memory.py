"""
fix_total_memory.py -- idempotent PyTorch compatibility fix.

Newer PyTorch renamed the CUDA device property ``total_mem`` to ``total_memory``.
This script rewrites every occurrence of the OLD name in a project directory.

Usage:
    python fix_total_memory.py [/root/autodl-tmp/HierFed-Matter-NSAC-DPBA]
"""
import os
import re
import sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
root = os.path.abspath(root)

SKIP_DIRS = {".git", "__pycache__", ".ipynb_checkpoints", "logs"}
SELF = "fix_total_memory.py"
OLD = ".total_" + "mem"          # built at runtime so this file never matches itself
NEW = ".total_memory"

n_files = n_hits = 0
for dp, dns, fns in os.walk(root):
    dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith("results")]
    for fn in fns:
        if not fn.endswith(".py") or fn == SELF:
            continue
        p = os.path.join(dp, fn)
        try:
            s = open(p, encoding="utf-8").read()
        except (UnicodeDecodeError, OSError):
            continue
        if OLD not in s:
            continue
        t = re.sub(re.escape(OLD) + r"\b", NEW, s)   # \b keeps `total_memory` intact
        if t != s:
            open(p, "w", encoding="utf-8").write(t)
            n_files += 1
            n_hits += len(re.findall(re.escape(OLD) + r"\b", s))
            print(f"  fixed: {os.path.relpath(p, root)}")

print(f"[fix_total_memory] patched {n_files} file(s), {n_hits} occurrence(s) under {root}")
if n_files == 0:
    print("[fix_total_memory] nothing to do (already OK)")

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
