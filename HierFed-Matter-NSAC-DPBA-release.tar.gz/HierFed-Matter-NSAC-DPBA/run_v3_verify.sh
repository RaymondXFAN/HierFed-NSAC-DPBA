#!/usr/bin/env bash
# =============================================================================
# run_v3_verify.sh -- after apply_fixes_v3.py, verify in ONE run (~20 min) that
#   (a) the subsampling really happens        -> DP-DEBUG shows n_part=4/20
#   (b) eps and sigma are self-consistent     -> "RDP base σ=0.3594 (eps 27, q=0.2)"
#   (c) utility is restored                   -> AUC ~ 0.96
#
#   bash run_v3_verify.sh            # launch
#   bash run_v3_verify.sh --wait     # launch and print the verdict
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}

cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }
mkdir -p logs results_v3

echo "=== config sanity ==="
grep -nE "^(epsilon_total|dp_noise_scale|dp_subsampling_rate|client_sample_rate|oversample_minority):" configs/base.yaml || true

nohup $PY -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
      --output_dir results_v3 --tag v3_full \
      > logs/v3_full.log 2>&1 &
echo "[v3] launched -> logs/v3_full.log"

if [ "${1:-}" = "--wait" ]; then
  wait
  echo
  echo "======================= V3 VERDICT ======================="
  echo "--- (a) 采样是否真的发生（应 n_part=4/20）---"
  grep -h "DP-DEBUG" logs/v3_full.log | sed -n '2p' || echo "  (no DP-DEBUG)"
  echo "--- (b) σ 是否自洽（应 σ=0.3594, q=0.200）---"
  grep -h "RDP base" logs/v3_full.log | tail -1 || echo "  (no sigma line)"
  echo "--- (c) 效用 ---"
  grep -h "Final:" logs/v3_full.log | tail -1 || echo "  (no final)"
  echo "=========================================================="
  cat <<'EOF'
期望: n_part=4/20  |  σ=0.3594  |  AUC ≈ 0.96 (>=0.90 即可)

全部满足 -> 定稿配置，进入全量重跑:
  mv results_ablation results_ablation_OLD_buggy
  mv results_baseline results_baseline_OLD_buggy
  mv results_eps      results_eps_OLD_buggy
  mv results_scale    results_scale_OLD_buggy
  export OMP_NUM_THREADS=8
  nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 \
        > logs/parallel_v3.log 2>&1 &

AUC 明显 <0.90 -> 采样带来的方差上升，需要把 client_sample_rate 提到 0.4 重试
                 （同时把 dp_subsampling_rate 改成 0.4）
EOF
fi

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
