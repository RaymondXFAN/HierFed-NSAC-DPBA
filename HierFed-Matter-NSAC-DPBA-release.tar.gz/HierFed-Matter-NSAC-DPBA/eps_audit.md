==============================================================================
  privacy-budget audit  (read-only)
  project root : /root/autodl-tmp/HierFed-Matter-NSAC-DPBA
==============================================================================

==============================================================================
  A. epsilon recorded in results.json   (config block)
==============================================================================
  method                 epsilon(s) found           #files
  --------------------------------------------------------------------------
  eps-sweep              0.5, 1.0, 2.0, 3.0, 5.0,   70
      e=0.5        e.g. results_eps_OLD_buggy/epsweep_eps0.5_alpha0.1_seed1/results.json
      e=1.0        e.g. results_eps_OLD_buggy/epsweep_eps1.0_alpha0.1_seed1/results.json
      e=2.0        e.g. results_eps_OLD_buggy/epsweep_eps2.0_alpha0.1_seed1/results.json
      e=3.0        e.g. results_eps_OLD_buggy/epsweep_eps3.0_alpha0.1_seed1/results.json
      e=5.0        e.g. results_eps_OLD_buggy/epsweep_eps5.0_alpha0.1_seed1/results.json
      e=8.0        e.g. results_eps_OLD_buggy/epsweep_eps8.0_alpha0.1_seed1/results.json
      e=10.0       e.g. results_eps_OLD_buggy/epsweep_eps10.0_alpha0.1_seed1/results.json
  proposed               3.0, 27.0, 108.0, 399.0    152
      e=3.0        e.g. results_ablation_OLD_buggy/proposed_iotid20_alpha0.1_seed1_full/results.json
      e=27.0       e.g. results_v3/proposed_iotid20_alpha0.5_seed1_v3_full/results.json
      e=108.0      e.g. results_probe/proposed_iotid20_alpha0.5_seed1_e108_full/results.json
      e=399.0      e.g. results_clip/proposed_iotid20_alpha0.5_seed1_clip0.05/results.json

==============================================================================
  B. sigma actually printed by the job logs   (ground truth)
==============================================================================
  log file                                       first sigma line                                                
  --------------------------------------------------------------------------------------------------------------
  adaptive_clip_dp_iotid20_alpha0.1_seed1.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.1_seed2.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.1_seed3.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.1_seed4.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.1_seed5.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.5_seed1.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.5_seed2.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.5_seed3.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.5_seed4.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  adaptive_clip_dp_iotid20_alpha0.5_seed5.log    [AdaptiveClip-DP] sigma(per unit C)=0.359, C in [0.10,3.00]
  dpfed6g_iotid20_alpha0.1_seed1.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.1_seed2.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.1_seed3.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.1_seed4.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.1_seed5.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.5_seed1.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.5_seed2.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.5_seed3.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.5_seed4.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfed6g_iotid20_alpha0.5_seed5.log             [DP-Fed6G] sigma_base=0.3592 schedule_rescale=2.79 sigma[1]=1.9278 sigma[T]=0.1285
  dpfedavg_iotid20_alpha0.1_seed1.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.1_seed2.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.1_seed3.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.1_seed4.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.1_seed5.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.5_seed1.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.5_seed2.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.5_seed3.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.5_seed4.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  dpfedavg_iotid20_alpha0.5_seed5.log            [DP-FedAvg] RDP σ=0.36 (ε=399.0, T=50, δ=1e-05)
  epsweep_eps0.5_alpha0.1_seed1.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.1_seed2.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.1_seed3.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.1_seed4.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.1_seed5.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.5_seed1.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.5_seed2.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.5_seed3.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.5_seed4.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  epsweep_eps0.5_alpha0.5_seed5.log              RDP base σ=68.5935 (ε_total=0.5, T=50, q=1.000)
  ... and 287 more

==============================================================================
  C. VERDICT -- is the comparison at a matched privacy budget?
==============================================================================
  METHODS DISAGREE ABOUT THE PRIVACY BUDGET:
    epsilon = 0.5        used by: eps-sweep
    epsilon = 1          used by: eps-sweep
    epsilon = 2          used by: eps-sweep
    epsilon = 3          used by: eps-sweep, proposed
    epsilon = 5          used by: eps-sweep
    epsilon = 8          used by: eps-sweep
    epsilon = 10         used by: eps-sweep
    epsilon = 27         used by: proposed
    epsilon = 108        used by: proposed
    epsilon = 399        used by: proposed

  an AUC comparison across different epsilon is NOT admissible;
  either re-run at a matched epsilon or report the (epsilon, AUC) curves.

==============================================================================
  -> upload this whole output to Mihiro
==============================================================================
