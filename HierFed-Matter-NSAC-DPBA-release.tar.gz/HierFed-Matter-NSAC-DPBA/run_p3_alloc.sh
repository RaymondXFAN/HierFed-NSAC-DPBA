#!/usr/bin/env bash
# =============================================================================
# run_p3_alloc.sh -- Phase 3：切片感知 CR × ε 联合分配（方向A 主实验）
# EN: run_p3_alloc.sh -- Phase 3: slice-aware CR x epsilon joint allocation (Direction A main experiment)
#
#   4 臂 × 2 数据集(iotid20, gotham25) × 5 seeds = 40 run
# EN: 4 arms x 2 datasets (iotid20, gotham25) x 5 seeds = 40 runs
#
#   bash run_p3_alloc.sh                      # 全量（后台依赖：见下）
# EN: bash run_p3_alloc.sh                      # full run (background dependencies: see below)
#   DS_LIST="gotham25" bash run_p3_alloc.sh   # 只跑一个数据集
# EN: DS_LIST="gotham25" bash run_p3_alloc.sh   # run only one dataset
#   T=2 bash run_p3_alloc.sh                  # 冒烟（只验开关，不进论文）
# EN: T=2 bash run_p3_alloc.sh                  # smoke test (only verify the switches, not for the paper)
#   bash run_p3_alloc.sh status               # 非阻塞看进度
# EN: bash run_p3_alloc.sh status               # non-blocking progress check
#   PAR=4 SEEDS="1 2 3 4 5" bash run_p3_alloc.sh
#
# 四臂（env 切换，无需 yaml）：
# EN: Four arms (switched via env, no yaml needed):
#   A1  NSAC_MODE=uniform EPSILON_MODE=uniform
#   A2  NSAC_MODE=slice   EPSILON_MODE=uniform
#   A3  NSAC_MODE=uniform EPSILON_MODE=slice
#   A4  NSAC_MODE=slice   EPSILON_MODE=slice
#
# 前置：fix_v17 + fix_v18 + fix_v20 已 apply；core/slice_alloc.py 已就位。
# EN: Prerequisite: fix_v17 + fix_v18 + fix_v20 applied; core/slice_alloc.py in place.
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
PAR=${PAR:-4}
SEEDS=${SEEDS:-"1 2 3 4 5"}
DS_LIST=${DS_LIST:-"iotid20 gotham25"}
ALPHA=${ALPHA:-0.5}
T=${T:-50}
RULE=${RULE:-bw}                      # slice_weight_rule: bw | k_ratio | inv_k_ratio
SLICE_MAP=${SLICE_MAP:-datadriven}    # datadriven | random
OUT=${OUT:-results_alloc}
LOG=${LOG:-logs/p3}
TIMEOUT=${TIMEOUT:-5400}              # 单 run 上限 90 min | EN: single-run cap 90 min

cd "$PROJ" || { echo "ERROR: 项目目录不存在: $PROJ"; exit 1; }
mkdir -p "$OUT" "$LOG"

ARMS="cruniform_epsuniform:uniform:uniform crslice_epsuniform:slice:uniform cruniform_epsslice:uniform:slice crslice_epsslice:slice:slice"

n_run(){ pgrep -f 'run_experiment\.py' 2>/dev/null | wc -l; }
throttle(){ while [ "$(n_run)" -ge "$PAR" ]; do sleep 15; done; }

summary(){
  local n=0
  for DS in $DS_LIST; do
    for spec in $ARMS; do
      local tag="${spec%%:*}"
      for s in $SEEDS; do
        [ -f "$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json" ] && n=$((n+1))
      done
    done
  done
  echo "  完成 $n / $(( $(echo $DS_LIST|wc -w) * 4 * $(echo $SEEDS|wc -w) ))   run   |   在跑 $(n_run)"
  echo "  最近日志:"; ls -t "$LOG" 2>/dev/null | head -3 | sed 's/^/    /'
}

if [ "${1:-run}" = "status" ]; then
  echo "=== Phase 3 status ==="; summary; exit 0
fi

echo "================================================================"
echo " Phase 3  切片感知 CR x ε 分配"
echo " datasets=[$DS_LIST]  arms=4  seeds=[$SEEDS]  alpha=$ALPHA  T=$T  par=$PAR"
echo " slice_map=$SLICE_MAP   slice_weight_rule=$RULE"
echo "================================================================"

# --------------------------------------------------------------- preflight
pre=0
grep -q "'gotham25'"           run_experiment.py 2>/dev/null || { echo "[!!] run_experiment.py 未含 gotham25 -> python fix_v17.py --apply"; pre=1; }
grep -q "\[fix_v18\]"          run_baselines.py  2>/dev/null || { echo "[!!] fix_v18 未打 -> python fix_v18.py --apply"; pre=1; }
grep -q "\[fix_v20\]"          core/simulator.py 2>/dev/null || { echo "[!!] fix_v20 未打 -> python fix_v20.py --apply"; pre=1; }
[ -f core/slice_alloc.py ]                                  || { echo "[!!] 缺 core/slice_alloc.py"; pre=1; }
$PY core/slice_alloc.py >/dev/null 2>&1                     || { echo "[!!] core/slice_alloc.py 自测未过"; pre=1; }
for ds in $DS_LIST; do
  [ -f "data/processed/${ds}_train.npz" ] || { echo "[!!] 缺 data/processed/${ds}_train.npz"; pre=1; }
done
[ "$pre" -eq 0 ] && echo "[preflight] OK" || { echo "[abort] preflight 未过。"; exit 1; }

# --------------------------------------------------------------- gate (T=2)
GATET=$( [ "$T" -gt 2 ] 2>/dev/null && echo 2 || echo "$T" )
echo "[gate] 每个数据集跑 1 个 T=$GATET 的冒烟，验开关 + 切片覆盖度"
for DS in $DS_LIST; do
  g="$LOG/gate_${DS}.log"
  NSAC_MODE=slice EPSILON_MODE=slice SLICE_WEIGHT_RULE=$RULE SLICE_MAP=$SLICE_MAP \
    timeout 1800 $PY -u run_experiment.py --method proposed --dataset "$DS" \
    --alpha "$ALPHA" --seed 1 --tag gateP3 --T "$GATET" --e_local 1 \
    --output_dir "$OUT/_gate" > "$g" 2>&1
  gj=$(find "$OUT/_gate" -name results.json 2>/dev/null | head -1)
  if [ -z "$gj" ]; then
    echo "  [FAIL] $DS gate 未写出 results.json，尾部:"; tail -n 12 "$g" | sed 's/^/     | /'; exit 1
  fi
  span=$(grep -oE "span=[0-9.]+" "$g" | head -1)
  nsl=$(grep -oE "slices=\[[^]]*\]" "$g" | head -1 | tr -cd ',' | wc -c)
  echo "  [ok] $DS gate 通过  $span  slices=$((nsl+1))"
  [ "${span#span=}" = "0.000" ] && echo "     [!!] 注意: sigma_mult span=0 -> slice 分配退化，检查 RULE/SLICE_MAP"
  [ "$((nsl+1))" -lt 3 ] && echo "     [!!] 注意: 只出现 $((nsl+1)) 个切片(<3) -> 论文的'三切片'覆盖不全，建议换 SLICE_MAP 或分区"
done
rm -rf "$OUT/_gate"

# --------------------------------------------------------------- launch
echo "[launch] 启动 (par=$PAR) ..."
for DS in $DS_LIST; do
  for spec in $ARMS; do
    tag="${spec%%:*}"; rest="${spec#*:}"; NSAC="${rest%%:*}"; EPS="${rest#*:}"
    for s in $SEEDS; do
      f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json"
      [ -f "$f" ] && { echo "  [skip] $DS $tag s$s"; continue; }
      throttle
      NSAC_MODE="$NSAC" EPSILON_MODE="$EPS" SLICE_WEIGHT_RULE="$RULE" SLICE_MAP="$SLICE_MAP" \
        timeout "$TIMEOUT" $PY -u run_experiment.py --method proposed \
        --dataset "$DS" --alpha "$ALPHA" --seed "$s" --tag "$tag" --T "$T" \
        --output_dir "$OUT/$DS" > "$LOG/${DS}_${tag}_s${s}.log" 2>&1 &
      echo "  [launch] $DS $tag s$s  (NSAC=$NSAC EPS=$EPS)"
    done
  done
done
wait

echo "[verify] 逐 run 检查产物（以文件为准，不看 exit code）"
miss=0
for DS in $DS_LIST; do
  for spec in $ARMS; do
    tag="${spec%%:*}"
    for s in $SEEDS; do
      f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${s}_${tag}/results.json"
      if [ ! -f "$f" ]; then
        miss=$((miss+1)); echo "  [MISSING] $f"
        tail -n 10 "$LOG/${DS}_${tag}_s${s}.log" 2>/dev/null | sed 's/^/     | /'
      fi
    done
  done
done
echo "================================================================"
summary
if [ "$miss" -eq 0 ]; then
  echo " [OK] Phase 3 全部完成 -> python analyze_alloc.py $OUT"
else
  echo " [FAIL] 缺 $miss 个 run —— 按上面恢复后重跑本脚本（幂等）"
fi
echo "================================================================"

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
