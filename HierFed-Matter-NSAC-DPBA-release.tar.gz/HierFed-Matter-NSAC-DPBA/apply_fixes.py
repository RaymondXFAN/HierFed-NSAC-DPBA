#!/usr/bin/env python3
"""
apply_fixes.py -- one-shot, idempotent patch for the 4 HierFed bugs (B1..B4).

Usage (from the project root):
    python apply_fixes.py                 # patch . in place, writes *.bak
    python apply_fixes.py /path/to/proj   # patch another tree
    python apply_fixes.py --dry_run       # show what would change

Bugs fixed
  B1  core/nsac.py        QSGD quantiser divided by `levels` twice ->
                          round-trip gain collapsed to 0.0097 (104x too small).
                          Every NSAC-enabled run was frozen near AUC 0.5.
  B2  core/simulator.py   compute_noise_scale_rdp() called without the client
                          subsampling rate q (=M/N) -> sigma inflated ~5x;
                          + non-finite divergence guard; + per-round SNR print.
  B3  6 files             `except ValueError: auc = 0.0` masked a diverged
                          (NaN) model as a genuine AUC of 0.0.
  B4  aggregate_supp.py   the baseline table pooled all 12 ablation tags of
                          "proposed" into one bogus n=60 row.

Safety: every replacement is asserted BEFORE anything is written; a file is
only written when all of its patches applied. Re-running is a no-op (files
already carrying the fix are reported as SKIP).
"""
import os
import sys
import shutil
import argparse

# (relpath, old, new)  -- ordered
P = []

# ------------------------------------------------------------------ B1
P.append(("core/nsac.py",
"""    # Quantize: scale each value to levels, then snap to level boundaries
    scaled = sparse_grad * levels / norm
    quantized = torch.sign(scaled) * torch.floor(scaled.abs()) / levels
    # Un-normalize to original scale
    q_values = quantized * norm / levels""",
"""    # [FIX B1] Standard QSGD: q_i = sign(g_i)*floor(|g_i|*L/||g||)*||g||/L
    # The previous version divided by `levels` TWICE (once inside `quantized`,
    # then again in `q_values`), so compress->decompress returned only ~0.0097
    # of the original norm (104x attenuation). Every NSAC-enabled run was
    # silently frozen near AUC 0.5. Verified by selftest_fix.py.
    scaled = sparse_grad * levels / norm
    q_values = torch.sign(scaled) * torch.floor(scaled.abs()) * norm / levels"""))

# ------------------------------------------------------------------ B2a config
P.append(("core/simulator.py",
"""        self.clip_norm = float(config.get('clip_norm', 1.0))
        self.T = config.get('T', 100)""",
"""        self.clip_norm = float(config.get('clip_norm', 1.0))
        # [FIX B2] The RDP accountant must be told the client subsampling rate.
        # It used to fall back to its default q=1.0, inflating sigma by ~1/q
        # (5x for M/N = 4/20).  Default here is the true M/N.
        self.dp_subsampling_rate = float(
            config.get('dp_subsampling_rate', float(M) / max(float(N), 1.0)))
        # [FIX B2] print ||dw|| vs ||noise|| each round so the SNR is visible.
        self.dp_debug = bool(config.get('dp_debug', False))
        self.T = config.get('T', 100)"""))

# ------------------------------------------------------------------ B2b sigma
P.append(("core/simulator.py",
"""            sigma_base = compute_noise_scale_rdp(self.epsilon_total, self.T,
                                                  self.delta, self.clip_norm)
            print(f"RDP base σ={sigma_base:.4f} (ε_total={self.epsilon_total}, T={self.T})")""",
"""            sigma_base = compute_noise_scale_rdp(
                self.epsilon_total, self.T, self.delta, self.clip_norm,
                subsampling_rate=self.dp_subsampling_rate)
            print(f"RDP base σ={sigma_base:.4f} (ε_total={self.epsilon_total}, "
                  f"T={self.T}, q={self.dp_subsampling_rate:.3f})")"""))

# ------------------------------------------------------------------ B2c loop + instrument
P.append(("core/simulator.py",
"""            # --- Step 1: Device local training + DP noise injection ---
            device_gradients = {}
            for dev_id in range(self.N):
                idx_list = self.partitions.get(str(dev_id), [])
                if len(idx_list) == 0:
                    device_gradients[dev_id] = torch.zeros(self.d, device=DEVICE)
                    continue

                local_data = self.X_train[idx_list]
                local_labels = self.y_train[idx_list]

                gradient = local_train(
                    self.model, local_data, local_labels,
                    num_epochs=self.config.get('E_local', 5),
                    batch_size=self.config.get('batch_size', 32),
                    learning_rate=self.eta,
                    oversample=self.config.get('oversample_minority', True),
                )

                if self.disable_dp:
                    # Ablation: no DP -> use the raw local update
                    device_gradients[dev_id] = gradient
                    continue

                # Clip -> per-device Gaussian noise (Eq.14/15).
                # sigma_i = sigma_base * (1.4 - 0.4*S_rel_i): high-sensitivity
                # devices receive LESS noise; low-sensitivity devices MORE.
                device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])
                clipped = clip_gradient(gradient, self.clip_norm)
                noise = torch.randn_like(clipped) * device_sigma
                device_gradients[dev_id] = clipped + noise""",
"""            # --- Step 1: Device local training + DP noise injection ---
            device_gradients = {}
            _dbg_dw, _dbg_noise, _dbg_sig = [], [], []
            for dev_id in range(self.N):
                idx_list = self.partitions.get(str(dev_id), [])
                if len(idx_list) == 0:
                    device_gradients[dev_id] = torch.zeros(self.d, device=DEVICE)
                    continue

                local_data = self.X_train[idx_list]
                local_labels = self.y_train[idx_list]

                gradient = local_train(
                    self.model, local_data, local_labels,
                    num_epochs=self.config.get('E_local', 5),
                    batch_size=self.config.get('batch_size', 32),
                    learning_rate=self.eta,
                    oversample=self.config.get('oversample_minority', True),
                )

                if self.disable_dp:
                    # Ablation: no DP -> use the raw local update
                    device_gradients[dev_id] = gradient
                    continue

                # Clip -> per-device Gaussian noise (Eq.14/15).
                # sigma_i = sigma_base * (1.4 - 0.4*S_rel_i): high-sensitivity
                # devices receive LESS noise; low-sensitivity devices MORE.
                device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])
                clipped = clip_gradient(gradient, self.clip_norm)
                noise = torch.randn_like(clipped) * device_sigma
                device_gradients[dev_id] = clipped + noise
                # [FIX B2] instrumentation: the model update returned by
                # local_train ALREADY contains the learning rate, so the noise
                # added here must be on the same scale. Track both norms.
                _dbg_dw.append(float(clipped.norm()))
                _dbg_noise.append(float(noise.norm()))
                _dbg_sig.append(float(device_sigma))

            if (not self.disable_dp) and self.dp_debug and _dbg_dw:
                import statistics as _st
                _dw = _st.mean(_dbg_dw)
                _nz = _st.mean(_dbg_noise)
                print(f"[DP-DEBUG] round {t}: ||dw||={_dw:.4f}  "
                      f"sigma_i~{_st.mean(_dbg_sig):.4f}  ||noise||={_nz:.2f}  "
                      f"SNR=||dw||/||noise||={_dw / (_nz + 1e-12):.3e}")"""))

# ------------------------------------------------------------------ B2d guard
P.append(("core/simulator.py",
"""                    enable_nsac=self.enable_nsac,
                )

            # --- Step 5: Update global model ---""",
"""                    enable_nsac=self.enable_nsac,
                )

            # [FIX B2] divergence guard: a single NaN round used to silently
            # poison the model for the remaining rounds (and later faked an
            # AUC of 0.0 via the B3 sentinel).
            if not torch.isfinite(new_params).all():
                _nbad = int((~torch.isfinite(new_params)).sum().item())
                print(f"[WARN] round {t}: {_nbad}/{new_params.numel()} non-finite "
                      f"params -> skipping update (DP noise too large?)")
                continue

            # --- Step 5: Update global model ---"""))

# ------------------------------------------------------------------ B3 simulator
P.append(("core/simulator.py",
"""        try:
            auc = roc_auc_score(y_true, y_prob)
        except ValueError:
            auc = 0.0

        # ---- 诊断打印 ----""",
"""        try:
            auc = roc_auc_score(y_true, y_prob)
        except ValueError:
            # [FIX B3] do NOT fake AUC=0.0 (which reads as "perfectly
            # inverted"). A ValueError here means y_prob contained NaN/inf,
            # i.e. the model diverged. Record NaN so aggregation can flag it.
            auc = float('nan')

        # ---- 诊断打印 ----"""))

# ------------------------------------------------------------------ B3 runner
P.append(("baselines/runner.py",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.0""",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        # [FIX B3] NaN sentinel instead of a fake 0.0 (see README_FIX.md)
        auc = float('nan')"""))

# ------------------------------------------------------------------ B3 evaluate
P.append(("evaluate.py",
"""        try:
            metrics['auc_roc'] = roc_auc_score(y_true, y_prob)
        except ValueError:
            metrics['auc_roc'] = 0.0""",
"""        try:
            metrics['auc_roc'] = roc_auc_score(y_true, y_prob)
        except ValueError:
            # [FIX B3] NaN sentinel instead of a fake 0.0
            metrics['auc_roc'] = float('nan')"""))

# ------------------------------------------------------------------ B3 focal
P.append(("run_focal_loss.py",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.0""",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        # [FIX B3] NaN sentinel instead of a fake 0.0
        auc = float('nan')"""))

# ------------------------------------------------------------------ B3 centralized
P.append(("run_centralized.py",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        auc = 0.0""",
"""    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        # [FIX B3] NaN sentinel instead of a fake 0.0
        auc = float('nan')"""))

# ------------------------------------------------------------------ B4 pooling
P.append(("aggregate_supp.py",
"""        for method in methods:
            vals = [v for (mth, a, t), lst in main.items()
                    if mth == method and a == alpha
                    for v in lst]""",
"""        for method in methods:
            # [FIX B4] "proposed" also carries 12 ablation tags (full,
            # hierfed_*, w_*); pooling them all produced a bogus n=60 row.
            # Use only the primary tag: "full" for proposed, "" for baselines.
            if method == "proposed":
                if (method, alpha, "full") not in main:
                    continue
                keep = "full"
            else:
                keep = ""
            vals = [v for (mth, a, t), lst in main.items()
                    if mth == method and a == alpha and t == keep
                    for v in lst]"""))

# ------------------------------------------------------------------ B4 nan-safe helpers
P.append(("aggregate_supp.py",
"""def _ms(vals):
    vals = [v for v in vals if v is not None]""",
"""def _clean(vals):
    \"\"\"[FIX B3] drop NaN/None so diverged (NaN) runs never poison a mean.\"\"\"
    import math
    out = []
    for v in vals:
        if v is None:
            continue
        try:
            if isinstance(v, float) and math.isnan(v):
                continue
        except Exception:
            pass
        out.append(v)
    return out


def _ms(vals):
    vals = _clean(vals)"""))

# ------------------------------------------------------------------ B4 data-quality banner
P.append(("aggregate_supp.py",
'''    md = ["# HierFed-Matter-NSAC-DPBA — Supplementary Result Tables",
          f"_generated by aggregate_supp.py_\\n"]''',
'''    md = ["# HierFed-Matter-NSAC-DPBA — Supplementary Result Tables",
          f"_generated by aggregate_supp.py_\\n"]
    # [FIX B3] surface runs whose AUC came back NaN (= diverged model), so a
    # "perfect" table can never hide a collapsed configuration again.
    _nan_rows = []
    for (_mth, _aa, _tt), _lst in sorted(main.items()):
        _nb = sum(1 for _, _fm, _ in _lst
                  if _fm.get("auc_roc") is None
                  or (isinstance(_fm.get("auc_roc"), float)
                      and np.isnan(_fm["auc_roc"])))
        if _nb:
            _nan_rows.append(f"{_mth}_a{_aa}" + (f"_{_tt}" if _tt else "")
                             + f" ({_nb}/{len(_lst)})")
    if _nan_rows:
        md.append("## \\u26a0 Data quality: non-finite (diverged) AUC, excluded")
        md.append(", ".join(_nan_rows) + "\\n")'''))

# ------------------------------------------------------------------ CSV nan safety (optional)
OPT = [
    ("np.mean(d['auc'])", "np.mean(_clean(d['auc']))", "aggregate_supp.py"),
    ("np.mean(d['f1m'])", "np.mean(_clean(d['f1m']))", "aggregate_supp.py"),
    ("np.mean([fm['auc_roc'] for _, fm, _ in lst])",
     "np.mean(_clean([fm['auc_roc'] for _, fm, _ in lst]))", "aggregate_supp.py"),
    ("np.mean([fm['f1_macro'] for _, fm, _ in lst])",
     "np.mean(_clean([fm['f1_macro'] for _, fm, _ in lst]))", "aggregate_supp.py"),
    ("np.mean(auc)", "np.mean(_clean(auc))", "aggregate_supp.py"),
    ("np.mean(f1m)", "np.mean(_clean(f1m))", "aggregate_supp.py"),
]

# ------------------------------------------------------------------ config
P.append(("configs/base.yaml",
"""clip_norm: 1.0          # 梯度裁剪范数 C""",
"""clip_norm: 1.0          # 梯度裁剪范数 C
dp_subsampling_rate: 0.2  # [FIX B2] 客户端采样率 q=M/N=4/20（此前漏传→默认1.0，σ 被放大5倍）
dp_debug: true            # [FIX B2] 每轮打印 ||dw|| vs ||noise||（SNR），便于诊断"""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--no_backup", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root)

    # group patches per file
    per_file = {}
    for rel, old, new in P:
        per_file.setdefault(rel, []).append((old, new))
    for (old, new, rel) in OPT:
        per_file.setdefault(rel, []).append((old, new, "optional"))

    n_ok = n_skip = n_fail = 0
    for rel in sorted(per_file):
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            print(f"  [MISSING] {rel}")
            n_fail += 1
            continue
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()

        todo = []
        for item in per_file[rel]:
            old, new = item[0], item[1]
            optional = len(item) > 2
            # Idempotency: if the patched text is already present this hunk is
            # done. (Must test `new in src` FIRST: for append-style hunks the
            # old text stays a prefix of the new one, so an `old not in src`
            # guard alone would re-append on every run.)
            if new in src:
                continue
            if old not in src:
                if optional:
                    continue
                print(f"  [FAIL] {rel}: pattern not found -> {old.splitlines()[0][:60]!r}")
                n_fail += 1
                todo = None
                break
            todo.append((old, new))

        if todo is None:
            continue
        if not todo:
            print(f"  [SKIP] {rel}: already patched")
            n_skip += 1
            continue

        out = src
        for old, new in todo:
            out = out.replace(old, new)
        if args.dry_run:
            print(f"  [DRY ] {rel}: {len(todo)} hunk(s) would apply")
            continue
        if not args.no_backup and not os.path.exists(path + ".bak"):
            shutil.copy2(path, path + ".bak")
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"  [ OK ] {rel}: {len(todo)} hunk(s) applied")
        n_ok += 1

    print(f"\napply_fixes: files_patched={n_ok}  already_ok={n_skip}  failed={n_fail}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
