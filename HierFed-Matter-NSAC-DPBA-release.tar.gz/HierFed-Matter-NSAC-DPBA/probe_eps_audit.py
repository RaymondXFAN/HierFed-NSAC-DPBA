#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
probe_eps_audit.py -- READ-ONLY privacy-budget audit, TREE-AWARE.

    python probe_eps_audit.py

WHY
---
The first version merged every `results*` directory by method name, so stale
exploration trees (results_v3, results_probe, results_clip, *_OLD_buggy) made
`proposed` look like it ran at four different epsilons.  It did not.

This version:
  A. groups by TOP-LEVEL RESULT TREE and reports, per tree, the epsilon each
     method recorded -- so the CURRENT batch is never mixed with history
  B. pulls the sigma each job actually printed (the ground truth), and
  C. checks whether the methods inside one tree share one privacy budget.

Stale trees are listed but excluded from the verdict.
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))

# trees that must NOT be treated as the current experiment
STALE = ("OLD", "buggy", "archive", "results_v3", "results_probe", "results_clip",
         "results_mia", "results_focal")
KEEP = ("results_baseline", "results_eps", "results_ablation", "results_scale",
        "results_v11gate", "results_v11gate_base")


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def method_of(dirname):
    if re.match(r"epsweep_eps[\d.]+_", dirname):
        return "eps-sweep"
    m = re.match(r"(.+?)_(iotid20|cicids2017|gotham|tii)", dirname)
    return m.group(1) if m else dirname


def trees():
    out = sorted(d for d in os.listdir(HERE)
                 if d.startswith("results") and os.path.isdir(os.path.join(HERE, d)))
    return out


def is_stale(t):
    return any(s in t for s in STALE)


def read_tree(tree):
    """method -> {'eps': {value: n}, 'dirs': [...]}"""
    info = defaultdict(lambda: {"eps": defaultdict(int), "dirs": []})
    for p in glob.glob(os.path.join(HERE, tree, "*", "results.json")):
        try:
            d = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        cfg = d.get("config") or {}
        e = cfg.get("epsilon_total", cfg.get("epsilon"))
        meth = method_of(os.path.basename(os.path.dirname(p)))
        info[meth]["dirs"].append(os.path.basename(os.path.dirname(p)))
        if e is not None:
            info[meth]["eps"][str(e)] += 1
    return info


def sigma_from_logs(meth, tree):
    """first sigma/epsilon line printed by this method's job logs."""
    pats = [os.path.join(HERE, "logs", "jobs", f"{meth}*.log"),
            os.path.join(HERE, "logs", f"{meth}*.log")]
    for pat in pats:
        for p in sorted(glob.glob(pat))[:1]:
            try:
                txt = open(p, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            for ln in txt.splitlines():
                if re.search(r"sigma|σ|noise scale|per unit C", ln, re.I):
                    return os.path.basename(p), ln.strip()[:96]
    return None, None


def sigma_value(text):
    """first float following sigma / \u03c3 in a log line."""
    if not text:
        return None
    m = re.search(r"(?:sigma[_a-zA-Z\s\(]*|σ\s*=)\s*=?\s*(\d+\.?\d*)", text, re.I)
    if not m:
        m = re.search(r"(\d+\.\d+)", text)
    try:
        return float(m.group(1)) if m else None
    except (TypeError, ValueError):
        return None


def main():
    print("=" * 78)
    print("  privacy-budget audit (tree-aware, read-only)")
    print(f"  project root : {HERE}")
    print("=" * 78)

    allt = trees()
    cur = [t for t in allt if not is_stale(t) and t in KEEP]
    stale = [t for t in allt if t not in cur]
    print(f"\n  current trees : {cur}")
    print(f"  stale/excluded: {stale or '(none)'}")

    summary = {}
    for tree in cur:
        bar(f"tree: {tree}")
        info = read_tree(tree)
        if not info:
            print("  (empty)")
            continue
        print(f"  {'method':<22} {'epsilon(config)':<24} {'n':>4}  sigma (log)")
        print("  " + "-" * 92)
        for meth in sorted(info):
            eps = info[meth]["eps"]
            n = len(info[meth]["dirs"])
            etxt = ", ".join(f"{k} x{v}" for k, v in
                             sorted(eps.items(), key=lambda kv: float(kv[0]))) or "--"
            logname, sig = sigma_from_logs(meth, tree)
            print(f"  {meth:<22} {etxt[:23]:<24} {n:>4}  {(sig or '')[:56]}")
            summary.setdefault(tree, {})[meth] = sorted(eps, key=lambda s: float(s))

    bar("verdict per tree -- do all methods share one privacy budget?")
    for tree in cur:
        d = summary.get(tree) or {}
        meths = [m for m in d if m != "eps-sweep"]
        if not meths:                      # the sweep spans a grid by design
            print(f"  [{tree}] epsilon GRID by design "
                  f"({', '.join(sorted({v for e in d.values() for v in e}, key=float))})"
                  f" -- expected for a sweep, not a problem")
            continue
        # the log sigma is the ground truth
        sig = {}
        for m in meths:
            _, line = sigma_from_logs(m, tree)
            v = sigma_value(line)
            if v is not None:
                sig[m] = v
        if len(sig) >= 2:
            med = sorted(sig.values())[len(sig) // 2]
            ok = all(0.67 <= v / med <= 1.5 for v in sig.values())
            print(f"  [{tree}] sigma used (from logs): " +
                  ", ".join(f"{k}={v:g}" for k, v in sorted(sig.items())))
            print(f"      median sigma = {med:g}  ->  "
                  f"{'MATCHED (all within 1.5x)' if ok else 'MISMATCHED'}")
            if not ok:
                print("      a method whose sigma differs by >1.5x is NOT comparable")
        else:
            vals = defaultdict(set)
            for m in meths:
                for v in d[m] or ["(unset)"]:
                    vals[v].add(m)
            if len(vals) <= 1:
                print(f"  [{tree}] MATCHED: epsilon = {next(iter(vals), '?')}")
            else:
                print(f"  [{tree}] config epsilon differs: " +
                      "; ".join(f"{v} <- {','.join(sorted(ms))}"
                                for v, ms in sorted(vals.items(),
                                                    key=lambda kv: float(kv[0])
                                                    if kv[0].replace('.', '', 1).isdigit()
                                                    else 1e18)))
    print("\n  NOTE: a config value of 3.0 that coexists with a log sigma for 399")
    print("  means the config file is STALE (base.yaml says 3.0, the runs used 399).")
    print("  The sigma line in the job log is the ground truth -- trust it, and fix")
    print("  base.yaml so the paper's reproducibility section is not wrong.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
