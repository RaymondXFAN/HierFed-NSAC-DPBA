#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v13.py -- repair the missing `import os` in core/nsac.py (introduced by
fix_v9's C-4 patch) AND audit the patched files for any other missing name.

    python fix_v13.py            # AUDIT ONLY (no writes) -- run this first
    python fix_v13.py --apply    # add the missing stdlib imports (backup .bak_v13)
    python fix_v13.py --revert   # restore

WHY
---
fix_v9 inserted slices_from_env() into core/nsac.py:

    def slices_from_env(env=None):
        e = os.environ if env is None else env      # <-- NameError: os

core/nsac.py imports torch / numpy / typing / dataclasses but NOT os, so every
path that constructs HierFedMatterSimulator dies instantly:

    core/simulator.py:244   _sv = slices_from_env()

That is the whole proposed path -- run_experiment.py, run_epsilon_sweep.py and
run_focal_loss.py.  Cheap to fix, but it silently wasted a batch launch.

The audit uses `ast` to find any *Load* name that is never imported, assigned,
a parameter or a builtin -- so it also catches the NEXT landmine before an
8-hour re-run.
"""
import argparse
import ast
import builtins
import os
import py_compile
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TARGETS = ["core/nsac.py", "core/simulator.py", "core/hierfed.py",
           "baselines/runner.py", "run_experiment.py", "run_epsilon_sweep.py",
           "run_parallel.py", "run_baselines.py"]
MARK = "[fix_v13]"
STDLIB_SAFE = {"os", "sys", "re", "json", "math", "time", "copy", "random",
               "itertools", "collections", "functools", "pathlib", "typing",
               "threading", "subprocess", "shutil", "glob", "warnings",
               "dataclasses", "hashlib", "uuid"}


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def missing_names(path):
    """Names used but never imported / assigned / parameter / builtin."""
    try:
        tree = ast.parse(open(path, encoding="utf-8").read())
    except Exception as e:
        return {"<parse error>": str(e)}
    known = set(dir(builtins)) | {"__file__", "__name__", "__doc__", "self", "cls"}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                known.add((a.asname or a.name).split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            for a in node.names:
                known.add(a.asname or a.name)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            known.add(node.id)
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            known.add(node.name)
            a = node.args
            for arg in list(a.args) + list(a.posonlyargs) + list(a.kwonlyargs):
                known.add(arg.arg)
            for extra in (a.vararg, a.kwarg):
                if extra:
                    known.add(extra.arg)
        elif isinstance(node, ast.ExceptHandler) and node.name:
            known.add(node.name)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            known.update(node.names)
        elif isinstance(node, ast.ClassDef):
            known.add(node.name)
        elif isinstance(node, ast.Lambda):
            a = node.args
            for arg in list(a.args) + list(a.posonlyargs) + list(a.kwonlyargs):
                known.add(arg.arg)
            for extra in (a.vararg, a.kwarg):
                if extra:
                    known.add(extra.arg)
    out = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            if node.id not in known:
                out.setdefault(node.id, node.lineno)
    return out


def audit(verbose=True):
    bar("missing-name audit  (imports / assignments / params / builtins)")
    findings = {}
    for rel in TARGETS:
        p = os.path.join(HERE, rel)
        if not os.path.exists(p):
            if verbose:
                print(f"  {rel:26} -- not found")
            continue
        miss = missing_names(p)
        findings[rel] = miss
        mark = "OK " if not miss else "!! "
        det = "" if not miss else "   -> " + ", ".join(
            f"{k} (line {v})" for k, v in sorted(miss.items(), key=lambda kv: kv[1]))
        if verbose or miss:
            print(f"  [{mark}] {rel:26}{det}")
    return findings


def apply_fix(findings):
    bar("applying [fix_v13]")
    rel = "core/nsac.py"
    p = os.path.join(HERE, rel)
    if not os.path.exists(p):
        print(f"  !! {rel} not found")
        return 1
    src = open(p, encoding="utf-8").read()
    if MARK in src:
        print(f"  [skip] {MARK} already applied")
        return 0
    miss = findings.get(rel) or missing_names(p)
    need = sorted(n for n in miss if n in STDLIB_SAFE)
    if not need:
        print(f"  nothing to add (unresolved: {sorted(miss) or 'none'})")
        return 0
    lines = src.splitlines(keepends=True)
    last = 0
    for i, l in enumerate(lines):
        if l.startswith(("import ", "from ")):
            last = i
    if last == 0:
        print("  !! no import block found -- aborting")
        return 1
    ins = "".join(f"import {n}  # {MARK} (used by slices_from_env)\n"
                  for n in need)
    new = "".join(lines[:last + 1]) + ins + "".join(lines[last + 1:])
    bak = p + ".bak_v13"
    if not os.path.exists(bak):
        shutil.copy2(p, bak)
        print(f"  backup -> {os.path.relpath(bak, HERE)}")
    with open(p, "w", encoding="utf-8") as f:
        f.write(new)
    try:
        py_compile.compile(p, doraise=True)
        print(f"  [ok] py_compile {rel}")
    except Exception as e:
        print(f"  !! py_compile FAILED: {e}\n  restoring")
        shutil.copy2(bak, p)
        return 1
    print(f"  added: {need}")
    chk = missing_names(p)
    print(f"  re-audit {rel}: {'CLEAN' if not chk else chk}")
    bar("NEXT")
    print("  python -c \"import core.nsac as n; print(n.slices_from_env())\"")
    print("  expect a dict with cr_scale / k_overrides / bits_overrides")
    print("\n  then re-run the proposed gate job:")
    print("    nohup python -u run_experiment.py --dataset iotid20 --alpha 0.5 "
          "--seed 1 --method proposed \\")
    print("          --tag v11gate --output_dir results_v11gate "
          "> logs/v11_gate_proposed.log 2>&1 &")
    print("    python check_v11_gate.py")
    return 0


def revert():
    bar("revert")
    p = os.path.join(HERE, "core", "nsac.py")
    bak = p + ".bak_v13"
    if not os.path.exists(bak):
        print("  !! no .bak_v13 found")
        return 1
    shutil.copy2(bak, p)
    print("  restored core/nsac.py")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  missing-import repair + audit  [fix_v13]")
    print(f"  project root : {HERE}")
    print("=" * 78)
    if a.revert:
        return revert()
    findings = audit()
    if a.apply:
        return apply_fix(findings)
    bad = {k: v for k, v in findings.items() if v}
    print(f"\n  {len(bad)} file(s) with unresolved names"
          if bad else "\n  every target file is clean")
    print("  (dry run -- nothing written.  --apply to fix core/nsac.py)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
