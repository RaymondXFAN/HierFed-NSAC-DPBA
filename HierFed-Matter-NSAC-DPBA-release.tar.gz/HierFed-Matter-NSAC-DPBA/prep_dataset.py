r"""
prep_dataset.py  (v3 -- multi-file + one-hot + NaN-aware + NATIVE device partitioning)

Why v3 (vs v2): Gotham's packet-level features are MUTUALLY EXCLUSIVE per protocol
(a UDP row has no tcp.* fields and vice versa), so a naive "drop rows containing NaN"
throws away ~every row. v3 probes a schema first, then:
  * one-hot encodes selected/auto categorical columns (frame.protocols, ip.proto, tcp.flags, ...)
  * handles NaN by policy:  --nan-mode zero | median | drop   (default: zero)
  * auto-drops identifier columns (ip.src, eth.dst, frame.time, ...)
  * keeps feature dim fixed across all files

Also builds, when --native-n > 0, a REAL device-level partition (Gotham ships one
file per device) -> non-IID with a genuine physical basis, no artificial Dirichlet.

Outputs (same schema as data/preprocess.py):
    data/processed/<name>_train.npz / _test.npz
    data/processed/<name>_partitions_alpha{alpha}.json     (Dirichlet)
    data/processed/<name>_partitions_native.json           (real device groups)
    data/processed/<name>_device_ids.npy
    data/processed/<name>_feature_names.txt

STEP 1 -- always inspect first:
    python prep_dataset.py --inspect --csv-glob '/root/autodl-tmp/raw/*.csv.gz'
"""
import os
import re
import glob
import json
import argparse

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

try:
    from data.preprocess import dirichlet_partition
except Exception:
    def dirichlet_partition(labels, N, alpha, seed=1):
        rng = np.random.default_rng(seed)
        labels = np.asarray(labels)
        device_indices = {i: [] for i in range(N)}
        for c in np.unique(labels):
            idx = np.where(labels == c)[0]
            rng.shuffle(idx)
            props = rng.dirichlet(np.repeat(alpha, N))
            cuts = (np.cumsum(props) * len(idx)).astype(int)[:-1]
            for i, part in enumerate(np.split(idx, cuts)):
                device_indices[i].extend(part.tolist())
        return {i: sorted(v) for i, v in device_indices.items()}


# auto-drop these identifier-ish columns (case-insensitive substring/regex)
ID_PATTERNS = [r"flow[._ ]?id", r"\bid\b", r"ip[._]?(src|dst)", r"eth[._]?(src|dst)",
               r"mac", r"frame[._]?time", r"\btime", r"timestamp", r"date"]
DEFAULT_ONEHOT = ["frame.protocols", "ip.proto", "ip.flags", "tcp.flags", "tcp.options"]


def human(n):
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f}{u}"
        n /= 1024.0
    return f"{n:.1f}PB"


def is_id_col(c):
    lc = c.lower().strip()
    return any(re.search(p, lc) for p in ID_PATTERNS)


def expand_sources(args):
    srcs = list(getattr(args, "csv_glob", None) or [])
    if getattr(args, "csv", None):
        srcs.insert(0, args.csv)
    out, seen = [], set()
    for pat in srcs:
        for s in (sorted(glob.glob(pat)) if any(ch in pat for ch in "*?[") else [pat]):
            if s not in seen and os.path.isfile(s):
                seen.add(s)
                out.append(s)
    return out


def do_inspect(srcs):
    print(f"[inspect] {len(srcs)} file(s), total "
          f"{human(sum(os.path.getsize(s) for s in srcs))}")
    for s in srcs[:4]:
        print(f"    {os.path.basename(s):<34} {human(os.path.getsize(s))}")
    if len(srcs) > 4:
        print(f"    ... (+{len(srcs) - 4} more)")
    df = pd.read_csv(srcs[0], nrows=2000, low_memory=False)
    print(f"\n[inspect] first-file preview shape={df.shape}, columns:")
    for c in df.columns:
        nun = df[c].nunique(dropna=True)
        nan = df[c].isna().mean()
        tag = ""
        if df[c].dtype == object or nun <= 15:
            tag = "  vals " + ", ".join(sorted(map(str, pd.unique(df[c].dropna())))[:8])
        print(f"    {c:<32} {str(df[c].dtype):<9} nuniq={nun:<7} nan={nan:5.1%}{tag}")
    print("\n[inspect] 列一致性 ...")
    heads = {}
    for s in srcs:
        try:
            heads[s] = pd.read_csv(s, nrows=0).columns.tolist()
        except Exception as e:
            print(f"    !! 读取失败 {os.path.basename(s)}: {e}")
    if heads:
        from collections import Counter
        cnt = Counter(tuple(v) for v in heads.values())
        ref_t, ref_n = cnt.most_common(1)[0]
        ref = list(ref_t)
        print(f"    主流表头: {ref_n}/{len(heads)} 个文件（{len(ref)} 列）")
        n_bad = 0
        for s, cols in heads.items():
            if tuple(cols) == ref_t:
                continue
            n_bad += 1
            miss = [c for c in ref if c not in cols]
            extra = [c for c in cols if c not in ref]
            print(f"    !! {os.path.basename(s)}: {len(cols)} 列 | 缺 {miss} | 多 {extra}")
        print("    " + ("OK 全部一致，可安全合并" if n_bad == 0
                        else f"WARN {n_bad} 个文件表头不同（转换时缺列按 0 填充）"))
    print("\n[inspect] 下一步示例：\n"
          f"  python prep_dataset.py --csv-glob '<glob>' --name gotham25 \\\n"
          f"    --label-col {df.columns[-1]} --normal-labels 'Benign' \\\n"
          f"    --onehot-cols {' '.join(DEFAULT_ONEHOT)} --nan-mode zero \\\n"
          f"    --max-per-device 8000 --max-samples 600000 --native-n 20")


def build_schema(args, srcs):
    # probe a sample spread across several files -> better category coverage
    per = max(2000, args.probe_rows // max(1, min(len(srcs), 8)))
    probe = pd.concat([pd.read_csv(s, nrows=per, low_memory=False)
                       for s in srcs[:8]], ignore_index=True)
    label = args.label_col
    feats = [c for c in probe.columns if c != label and c not in args.drop_cols
             and not is_id_col(c)]
    num, cat, dropped = [], [], []
    for c in feats:
        s = probe[c]
        nun = s.nunique(dropna=True)
        if c in args.onehot_cols:
            cat.append(c)                       # forced categorical (even if numeric dtype)
        elif pd.api.types.is_numeric_dtype(s):
            num.append(c)                       # keep even if mostly-NaN (protocol-exclusive)
        elif args.auto_onehot_maxcard and nun <= args.auto_onehot_maxcard:
            cat.append(c)
        else:
            v = pd.to_numeric(s, errors="coerce")
            if v.notna().mean() >= 0.5 and nun > args.onehot_max_categories:
                num.append(c)
            else:
                dropped.append(c)
    vocab = {}
    for c in cat:
        vals = sorted(set(probe[c].dropna().astype(str)))[:args.onehot_max_categories]
        vocab[c] = vals
    med = {c: float(pd.to_numeric(probe[c], errors="coerce").median()) for c in num}
    names = list(num)
    for c in cat:
        names += [f"{c}={v}" for v in vocab[c]]
    print(f"[schema] numeric={len(num)} onehot={ {c: len(v) for c, v in vocab.items()} } "
          f"dropped={dropped}")
    return {"num": num, "cat": cat, "vocab": vocab, "med": med, "names": names}


def transform(chunk, schema, args, normals, report=None):
    """Build a fixed-width feature matrix. Columns missing from THIS file are
    filled with zeros and recorded in `report` (files are not guaranteed to share
    an identical header set)."""
    y = (~chunk[args.label_col].astype(str).str.strip().isin(normals)).astype(int).values
    n = len(chunk)
    cols = []
    for c in schema["num"]:
        if c not in chunk.columns:
            if report is not None:
                report.add(c)
            cols.append(np.zeros(n, dtype=np.float32))
            continue
        v = pd.to_numeric(chunk[c].astype(str), errors="coerce")
        if args.nan_mode == "median":
            v = v.fillna(schema["med"][c])
        elif args.nan_mode == "drop":
            pass
        else:
            v = v.fillna(0.0)
        cols.append(v.to_numpy(dtype=np.float32))
    for c in schema["cat"]:
        if c not in chunk.columns:
            if report is not None:
                report.add(c)
            for _ in schema["vocab"][c]:
                cols.append(np.zeros(n, dtype=np.float32))
            continue
        s = chunk[c].astype(str)
        for val in schema["vocab"][c]:
            cols.append((s == val).to_numpy(dtype=np.float32))
    if not cols:
        raise ValueError("no features built")
    X = np.column_stack(cols) if len(cols) > 1 else cols[0].reshape(-1, 1)
    X[~np.isfinite(X)] = 0.0
    if args.nan_mode == "drop":
        present_num = [c for c in schema["num"] if c in chunk.columns]
        if present_num:
            good = ~np.isnan(np.column_stack([
                pd.to_numeric(chunk[c].astype(str), errors="coerce").to_numpy()
                for c in present_num]))
            keep = good.all(axis=1)
            X, y = X[keep], y[keep]
    return X, y


def do_inspect_labels(srcs, label_col="label"):
    """Per-file label audit: how many classes, which files are pure-single-class."""
    print(f"[labels] auditing {len(srcs)} files on column {label_col!r} ...")
    grand, pure, mixed = {}, [], []
    for s in srcs:
        try:
            d = pd.read_csv(s, usecols=[label_col], low_memory=False)
        except Exception as e:
            print(f"    !! {os.path.basename(s)}: {e}")
            continue
        vc = d[label_col].value_counts(dropna=False).to_dict()
        for k, v in vc.items():
            grand[k] = grand.get(k, 0) + int(v)
        tag = "PURE" if len(vc) == 1 else f"mixed({len(vc)})"
        (pure if len(vc) == 1 else mixed).append(os.path.basename(s))
        print(f"    {os.path.basename(s):<34} rows={len(d):<9} {tag:<10} {vc}")
    tot = sum(grand.values())
    print(f"\n[labels] TOTAL rows = {tot}")
    print(f"[labels] GLOBAL distribution (sorted by count):")
    for k, v in sorted(grand.items(), key=lambda x: -x[1]):
        print(f"    label={k:<6} {v:>12,}  {v / max(1, tot):6.2%}")
    print(f"[labels] pure-single-class files: {len(pure)} / {len(srcs)}")
    print(f"[labels] mixed files: {len(mixed)}")
    print(f"[labels] non-normal classes present: "
          f"{sorted(k for k in grand if str(k) not in ('0', '0.0'))}")
    print("\n[labels] 若 0 是正常类，二分类设定为: normal=label 0, attack=其余。")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv"); ap.add_argument("--csv-glob", nargs="+")
    ap.add_argument("--name"); ap.add_argument("--inspect", action="store_true")
    ap.add_argument("--inspect-labels", action="store_true",
                    help="audit the per-file label composition and exit")
    ap.add_argument("--label-col", default="label")
    ap.add_argument("--normal-labels",
                    default="Benign,Normal,normal,BENIGN,normal.,0,0.0,false")
    ap.add_argument("--drop-cols", nargs="*", default=[])
    ap.add_argument("--onehot-cols", nargs="*", default=DEFAULT_ONEHOT)
    ap.add_argument("--auto-onehot-maxcard", type=int, default=15)
    ap.add_argument("--onehot-max-categories", type=int, default=40)
    ap.add_argument("--nan-mode", choices=["zero", "median", "drop"], default="zero")
    ap.add_argument("--probe-rows", type=int, default=200000)
    ap.add_argument("--max-samples", type=int, default=600000)
    ap.add_argument("--max-per-device", type=int, default=0)
    ap.add_argument("--sample-frac", type=float, default=0.0,
                    help="keep a random fraction of EVERY file (memory-flat on huge "
                         "corpora, e.g. 17M rows). 0 = off.")
    ap.add_argument("--exclude-glob", nargs="*", default=[],
                    help="glob(s) of files to EXCLUDE from the corpus")
    ap.add_argument("--device-regex", default=r"(\d+)")
    ap.add_argument("--native-n", type=int, default=0)
    ap.add_argument("--test-ratio", type=float, default=0.2)
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--alphas", type=float, nargs="+", default=[0.5, 0.1])
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out-dir", default="data/processed")
    ap.add_argument("--chunksize", type=int, default=200000)
    args = ap.parse_args()

    srcs = expand_sources(args)
    if args.exclude_glob:
        excl = set()
        for e in args.exclude_glob:
            excl.update(glob.glob(e))
        before = len(srcs)
        srcs = [s for s in srcs if s not in excl]
        print(f"[prep] --exclude-glob removed {before - len(srcs)} file(s)")
    if not srcs:
        ap.error("no input files (use --csv or --csv-glob)")
    if args.inspect:
        do_inspect(srcs); return
    if args.inspect_labels:
        do_inspect_labels(srcs, args.label_col); return
    if not args.name:
        ap.error("--name is required for conversion")

    normals = {s.strip() for s in args.normal_labels.split(",") if s.strip()}
    dev_re = re.compile(args.device_regex)
    schema = build_schema(args, srcs)

    Xs_all, ys_all, dev_all = [], [], []
    missing_report = set()
    need = set([args.label_col] + schema["num"] + schema["cat"])
    for si, src in enumerate(srcs):
        m = dev_re.search(os.path.basename(src))
        dev_id = int(m.group(1)) if m else si
        size_mb = os.path.getsize(src) / 1e6
        df = pd.read_csv(src, usecols=lambda c: c in need, low_memory=False)
        if args.label_col not in df.columns:
            raise KeyError(f"{os.path.basename(src)}: no column {args.label_col!r}")
        n0 = len(df)
        # optional per-file random fraction (keeps memory flat on huge corpora:
        # e.g. 17M rows -> keep 6% of every file instead of loading everything)
        if args.sample_frac and 0.0 < args.sample_frac < 1.0:
            df = df.sample(frac=args.sample_frac, random_state=args.seed + dev_id)
        # RANDOM per-device subsample (NOT head!) -- files are label-sorted, so
        # taking the first K rows would grab a single class and destroy the data.
        if args.max_per_device and len(df) > args.max_per_device:
            df = df.sample(n=args.max_per_device, random_state=args.seed + dev_id)
        X, y = transform(df, schema, args, normals, missing_report)
        print(f"[prep] {os.path.basename(src):<34} dev={dev_id:<4} "
              f"kept={len(X):<7}(of {n0}, {size_mb:.1f}MB) "
              f"normal={int((y == 0).sum())} attack={int((y == 1).sum())}")
        Xs_all.append(X)
        ys_all.append(y)
        dev_all.append(np.full(len(X), dev_id, dtype=np.int32))

    if missing_report:
        print(f"[warn] 以下列在部分文件中缺失，已按 0 填充: {sorted(missing_report)}")

    X = np.vstack(Xs_all); y = np.concatenate(ys_all); dev = np.concatenate(dev_all)
    dim = X.shape[1]
    print(f"[prep] merged {len(X)} rows x {dim} feats, {len(np.unique(dev))} devices, "
          f"normal={int((y == 0).sum())} attack={int((y == 1).sum())}")

    if args.max_samples and len(X) > args.max_samples:
        keep, _ = train_test_split(np.arange(len(X)), train_size=args.max_samples,
                                   random_state=args.seed, stratify=y)
        keep = np.sort(keep); X, y, dev = X[keep], y[keep], dev[keep]
        print(f"[prep] stratified cap -> {len(X)} rows")

    X = StandardScaler().fit_transform(X).astype(np.float32)
    X_tr, X_te, y_tr, y_te, dev_tr, _ = train_test_split(
        X, y, dev, test_size=args.test_ratio, random_state=args.seed, stratify=y)

    os.makedirs(args.out_dir, exist_ok=True)
    np.savez(os.path.join(args.out_dir, f"{args.name}_train.npz"), X=X_tr, y=y_tr)
    np.savez(os.path.join(args.out_dir, f"{args.name}_test.npz"), X=X_te, y=y_te)
    np.save(os.path.join(args.out_dir, f"{args.name}_device_ids.npy"), dev_tr)
    with open(os.path.join(args.out_dir, f"{args.name}_feature_names.txt"), "w") as f:
        f.write("\n".join(schema["names"]))

    meta = {"N": args.N, "seed": args.seed, "feature_dim": int(dim),
            "num_train": int(len(y_tr)), "num_test": int(len(y_te)),
            "normal_train": int((y_tr == 0).sum()), "attack_train": int((y_tr == 1).sum()),
            "nan_mode": args.nan_mode, "n_source_files": len(srcs),
            "n_devices_raw": int(len(np.unique(dev_tr)))}

    for a in args.alphas:
        blob = dict(meta, alpha=a, device_indices=dirichlet_partition(y_tr, args.N, a, args.seed))
        with open(os.path.join(args.out_dir, f"{args.name}_partitions_alpha{a}.json"), "w") as f:
            json.dump(blob, f, indent=2)
        print(f"[prep] wrote {args.name}_partitions_alpha{a}.json")

    if args.native_n > 0:
        uniq, counts = np.unique(dev_tr, return_counts=True)
        order = np.argsort(-counts)
        groups = {i: [] for i in range(args.native_n)}; load = [0] * args.native_n
        for oi in order:
            g = int(np.argmin(load)); groups[g].append(int(uniq[oi])); load[g] += int(counts[oi])
        idx_by_dev = {int(d): np.where(dev_tr == d)[0].tolist() for d in uniq}
        native = {str(i): sorted(i for d in groups[i] for i in idx_by_dev[d])
                  for i in range(args.native_n)}
        blob = dict(meta, alpha="native", partition="device-level (real non-IID)",
                    N=args.native_n, device_groups={str(i): groups[i] for i in range(args.native_n)},
                    device_indices=native)
        with open(os.path.join(args.out_dir, f"{args.name}_partitions_native.json"), "w") as f:
            json.dump(blob, f, indent=2)
        print(f"[prep] wrote {args.name}_partitions_native.json "
              f"({len(uniq)} devices -> {args.native_n} clients)")

    print(f"[prep] DONE -> {args.out_dir}/{args.name}_*  (feature_dim={dim})")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
