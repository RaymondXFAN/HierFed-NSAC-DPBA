#!/usr/bin/env bash
# =============================================================================
# apply_config_A.sh -- freeze the FINAL configuration (Route A, decided 2026-10-03)
#
# Route A = keep the paper's original protocol (ALL N=20 devices participate,
# q = 1.0), and report the privacy level HONESTLY.
#
#   eps = 399  <->  sigma_base = 0.3592  <->  AUC ~ 0.96   (the measured optimum)
#
# Config-only: no source code is touched.
#   bash apply_config_A.sh          # apply
#   bash apply_config_A.sh --check  # show current values only
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }

show () {
  echo "--- configs/base.yaml ---"
  grep -nE '^(epsilon_total|dp_subsampling_rate|client_sample_rate|dp_noise_scale|oversample_minority|alpha_s|delta_s):' configs/base.yaml || true
  echo "--- run_epsilon_sweep.py ---"
  grep -n '^EPSILON_VALUES' run_epsilon_sweep.py || true
}

if [ "${1:-}" = "--check" ]; then show; exit 0; fi

cp -n configs/base.yaml configs/base.yaml.bak_A 2>/dev/null || true

# q = 1 both in the protocol and in the accountant (they MUST agree)
sed -i 's|^epsilon_total:.*|epsilon_total: 399.0      # [A] 诚实 eps（q=1，σ_base=0.3592，实测 AUC≈0.96）|' configs/base.yaml
sed -i 's|^dp_subsampling_rate:.*|dp_subsampling_rate: 1.0   # [A] 全设备参与（与论文 Eq.1-2 一致）|' configs/base.yaml
if grep -q '^client_sample_rate:' configs/base.yaml; then
  sed -i 's|^client_sample_rate:.*|client_sample_rate: 1.0    # [A] 不采样：协议全部设备参与|' configs/base.yaml
else
  echo 'client_sample_rate: 1.0    # [A] 不采样：协议全部设备参与' >> configs/base.yaml
fi
sed -i 's|^dp_noise_scale:.*|dp_noise_scale: 1.0       # [A] σ 完全由 epsilon_total 推出|' configs/base.yaml
sed -i 's|^oversample_minority:.*|oversample_minority: true  # [A] B 路证明：必须开启，否则塌向单类|' configs/base.yaml

# the old eps range {0.5..10} sits entirely in the "far too noisy" zone
sed -i 's|^EPSILON_VALUES = .*|EPSILON_VALUES = [100.0, 200.0, 300.0, 400.0, 700.0, 1500.0]|' run_epsilon_sweep.py

echo "[A] configuration frozen:"
show
cat <<'EOF'

下一步（顺序执行）:
  1) 单 seed 验证（约 20 分钟）
       nohup python -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
             --output_dir results_A --tag A_full > logs/A_full.log 2>&1 &
       # 期望: RDP base σ=0.3592 (ε_total=399.0, T=50, q=1.000)
       # EN: expected: RDP base σ=0.3592 (ε_total=399.0, T=50, q=1.000)
       #       n_part=20/20   Final: AUC ≈ 0.96

  2) 挪走全部旧结果
       mv results_ablation results_ablation_OLD_buggy
       mv results_baseline results_baseline_OLD_buggy
       mv results_eps      results_eps_OLD_buggy
       mv results_scale    results_scale_OLD_buggy

  3) 全量重跑（4 并发，约 20h）
       export OMP_NUM_THREADS=8
       nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 \
             > logs/parallel_A.log 2>&1 &
EOF

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
