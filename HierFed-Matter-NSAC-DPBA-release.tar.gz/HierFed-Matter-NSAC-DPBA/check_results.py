"""
check_results.py -- validate every results.json before pausing / after resuming.

Why this matters
----------------
run_parallel.py treats an experiment as "done" if its results.json exists. But a
process killed while writing results.json leaves a TRUNCATED file, which would be
silently skipped forever and would later break the aggregate tables.

This script verifies each results.json:
  * parses as JSON
  * contains final_metrics.auc_roc
and moves any BAD file to logs/corrupt/<name>_results.json while deleting the
experiment folder, so the parallel driver re-runs it cleanly.

Usage
-----
    python check_results.py             # validate and quarantine bad files
    python check_results.py --dry_run   # report only, change nothing
"""
import os
import sys
import json
import glob
import shutil
import argparse

ROOTS = ["results", "results_ablation", "results_baseline", "results_eps",
         "results_scale", "results_precheck"]


def check(path):
    try:
        with open(path, encoding="utf-8") as f:
            r = json.load(f)
    except Exception as e:  # noqa: BLE001
        return False, f"json error: {type(e).__name__}: {e}"
    if not isinstance(r, dict):
        return False, "top level is not a dict"
    fm = r.get("final_metrics")
    if not isinstance(fm, dict):
        return False, "missing final_metrics"
    if "auc_roc" not in fm:
        return False, "missing auc_roc"
    return True, "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--roots", nargs="+", default=ROOTS)
    args = ap.parse_args()

    corrupt_dir = os.path.join("logs", "corrupt")
    total = good = bad = 0
    bad_list = []

    for root in args.roots:
        if not os.path.isdir(root):
            continue
        for path in sorted(glob.glob(os.path.join(root, "*", "results.json"))):
            total += 1
            ok, why = check(path)
            if ok:
                good += 1
            else:
                bad += 1
                exp_dir = os.path.dirname(path)
                bad_list.append((path, why))
                print(f"  [BAD] {path}  ({why})")
                if not args.dry_run:
                    os.makedirs(corrupt_dir, exist_ok=True)
                    dst = os.path.join(corrupt_dir,
                                       os.path.basename(exp_dir) + "__results.json")
                    try:
                        shutil.move(path, dst)
                    except Exception:  # noqa: BLE001
                        pass
                    shutil.rmtree(exp_dir, ignore_errors=True)

    print()
    print(f"[check_results] scanned={total}  ok={good}  bad={bad}")
    if bad and not args.dry_run:
        print(f"[check_results] quarantined {bad} bad file(s) -> {corrupt_dir}/"
              f"  (they will be re-run on resume)")
    elif bad:
        print("[check_results] dry run only -- nothing was changed")
    else:
        print("[check_results] all result files are valid ✔  safe to pause/resume")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
