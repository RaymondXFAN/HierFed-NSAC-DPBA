#!/usr/bin/env python3
"""Offline logic test for fix_v10: reproduce the mixed-device crash with the
OLD run_topk_qsgd and prove the NEW one survives an empty partition, with
correct byte accounting.  Pure numpy -- no torch, no GPU, no data."""
import numpy as np
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------ mini torch
class T:
    def __init__(self, data, device='cpu'):
        self.data = np.asarray(data, dtype=np.float32)
        self.device = device
    def __len__(self): return self.data.shape[0]
    def to(self, d): return T(self.data, d)
    def float(self): return self
    def abs(self): return T(np.abs(self.data), self.device)
    def norm(self): return T(np.array([np.linalg.norm(self.data)]), self.device)
    def all(self): return bool(np.all(self.data))

class Torch:
    def zeros(self, n, device='cpu'): return T(np.zeros(n), device)
    def isfinite(self, x): return T(np.isfinite(x.data).astype(np.float32), x.device)
    def nan_to_num(self, x, nan=0.0, posinf=0.0, neginf=0.0):
        return T(np.nan_to_num(x.data, nan=nan, posinf=posinf, neginf=neginf), x.device)
    def stack(self, xs):
        devs = {x.device for x in xs}
        if len(devs) > 1:
            raise RuntimeError("Expected all tensors to be on the same device, "
                               "but found at least two devices, cuda:0 and cpu!")
        class S:
            def __init__(s, a, d): s.data, s.device = a, d
            def mean(s, dim=0): return T(s.data.mean(axis=dim), s.device)
        return S(np.stack([x.data for x in xs]), xs[0].device)

DEVICE = 'cuda:0'
N, T_ = 4, 3
D = 10
NPZ = {}

def _mkglobals():
    def nsac_compress(g, sc, adaptive_down=False):
        return {'compressed_bytes': 6, 'CR_actual': 0.15}
    def nsac_decompress(c, d):            # NOTE: returns CPU, like the real one
        return T(np.zeros(d), 'cpu')
    def _local_train(model, X, y, E, bs, eta):
        return T(np.arange(D, dtype=np.float32), DEVICE)
    def star_aggregate(devs, gp, eta):
        return T(Torch().stack(list(devs.values())).mean(0).data, DEVICE)
    return dict(torch=Torch(), DEVICE=DEVICE, np=np, Dict=dict,
                SLICE_CONFIGS={'embb': type('C', (), {'k_ratio': 0.3, 'b_bits': 16,
                                                      'name': 'eMBB'})()},
                nsac_compress=nsac_compress, nsac_decompress=nsac_decompress,
                _local_train=_local_train, star_aggregate=star_aggregate,
                _get_flat_params=lambda m: T(np.zeros(D), DEVICE),
                _set_flat_params=lambda m, p: None,
                _evaluate=lambda m, X, y: {'auc_roc': 0.9, 'f1_macro': 0.8, 'f1': 0.8},
                _load_partitioned_data=lambda c: (np.zeros((20, D), np.float32),
                                                  np.zeros(20, np.float32), NPZ),
                _load_test_data=lambda c: (np.zeros((5, D), np.float32),
                                           np.zeros(5, np.float32)),
                build_model=lambda d: type('M', (), {'num_parameters': D,
                                                     'to': lambda s, x: s})())


def load_fn(path, name):
    src = open(path, encoding='utf-8').read()
    m = re.search(r"^def %s\(.*?(?=^def |^# ={20,})" % name, src, re.S | re.M)
    g = _mkglobals()
    exec(compile(m.group(0), path, 'exec'), g)
    return g[name]


NPZ = {str(i): np.arange(4) for i in range(N)}
NPZ['2'] = np.array([], dtype=int)          # device 2 has NO local data (alpha=0.1)

print("partitions:", {k: len(v) for k, v in NPZ.items()})

old = load_fn(os.path.join(HERE,'baselines','runner.py.bak_v10'), 'run_topk_qsgd')
new = load_fn(os.path.join(HERE,'baselines','runner.py'), 'run_topk_qsgd')

try:
    old({'T': T_, 'N': N}); print("OLD: no error  <-- unexpected")
except Exception as e:
    print("OLD:", type(e).__name__, "-", str(e)[:80])

r = new({'T': T_, 'N': N})
fm = r['final_metrics']
print("NEW: OK   bytes=%d full=%d CR=%.4f CF=%.2fx empty=%d" % (
    fm['comm_bytes_total'], fm['comm_bytes_full_fp32'],
    fm['compression_ratio_empirical'], fm['compression_factor_empirical'],
    fm['n_empty_device_rounds']))
assert fm['comm_bytes_total'] == 6 * (N - 1) * T_
assert fm['n_empty_device_rounds'] == 1 * T_
assert abs(fm['compression_factor_empirical'] - (N * D * 4 * T_) / (6 * (N - 1) * T_)) < 1e-9
assert len(r['round_metrics']) == T_ and 'bytes_round' in r['round_metrics'][0]
print("[mini_test] PASS")

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
