#!/usr/bin/env bash
# =============================================================================
# run_route_b.sh (v2) -- Route B: fix the class-imbalance collapse FIRST, then
#                        see whether that buys DP-noise headroom.
#
#   bash run_route_b.sh            # launch 4 runs in parallel (~20-25 min)
#   bash run_route_b.sh --wait     # ...and print a summary
#
# Why these 4 (calibrated on the finished Route-A sweep):
#   Route A (no oversampling) gave AUC 0.9325 / 0.9439 / 0.7640 / 0.6633 for
#   scale 0.05 / 0.1 / 0.2 / 0.3, i.e. the ceiling is ~0.94 and scale >= 0.2
#   already collapses.  So Route B must answer: does repairing the imbalance
#   (oversample_minority: true, which local_train already supports but was
#   turned off in base.yaml) move the *noise tolerance* to the right?
#
#   b1  oversample, NO dp, NO nsac  -> base ceiling        target >= 0.98
#   b2  oversample, NO dp, NSAC     -> NSAC cost alone     target >= 0.93
#   b3  oversample, dp scale 0.30   -> Route-A failed here (0.663).
#                                      Does oversampling rescue it?  target >= 0.85
#   b4  oversample, dp scale 1.00   -> the honest eps=3 noise.  target >= 0.85
#
# Only config files are written; no source code is touched.
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}

cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }
mkdir -p logs configs results_route_b

mkcfg () {          # $1 = suffix, $2 = oversample, $3 = dp_noise_scale
  local out="configs/rb_$1.yaml"
  cp configs/base.yaml "$out"
  if grep -q "^oversample_minority:" "$out"; then
    sed -i "s|^oversample_minority:.*|oversample_minority: $2|" "$out"
  else
    echo "oversample_minority: $2" >> "$out"
  fi
  if grep -q "^dp_noise_scale:" "$out"; then
    sed -i "s|^dp_noise_scale:.*|dp_noise_scale: $3|" "$out"
  else
    echo "dp_noise_scale: $3" >> "$out"
  fi
  printf "  [cfg] %-24s oversample=%s  dp_noise_scale=%s\n" "$out" "$2" "$3"
}

run () {            # $1 = tag, $2 = cfg suffix, $3.. = extra CLI flags
  local tag=$1 cfg=$2; shift 2
  echo "[route-b] launch $tag"
  nohup $PY -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
        --output_dir results_route_b --tag "$tag" \
        --config "configs/rb_${cfg}.yaml" "$@" \
        > "logs/rb_${tag}.log" 2>&1 &
}

mkcfg b1_ov_nodp      true  1.0
mkcfg b2_ov_nsac_nodp true  1.0
mkcfg b3_ov_dp030     true  0.30
mkcfg b4_ov_dp100     true  1.00

run b1_ov_nodp      b1_ov_nodp      --disable_dp --disable_nsac
run b2_ov_nsac_nodp b2_ov_nsac_nodp --disable_dp
run b3_ov_dp030     b3_ov_dp030
run b4_ov_dp100     b4_ov_dp100

cat <<'EOF'

[route-b] 4 runs launched (T=50, ~20-25 min, 4-way parallel).
  轨迹: grep -E "Round 1/|DP-DEBUG|WARN" logs/rb_b4_ov_dp100.log | head -8
  结果: grep -h "Final:" logs/rb_*.log
EOF

if [ "${1:-}" = "--wait" ]; then
  wait
  echo
  echo "======================= ROUTE-B SUMMARY ======================="
  for t in b1_ov_nodp b2_ov_nsac_nodp b3_ov_dp030 b4_ov_dp100; do
    printf "  %-18s " "$t"
    grep -h "Final:" "logs/rb_${t}.log" 2>/dev/null | tail -1 || echo "(no output)"
  done
  echo
  echo "  --- Route-A reference (no oversampling) ---"
  echo "    scale 0.3 -> AUC 0.6633 | scale 1.0 -> AUC 0.4997 (exploded)"
  echo
  echo "  --- ||dw|| / ||w|| / ||noise|| at round 2 ---"
  for t in b2_ov_nsac_nodp b3_ov_dp030 b4_ov_dp100; do
    printf "  %-18s " "$t"
    grep -h "DP-DEBUG" "logs/rb_${t}.log" 2>/dev/null | sed -n '2p' || true
    echo
  done
  echo "=============================================================="
  cat <<'EOF'
判读:
  b1 >= 0.98             -> base 修好了
  b1 ~ 0.83              -> oversampling 不够 -> Mihiro 出 v3 (focal loss)
  b3 >= 0.85             -> 噪声容限右移 >= 1.5x -> 有希望冲 eps 更小的口径
  b3 < 0.85 但明显优于 0.663 -> 容限右移但不够 -> 再细扫 {0.1,0.15,0.2} 找新 s*
  b4 >= 0.85             -> ***** eps=3 保住，可放全量 *****
  b3,b4 都无改善         -> eps=3 在此设置下不可达 -> 走"如实报 eps + 隐私-效用曲线"
EOF
fi

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
