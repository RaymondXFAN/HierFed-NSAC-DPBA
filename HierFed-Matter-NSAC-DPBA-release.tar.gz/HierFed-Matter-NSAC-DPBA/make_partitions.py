#!/usr/bin/env python3
r"""
make_partitions.py -- (re)generate partition json files from an EXISTING npz.
No raw-data re-read: seconds instead of minutes.

Reads:  data/processed/<name>_train.npz        (X, y)
        data/processed/<name>_device_ids.npy   (device id of each train row)

Writes: data/processed/<name>_partitions_alpha{a}.json   for each --alphas
        data/processed/<name>_partitions_native.json     if --native-n > 0

Key flag: --ensure-attack
    Makes sure EVERY client gets >=1 attack sample. Needed on Gotham, where
    70/78 devices are pure-benign, so a naive device grouping leaves ~12/20
    clients with zero attacks (those clients cannot learn any decision boundary).
    Implementation: group devices first; if a client still has no attack, a
    slice of attack rows is *sharded* from the attack-richest client into it.
    (This makes the partition "device-grouped + attack-sharded" -- documented
    in the json under "note".)

Usage:
  python make_partitions.py --name gotham25 --alphas 0.5 0.1 1.0 --N 20
  python make_partitions.py --name gotham25 --native-n 20 --ensure-attack
"""
import os
import json
import argparse
import numpy as np

try:
    from data.preprocess import dirichlet_partition
except Exception:
    def dirichlet_partition(labels, N, alpha, seed=1):
        rng = np.random.default_rng(seed)
        labels = np.asarray(labels)
        device_indices = {i: [] for i in range(N)}
        for c in np.unique(labels):
            idx = np.where(labels == c)[0]
            rng.shuffle(idx)
            props = rng.dirichlet(np.repeat(alpha, N))
            cuts = (np.cumsum(props) * len(idx)).astype(int)[:-1]
            for i, part in enumerate(np.split(idx, cuts)):
                device_indices[i].extend(part.tolist())
        return {i: sorted(v) for i, v in device_indices.items()}


def load(name, processed_dir):
    tr = np.load(os.path.join(processed_dir, f"{name}_train.npz"))
    y = tr["y"]
    dev_path = os.path.join(processed_dir, f"{name}_device_ids.npy")
    dev = np.load(dev_path) if os.path.exists(dev_path) else None
    return y, dev


def greedy_group(dev, y, n_clients):
    """Balance device sizes across n_clients (largest-first bin packing)."""
    uniq, counts = np.unique(dev, return_counts=True)
    order = np.argsort(-counts)
    groups = {i: [] for i in range(n_clients)}
    load_ = [0] * n_clients
    idx_by_dev = {int(d): np.where(dev == d)[0].tolist() for d in uniq}
    for oi in order:
        g = int(np.argmin(load_))
        groups[g].append(int(uniq[oi]))
        load_[g] += int(counts[oi])
    native = {i: sorted(i for d in groups[i] for i in idx_by_dev[d]) for i in range(n_clients)}
    return native, groups


def ensure_attack(native, groups, y, rng, attack_class=0):
    """Guarantee >=1 attack row per client by sharding from the richest client.

    attack_class: the label value that denotes ATTACK. This project's convention
    (configs/base.yaml:69) is 0=attack, 1=normal.
    """
    def atk(idxs):
        return int((y[idxs] == attack_class).sum()) if idxs else 0
    empty = [g for g in native if atk(native[g]) == 0]
    if not empty:
        return native, groups, 0
    donor = max(native, key=lambda g: atk(native[g]))
    pool = [i for i in native[donor] if y[i] == attack_class]
    rng.shuffle(pool)
    n_share = len(empty) + 1                       # donor keeps 1 share
    pieces = np.array_split(np.array(pool), n_share)
    moved = set()
    for g, piece in zip(empty, pieces[1:]):
        native[g] = sorted(native[g] + piece.tolist())
        moved.update(piece.tolist())
    native[donor] = [i for i in native[donor] if i not in moved]
    return native, groups, len(empty)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--processed-dir", default="data/processed")
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--alphas", type=float, nargs="*", default=[])
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--native-n", type=int, default=0)
    ap.add_argument("--attack-class", type=int, default=0,
                    help="label value meaning ATTACK (this project: 0=attack, "
                         "1=normal; see configs/base.yaml:69)")
    ap.add_argument("--device-regex", default=None,
                    help="(unused here; kept for CLI symmetry with prep_dataset.py)")
    ap.add_argument("--ensure-attack", action="store_true")
    args = ap.parse_args()

    y, dev = load(args.name, args.processed_dir)
    n_atk = int((y == args.attack_class).sum())
    print(f"[part] {args.name}: {len(y)} train rows, "
          f"attack(class {args.attack_class})={n_atk} normal={len(y) - n_atk}"
          f"{'' if dev is not None else '  (no device_ids found!)'}")

    meta = {"N": args.N, "seed": args.seed, "feature_dim": None,
            "num_train": int(len(y)), "attack_class": args.attack_class,
            "attack_train": n_atk, "normal_train": int(len(y) - n_atk)}

    for a in args.alphas:
        part = dirichlet_partition(y, args.N, a, args.seed)
        sizes = [len(v) for v in part.values()]
        atk = [int((y[v] == args.attack_class).sum()) if v else 0 for v in part.values()]
        blob = dict(meta, alpha=a, device_indices=part)
        fn = os.path.join(args.processed_dir, f"{args.name}_partitions_alpha{a}.json")
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(blob, f)
        print(f"[part] alpha={a:<5} min={min(sizes):<8} max={max(sizes):<8} "
              f"empty={sum(1 for s in sizes if s == 0)} "
              f"zero-attack-clients={sum(1 for x in atk if x == 0)}  -> {os.path.basename(fn)}")

    if args.native_n > 0:
        if dev is None:
            raise SystemExit("--native-n needs <name>_device_ids.npy")
        native, groups = greedy_group(dev, y, args.native_n)
        note = "device-level (real non-IID)"
        if args.ensure_attack:
            native, groups, n_fixed = ensure_attack(
                native, groups, y, np.random.default_rng(args.seed),
                attack_class=args.attack_class)
            if n_fixed:
                note += f" + attack-sharded into {n_fixed} attack-free clients"
        sizes = [len(v) for v in native.values()]
        atk = [int((y[v] == args.attack_class).sum()) if v else 0 for v in native.values()]
        blob = dict(meta, alpha="native", partition=note, N=args.native_n,
                    device_groups={str(k): v for k, v in groups.items()},
                    device_indices={str(k): sorted(v) for k, v in native.items()})
        fn = os.path.join(args.processed_dir, f"{args.name}_partitions_native.json")
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(blob, f)
        print(f"[part] native N={args.native_n} min={min(sizes)} max={max(sizes)} "
              f"zero-attack-clients={sum(1 for x in atk if x == 0)}  -> {os.path.basename(fn)}")
        print(f"[part] note: {note}")

    print("[part] DONE")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
