"""
Ablation & weight-sensitivity runner for HierFed-Matter-NSAC-DPBA (paper Table 8
+ Table B.2.2).

Answers the reviewers' core demand: isolate the marginal contribution of
HierFed / NSAC / DPBA-FIM, and quantify the Fisher-information term.

Two suites
----------
--suite component : 6 component-ablation configs (full + 5 variants)
--suite weights   : Eq.7 weight combinations, incl. "FIM-only" (0,0,0,1)
--suite both      : run both

Every run is written to <output_dir>/proposed_iotid20_alpha{A}_seed{S}_{tag}/
and aggregated across seeds into aggregate_proposed_iotid20_alpha{A}_{tag}.json.

Usage
-----
python run_ablation.py --suite component --alpha 0.5 0.1 --seeds 1 2 3 4 5 6 7 8 9 10
python run_ablation.py --suite weights   --alpha 0.5 --seeds 1 2 3 4 5
python run_ablation.py --suite both --aggregate_only
"""

import os
import sys
import json
import argparse
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

import numpy as np
import torch

from run_experiment import run_single_experiment, aggregate_results, load_config
from ablation_configs import COMPONENT_CONFIGS, WEIGHT_CONFIGS

# COMPONENT_CONFIGS / WEIGHT_CONFIGS live in ablation_configs.py (torch-free) so
# that parallel drivers can build job lists without importing this module.


def run_suite(suite_name, configs, dataset, alphas, seeds, output_dir,
              config_base, config_nsac, run_experiments=True, skip_existing=True):
    print(f"\n{'#'*70}\n# SUITE: {suite_name}\n{'#'*70}")
    table = {}
    for tag, (label, ov) in configs.items():
        for alpha in alphas:
            agg = None
            for seed in seeds:
                exp_dir = os.path.join(
                    output_dir,
                    f"proposed_{dataset}_alpha{alpha}_seed{seed}_{tag}")
                done = os.path.join(exp_dir, "results.json")
                if not run_experiments:
                    continue
                if skip_existing and os.path.exists(done):
                    print(f"[skip] {done} exists")
                    continue
                overrides = dict(ov)
                overrides["_tag"] = tag
                np.random.seed(seed)
                torch.manual_seed(seed)
                if torch.cuda.is_available():
                    torch.cuda.manual_seed(seed)
                try:
                    run_single_experiment(
                        dataset, alpha, seed, "proposed",
                        config_base, config_nsac, output_dir,
                        overrides=overrides)
                except Exception as e:
                    print(f"[ERROR] {tag} alpha={alpha} seed={seed}: {e}")
                    import traceback
                    traceback.print_exc()
            agg = aggregate_results(output_dir, dataset, alpha, "proposed",
                                    seeds, tag=tag)
            if agg:
                agg["label"] = label
                table[f"{tag}_alpha{alpha}"] = agg
    # persist suite table
    tbl_path = os.path.join(output_dir, f"ablation_table_{suite_name}.json")
    with open(tbl_path, "w", encoding="utf-8") as f:
        json.dump(table, f, indent=2)
    print(f"\n[saved] {tbl_path}")
    return table


def main():
    p = argparse.ArgumentParser(description="Ablation / weight-sensitivity runner")
    p.add_argument("--suite", choices=["component", "weights", "both"],
                   default="component")
    p.add_argument("--dataset", default="iotid20")
    p.add_argument("--alpha", type=float, nargs="+", default=[0.5, 0.1])
    p.add_argument("--seeds", type=int, nargs="+",
                   default=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    p.add_argument("--output_dir", default="results_ablation")
    p.add_argument("--config", default="configs/base.yaml")
    p.add_argument("--nsac_config", default="configs/nsac.yaml")
    p.add_argument("--aggregate_only", action="store_true",
                   help="only re-aggregate existing per-seed results")
    p.add_argument("--T", type=int, default=None,
                   help="override number of FL rounds (quick pre-checks)")
    p.add_argument("--e_local", type=int, default=None,
                   help="override local epochs per round")
    p.add_argument("--arms", nargs="+", default=None,
                   help="[fix_v16] run only these arms (keys of the suite dict)")
    p.add_argument("--epsilon", type=float, default=None,
                   help="[fix_v15] override epsilon_total (run an ablation at a"
                        " chosen privacy budget)")
    args = p.parse_args()

    config_base = load_config(args.config)
    config_nsac = load_config(args.nsac_config)
    if args.T is not None:
        config_base["T"] = args.T
    if args.e_local is not None:
        config_base["E_local"] = args.e_local
    os.makedirs(args.output_dir, exist_ok=True)
    def _select(cfgs):                               # [fix_v16]
        if not args.arms:
            return cfgs
        want = set(args.arms)
        kept = {k: v for k, v in cfgs.items() if k in want}
        missing = sorted(want - set(cfgs))
        print(f"[[fix_v16]] arms kept: {sorted(kept)} of {sorted(cfgs)}", flush=True)
        if missing:
            print(f"[[fix_v16]] WARNING unknown arms ignored: {missing}", flush=True)
        return kept

    if args.epsilon is not None:                     # [fix_v15]
        config_base["epsilon_total"] = args.epsilon
    print(f"[[fix_v15]] output_dir={args.output_dir} "
          f"epsilon_total={config_base.get('epsilon_total')} "
          f"oversample_minority={config_base.get('oversample_minority')} "
          f"T={config_base.get('T')}", flush=True)

    if torch.cuda.is_available():
        print(f"[GPU] {torch.cuda.get_device_name()}")
    else:
        print("[GPU] none (CPU)")

    if not args.aggregate_only and args.suite in ("component", "both"):
        run_suite("component", _select(COMPONENT_CONFIGS), args.dataset, args.alpha,
                  args.seeds, args.output_dir, config_base, config_nsac)
    if not args.aggregate_only and args.suite in ("weights", "both"):
        run_suite("weights", _select(WEIGHT_CONFIGS), args.dataset, args.alpha,
                  args.seeds, args.output_dir, config_base, config_nsac)

    # aggregate-only pass (rebuild tables from whatever is on disk)
    if args.aggregate_only:
        if args.suite in ("component", "both"):
            run_suite("component", _select(COMPONENT_CONFIGS), args.dataset, args.alpha,
                      args.seeds, args.output_dir, config_base, config_nsac,
                      run_experiments=False)
        if args.suite in ("weights", "both"):
            run_suite("weights", _select(WEIGHT_CONFIGS), args.dataset, args.alpha,
                      args.seeds, args.output_dir, config_base, config_nsac,
                      run_experiments=False)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
