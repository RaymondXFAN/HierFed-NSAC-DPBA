#!/usr/bin/env bash
# =============================================================================
# run_ablation_probe.sh -- 30-minute gate BEFORE the ~20h full rerun.
#
# Question it answers: at the chosen privacy level, does the ADAPTIVE
# allocation (DPBA) actually change anything vs uniform DP?  If every
# configuration lands on the same AUC, the paper's core ablation is empty --
# better to learn that now than after 20 hours.
#
# 3 configs x 2 noise levels, 1 seed, T=50 (two waves of 3, ~30 min total):
#   full   : proposed (NSAC + DPBA)
#   uni    : uniform DP        (--disable_dpba_fim)
#   nodp   : no DP at all      (--disable_dp)
# levels: eps=399 (sigma 0.359, AUC~0.96)  and  eps=108 (sigma 0.719, AUC~0.65)
#
# NOTE: this script WAITS for both waves (there is no background mode).
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-6}

cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }
mkdir -p logs configs results_probe

mkcfg () {          # $1 = suffix, $2 = epsilon_total
  local out="configs/probe_$1.yaml"
  cp configs/base.yaml "$out"
  sed -i "s|^epsilon_total:.*|epsilon_total: $2|" "$out"
  printf "  [cfg] %-26s epsilon_total=%s\n" "$out" "$2"
}

run () {            # $1 = tag, $2 = cfg, $3.. = extra flags
  local tag=$1 cfg=$2; shift 2
  echo "[probe] launch $tag"
  $PY -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
      --output_dir results_probe --tag "$tag" \
      --config "configs/probe_${cfg}.yaml" "$@" \
      > "logs/probe_${tag}.log" 2>&1
}

echo "=== freezing candidate config A first? (run apply_config_A.sh) ==="
grep -nE '^(epsilon_total|dp_subsampling_rate|client_sample_rate|oversample_minority):' configs/base.yaml || true

mkcfg eps399 399.0
mkcfg eps108 108.0

echo
echo "--- wave 1/2 : eps=399 (low noise) ---"
run e399_full eps399 &
run e399_uni  eps399 --disable_dpba_fim &
run e399_nodp eps399 --disable_dp &
wait

echo
echo "--- wave 2/2 : eps=108 (high noise -- where allocation should matter most) ---"
run e108_full eps108 &
run e108_uni  eps108 --disable_dpba_fim &
run e108_nodp eps108 --disable_dp &
wait

echo
echo "====================== ABLATION PROBE SUMMARY ======================"
for tag in e399_full e399_uni e399_nodp e108_full e108_uni e108_nodp; do
  printf "  %-12s " "$tag"
  grep -h "Final:" "logs/probe_${tag}.log" 2>/dev/null | tail -1 || echo "(no output)"
done
echo "==================================================================="
cat <<'EOF'

判读（关键看 uni vs full 的差距）:
  eps=399: full 与 uni 相差 > 0.02  -> DPBA 在低噪声下也有效    -> 主配置用 eps=399
  eps=399: 两者几乎一样            -> 主配置改用 eps=108（噪声大、分配才有发挥空间）
  eps=108: full 明显优于 uni        -> 论文主线 = 同等噪声下自适应分配的优势（数据支持）
  两档都看不出差别                 -> 需要换叙事（避开"自适应分配"这个卖点）
EOF

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
