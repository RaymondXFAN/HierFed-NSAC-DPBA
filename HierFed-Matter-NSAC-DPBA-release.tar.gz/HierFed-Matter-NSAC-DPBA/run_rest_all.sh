#!/usr/bin/env bash
# =============================================================================
# run_rest_all.sh -- one-click runner for EVERYTHING still outstanding.
#
#   bash run_rest_all.sh              # wait for epsgrid -> abl -> G-1 -> aggregate
#   SKIP_WAIT=1 bash run_rest_all.sh  # do not wait for the running epsgrid sweep
#   SUITES="component" bash run_rest_all.sh      # skip the weights suite
#   bash run_rest_all.sh status       # non-blocking progress + rate + ETA
#   bash run_rest_all.sh gate         # pre-flight gate only
#
# WHY THIS EXISTS
#   run_supplementary.sh phase_abl calls run_ablation.py ONCE, and run_suite()
#   loops config x alpha x seed SEQUENTIALLY in a single process:
#       6 configs x 2 alpha x 5 seeds = 60 runs x ~20 min = ~20 h.
#   This script splits the same 60 runs into (alpha, seed) slices and keeps PAR
#   of them in flight -> ~5 h of wall clock, same total work.
#
#   It also verifies every run by looking for results.json ON DISK:
#   run_ablation.py catches per-run exceptions and keeps going, so its exit
#   code (and run_supplementary.sh's) proves nothing.
#
#   NOTE: run_supplementary.sh "all" runs precheck -> par -> agg.  It does NOT
#   run the ablation.  That is why results_ablation/ is still empty.
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1

PY=${PY:-python}
PAR=${PAR:-4}
SUITES=${SUITES:-"component weights"}
DO_CRMATCH=${DO_CRMATCH:-1}
DO_AGG=${DO_AGG:-1}
SKIP_WAIT=${SKIP_WAIT:-0}
ABL_EPS=${ABL_EPS:-}        # [fix_v15] optional: run the ablation at this eps
ABL_ARMS=${ABL_ARMS:-}      # [fix_v16] optional: only these arms (space separated)
ABL_OK_SINCE=${ABL_OK_SINCE:-}  # treat ablation files newer than this as valid
                                # (e.g. a partial run you already completed)
EPS_EXPECT=${EPS_EXPECT:-210}
ALPHA_LIST=${ALPHA_LIST:-"0.5 0.1"}
SEED_LIST=${SEED_LIST:-"1 2 3 4 5"}

ABL=results_ablation
CR_OUT=results_crsweep
LOG=logs/rest
mkdir -p "$LOG" "$ABL" results_summary logs

ts(){ date "+%F %T"; }
log(){ echo "[$(ts)] $*" | tee -a logs/rest_runner.log; }
bar(){ echo; echo "================================================================"; \
       echo "  $*"; echo "================================================================"; }
count_json(){ find "$1" -name results.json 2>/dev/null | wc -l; }
alive(){ ps -ef | grep -v grep | grep -cE "$1"; }
throttle(){ while [ "$(jobs -rp | wc -l)" -ge "$PAR" ]; do sleep 15; done; }

tags_for(){
  # read the tag list straight from ablation_configs.py, so a newly added arm
  # (e.g. the fix_v16 TRUE-uniform controls) is never forgotten here.
  $PY - "$1" <<'PYEOF'
import importlib.util, sys
spec = importlib.util.spec_from_file_location("ac", "ablation_configs.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
d = {"component": m.COMPONENT_CONFIGS, "weights": m.WEIGHT_CONFIGS,
     "both": {**m.COMPONENT_CONFIGS, **m.WEIGHT_CONFIGS}}
print(" ".join(d[sys.argv[1]].keys()))
PYEOF
}

filter_arms(){          # $1 = full tag list -> keep only $ABL_ARMS when set
  [ -n "$ABL_ARMS" ] || { echo "$1"; return; }
  local out="" t w
  for t in $1; do
    for w in $ABL_ARMS; do
      [ "$t" = "$w" ] && out="$out $t"
    done
  done
  echo "$out"
}

# --------------------------------------------------------------------- status
rate_eta(){
  $PY - <<'PYEOF'
import glob, os, time
def scan(pat, total):
    f = sorted((os.path.getmtime(p), p) for p in glob.glob(pat))
    n = len(f)
    if n == 0:
        return n, total, None, None
    w = f[-20:]
    dt = w[-1][0] - w[0][0]
    r = (len(w) - 1) / dt * 3600.0 if dt > 0 and len(w) > 1 else 0.0
    left = total - n
    eta = left / r * 3600.0 if r > 0 else None
    when = time.strftime("%H:%M", time.localtime(time.time() + eta)) if eta else "--:--"
    return n, total, r, (eta, when)
for pat, total, name in (("results_epsgrid/*/*/results.json", 210, "epsgrid"),
                         ("results_ablation/*/results.json", 120, "ablation")):
    n, tot, r, e = scan(pat, total)
    if r:
        print("  %-9s %3d/%-4d  rate %5.1f job/h   ETA %4.2f h -> %s (if nothing else runs)"
              % (name, n, tot, r, e[0] / 3600.0, e[1]))
    else:
        print("  %-9s %3d/%-4d  (no rate yet)" % (name, n, tot))
PYEOF
}

status_now(){
  echo "=== $(ts) ==="
  echo "  alive jobs : $(alive '[r]un_baselines.py') baselines | $(alive '[r]un_ablation.py') ablation | $(alive '[r]un_experiment.py') experiment"
  echo "  epsgrid    : $(count_json results_epsgrid)/210"
  echo "  ablation   : $(count_json "$ABL")"
  for t in $(tags_for component); do
    n=$(find "$ABL" -maxdepth 1 -name "*_${t}" -type d 2>/dev/null | wc -l)
    printf "      %-20s %s dir(s)\n" "$t" "$n"
  done
  echo "  cr-match   : $(count_json "$CR_OUT")   (dir: $CR_OUT)"
  echo "  TABLES TBD : $(grep -c TBD results_summary/TABLES.md 2>/dev/null || echo '-')"
  echo "--- rate / ETA ---"
  rate_eta
  echo "--- last runner lines ---"
  tail -n 4 logs/rest_runner.log 2>/dev/null || echo "  (no runner log yet)"
}

# ------------------------------------------------------------------ 0 preflight
preflight(){
  bar "[0] preflight"
  local bad=0
  for f in run_experiment.py run_baselines.py run_ablation.py ablation_configs.py \
           run_cr_match.sh aggregate_supp.py configs/base.yaml; do
    if [ -e "$f" ]; then echo "  [ok] $f"; else echo "  [!!] MISSING $f"; bad=1; fi
  done
  grep -q "fix_v11" core/nsac.py 2>/dev/null \
    && echo "  [ok] [fix_v11] present in core/nsac.py" \
    || { echo "  [!!] fix_v11 not applied -> run: python fix_v11.py --apply"; bad=1; }
  grep -q "NSAC_CR_SCALE" core/nsac.py 2>/dev/null \
    && echo "  [ok] fix_v9 NSAC_CR_SCALE present" \
    || { echo "  [!!] fix_v9 not applied -> run: python fix_v9.py --apply"; bad=1; }
  [ "$bad" -eq 0 ] || { log "[abort] preflight failed"; return 1; }
  local pre
  pre=$(find "$ABL" -name results.json 2>/dev/null | wc -l)
  if [ "$pre" -gt 0 ]; then
    log "[0] WARNING: $ABL already holds $pre results.json."
    log "[0] run_ablation.py uses skip_existing=True -- it will KEEP them."
    log "[0] oldest mtime: $(find "$ABL" -name results.json -printf '%T+\n' 2>/dev/null | sort | head -1)"
    log "[0] run  python diag_ablation.py  to check freshness before trusting it."
  fi
  local ov
  ov=$(grep -E "^oversample_minority:" configs/base.yaml 2>/dev/null | awk '{print $2}')
  case "$ov" in
    true|True|TRUE)
      log "[0] !! configs/base.yaml has oversample_minority=$ov."
      log "[0] !! run_baselines.py/run_epsilon_sweep.py hard-set false, so this"
      log "[0] !! makes the ablation tree INCOMPARABLE with them. Run fix_v15.py." ;;
    false|False|FALSE) log "[0] ok oversample_minority=$ov (all drivers agree)" ;;
    *) log "[0] ?? oversample_minority not found in configs/base.yaml" ;;
  esac
  log "preflight OK   par=$PAR  suites=[$SUITES]  alphas=[$ALPHA_LIST]  seeds=[$SEED_LIST]  abl_eps=${ABL_EPS:-from-config}"
}

# ------------------------------------------------------------------ 1 wait
wait_epsgrid(){
  if [ "$SKIP_WAIT" = "1" ]; then log "[wait] SKIP_WAIT=1 -> not waiting"; return 0; fi
  bar "[1] waiting for the running epsgrid sweep (expect $EPS_EXPECT results.json)"
  local last=-1 same=0 n a
  while true; do
    n=$(count_json results_epsgrid); a=$(alive '[r]un_baselines.py')
    log "[wait] epsgrid=$n/$EPS_EXPECT   run_baselines alive=$a"
    if [ "$a" -eq 0 ]; then
      if [ "$n" -ge "$EPS_EXPECT" ]; then log "[wait] epsgrid DONE"; return 0; fi
      if [ "$n" -eq "$last" ]; then
        same=$((same+1))
        if [ "$same" -ge 2 ]; then
          log "[wait] WARNING: sweep stopped at $n/$EPS_EXPECT with nothing running."
          log "[wait] continuing anyway -- check logs/epsgrid/*.log for Traceback."
          return 0
        fi
      else
        same=0
      fi
    fi
    last=$n
    sleep 120
  done
}

# ------------------------------------------------------------------ 2 abl gate
gate_abl(){
  bar "[2] ablation gate: one miniature run (T=2, e_local=1) must write results.json"
  rm -rf "$ABL/_gate"
  timeout 900 $PY -u run_ablation.py --suite component --alpha 0.5 --seeds 1 \
      --T 2 --e_local 1 --output_dir "$ABL/_gate" \
      ${ABL_EPS:+--epsilon "$ABL_EPS"} ${ABL_ARMS:+--arms $ABL_ARMS} \
      > "$LOG/gate.log" 2>&1
  if [ -n "$ABL_EPS" ]; then
    grep -q "epsilon_total=${ABL_EPS}" "$LOG/gate.log" \
      && log "[gate] ok --epsilon took effect: $(grep -m1 '\[\[fix_v15\]\]' "$LOG/gate.log")" \
      || { log "[gate] FAILED -- the log does not show epsilon_total=${ABL_EPS}"; \
           tail -n 12 "$LOG/gate.log" | sed 's/^/     /'; return 1; }
  fi
  local d
  d=$(ls "$ABL"/_gate/*/results.json 2>/dev/null | head -1)
  if [ -n "$d" ]; then
    log "[gate] PASSED -> $d"
    rm -rf "$ABL/_gate"
    return 0
  fi
  log "[gate] FAILED -- tail of $LOG/gate.log:"
  tail -n 20 "$LOG/gate.log" | sed 's/^/     /'
  return 1
}

# ------------------------------------------------------------------ 3 abl run
launch_abl(){
  local suite="$1" tags n=0
  tags=$(tags_for "$suite")
  [ -n "$tags" ] || { log "[abl] unknown suite '$suite'"; return 1; }
  tags=$(filter_arms "$tags")
  [ -n "$tags" ] || { log "[abl] ABL_ARMS matched nothing in suite $suite"; return 1; }
  log "[abl] arms to verify: $tags"
  bar "[3] ablation suite=$suite   slices = $(echo $ALPHA_LIST | wc -w) alphas x $(echo $SEED_LIST | wc -w) seeds, par=$PAR"
  local t0 a s l
  if [ -n "$ABL_OK_SINCE" ]; then
    t0=$(date -d "$ABL_OK_SINCE" +%s 2>/dev/null || echo 0)
    log "[abl] freshness cutoff = '$ABL_OK_SINCE' (t0=$t0) -- files newer are accepted"
  else
    t0=$(date +%s)
  fi
  log "[abl] start stamp = $t0  (files older than this were NOT produced by this run)"
  for a in $ALPHA_LIST; do
    for s in $SEED_LIST; do
      throttle
      l="$LOG/${suite}_a${a}_s${s}.log"
      nohup $PY -u run_ablation.py --suite "$suite" --alpha "$a" --seeds "$s" \
            --output_dir "$ABL" ${ABL_EPS:+--epsilon "$ABL_EPS"} \
            ${ABL_ARMS:+--arms $ABL_ARMS} > "$l" 2>&1 &
      n=$((n+1))
      log "[abl] launched $n: $suite alpha=$a seed=$s -> $l"
    done
  done
  log "[abl] $n slices launched; waiting ..."
  wait
  local miss=0 exp=0 stale=0 f mt
  for a in $ALPHA_LIST; do for s in $SEED_LIST; do for t in $tags; do
    exp=$((exp+1))
    f="$ABL/proposed_iotid20_alpha${a}_seed${s}_${t}/results.json"
    if [ ! -f "$f" ]; then
      miss=$((miss+1)); log "[abl][MISSING] $f"
      continue
    fi
    mt=$(stat -c %Y "$f" 2>/dev/null || echo 0)
    if [ "$mt" -lt "$t0" ]; then
      stale=$((stale+1))
      log "[abl][PRE-EXISTING] $f  (mtime $(date -d @$mt '+%m-%d %H:%M') < start)"
    fi
  done; done; done
  log "[abl] suite=$suite  expected=$exp  missing=$miss  pre-existing=$stale"
  if [ "$stale" -gt 0 ]; then
    log "[abl] !! $stale file(s) predate this run -- skip_existing=True KEPT them."
    log "[abl] !! delete and re-run:  rm -rf $ABL/*_<tag>   then rerun this script"
    return 1
  fi
  if [ "$miss" -gt 0 ]; then
    log "[abl] look for 'Traceback' / 'ERROR' in $LOG/${suite}_a*_s*.log"
    return 1
  fi
  return 0
}

aggregate_abl(){
  bar "[4] rebuild ablation tables from disk (all seeds x alphas pooled)"
  local s
  for s in $SUITES; do
    $PY -u run_ablation.py --suite "$s" --alpha $ALPHA_LIST --seeds $SEED_LIST \
        --aggregate_only --output_dir "$ABL" ${ABL_EPS:+--epsilon "$ABL_EPS"} \
        2>&1 | tee -a "$LOG/agg_abl.log" | tail -n 6
  done
  ls -l "$ABL"/ablation_table_*.json 2>/dev/null || log "[agg] no ablation_table_*.json"
}

# ------------------------------------------------------------------ 5 G-1
run_crmatch(){
  bar "[5] G-1 matched-compression control (fairness anchor vs topk_qsgd CF 3.33x)"
  PAR="$PAR" bash run_cr_match.sh 2>&1 | tee -a "$LOG/crmatch.log"
  local n
  n=$(count_json "$CR_OUT")
  log "[G-1] results_crsweep results.json = $n  (expect 20)"
  [ "$n" -ge 20 ] || log "[G-1] WARNING: fewer than 20 -- check $LOG/crmatch.log"
}

# ------------------------------------------------------------------ 6 final
final_agg(){
  bar "[6] final aggregate -> results_summary/"
  $PY -u aggregate_supp.py \
      --roots "$ABL" results_baseline results_eps results_scale results \
      --out_dir results_summary 2>&1 | tee -a "$LOG/agg_final.log" | tail -n 10
  {
    echo "=============================================================="
    echo " run_rest_all.sh -- finished $(ts)"
    echo " ablation runs : $(count_json "$ABL")"
    echo " baselines     : $(count_json results_baseline)"
    echo " epsgrid       : $(count_json results_epsgrid)"
    echo " ours eps      : $(count_json results_eps)"
    echo " cr-match      : $(count_json "$CR_OUT")"
    echo " TABLES TBD    : $(grep -c TBD results_summary/TABLES.md 2>/dev/null || echo '-')"
    echo "--------------------------------------------------------------"
    [ -f results_summary/TABLES.md ] && cat results_summary/TABLES.md
    echo "=============================================================="
  } > logs/REST_SUMMARY.txt
  log "summary written -> logs/REST_SUMMARY.txt"
  echo
  cat logs/REST_SUMMARY.txt
}

# ------------------------------------------------------------------ dispatch
case "${1:-all}" in
  status) status_now ;;
  gate)   preflight && gate_abl ;;
  all)
    preflight || exit 1
    wait_epsgrid || exit 1
    gate_abl || { log "[abort] ablation gate failed -- nothing launched"; exit 1; }
    for s in $SUITES; do
      launch_abl "$s" || log "[warn] suite=$s finished with missing runs"
    done
    aggregate_abl
    [ "$DO_CRMATCH" = "1" ] && run_crmatch
    [ "$DO_AGG" = "1" ] && final_agg
    log "ALL DONE"
    ;;
  *) echo "usage: bash run_rest_all.sh {all|status|gate}"; exit 1 ;;
esac

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
