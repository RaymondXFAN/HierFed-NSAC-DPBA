"""
Main experiment runner: one command to run all experiments across
datasets, seeds, alpha values, and methods (proposed + baselines).

Usage:
  python run_experiment.py --dataset iotid20 --alpha 0.5 --seed 1
  python run_experiment.py --dataset both --alpha both --method all
  bash run_all_seeds.sh   # 5 seeds × 2 datasets × 2 alphas
"""

import os
import sys
import json
import argparse
import yaml
import numpy as np
import torch
from datetime import datetime
from pathlib import Path

# Add project root to path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from core.simulator import HierFedMatterSimulator
from baselines.runner import run_baseline


def load_config(config_path: str) -> dict:
    """Load YAML config file."""
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def run_single_experiment(
    dataset: str,
    alpha: float,
    seed: int,
    method: str = 'proposed',
    config_base: dict = None,
    config_nsac: dict = None,
    output_dir: str = 'results',
    overrides: dict = None,
) -> dict:
    """Run a single experiment (one seed, one dataset, one method).

    `overrides` may carry sensitivity weights (alpha_s/beta_s_coeff/gamma_s/delta_s),
    ablation switches (disable_dpba_fim/disable_nsac/disable_hierfed/disable_dp),
    and an optional '_tag' used to suffix the experiment folder name.
    """

    if config_base is None:
        config_base = load_config(str(ROOT / 'configs' / 'base.yaml'))
    if config_nsac is None:
        config_nsac = load_config(str(ROOT / 'configs' / 'nsac.yaml'))

    # Merge configs
    config = {**config_base, **config_nsac}
    config['seed'] = seed
    config['alpha'] = alpha
    config['dataset_name'] = dataset
    config['processed_dir'] = str(ROOT / 'data' / 'processed')
    _cn = os.environ.get('CLIP_NORM')            # [fix_v19]
    if _cn:
        config['clip_norm'] = float(_cn)
    _dm = os.environ.get('DP_CLIP_MODE')         # [fix_v19]
    if _dm:
        config['dp_clip_mode'] = _dm

    # Apply CLI overrides (sensitivity weights + ablation switches)
    tag = ''
    if overrides:
        for k, v in overrides.items():
            if k == '_tag':
                tag = str(v)
            elif v is not None:
                config[k] = v

    # Set random seed
    np.random.seed(seed)
    torch.manual_seed(seed)

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    tag_suffix = f"_{tag}" if tag else ""
    exp_name = f"{method}_{dataset}_alpha{alpha}_seed{seed}{tag_suffix}"

    print(f"\n{'='*70}")
    print(f"Experiment: {exp_name}")
    print(f"Timestamp:  {timestamp}")
    print(f"{'='*70}\n")

    if method == 'proposed':
        # Full HierFed-Matter-NSAC-DPBA
        try:
            sim = HierFedMatterSimulator(config)
            results = sim.run()
        except FileNotFoundError as e:
            print(f"⚠ Dataset not found, skipping: {e}")
            return {}
    else:
        # Baseline method
        try:
            results = run_baseline(method, config)
        except FileNotFoundError as e:
            print(f"⚠ Dataset not found, skipping: {e}")
            return {}

    # Save results
    out_path = os.path.join(output_dir, exp_name)
    os.makedirs(out_path, exist_ok=True)

    with open(os.path.join(out_path, 'results.json'), 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, default=str)

    # Quick summary
    if 'final_metrics' in results:
        fm = results['final_metrics']
        print(f"\n📊 {exp_name} Summary:")
        print(f"   F1 = {fm['f1']:.4f}  |  macro-F1 = {fm['f1_macro']:.4f}  |  "
              f"AUC = {fm['auc_roc']:.4f}  |  thresh = {fm['optimal_threshold']:.2f}")
        if 'communication_stats' in results:
            cs = results['communication_stats']
            print(f"   Speedup = {cs['speedup']:.1f}×  |  "
                  f"Core traffic = {cs['core_traffic_MB']:.1f} MB")

    return results


def aggregate_results(output_dir: str, dataset: str, alpha: float,
                      method: str = 'proposed', seeds: list = [1,2,3,4,5],
                      tag: str = ''):
    """Aggregate results across seeds for Table 4/5/6 format."""
    f1s, accs, aucs, speedups = [], [], [], []
    tag_suffix = f"_{tag}" if tag else ""

    for seed in seeds:
        exp_name = f"{method}_{dataset}_alpha{alpha}_seed{seed}{tag_suffix}"
        result_file = os.path.join(output_dir, exp_name, 'results.json')
        if not os.path.exists(result_file):
            print(f"  ⚠ Missing: {result_file}")
            continue
        with open(result_file, 'r', encoding='utf-8') as f:
            r = json.load(f)
        fm = r['final_metrics']
        f1s.append(fm['f1'])
        accs.append(fm['accuracy'])
        aucs.append(fm['auc_roc'])
        if 'communication_stats' in r:
            speedups.append(r['communication_stats']['speedup'])

    summary = {
        'method': method,
        'dataset': dataset,
        'alpha': alpha,
        'f1_mean': np.mean(f1s) if f1s else 0,
        'f1_std': np.std(f1s) if f1s else 0,
        'accuracy_mean': np.mean(accs) if accs else 0,
        'auc_mean': np.mean(aucs) if aucs else 0,
        'speedup_mean': np.mean(speedups) if speedups else 0,
        'num_seeds': len(f1s),
    }
    print(f"\n📊 Aggregated ({method}, {dataset}, α={alpha}):")
    print(f"   F1 = {summary['f1_mean']:.4f} ± {summary['f1_std']:.4f}")
    print(f"   Acc = {summary['accuracy_mean']:.4f}")
    print(f"   AUC = {summary['auc_mean']:.4f}")
    if speedups:
        print(f"   Speedup = {summary['speedup_mean']:.1f}×")

    # Save aggregate
    agg_file = os.path.join(output_dir,
        f"aggregate_{method}_{dataset}_alpha{alpha}{tag_suffix}.json")
    with open(agg_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2)

    return summary


def main():
    parser = argparse.ArgumentParser(description='Run FL experiments')
    parser.add_argument('--dataset', choices=['iotid20', 'cicids2017', 'gotham25', 'tii23', 'both'],
                        default='iotid20')
    parser.add_argument('--alpha', type=float, nargs='+', default=[0.5, 0.1])
    parser.add_argument('--seed', type=int, nargs='+', default=[1, 2, 3, 4, 5])
    parser.add_argument('--method', choices=['proposed', 'fedavg', 'fedprox',
                        'dpfedavg', 'hierfed', 'hierfed_dp', 'topk_qsgd',
                        'safeliot', 'dpfed6g', 'fedprox_dp',
                        'adaptive_clip_dp', 'layer_adaptive_dp', 'all'],
                        default='proposed')
    parser.add_argument('--output_dir', default='results')
    parser.add_argument('--config', default='configs/base.yaml')
    parser.add_argument('--nsac_config', default='configs/nsac.yaml')
    parser.add_argument('--aggregate_only', action='store_true',
                        help='Only aggregate existing results, skip running.')
    # --- sensitivity weights (Eq.7) ---
    parser.add_argument('--as', dest='alpha_s', type=float, default=None,
                        help='weight of device-type term (alpha_s)')
    parser.add_argument('--bs', dest='beta_s', type=float, default=None,
                        help='weight of data-volume term (beta_s)')
    parser.add_argument('--gs', dest='gamma_s', type=float, default=None,
                        help='weight of heterogeneity term (gamma_s)')
    parser.add_argument('--ds', dest='delta_s', type=float, default=None,
                        help='weight of Fisher-information term (delta_s)')
    # --- ablation switches ---
    parser.add_argument('--disable_dpba_fim', action='store_true')
    parser.add_argument('--disable_nsac', action='store_true')
    parser.add_argument('--disable_hierfed', action='store_true')
    parser.add_argument('--disable_dp', action='store_true')
    parser.add_argument('--tag', default='',
                        help='suffix appended to the experiment folder name')
    parser.add_argument('--T', type=int, default=None,
                        help='override number of FL rounds (for quick pre-checks)')
    parser.add_argument('--e_local', type=int, default=None,
                        help='override local epochs per round')
    parser.add_argument('--clip_norm', type=float, default=None,
                        help='[fix_v19] global clipping bound C '
                             '(only effective when dp_clip_mode=global)')
    parser.add_argument('--dp_clip_mode', choices=['global', 'per_device'],
                        default=None,
                        help='[fix_v19] override configs/base.yaml dp_clip_mode')
    args = parser.parse_args()

    # [fix_v19] 经 env 透传到 run_single_experiment（不改其签名）
    # EN: [fix_v19] passed through the env to run_single_experiment (without changing its signature)
    if args.clip_norm is not None:
        os.environ['CLIP_NORM'] = str(args.clip_norm)
    if args.dp_clip_mode is not None:
        os.environ['DP_CLIP_MODE'] = args.dp_clip_mode

    config_base = load_config(args.config)
    config_nsac = load_config(args.nsac_config)
    datasets = ['iotid20', 'cicids2017'] if args.dataset == 'both' else [args.dataset]
    alphas = args.alpha
    seeds = args.seed

    overrides = {
        'alpha_s': args.alpha_s,
        'beta_s_coeff': args.beta_s,
        'gamma_s': args.gamma_s,
        'delta_s': args.delta_s,
        'disable_dpba_fim': True if args.disable_dpba_fim else None,
        'disable_nsac': True if args.disable_nsac else None,
        'disable_hierfed': True if args.disable_hierfed else None,
        'disable_dp': True if args.disable_dp else None,
        'T': args.T,
        'E_local': args.e_local,
        '_tag': args.tag,
    }

    if args.method == 'all':
        methods = ['proposed', 'fedavg', 'fedprox', 'dpfedavg',
                   'hierfed', 'hierfed_dp', 'topk_qsgd',
                   'adaptive_clip_dp', 'layer_adaptive_dp']
    else:
        methods = [args.method]

    for dataset in datasets:
        for alpha in alphas:
            for method in methods:
                if not args.aggregate_only:
                    for seed in seeds:
                        run_single_experiment(
                            dataset, alpha, seed, method,
                            config_base, config_nsac, args.output_dir,
                            overrides=overrides,
                        )
                # Aggregate across seeds
                aggregate_results(args.output_dir, dataset, alpha, method,
                                  seeds, tag=args.tag)


if __name__ == '__main__':
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
