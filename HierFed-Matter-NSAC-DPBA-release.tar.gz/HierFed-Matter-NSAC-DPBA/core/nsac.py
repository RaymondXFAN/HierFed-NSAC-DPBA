"""
NSAC: Network-Slice-Aware Compression (Top-k + QSGD-style quantization).

Per-slice configurations (aligned with §4.2 + Figure 4):
  - uRLLC: k_ratio=0.1, b_bits=8  → 40× compression
  - eMBB:  k_ratio=0.3, b_bits=16 → ~7× compression
  - mMTC:  k_ratio=0.05, b_bits=8 → 80× compression

CR_s = (k_ratio * d) / d * (b_bits / 32) = k_ratio * b_bits / 32
"""

import torch
import numpy as np
from typing import Dict, Tuple, Optional
from dataclasses import dataclass
import os  # [fix_v13] (used by slices_from_env)


@dataclass
class SliceConfig:
    """Per-slice compression configuration."""
    name: str
    k_ratio: float       # fraction of parameters to keep (Top-k)
    b_bits: int          # quantization bit-width
    BW_mbps: float       # allocated bandwidth (Mbps)
    L_max_ms: float      # maximum latency constraint (ms)
    proc_ms: float       # processing delay (ms)

    @property
    def CR(self) -> float:
        """Compression ratio (compressed size / full size)."""
        return self.k_ratio * self.b_bits / 32.0

    @property
    def compression_factor(self) -> float:
        """Compression factor = 1 / CR."""
        return 1.0 / self.CR if self.CR > 0 else float('inf')


# Default slice configs (§4.2)
SLICE_CONFIGS = {
    'urllc': SliceConfig('uRLLC', k_ratio=0.1, b_bits=8,
                          BW_mbps=10, L_max_ms=200, proc_ms=12),
    'embb': SliceConfig('eMBB', k_ratio=0.3, b_bits=16,
                          BW_mbps=100, L_max_ms=500, proc_ms=8),
    'mmtc': SliceConfig('mMTC', k_ratio=0.05, b_bits=8,
                          BW_mbps=1, L_max_ms=1000, proc_ms=5),
}


# ============================================================
# v9: allocation modes (Direction A)
# ============================================================
def make_uniform_slice(slice_names, d, b_bits=8, name='uniform'):
    """Byte-matched *uniform* SliceConfig (the control arm).

    `slice_names` = the slice names actually assigned to the gateways in the
    slice-aware arm.  The returned config uses a single (k, b) for every client
    and is solved so that the per-client payload equals the slice-aware arm's
    MEAN payload, i.e. the total uplink budget is preserved.  This makes
    "uniform vs slice-aware" an apples-to-apples comparison.

    payload(k, b) = k*4 + k*(b//8)      (indices 4 B each + quantised values)
    """
    tot = 0.0
    for s in slice_names:
        cfg = SLICE_CONFIGS[s]
        k = max(1, int(cfg.k_ratio * d))
        tot += k * 4 + k * (cfg.b_bits // 8)
    mean_bytes = tot / max(1, len(slice_names))
    k_u = mean_bytes / (4.0 + b_bits / 8.0)
    k_ratio = max(1e-6, min(1.0, k_u / float(d)))
    bw = sum(SLICE_CONFIGS[s].BW_mbps for s in slice_names) / max(1, len(slice_names))
    return SliceConfig(name=name, k_ratio=k_ratio, b_bits=b_bits,
                       BW_mbps=bw, L_max_ms=1000.0, proc_ms=8.0)


def configure_slices(cr_scale=1.0, k_overrides=None, bits_overrides=None,
                     verbose=True):
    """v9: scale / override the per-slice compression settings in place.

    CR_s = k_ratio * b_bits / 32, so scaling k_ratio scales CR.
    Used by the CR x C grid (P2) and by the CR-scan driver.
    """
    cr_scale = float(cr_scale)
    for key, cfg in SLICE_CONFIGS.items():
        if k_overrides and str(key) in k_overrides and k_overrides[str(key)] is not None:
            cfg.k_ratio = float(k_overrides[str(key)])
        elif cr_scale != 1.0:
            cfg.k_ratio = max(1e-6, min(1.0, cfg.k_ratio * cr_scale))
        if bits_overrides and str(key) in bits_overrides and bits_overrides[str(key)] is not None:
            cfg.b_bits = int(bits_overrides[str(key)])
    if verbose:
        print("[NSAC] slice configs (v9): " + ", ".join(
            f"{k}: k={c.k_ratio:.4f}, b={c.b_bits}, CR={c.CR:.4f}"
            for k, c in SLICE_CONFIGS.items()))


def slices_from_env(env=None):
    """Build the configure_slices() kwargs from the environment."""
    e = os.environ if env is None else env

    def _f(name):
        v = e.get(name)
        try:
            return float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    return dict(
        cr_scale=(_f('NSAC_CR_SCALE') if _f('NSAC_CR_SCALE') is not None else 1.0),
        k_overrides={'urllc': _f('NSAC_K_URLLC'), 'embb': _f('NSAC_K_EMBB'),
                     'mmtc': _f('NSAC_K_MMTC')},
        bits_overrides={'urllc': _f('NSAC_BITS_URLLC'), 'embb': _f('NSAC_BITS_EMBB'),
                        'mmtc': _f('NSAC_BITS_MMTC')},
    )


def nsac_compress(
    gradient: torch.Tensor,
    slice_config: SliceConfig,
    model_size_bytes: int = 31304,  # |w| ≈ 30.6 KB (d=7826 × 4 bytes, lightweight)
    adaptive_down: bool = True,
    min_k_ratio: float = 0.01,
    k_step: float = 0.01,
) -> Dict:
    """
    NSAC compression: Top-k sparsification + QSGD-style quantization.

    Args:
        gradient: Full gradient vector (1D tensor of length d).
        slice_config: Per-slice configuration.
        model_size_bytes: Full model size in bytes (for latency estimation).
        adaptive_down: If True, reduce k when latency exceeds L_max.

    Returns:
        Dict with: indices, q_values, b_bits, k_ratio_actual, CR_actual,
                   latency_ms, compressed_bytes.
    """
    d = gradient.numel()
    k = int(slice_config.k_ratio * d)
    if k < 1:
        k = 1
    b = slice_config.b_bits
    levels = 2 ** (b - 1) - 1  # quantization levels

    # --- Adaptive k adjustment for latency ---
    k_ratio_actual = slice_config.k_ratio
    while adaptive_down and k_ratio_actual > min_k_ratio:
        CR_actual = k_ratio_actual * b / 32.0
        # Model size in bytes: d × 4 (float32)
        payload_bytes = int(CR_actual * d * 4)  # compressed payload
        BW_bytes_per_ms = slice_config.BW_mbps * 1e6 / 8 / 1000  # bytes/ms
        latency_est = payload_bytes / BW_bytes_per_ms + slice_config.proc_ms
        if latency_est <= slice_config.L_max_ms:
            break
        k_ratio_actual -= k_step
        k = int(k_ratio_actual * d)
        if k < 1:
            k = 1

    # --- Top-k sparsification ---
    abs_grad = gradient.abs()
    topk_values, topk_indices = torch.topk(abs_grad, k)
    sparse_grad = gradient[topk_indices]

    # --- QSGD-style quantization ---
    # q_val = sign(val) × floor(|val| × levels / ‖val‖) / levels
    # Normalize by the norm of selected values for unbiasedness
    norm = sparse_grad.norm()
    if norm < 1e-10:
        norm = torch.tensor(1.0, device=gradient.device)

    # [FIX B1] Standard QSGD: q_i = sign(g_i)*floor(|g_i|*L/||g||)*||g||/L
    # The previous version divided by `levels` TWICE (once inside `quantized`,
    # then again in `q_values`), so compress->decompress returned only ~0.0097
    # of the original norm (104x attenuation). Every NSAC-enabled run was
    # silently frozen near AUC 0.5. Verified by selftest_fix.py.
    scaled = sparse_grad * levels / norm
    q_values = torch.sign(scaled) * torch.floor(scaled.abs()) * norm / levels

    # --- Pack result ---
    # [fix_v12] CR_actual becomes the EMPIRICAL, index-aware compression
    # ratio so that every downstream number (latency, round_stats,
    # avg_compression_ratio, the end-to-end speedup) uses one convention.
    # The old indices-free value is kept as CR_declared.
    CR_declared = k_ratio_actual * b / 32.0
    index_bytes = 2 if d <= 65535 else 4
    compressed_bytes = k * index_bytes + k * (b // 8)
    CR_actual = compressed_bytes / (d * 4.0)
    # More accurate latency estimation
    BW_bytes_per_ms = slice_config.BW_mbps * 1e6 / 8 / 1000
    latency_ms = compressed_bytes / BW_bytes_per_ms + slice_config.proc_ms

    return {
        'indices': topk_indices.cpu().numpy(),
        'q_values': q_values.cpu().numpy(),
        'b_bits': b,
        'k_ratio_actual': k_ratio_actual,
        'CR_actual': CR_actual,
        'CR_declared': CR_declared,
        'compression_factor': 1.0 / CR_actual if CR_actual > 0 else float('inf'),
        'latency_ms': latency_ms,
        'compressed_bytes': compressed_bytes,
        'norm': norm.item(),  # for decompression
    }


def nsac_decompress(
    compressed: Dict,
    d: int,
    device=None,
) -> torch.Tensor:
    """
    Decompress NSAC-compressed gradient back to full d-dimensional vector.

    Reconstruction: Δw[idx] = q_val × ‖g‖ / sqrt(k), others = 0.
    (Unbiased reconstruction using norm preservation)
    """
    indices = compressed['indices']
    q_values = compressed['q_values']
    norm = compressed['norm']
    k = len(indices)

    # Reconstruct: place quantized values at selected indices, 0 elsewhere
    _dev = device if device is not None else torch.device('cpu')
    reconstructed = torch.zeros(d, dtype=torch.float32, device=_dev)
    # Scale factor for unbiasedness: norm / sqrt(k)
    # [fix_v11] q_values is already at the natural scale (see [FIX B1]),
    # so the reconstruction must NOT be rescaled again.  The old
    # `norm/sqrt(k)` made the applied update track ||g||^2, i.e. an
    # unintended, gradient- and k-dependent gain.
    scale = 1.0
    reconstructed[indices] = torch.as_tensor(
        q_values, dtype=torch.float32, device=reconstructed.device) * scale

    return reconstructed


def compute_communication_stats(
    d: int,
    N: int,
    M: int,
    T: int,
    slice_assignments: Dict[int, str],
    model_size_bytes: int = 31304,  # |w| ~ 30.6 KB (d=7762 x 4 bytes, lightweight)
) -> Dict:
    """
    Compute total communication statistics for one experiment run.

    [fix_v12] The compressed payload is now billed the SAME way nsac_compress()
    bills it: k = int(k_ratio*d) positions (2 bytes each, uint16, since
    d < 65536) + k quantised values (b//8 bytes each).  The previous formula
    `CR = k_ratio*b/32; payload = CR*d*4` treated the top-k positions as FREE,
    which overstates the compression by the index overhead.

    `speedup_declared` keeps the old, indices-free number for reference.
    """
    star_traffic = N * model_size_bytes * T  # Eq.(3)
    index_bytes = 2 if d <= 65535 else 4

    total_compressed_bytes_per_round = 0
    total_declared_bytes_per_round = 0
    for gw_id in range(M):
        slice_name = slice_assignments.get(gw_id, 'embb')  # default eMBB
        sc = SLICE_CONFIGS[slice_name]
        k = int(sc.k_ratio * d)
        total_compressed_bytes_per_round += k * index_bytes + k * (sc.b_bits // 8)
        total_declared_bytes_per_round += int((sc.k_ratio * sc.b_bits / 32.0) * d * 4)

    core_traffic = total_compressed_bytes_per_round * T      # Eq.(5) with compression
    core_declared = total_declared_bytes_per_round * T
    speedup = star_traffic / core_traffic if core_traffic > 0 else float('inf')

    # Edge traffic (local, doesn't traverse core)
    edge_traffic = N * model_size_bytes * T                  # Eq.(4)

    return {
        'star_traffic_MB': star_traffic / 1e6,
        'core_traffic_MB': core_traffic / 1e6,
        'edge_traffic_MB': edge_traffic / 1e6,
        'speedup': speedup,
        'reduction_pct': (1 - core_traffic / star_traffic) * 100,
        # --- transparency fields ---
        'index_bytes': index_bytes,
        'cr_empirical_avg': total_compressed_bytes_per_round / (M * d * 4),
        'core_traffic_declared_MB': core_declared / 1e6,
        'speedup_declared': (star_traffic / core_declared
                             if core_declared > 0 else float('inf')),
        'reduction_pct_declared': (1 - core_declared / star_traffic) * 100,
    }



# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
