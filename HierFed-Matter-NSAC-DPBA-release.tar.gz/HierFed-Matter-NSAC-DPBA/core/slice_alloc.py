#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
core/slice_alloc.py -- 方向A 的两个基础构件（纯 numpy，无 torch 依赖）

  C-3  assign_device_types_datadriven(...)  数据驱动的 设备 → 切片 映射
  C-2  allocate_privacy_budget_mode(...)    epsilon_mode ∈ {uniform, slice, adaptive}

设计约束（都是刻意的）
---------------------
1. **预算中立**：三种 epsilon_mode 都满足 Σ_{i,l} ε_{i,l} = ε_total / T，
   否则「统一 vs 切片」的对比不成立（这正是 G-1 公平锚点的同一套逻辑）。
2. **纯函数**：不读写文件、不初始化 torch，可以在任何机器上 `python core/slice_alloc.py` 自测。
3. **参数全部可调**（等闸门结果再定夺）：
       criterion        : 'size' | 'attack_ratio' | 'entropy' | 'feature'
       quantiles        : 分位切点，默认 (1/3, 2/3)
       mapping          : {0,1,2} → {urllc, embb, mmtc}（方向本身是个待调参数）
       slice_weight_rule: 'equal' | 'bw' | 'k_ratio' | 'inv_k_ratio'

自测
    python core/slice_alloc.py        # 打印映射样例 + 三种预算模式的 Σ 校验

--- EN ---
core/slice_alloc.py -- the two basic building blocks of Direction A (pure numpy, no torch dependency)

  C-3  assign_device_types_datadriven(...)  data-driven device -> slice mapping
  C-2  allocate_privacy_budget_mode(...)    epsilon_mode in {uniform, slice, adaptive}

Design constraints (all intentional)
---------------------
1. **Budget-neutral**: all three epsilon_mode satisfy Sum_{i,l} eps_{i,l} = eps_total / T,
   otherwise the "uniform vs slice" comparison does not hold (this is exactly the same logic as the G-1 fairness anchor).
2. **Pure functions**: no file I/O, no torch initialization; can self-test on any machine with `python core/slice_alloc.py`.
3. **All parameters are tunable** (to be decided once the gate results are in):
       criterion        : 'size' | 'attack_ratio' | 'entropy' | 'feature'
       quantiles        : quantile cut points, default (1/3, 2/3)
       mapping          : {0,1,2} -> {urllc, embb, mmtc}  (the direction itself is a parameter to be tuned)
       slice_weight_rule: 'equal' | 'bw' | 'k_ratio' | 'inv_k_ratio'

Self-test
    python core/slice_alloc.py        # print a mapping sample + the Sum check of the three budget modes
"""
import numpy as np

SLICE_TAGS = ("urllc", "embb", "mmtc")
_DEFAULT_BW = {"urllc": 10.0, "embb": 100.0, "mmtc": 1.0}
_DEFAULT_K = {"urllc": 0.10, "embb": 0.30, "mmtc": 0.05}
_DEFAULT_MAP = {0: "mmtc", 1: "embb", 2: "urllc"}   # 低→mMTC(压最狠) 高→uRLLC | EN: low -> mMTC (compressed the hardest), high -> uRLLC


# ============================================================
# C-3 : 数据驱动的 设备 → 切片 映射
# EN: C-3 : data-driven device -> slice mapping
# ============================================================
def device_metrics(partitions, y_train=None, criterion="size"):
    """每个设备一个标量指标（越大 = 越'重'的设备）。

--- EN ---
A per-device scalar metric (larger = a "heavier" device)."""
    N = len(partitions)
    n = np.zeros(N)
    p = np.zeros(N)
    H = np.zeros(N)
    for i in range(N):
        idx = partitions.get(str(i), []) if isinstance(partitions, dict) else partitions[i]
        n[i] = len(idx)
        if y_train is not None and len(idx):
            lab = np.asarray(y_train)[idx]
            pp = lab.mean()
            p[i] = pp
            q = np.clip(pp, 1e-9, 1 - 1e-9)
            H[i] = -(q * np.log2(q) + (1 - q) * np.log2(1 - q))
    if criterion == "size":
        return n
    if criterion == "attack_ratio":
        return p
    if criterion == "entropy":
        return H
    raise ValueError(f"criterion={criterion!r} 只能用于 build; 'feature' 请直接传 device_feats")


def assign_device_types_datadriven(
    N,
    partitions,
    y_train=None,
    criterion="size",
    quantiles=(1.0 / 3.0, 2.0 / 3.0),
    mapping=None,
    device_feats=None,
):
    """
    把 N 个设备按指标分位切成 3 组，映射为切片标签。
    返回 (device_types: List[str], info: dict)

    --- EN ---
    Split the N devices into 3 groups by metric quantiles and map them to slice labels.
    Returns (device_types: List[str], info: dict)
    """
    mapping = dict(_DEFAULT_MAP if mapping is None else mapping)
    if criterion == "feature":
        if device_feats is None:
            raise ValueError("criterion='feature' 需要 device_feats (长度 N 的数组)")
        m = np.asarray(device_feats, float).ravel()
    else:
        m = device_metrics(partitions, y_train, criterion)

    # 空设备（n=0）永远丢进最"轻"的一组，避免污染分位
    # EN: Empty devices (n=0) are always put into the "lightest" group, to avoid polluting the quantiles.
    ok = np.isfinite(m)
    if ok.sum() >= 3:
        lo, hi = np.quantile(m[ok], quantiles)
    else:
        lo, hi = -np.inf, np.inf
    group = np.where(m < lo, 0, np.where(m < hi, 1, 2)).astype(int)

    types = [mapping[int(g)] for g in group]
    info = {
        "criterion": criterion, "lo": float(lo), "hi": float(hi),
        "group_counts": {int(k): int((group == k).sum()) for k in (0, 1, 2)},
        "slice_counts": {s: int(sum(1 for t in types if t == s)) for s in SLICE_TAGS},
    }
    return types, info


def assign_slice_to_gateways_datadriven(M, device_types, cluster_map):
    """网关 → 切片（簇内主导设备类型）。与旧版语义一致，但切片名统一为 urllc/embb/mmtc。

--- EN ---
gateway -> slice (the dominant device type within the cluster). Same semantics as the old version, but the slice names are unified as urllc/embb/mmtc."""
    out = {}
    for gw, devs in cluster_map.items():
        cnt = {}
        for d in devs:
            t = device_types[d]
            cnt[t] = cnt.get(t, 0) + 1
        out[gw] = max(cnt, key=cnt.get) if cnt else "embb"
    return out


# ============================================================
# C-2 : 隐私预算分配模式
# EN: C-2 : privacy budget allocation modes
# ============================================================
def _slice_weights(uniq, rule, slice_weights):
    if slice_weights is not None:
        return {s: float(slice_weights[s]) for s in uniq}
    if rule == "equal":
        return {s: 1.0 for s in uniq}
    if rule == "bw":
        return {s: _DEFAULT_BW.get(s, 1.0) for s in uniq}
    if rule == "k_ratio":
        return {s: _DEFAULT_K.get(s, 0.1) for s in uniq}
    if rule == "inv_k_ratio":
        return {s: 1.0 / _DEFAULT_K.get(s, 0.1) for s in uniq}
    raise ValueError(f"slice_weight_rule={rule!r}")


def allocate_privacy_budget_mode(
    epsilon_total,
    T,
    fim_weights,
    device_sensitivity,
    num_devices,
    num_layers,
    epsilon_mode="uniform",
    slice_of_device=None,
    slice_weight_rule="equal",
    slice_weights=None,
):
    """
    返回 [num_devices, num_layers] 的预算矩阵；三种模式都满足
        Σ_{i,l} ε_{i,l} == epsilon_total / T
    unifrom : w_i = 1/N                       （设备等权）
    adaptive: w_i = S_i / ΣS                   （现行为 / DPBA-FIM）
    slice   : 先按切片分 ε_r，组内再等权
              w_i = (w_{s(i)} / Σ_s w_s) / n_{s(i)}

    --- EN ---
    Returns a [num_devices, num_layers] budget matrix; all three modes satisfy
        Sum_{i,l} eps_{i,l} == epsilon_total / T
    unifrom : w_i = 1/N                       (equal device weight)
    adaptive: w_i = S_i / Sum S               (current behavior / DPBA-FIM)
    slice   : allocate eps_r per slice first, then equal weight within a group
              w_i = (w_{s(i)} / Sum_s w_s) / n_{s(i)}
    """
    eps_r = float(epsilon_total) / max(int(T), 1)
    fim_w = np.asarray(fim_weights, float).ravel()
    fim_w = fim_w / fim_w.sum() if fim_w.sum() > 0 else np.ones(num_layers) / num_layers
    S = np.asarray(device_sensitivity, float).ravel()

    if epsilon_mode == "uniform":
        w_dev = np.ones(num_devices) / num_devices
    elif epsilon_mode == "adaptive":
        w_dev = S / S.sum() if S.sum() > 0 else np.ones(num_devices) / num_devices
    elif epsilon_mode == "slice":
        if slice_of_device is None:
            raise ValueError("epsilon_mode='slice' 需要 slice_of_device (长度 N)")
        sd = np.asarray(slice_of_device, dtype=object)
        uniq = list(dict.fromkeys(sd.tolist()))
        sw = _slice_weights(uniq, slice_weight_rule, slice_weights)
        tot = sum(sw[s] for s in uniq)          # 注意：按【唯一切片】求和，不是按设备 | EN: note: sum over the UNIQUE slices, not over the devices
        n_per = {s: int((sd == s).sum()) for s in uniq}
        w_dev = np.array([sw[s] / tot / max(n_per[s], 1) for s in sd])
    else:
        raise ValueError(f"epsilon_mode={epsilon_mode!r} ∈ {{uniform, slice, adaptive}}")

    budgets = np.outer(w_dev, fim_w) * eps_r
    return budgets


def assign_slice_to_gateways_ranked(M, device_types, cluster_map,
                                    device_metric=None,
                                    order=("mmtc", "embb", "urllc")):
    """
    数据驱动 **且保证覆盖** 的 网关 → 切片 映射。

    为什么需要它：原来的 assign_slice_to_gateways 取"簇内主导设备类型"，
    当 M 较小或设备类型偏斜时**可能让所有网关落进同一切片**（2026-10-14 实测
    iotid20 上 4 个网关全判成 embb -> 单切片 -> eps=slice 臂与 uniform 臂逐位相同）。
    本函数按每个网关的**聚合负载指标**升序排序，再 np.array_split(...,3) 切三段：
        低负载 -> order[0] ; 中 -> order[1] ; 高 -> order[2]
    M >= 3 时三种切片**必然都出现**，切片彼此规模也不等 -> 权重必然有区分度。

    device_metric: 每台设备的标量负载（建议传 n_i = 本设备样本数）；缺省用类型名义权重。

    --- EN ---
    Data-driven **and coverage-guaranteed** gateway -> slice mapping.

    Why it is needed: the original assign_slice_to_gateways takes the "dominant device type within the cluster",
    and when M is small or the device types are skewed it **may put all gateways into the same slice** (measured on 2026-10-14:
    on iotid20 all 4 gateways were judged as embb -> single slice -> the eps=slice arm and the uniform arm are bit-for-bit identical).
    This function sorts gateways by their **aggregate load metric** in ascending order, then splits them into three parts with np.array_split(...,3):
        low load -> order[0] ; medium -> order[1] ; high -> order[2]
    When M >= 3 all three slices are **guaranteed to appear**, and the slices have unequal sizes -> the weights necessarily have discrimination.

    device_metric: the scalar load of each device (recommended: pass n_i = the number of samples on this device); by default the nominal weight of the type is used.
    """
    def _dm(i):
        if device_metric is not None and i < len(device_metric):
            return float(device_metric[i])
        return {"camera": 3.0, "thermostat": 2.0, "bulb": 1.0}.get(device_types[i], 1.0)

    gw_metric = {}
    for gw, devs in cluster_map.items():
        vals = [_dm(d) for d in devs] or [0.0]
        gw_metric[gw] = float(np.mean(vals))

    gws = sorted(cluster_map.keys(), key=lambda g: (gw_metric[g], g))
    out = {}
    for i, part in enumerate(np.array_split(np.array(gws, dtype=object), 3)):
        for g in part:
            out[int(g)] = order[i]
    return out


# ============================================================
# 自测
# EN: self-test
# ============================================================
def _self_test():
    rng = np.random.RandomState(0)
    N, T, L = 20, 50, 4
    sizes = rng.randint(50, 5000, size=N)
    y = rng.randint(0, 2, size=int(sizes.sum()))
    parts, off = {}, 0
    for i, s in enumerate(sizes):
        parts[str(i)] = list(range(off, off + int(s)))
        off += int(s)

    print("=" * 68)
    print(" [C-3] 数据驱动 设备→切片 映射")
    types, info = assign_device_types_datadriven(N, parts, y, criterion="size")
    print(f"   criterion=size  groups={info['group_counts']}  slices={info['slice_counts']}")
    print(f"   first 8: {types[:8]}")

    cm = {g: list(range(g * (N // 4), min((g + 1) * (N // 4), N))) for g in range(4)}
    gw = assign_slice_to_gateways_datadriven(4, types, cm)
    print(f"   gateway->slice (dominant): {gw}   覆盖 {len(set(gw.values()))} 种")
    gwr = assign_slice_to_gateways_ranked(4, types, cm, device_metric=sizes.tolist())
    print(f"   gateway->slice (ranked)  : {gwr}   覆盖 {len(set(gwr.values()))} 种")
    assert len(set(gwr.values())) == 3, "ranked 映射未覆盖三种切片"
    gwr2 = assign_slice_to_gateways_ranked(4, ["camera"] * N, cm, device_metric=sizes.tolist())
    assert len(set(gwr2.values())) == 3, "偏斜输入下 ranked 未覆盖三种切片"
    print("   ranked 在均匀 + 偏斜输入下都覆盖 3 种切片  OK")
    # 切片规模不等 -> bw 权重必然有跨度
    # EN: slice sizes are unequal -> the bw weights are guaranteed to span a range
    _sod = [gwr[d // (N // 4)] for d in range(N)]
    _b = allocate_privacy_budget_mode(399.0, 1, np.ones(1), np.ones(N), N, 1,
                                      epsilon_mode="slice", slice_of_device=_sod,
                                      slice_weight_rule="bw")
    _w = _b[:, 0]; _w = _w / _w.mean()
    print(f"   ranked + bw: sigma_mult span = {_w.max() - _w.min():.3f}  (必须 > 0)")
    assert (_w.max() - _w.min()) > 1e-6, "ranked + bw 仍退化"

    print("=" * 68)
    print(" [C-2] 预算模式（必须满足 Σ = ε_total/T）")
    S = rng.rand(N) + 0.5
    fim = rng.rand(L) + 0.1
    slice_of_dev = [types[i] for i in range(N)]
    target = 399.0 / T
    for mode, kw in (("uniform", {}),
                     ("adaptive", {}),
                     ("slice", dict(slice_of_device=slice_of_dev, slice_weight_rule="equal")),
                     ("slice", dict(slice_of_device=slice_of_dev, slice_weight_rule="bw"))):
        b = allocate_privacy_budget_mode(399.0, T, fim, S, N, L, epsilon_mode=mode, **kw)
        tag = mode + ("/" + kw.get("slice_weight_rule", "") if kw else "")
        ok = abs(b.sum() - target) < 1e-9
        print(f"   {tag:18s} Σε={b.sum():.6f}  目标={target:.6f}  {'OK' if ok else 'FAIL'}")
        assert ok, tag

    # slice 模式：同一切片内每台设备预算必须相等
    # EN: slice mode: every device inside the same slice must get an equal budget
    b = allocate_privacy_budget_mode(399.0, T, fim, S, N, L,
                                     epsilon_mode="slice",
                                     slice_of_device=slice_of_dev)
    for s in set(slice_of_dev):
        idx = [i for i in range(N) if slice_of_dev[i] == s]
        vals = b[idx, 0]
        assert np.allclose(vals, vals[0]), f"slice {s} 组内不等权"
    print("   组内等权校验 OK")
    print("=" * 68)
    print(" ALL SELF-TESTS PASSED")


if __name__ == "__main__":
    _self_test()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
