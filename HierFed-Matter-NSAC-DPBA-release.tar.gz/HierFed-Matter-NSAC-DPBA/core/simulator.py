"""
Single-machine simulator for HierFed-Matter-NSAC-DPBA.

Simulates the device → gateway → cloud three-tier topology,
NSAC compression, DPBA-FIM noise injection, and full FL training loop.
"""

import os
import json
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset, WeightedRandomSampler
import numpy as np
from typing import Dict, List, Tuple, Optional
from pathlib import Path

from models.dnn import AnomalyDNN, build_model
from core.hierfed import hierfed_matter_round, star_aggregate, edge_aggregate, core_aggregate
from core.nsac import (SLICE_CONFIGS, compute_communication_stats,
                       make_uniform_slice, configure_slices, slices_from_env)
from data.preprocess import dirichlet_partition
from core.dpba_fim import (
    FIMTracker, compute_device_sensitivity, allocate_privacy_budget,
    compute_heterogeneity_from_partition, clip_gradient, inject_dp_noise,
    inject_dp_noise_rdp, compute_noise_scale_rdp,
    dpba_fim_gradient_processing, compute_noise_scale,
)

# ============================================================
# GPU Support
# ============================================================
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
if torch.cuda.is_available():
    print(f"[GPU] Using {torch.cuda.get_device_name()} | "
          f"VRAM={torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
else:
    print("[GPU] No GPU available, running on CPU")


# ============================================================
# Device assignment
# ============================================================
def assign_device_types(N: int, seed: int = 1) -> List[str]:
    """Assign device types (camera 40%, thermostat 30%, bulb 30%)."""
    np.random.seed(seed)
    types = []
    for i in range(N):
        r = np.random.random()
        if r < 0.4:
            types.append('camera')
        elif r < 0.7:
            types.append('thermostat')
        else:
            types.append('bulb')
    return types


def assign_slice_to_gateways(
    M: int,
    device_types: List[str],
    cluster_map: Dict[int, List[int]],
) -> Dict[int, str]:
    """
    Assign slice types to gateways based on dominant device type in cluster.

    camera-heavy → uRLLC, thermostat-heavy → eMBB, bulb-heavy → mMTC.
    """
    assignments = {}
    type_to_slice = {'camera': 'urllc', 'thermostat': 'embb', 'bulb': 'mmtc'}

    for gw_id, device_ids in cluster_map.items():
        # Count device types in this cluster
        type_counts = {}
        for dev_id in device_ids:
            dt = device_types[dev_id]
            type_counts[dt] = type_counts.get(dt, 0) + 1
        # Dominant type determines slice
        dominant = max(type_counts, key=type_counts.get)
        assignments[gw_id] = type_to_slice.get(dominant, 'embb')

    return assignments


# ============================================================
# Local Training
# ============================================================
def local_train(
    model: AnomalyDNN,
    train_data: np.ndarray,  # (n_i, dim)
    train_labels: np.ndarray,  # (n_i,)
    num_epochs: int = 5,
    batch_size: int = 32,
    learning_rate: float = 0.01,
    oversample: bool = True,
) -> torch.Tensor:
    """
    Local training on a device: compute gradient of the full model.

    Returns: flat gradient vector (1D tensor of length d).
    """
    device_data = torch.tensor(train_data, dtype=torch.float32).to(DEVICE)
    device_labels = torch.tensor(train_labels, dtype=torch.long).to(DEVICE)
    n_local = len(device_labels)
    if n_local == 0:
        return torch.zeros(model.num_parameters, device=DEVICE)

    # ---- 损失函数：plain CE ----
    # EN: ---- Loss function: plain CE ----
    # FL 聚合中全局/本地类别权重导致各设备梯度方向不一致，
    # 聚合后方向打架 → AUC 反降。改用 plain CE，推理时阈值调整弥补不平衡。
    # EN: During FL aggregation, global/local class weights make the devices' gradient directions inconsistent,
    # EN: and after aggregation the directions conflict -> AUC drops instead. Switch to plain CE and compensate for the imbalance by tuning the threshold at inference.
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)

    # Save initial params
    initial_params = torch.cat([p.data.clone().flatten() for p in model.parameters()])

    # Local training — balanced sampling via WeightedRandomSampler
    model.train()
    class_counts = torch.bincount(device_labels, minlength=2).float()
    both_present = (class_counts.min() > 0) and oversample

    if both_present:
        # ---- Oversample minority: each mini-batch gets balanced class mix ----
        # WeightedRandomSampler draws n_local samples per epoch (same iteration count),
        # but minority samples appear more often → gradient has balanced class signal.
        # This is DIFFERENT from class-weighted CE (which changed gradient DIRECTION
        # and caused FL inconsistency). Oversampling changes data COMPOSITION, not loss.
        class_weights = 1.0 / class_counts
        sample_weights = class_weights[device_labels]
        sampler = WeightedRandomSampler(
            weights=sample_weights, num_samples=n_local, replacement=True
        )
        dataset = TensorDataset(device_data, device_labels)
        loader = DataLoader(dataset, batch_size=batch_size, sampler=sampler)
        for epoch in range(num_epochs):
            for batch_x, batch_y in loader:
                optimizer.zero_grad()
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()
    else:
        # ---- Uniform sampling (single-class device or oversample=False) ----
        for epoch in range(num_epochs):
            indices = torch.randperm(n_local)
            for start in range(0, n_local, batch_size):
                end = min(start + batch_size, n_local)
                batch_idx = indices[start:end]
                batch_x = device_data[batch_idx]
                batch_y = device_labels[batch_idx]

                optimizer.zero_grad()
                outputs = model(batch_x)
                loss = criterion(outputs, batch_y)
                loss.backward()
                optimizer.step()

    # Compute gradient as difference: g = w_after - w_before
    final_params = torch.cat([p.data.clone().flatten() for p in model.parameters()])
    gradient = final_params - initial_params  # This is Δw = η * avg_gradient

    # Reset model to initial state (global model)
    with torch.no_grad():
        idx = 0
        for p in model.parameters():
            size = p.numel()
            p.data.copy_(initial_params[idx:idx + size].reshape(p.shape))
            idx += size

    return gradient


# ============================================================
# Main Simulation Loop
# ============================================================
class HierFedMatterSimulator:
    """Full simulation of HierFed-Matter-NSAC-DPBA on a single machine."""

    def __init__(self, config: dict):
        self.config = config
        self.dataset_name = config.get('dataset_name', 'iotid20')

        # Load data
        self._load_data()

        # Build model
        input_dim = self.feature_dim
        self.model = build_model(input_dim).to(DEVICE)
        self.d = self.model.num_parameters

        # Cluster topology
        N = config.get('N', 50)
        M = config.get('M', 5)
        K = config.get('K', 10)
        self.N = N
        self.M = M
        self.K = K

        # Cluster map: gateway_id → [device_ids]
        self.cluster_map = {}
        for gw_id in range(M):
            start_dev = gw_id * K
            end_dev = start_dev + K
            self.cluster_map[gw_id] = list(range(start_dev, min(end_dev, N)))

        # Device types
        _smap = (os.environ.get('SLICE_MAP') or config.get('slice_map', 'random')).lower()
        if _smap in ('datadriven', 'data'):
            from core.slice_alloc import assign_device_types_datadriven as _add   # [fix_v20]
            self.device_types, _sm_info = _add(
                N, self.partitions, self.y_train,
                criterion=(os.environ.get('SLICE_MAP_CRITERION')
                           or config.get('slice_map_criterion', 'size')))
            print(f"[fix_v20] slice_map=datadriven criterion={_sm_info['criterion']} "
                  f"slices={_sm_info['slice_counts']}")
        else:
            self.device_types = assign_device_types(N, config.get('seed', 1))

        # Slice assignments
        _gwm = (os.environ.get('SLICE_MAP') or config.get('slice_map', 'random')).lower()
        if _gwm in ('ranked', 'datadriven', 'data'):
            from core.slice_alloc import assign_slice_to_gateways_ranked as _asg   # [fix_v20]
            _dm = [len(self.partitions.get(str(_i), [])) for _i in range(N)]
            self.slice_assignments = _asg(M, self.device_types, self.cluster_map,
                                          device_metric=_dm)
        else:
            self.slice_assignments = assign_slice_to_gateways(
                M, self.device_types, self.cluster_map
            )
        print(f"[fix_v20] slice_assignments={self.slice_assignments} "
              f"coverage={len(set(self.slice_assignments.values()))}")

        # DPBA-FIM components
        num_linear_layers = len([m for m in self.model.net
                                  if isinstance(m, torch.nn.Linear)])
        self.fim_tracker = FIMTracker(num_linear_layers,
                                       beta_F=config.get('beta_F', 0.9))

        # --- Sensitivity weights (Eq.7); CLI/config overridable ---
        self.alpha_s = float(config.get('alpha_s', 0.5))
        self.beta_s = float(config.get('beta_s_coeff', 0.3))
        self.gamma_s = float(config.get('gamma_s', 0.2))
        self.delta_s = float(config.get('delta_s', 0.0))

        # --- Ablation switches ---
        # disable_dpba_fim : use uniform σ for all devices (ablate the FIM/DPBA term)
        # disable_dp       : no DP noise at all
        # disable_hierfed  : use star aggregation instead of hierarchical
        # disable_nsac     : send full (uncompressed) updates
        self.disable_dpba_fim = bool(config.get('disable_dpba_fim', False))
        self.disable_dp = bool(config.get('disable_dp', False))
        self.disable_hierfed = bool(config.get('disable_hierfed', False))
        self.enable_nsac = bool(config.get('enable_nsac',
                                           not config.get('disable_nsac', False)))

        # --- v9 (Direction A): allocation modes, env-first, config fallback ---
        self.nsac_mode = str(os.environ.get(
            'NSAC_MODE', config.get('nsac_mode', 'slice'))).lower()
        if self.nsac_mode not in ('slice', 'uniform'):
            raise ValueError("nsac_mode must be 'slice' or 'uniform', got %r" % self.nsac_mode)
        self.uniform_bits = int(os.environ.get(
            'NSAC_UNIFORM_BITS', config.get('nsac_uniform_bits', 8)))
        _sv = slices_from_env()
        _use = (abs(_sv['cr_scale'] - 1.0) > 1e-12
                or any(v is not None for v in _sv['k_overrides'].values())
                or any(v is not None for v in _sv['bits_overrides'].values()))
        if _use:
            configure_slices(**_sv)
        print("[v9] nsac_mode=%s, uniform_bits=%d" % (self.nsac_mode, self.uniform_bits))

        # --- Per-device Fisher information (Eq.7, F_rel,i) ---
        self.fim_every = int(config.get('fim_every', 5))
        self.device_fim_ema = np.ones(N, dtype=np.float64)  # uniform init

        # --- Device sensitivity (Eq.7) ---
        self.local_counts = [len(self.partitions.get(str(i), [])) for i in range(N)]
        self.H_scores = compute_heterogeneity_from_partition(
            self.y_train, self.partitions)
        self.device_sensitivity = self._compute_sensitivity()

        # Privacy budgets
        # float() 防御：PyYAML 会把 '1e-5' 这种无小数点的写法解析成字符串，
        # 显式转 float 可避免后续做除法时出现 TypeError
        # EN: float() defense: PyYAML parses a value like '1e-5' (no decimal point) as a string,
        # EN: so converting to float explicitly avoids a TypeError when doing division later
        self.epsilon_total = float(config.get('epsilon_total', 3.0))
        self.delta = float(config.get('delta', 1e-5))
        self.clip_norm = float(config.get('clip_norm', 1.0))
        # [v7] per-device adaptive clipping: scale DP noise by each device's own
        # sensitivity C_i = EMA(||dW_i||), instead of one global worst-case bound.
        self.dp_clip_mode = str(config.get('dp_clip_mode', 'global')).lower()
        self.adaptive_clip_beta = float(config.get('adaptive_clip_beta', 0.2))
        self.adaptive_clip_min = float(config.get('adaptive_clip_min', 0.05))
        self.adaptive_clip_max = float(config.get('adaptive_clip_max', 3.0))
        self._dev_clip = {}

        # [fix_v20] C-2  epsilon allocation mode: adaptive | uniform | slice
        #   adaptive = 现行为（逐设备敏感度调制）；uniform/slice = 方向A 的两个对照臂。
        #   两种新模式都归一化到"sigma_mult 均值 = 1"，即总噪声量级不变（预算中立），
        #   只有【切片/设备之间】的分配不同 —— 否则对比不成立。
        # EN:   adaptive = current behaviour (per-device sensitivity modulation); uniform/slice = the two control arms of Direction A.
        # EN:   both new modes are normalized so that the mean of sigma_mult = 1, i.e. the total noise magnitude is unchanged (budget-neutral),
        # EN:   and only the [inter-slice / inter-device] allocation differs -- otherwise the comparison would not hold.
        self.epsilon_mode = str(os.environ.get('EPSILON_MODE')
                                or config.get('epsilon_mode', 'adaptive')).lower()
        if self.epsilon_mode not in ('adaptive', 'uniform', 'slice'):
            raise ValueError("epsilon_mode must be adaptive|uniform|slice, got %r"
                             % self.epsilon_mode)
        self._slice_sigma_mult = None
        if self.epsilon_mode in ('slice', 'uniform'):
            try:
                from core.slice_alloc import allocate_privacy_budget_mode as _apbm
                _K = max(int(K), 1)
                _sod = [self.slice_assignments[min(dev_id // _K, M - 1)]
                        for dev_id in range(N)]
                # T 传 1 即可：权重随后按均值归一化，eps_r 因子会约掉（不依赖 self.T）
                # EN: passing T=1 is enough: the weights are then normalized by the mean, so the eps_r factor cancels out (independent of self.T)
                _bud = _apbm(self.epsilon_total, 1, np.ones(1),
                             np.asarray(self.device_sensitivity, dtype=float),
                             N, 1, epsilon_mode=self.epsilon_mode,
                             slice_of_device=_sod,
                             slice_weight_rule=(os.environ.get('SLICE_WEIGHT_RULE')
                                                or config.get('slice_weight_rule', 'equal')))
                _w = np.asarray(_bud, dtype=float)[:, 0]
                _w = _w / max(float(_w.mean()), 1e-12)          # 归一化到均值 1 | EN: normalize to mean 1
                self._slice_sigma_mult = _w.tolist()
                _span = float(_w.max() - _w.min())
                print(f"[fix_v20] epsilon_mode={self.epsilon_mode} "
                      f"rule={os.environ.get('SLICE_WEIGHT_RULE') or config.get('slice_weight_rule', 'equal')} "
                      f"sigma_mult=[{_w.min():.3f},{_w.max():.3f}] span={_span:.3f} "
                      f"slices={sorted(set(_sod))}")
                if self.epsilon_mode == 'slice' and _span < 1e-9:
                    _ns = len(set(_sod))
                    if _ns < 2:
                        raise ValueError(
                            "[fix_v20] 切片映射只产生 1 个切片 (slices=%s) —— eps=slice 臂会与 "
                            "uniform 臂逐位相同，对比无效。请设 SLICE_MAP=ranked"
                            "（ranked 在 M>=3 时保证三切片都出现），或检查设备->切片映射。"
                            % sorted(set(_sod)))
                    raise ValueError(
                        "[fix_v20] slice 分配退化为 uniform（切片权重全等）。请改 "
                        "SLICE_WEIGHT_RULE=k_ratio 或 inv_k_ratio（bw 在切片规模相等时也可能全等），"
                        " 或检查各切片规模是否恰好相等。")
            except Exception as _e:
                if '[fix_v20]' in str(_e):
                    raise                      # 退化必须硬失败，绝不静默降级成 adaptive | EN: degradation must hard-fail; never silently fall back to adaptive
                print(f"[fix_v20] !! epsilon_mode={self.epsilon_mode} init failed ({_e});"
                      f" falling back to adaptive")
                self.epsilon_mode = 'adaptive'
        # [FIX B2] The RDP accountant must be told the client subsampling rate.
        # It used to fall back to its default q=1.0, inflating sigma by ~1/q
        # (5x for M/N = 4/20).  Default here is the true M/N.
        self.dp_subsampling_rate = float(
            config.get('dp_subsampling_rate', float(M) / max(float(N), 1.0)))
        # [FIX B2] print ||dw|| vs ||noise|| each round so the SNR is visible.
        self.dp_debug = bool(config.get('dp_debug', False))
        # [v2] empirical multiplier on the injected DP noise (1.0 = no change).
        self.dp_noise_scale = float(config.get('dp_noise_scale', 1.0))
        # [v3] fraction of devices sampled per round (1.0 = everybody).
        # The RDP accountant only earns its subsampling amplification if the
        # protocol REALLY samples clients, so this must equal
        # dp_subsampling_rate.
        self.client_sample_rate = float(config.get('client_sample_rate', 1.0))
        # [v4] keep DPBA's total noise energy equal to uniform DP (fair compare)
        self.dpba_budget_neutral = bool(config.get('dpba_budget_neutral', True))
        if abs(self.client_sample_rate - self.dp_subsampling_rate) > 1e-9:
            print(f"[WARN] client_sample_rate={self.client_sample_rate} != "
                  f"dp_subsampling_rate={self.dp_subsampling_rate}: the RDP "
                  f"amplification term would be unjustified.")
        self.T = config.get('T', 100)
        self.eta = config.get('eta', 0.01)

        # Tracking
        self.round_metrics = []

    def _compute_sensitivity(self) -> np.ndarray:
        """
        Device sensitivity S_i (Eq.7).

        S_i = α_s·σ_i + β_s·(n_i/n_max) + γ_s·H_i + δ_s·F_rel,i

        The FIM term F_rel,i = F_i / max_j F_j is only included when δ_s > 0.
        """
        fim_rel = None
        if self.delta_s > 0.0:
            # F_rel,i = F_i / max_j F_j  (paper Eq.7) → F_rel ∈ (0, 1]
            max_fim = float(np.max(self.device_fim_ema)) + 1e-12
            fim_rel = self.device_fim_ema / max_fim
        return compute_device_sensitivity(
            self.device_types, self.local_counts, self.H_scores,
            alpha_s=self.alpha_s, beta_s=self.beta_s, gamma_s=self.gamma_s,
            fim_rel_scores=fim_rel, delta_s=self.delta_s,
        )

    def _update_device_fim(self):
        """Recompute each device's local FIM trace and update its EMA (Eq.11)."""
        beta_F = self.fim_tracker.beta_F
        for dev_id in range(self.N):
            idx_list = self.partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                continue
            d_t = torch.tensor(self.X_train[idx_list],
                               dtype=torch.float32).to(DEVICE)
            l_t = torch.tensor(self.y_train[idx_list],
                               dtype=torch.long).to(DEVICE)
            traces = self.fim_tracker.local_trace(self.model, d_t, l_t)
            scalar = float(traces.sum())
            self.device_fim_ema[dev_id] = (beta_F * self.device_fim_ema[dev_id]
                                           + (1.0 - beta_F) * scalar)
        print(f"  [FIM] device FIM updated: mean={self.device_fim_ema.mean():.3e}, "
              f"min={self.device_fim_ema.min():.3e}, max={self.device_fim_ema.max():.3e}")


    def _load_data(self):
        """Load preprocessed data and partition, with α-aware partition loading/regeneration."""
        processed_dir = self.config.get('processed_dir', 'data/processed')
        dataset = self.dataset_name
        alpha = self.config.get('alpha', 0.5)
        N = self.config.get('N', 20)

        prefix = (dataset if os.path.exists(os.path.join(processed_dir, f'{dataset}_train.npz'))
                  else ('iotid20' if dataset == 'iotid20' else 'cicids'))  # [fix_v17]
        train_file = os.path.join(processed_dir, f'{prefix}_train.npz')
        test_file = os.path.join(processed_dir, f'{prefix}_test.npz')

        # --- Load train/test data ---
        train_npz = np.load(train_file)
        self.X_train = train_npz['X']
        self.y_train = train_npz['y']
        self.feature_dim = self.X_train.shape[1]

        test_npz = np.load(test_file)
        self.X_test = test_npz['X']
        self.y_test = test_npz['y']

        # --- α-aware partition loading ---
        # 优先查找 per-α 分区文件
        # EN: Prefer the per-α partition file
        per_alpha_file = os.path.join(processed_dir,
                                       f'{prefix}_partitions_alpha{alpha}.json')
        generic_file = os.path.join(processed_dir, f'{prefix}_partitions.json')

        partition_loaded = False
        # 1) 尝试加载 per-α 分区文件
        # EN: 1) Try to load the per-α partition file
        if os.path.exists(per_alpha_file):
            with open(per_alpha_file, 'r', encoding='utf-8') as f:
                part_data = json.load(f)
            self.partitions = part_data['device_indices']
            partition_loaded = True
            print(f"[Partition] Loaded per-α file: {per_alpha_file} (α={alpha})")
        # 2) 尝试加载通用分区文件，检查 α 是否匹配
        # EN: 2) Try to load the generic partition file and check whether α matches
        elif os.path.exists(generic_file):
            with open(generic_file, 'r', encoding='utf-8') as f:
                part_data = json.load(f)
            file_alpha = part_data.get('alpha', None)
            if file_alpha == alpha:
                self.partitions = part_data['device_indices']
                partition_loaded = True
                print(f"[Partition] Loaded generic file (α matches: {alpha})")
            else:
                print(f"[Partition] ⚠️ Generic file α={file_alpha} ≠ config α={alpha}, regenerating...")
        # 3) 没找到任何分区文件
        # EN: 3) No partition file found
        else:
            print(f"[Partition] No partition file found, regenerating for α={alpha}...")

        # --- 如果分区未加载，用 dirichlet_partition 动态生成 ---
        # EN: --- If the partition was not loaded, generate it dynamically with dirichlet_partition ---
        if not partition_loaded:
            # 用固定的 partition_seed=1（与预处理一致）确保可复现
            # EN: Use a fixed partition_seed=1 (consistent with preprocessing) to ensure reproducibility
            partition_seed = 1
            partitions = dirichlet_partition(self.y_train, N, alpha, partition_seed)
            self.partitions = partitions
            # 保存为 per-α 文件供后续复用
            # EN: Save as a per-α file for later reuse
            save_data = {
                'N': N, 'alpha': alpha, 'seed': partition_seed,
                'feature_dim': self.feature_dim,
                'num_train': len(self.y_train),
                'num_test': len(self.y_test),
                'normal_train': int(np.sum(self.y_train == 0)),
                'attack_train': int(np.sum(self.y_train == 1)),
                'device_indices': partitions
            }
            os.makedirs(processed_dir, exist_ok=True)
            with open(per_alpha_file, 'w', encoding='utf-8') as f:
                json.dump(save_data, f, indent=2)
            print(f"[Partition] Saved new per-α file: {per_alpha_file}")

        # ---- 诊断：训练集 & 测试集类别分布 ----
        # EN: ---- Diagnostics: class distribution of the train & test sets ----
        n_tr0 = int(np.sum(self.y_train == 0))
        n_tr1 = int(np.sum(self.y_train == 1))
        n_te0 = int(np.sum(self.y_test == 0))
        n_te1 = int(np.sum(self.y_test == 1))
        print(f"[Diag] Train: class0={n_tr0}({n_tr0/len(self.y_train)*100:.1f}%), "
              f"class1={n_tr1}({n_tr1/len(self.y_train)*100:.1f}%), "
              f"total={len(self.y_train)}")
        print(f"[Diag] Test:  class0={n_te0}({n_te0/len(self.y_test)*100:.1f}%), "
              f"class1={n_te1}({n_te1/len(self.y_test)*100:.1f}%), "
              f"total={len(self.y_test)}")

    def run(self) -> Dict:
        """Run full HierFed-Matter-NSAC-DPBA simulation for T rounds."""
        print(f"\n{'='*60}")
        print(f"Running HierFed-Matter-NSAC-DPBA on {self.dataset_name}")
        print(f"N={self.N}, M={self.M}, K={self.K}, T={self.T}")
        print(f"ε={self.epsilon_total}, δ={self.delta}, C={self.clip_norm}")
        print(f"d={self.d}, feature_dim={self.feature_dim}")

        # Compute base σ via RDP composition ONCE (not per-device per-round)
        if self.disable_dp:
            sigma_base = 0.0
            print("[DP] disabled (ablation) -> no DP noise injected")
        else:
            sigma_base = compute_noise_scale_rdp(
                self.epsilon_total, self.T, self.delta, self.clip_norm,
                subsampling_rate=self.dp_subsampling_rate)
            print(f"RDP base σ={sigma_base:.4f} (ε_total={self.epsilon_total}, "
                  f"T={self.T}, q={self.dp_subsampling_rate:.3f})")
        print(f"[Ablation] nsac={self.enable_nsac}, hierfed={not self.disable_hierfed}, "
              f"dpba_fim={not self.disable_dpba_fim}, dp={not self.disable_dp}, "
              f"w=(a={self.alpha_s},b={self.beta_s},g={self.gamma_s},d={self.delta_s})")
        # --- v9: build the byte-matched uniform config once d is known ---
        uniform_slice = None
        if self.enable_nsac and self.nsac_mode == 'uniform':
            uniform_slice = make_uniform_slice(
                list(self.slice_assignments.values()), self.d,
                b_bits=self.uniform_bits)
            _names = list(self.slice_assignments.values())
            _slice_bytes = sum(
                max(1, int(SLICE_CONFIGS[s].k_ratio * self.d)) *
                (4 + SLICE_CONFIGS[s].b_bits // 8) for s in _names)
            _uni_bytes = len(_names) * (
                max(1, int(uniform_slice.k_ratio * self.d)) *
                (4 + uniform_slice.b_bits // 8))
            print("[v9] UNIFORM arm: k_ratio=%.4f CR=%.4f | budget slice=%dB vs "
                  "uniform=%dB (ratio %.4f)"
                  % (uniform_slice.k_ratio, uniform_slice.CR, _slice_bytes,
                     _uni_bytes, _uni_bytes / max(1, _slice_bytes)))

        print(f"{'='*60}\n")

        all_results = []

        for t in range(1, self.T + 1):
            # --- Step 0: refresh device-level FIM (Eq.7, F_rel,i) ---
            if (not self.disable_dpba_fim) and self.delta_s > 0.0 \
                    and (t % self.fim_every == 1):
                self._update_device_fim()
                self.device_sensitivity = self._compute_sensitivity()

            # Relative sensitivity weighting (Eq.8): high S_i -> less noise
            if self.disable_dpba_fim:
                s_rel = np.ones(self.N, dtype=np.float64)  # uniform DP
            else:
                s_rel = self.device_sensitivity / (self.device_sensitivity.max() + 1e-12)

            # [v4] Budget-neutral allocation.
            # (1.4 - 0.4*s_rel) has mean-square 1.4533, so using it raw makes
            # DPBA inject ~20.6% more noise energy than uniform DP and lose a
            # comparison it should win.  Normalise so mean(m^2) == 1: only the
            # DISTRIBUTION of the noise across devices changes, not the total.
            _raw = 1.4 - 0.4 * s_rel
            if self.dpba_budget_neutral:
                _den = float(np.sqrt(np.mean(_raw ** 2))) or 1.0
                sigma_mult = _raw / _den
            else:
                sigma_mult = _raw

            # --- [v3] client subsampling ---
            # Only a random subset of devices participates this round.  This is
            # what makes a subsampling rate q < 1 (and the resulting privacy
            # amplification) legitimate rather than decorative.
            if self.client_sample_rate < 1.0:
                _m = max(1, int(round(self.client_sample_rate * self.N)))
                self._participants = set(
                    np.random.choice(self.N, size=_m, replace=False).tolist())
            else:
                self._participants = set(range(self.N))

            # --- Step 1: Device local training + DP noise injection ---
            device_gradients = {}
            _dbg_dw, _dbg_noise, _dbg_sig = [], [], []
            for dev_id in range(self.N):
                if dev_id not in self._participants:
                    continue
                idx_list = self.partitions.get(str(dev_id), [])
                if len(idx_list) == 0:
                    device_gradients[dev_id] = torch.zeros(self.d, device=DEVICE)
                    continue

                local_data = self.X_train[idx_list]
                local_labels = self.y_train[idx_list]

                gradient = local_train(
                    self.model, local_data, local_labels,
                    num_epochs=self.config.get('E_local', 5),
                    batch_size=self.config.get('batch_size', 32),
                    learning_rate=self.eta,
                    oversample=self.config.get('oversample_minority', True),
                )

                if self.disable_dp:
                    # Ablation: no DP -> use the raw local update
                    device_gradients[dev_id] = gradient
                    continue

                # Clip -> per-device Gaussian noise (Eq.14/15).
                # sigma_i = sigma_base * (1.4 - 0.4*S_rel_i): high-sensitivity
                # devices receive LESS noise; low-sensitivity devices MORE.
                # [v7] per-device sensitivity matching
                if self.dp_clip_mode == 'per_device':
                    _raw_norm = float(gradient.norm())
                    _prev = self._dev_clip.get(dev_id, self.clip_norm)
                    _ema = (1.0 - self.adaptive_clip_beta) * _prev \
                        + self.adaptive_clip_beta * _raw_norm
                    _C_i = float(min(max(_ema, self.adaptive_clip_min),
                                      self.adaptive_clip_max))
                    self._dev_clip[dev_id] = _C_i
                else:
                    _C_i = self.clip_norm
                # sigma_base was computed for sensitivity clip_norm -> rescale to C_i
                if self.epsilon_mode == 'slice':
                    _sm = float(self._slice_sigma_mult[dev_id])
                elif self.epsilon_mode == 'uniform':
                    _sm = 1.0
                else:
                    _sm = float(sigma_mult[dev_id])          # adaptive (默认 = 原行为) | EN: adaptive (default = original behaviour)
                device_sigma = (sigma_base * _sm
                                * (_C_i / max(self.clip_norm, 1e-12)))
                clipped = clip_gradient(gradient, _C_i)
                # [v2] `dp_noise_scale` calibrates the noise magnitude.  The
                # update returned by local_train ALREADY contains the learning
                # rate, so the DP noise has to be brought to the same order of
                # magnitude (standard DP-FL adds it *before* the lr is applied).
                # Use run_noise_sweep.sh to pick it empirically.
                noise = (torch.randn_like(clipped)
                         * device_sigma * self.dp_noise_scale)
                device_gradients[dev_id] = clipped + noise
                # [FIX B2] instrumentation: the model update returned by
                # local_train ALREADY contains the learning rate, so the noise
                # added here must be on the same scale. Track both norms.
                _dbg_dw.append(float(clipped.norm()))
                _dbg_noise.append(float(noise.norm()))
                _dbg_sig.append(float(device_sigma))

            if (not self.disable_dp) and self.dp_debug and _dbg_dw:
                import statistics as _st
                _dw = _st.mean(_dbg_dw)
                _nz = _st.mean(_dbg_noise)
                _wn = float(torch.cat([p.data.flatten()
                                       for p in self.model.parameters()]).norm())
                print(f"[DP-DEBUG] round {t}: ||dw||={_dw:.4f}  ||w||={_wn:.3f}  "
                      f"sigma_i~{_st.mean(_dbg_sig):.4f}  ||noise||={_nz:.2f}  "
                      f"SNR={_dw / (_nz + 1e-12):.3e}  "
                      f"noise_scale={self.dp_noise_scale}  "
                      f"n_part={len(self._participants)}/{self.N}")

            # --- Step 4: HierFed-Matter round ---
            global_params = torch.cat([p.data.clone().flatten()
                                       for p in self.model.parameters()])
            if self.disable_hierfed:
                # Ablation: flat star topology (no gateway tier)
                new_params = star_aggregate(device_gradients, global_params, self.eta)
                n_upd = max(len(device_gradients), 1)
                round_stats = {
                    'compression_ratios': [1.0] * n_upd,
                    'latencies_ms': [0.0] * n_upd,
                    'total_compressed_bytes': self.d * 4 * n_upd,
                }
            else:
                new_params, round_stats = hierfed_matter_round(
                    device_gradients, self.cluster_map,
                    self.slice_assignments, global_params,
                    learning_rate=self.eta, d=self.d,
                    model_size_bytes=self.d * 4,
                    enable_nsac=self.enable_nsac,
                    uniform_slice=uniform_slice,
                )

            # [FIX B2] divergence guard: a single NaN round used to silently
            # poison the model for the remaining rounds (and later faked an
            # AUC of 0.0 via the B3 sentinel).
            if not torch.isfinite(new_params).all():
                _nbad = int((~torch.isfinite(new_params)).sum().item())
                print(f"[WARN] round {t}: {_nbad}/{new_params.numel()} non-finite "
                      f"params -> keeping last finite model")
                new_params = global_params          # keep the last finite model
            elif float(new_params.norm()) > 1e3:
                print(f"[WARN] round {t}: ||params||={float(new_params.norm()):.1f} "
                      f"-> explosion, keeping last finite model")
                new_params = global_params

            # --- Step 5: Update global model ---
            idx = 0
            with torch.no_grad():
                for p in self.model.parameters():
                    size = p.numel()
                    p.data.copy_(new_params[idx:idx + size].reshape(p.shape))
                    idx += size

            # --- Step 6: Evaluate on test set (throttled: t=1 / every eval_every / last) ---
            eval_every = int(self.config.get('eval_every', 25))
            do_eval = (t == 1) or (t == self.T) or (eval_every > 0 and t % eval_every == 0)
            if do_eval:
                test_metrics = self._evaluate()

                round_result = {
                    'round': t,
                    **test_metrics,
                    'avg_compression_ratio': np.mean(round_stats['compression_ratios']),
                    'avg_latency_ms': np.mean(round_stats['latencies_ms']),
                    'total_compressed_bytes': round_stats['total_compressed_bytes'],
                }
                all_results.append(round_result)

                print(f"Round {t}/{self.T}: "
                      f"F1={test_metrics['f1']:.4f}, "
                      f"macro-F1={test_metrics['f1_macro']:.4f}, "
                      f"Acc={test_metrics['accuracy']:.4f}, "
                      f"AUC={test_metrics['auc_roc']:.4f}, "
                      f"thresh={test_metrics['optimal_threshold']:.2f}, "
                      f"CR={round_result['avg_compression_ratio']:.4f}")
            else:
                if t % 10 == 0:
                    print(f"Round {t}/{self.T}: (eval skipped)")

        # --- Final evaluation ---
        final_metrics = self._evaluate()
        print(f"\nFinal: F1={final_metrics['f1']:.4f}, "
              f"macro-F1={final_metrics['f1_macro']:.4f}, "
              f"Acc={final_metrics['accuracy']:.4f}, "
              f"AUC={final_metrics['auc_roc']:.4f}, "
              f"optimal_threshold={final_metrics['optimal_threshold']:.2f}")

        # Communication stats
        comm_stats = compute_communication_stats(
            self.d, self.N, self.M, self.T,
            self.slice_assignments
        )
        print(f"Communication: speedup={comm_stats['speedup']:.1f}×, "
              f"reduction={comm_stats['reduction_pct']:.1f}%")

        return {
            'final_metrics': final_metrics,
            'round_metrics': all_results,
            'communication_stats': comm_stats,
            'config': self.config,
        }

    def _evaluate(self) -> Dict:
        """Evaluate model on test set with threshold optimization."""
        from sklearn.metrics import f1_score, accuracy_score, roc_auc_score

        self.model.eval()
        if getattr(self, '_X_test_t', None) is None:
            self._X_test_t = torch.tensor(self.X_test, dtype=torch.float32).to(DEVICE)
        X_t = self._X_test_t
        with torch.no_grad():
            outputs = self.model(X_t)
            probs = torch.softmax(outputs, dim=1)
            preds_default = outputs.argmax(dim=1).cpu().numpy()

        y_true = self.y_test
        y_prob = probs[:, 1].cpu().numpy()  # P(class=1)

        # ---- Threshold optimization: find threshold that maximizes F1 ----
        best_f1 = 0.0
        best_thresh = 0.5
        for thresh in np.arange(0.05, 0.95, 0.05):
            preds_t = (y_prob >= thresh).astype(int)
            f1_t = f1_score(y_true, preds_t, zero_division=0)
            if f1_t > best_f1:
                best_f1 = f1_t
                best_thresh = thresh

        preds_optimal = (y_prob >= best_thresh).astype(int)
        f1_optimal = best_f1
        acc_optimal = accuracy_score(y_true, preds_optimal)

        # Default threshold (0.5) metrics
        f1_default = f1_score(y_true, preds_default, zero_division=0)
        acc_default = accuracy_score(y_true, preds_default)

        # Macro-F1 (average F1 across both classes)
        f1_macro = f1_score(y_true, preds_optimal, average='macro', zero_division=0)

        try:
            auc = roc_auc_score(y_true, y_prob)
        except ValueError:
            # [FIX B3] do NOT fake AUC=0.0 (which reads as "perfectly
            # inverted"). A ValueError here means y_prob contained NaN/inf,
            # i.e. the model diverged. Record NaN so aggregation can flag it.
            auc = float('nan')

        # ---- 诊断打印 ----
        # EN: ---- Diagnostic printing ----
        n_cls0 = int(np.sum(y_true == 0))
        n_cls1 = int(np.sum(y_true == 1))
        print(f"[Diag] Test set: total={len(y_true)}, "
              f"class0={n_cls0}({n_cls0/len(y_true)*100:.1f}%), "
              f"class1={n_cls1}({n_cls1/len(y_true)*100:.1f}%)")
        print(f"[Diag] Prob: P(cls1)_mean={y_prob.mean():.4f}, "
              f"std={y_prob.std():.4f}, "
              f"min={y_prob.min():.4f}, max={y_prob.max():.4f}")
        print(f"[Diag] Threshold: optimal={best_thresh:.2f} "
              f"(F1={f1_optimal:.4f}, macro-F1={f1_macro:.4f}, "
              f"Acc={acc_optimal:.4f})")
        print(f"[Diag] Default:   thresh=0.50 "
              f"(F1={f1_default:.4f}, Acc={acc_default:.4f})")

        return {
            'f1': f1_optimal,
            'f1_default': f1_default,
            'f1_macro': f1_macro,
            'accuracy': acc_optimal,
            'accuracy_default': acc_default,
            'auc_roc': auc,
            'optimal_threshold': best_thresh,
        }

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
