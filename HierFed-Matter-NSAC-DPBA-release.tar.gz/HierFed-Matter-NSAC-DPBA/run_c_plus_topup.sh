#!/usr/bin/env bash
# =============================================================================
# run_c_plus_topup.sh -- 上一次 C 没起来（看门狗自杀），这次一把梭：
# EN: run_c_plus_topup.sh -- last time C did not start (the watchdog killed itself); this time do it all in one go:
#   ① TOPUP：补 A1/A2 的 seed 6-8（bw, 12 run）—— 治 B 的病（A1 只有 n=5，配对卡在 5 对）
# EN: ① TOPUP: top up A1/A2 with seeds 6-8 (bw, 12 runs) -- fixes B's problem (A1 has only n=5, so pairing is stuck at 5 pairs)
#   ② C    ：4 臂 × 2 数据集 × seed 1-5（k_ratio, 40 run）—— 见结果选路线
# EN: ② C    : 4 arms x 2 datasets x seeds 1-5 (k_ratio, 40 runs) -- pick the route based on the results
#   合计 52 run，par=4 约 3~3.5h
# EN: 52 runs in total, about 3~3.5 h at par=4
#
# 用法：
# EN: Usage:
#   nohup bash run_c_plus_topup.sh > logs/c_plus.log 2>&1 &
#   sleep 90; tail -n 40 logs/c_plus.log          # 确认 gate 过了、开始跑 | EN: confirm the gate passed and the run started
#   tail -n 5 logs/c_plus.log                     # 后续看心跳（每 10 min） | EN: then watch the heartbeat (every 10 min)
#
#   DO_TOPUP=0 bash run_c_plus_topup.sh           # 只跑 C，不补 A1/A2 | EN: run only C, do not top up A1/A2
#   PAR=6 bash run_c_plus_topup.sh                # 提高并发（4090 上 6 路一般 OK） | EN: raise the concurrency (6 parallel jobs are usually OK on a 4090)
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
PAR=${PAR:-4}
DO_TOPUP=${DO_TOPUP:-1}
T=${T:-50}
ALPHA=${ALPHA:-0.5}
SLICE_MAP=${SLICE_MAP:-ranked}
LOG=${LOG:-logs/c_plus}
TIMEOUT=${TIMEOUT:-5400}

cd "$PROJ" || { echo "ERROR: $PROJ 不存在"; exit 1; }
mkdir -p "$LOG" results_alloc_kr

TS(){ date +"%H:%M:%S"; }
SAY(){ echo "[$(TS)] $*" | tee -a "$LOG/main.log"; }
NB(){ pgrep -f 'run_experiment\.py' 2>/dev/null | wc -l; }
THR(){ while [ "$(NB)" -ge "$PAR" ]; do sleep 15; done; }

# ------------------------------------------------------------------ preflight
echo "==================== PREFLIGHT ===================="
pre=0
grep -q "'gotham25'"  run_experiment.py 2>/dev/null || { echo "[!!] run_experiment.py 缺 gotham25 -> python fix_v17.py --apply"; pre=1; }
grep -q "\[fix_v20\]" core/simulator.py 2>/dev/null || { echo "[!!] fix_v20 未打 -> python fix_v20.py --apply"; pre=1; }
[ -f core/slice_alloc.py ]                            || { echo "[!!] 缺 core/slice_alloc.py"; pre=1; }
$PY -c "import core.slice_alloc" 2>/dev/null          || { echo "[!!] core/slice_alloc.py 不能 import"; pre=1; }
for ds in iotid20 gotham25; do
  [ -f "data/processed/${ds}_train.npz" ] || { echo "[!!] 缺 data/processed/${ds}_train.npz"; pre=1; }
done
[ "$pre" -eq 0 ] && echo "[preflight] OK" || { echo "[abort] 先修 preflight"; exit 1; }

# ------------------------------------------------------------------ gate (T=2)
echo "==================== GATE (T=2, k_ratio+slice) ===================="
gk="$LOG/gate_kratio_gotham25.log"
NSAC_MODE=slice EPSILON_MODE=slice SLICE_WEIGHT_RULE=k_ratio SLICE_MAP="$SLICE_MAP" \
  timeout 1800 $PY -u run_experiment.py --method proposed --dataset gotham25 \
  --alpha "$ALPHA" --seed 1 --tag gateC --T 2 --e_local 1 \
  --output_dir results_alloc_kr/_gate > "$gk" 2>&1
gj=$(find results_alloc_kr/_gate -name results.json 2>/dev/null | head -1)
if [ -z "$gj" ]; then
  echo "  [FAIL] k_ratio gate 未写出 results.json"; tail -n 15 "$gk" | sed 's/^/     | /'; exit 1
fi
span=$(grep -oE "span=[0-9.]+"  "$gk" | head -1)
slices=$(grep -oE "slices=\[[^]]*\]" "$gk" | head -1)
echo "  [ok] gate 通过  ${span:-（无 span 打印）}  ${slices:-（无 slices 打印）}"
rm -rf results_alloc_kr/_gate

# ------------------------------------------------------------------ task list
declare -a TASKS=()
addtask(){ TASKS+=("$1|$2|$3|$4|$5|$6|$7"); }   # OUT|DS|TAG|NSAC|EPS|RULE|SEED

if [ "$DO_TOPUP" = "1" ]; then
  for DS in iotid20 gotham25; do
    for S in 6 7 8; do
      addtask results_alloc    "$DS" cruniform_epsuniform uniform uniform bw "$S"
      addtask results_alloc    "$DS" crslice_epsuniform   slice   uniform bw "$S"
    done
  done
fi
for DS in iotid20 gotham25; do
  for S in 1 2 3 4 5; do
    addtask results_alloc_kr "$DS" cruniform_epsuniform uniform uniform k_ratio "$S"
    addtask results_alloc_kr "$DS" crslice_epsuniform   slice   uniform k_ratio "$S"
    addtask results_alloc_kr "$DS" cruniform_epsslice   uniform slice   k_ratio "$S"
    addtask results_alloc_kr "$DS" crslice_epsslice     slice   slice   k_ratio "$S"
  done
done

SAY "任务清单：${#TASKS[@]} 个 run（TOPUP=$DO_TOPUP, PAR=$PAR, RULE_C=k_ratio, RULE_TOPUP=bw）"

done_file(){  # OUT DS TAG SEED
  echo "$1/$2/proposed_${2}_alpha${ALPHA}_seed${4}_${3}/results.json"
}

# ------------------------------------------------------------------ launch
n_launch=0; n_skip=0
for task in "${TASKS[@]}"; do
  IFS='|' read -r OUT DS TAG NSAC EPS RULE SEED <<< "$task"
  f=$(done_file "$OUT" "$DS" "$TAG" "$SEED")
  if [ -f "$f" ]; then n_skip=$((n_skip+1)); continue; fi
  THR
  NSAC_MODE="$NSAC" EPSILON_MODE="$EPS" SLICE_WEIGHT_RULE="$RULE" SLICE_MAP="$SLICE_MAP" \
    HIERFED_DATASET="$DS" timeout "$TIMEOUT" $PY -u run_experiment.py --method proposed \
    --dataset "$DS" --alpha "$ALPHA" --seed "$SEED" --tag "$TAG" --T "$T" \
    --output_dir "$OUT/$DS" > "$LOG/${OUT##*/}_${DS}_${TAG}_s${SEED}.log" 2>&1 &
  n_launch=$((n_launch+1))
  SAY "  [launch] $OUT $DS $TAG s$SEED  (NSAC=$NSAC EPS=$EPS RULE=$RULE)"
done
SAY "已启动 $n_launch 个，跳过 $n_skip 个（已有）"

# ------------------------------------------------------------------ heartbeat wait
total_done=0
while [ "$(NB)" -gt 0 ]; do
  n=0
  for task in "${TASKS[@]}"; do
    IFS='|' read -r OUT DS TAG NSAC EPS RULE SEED <<< "$task"
    [ -f "$(done_file "$OUT" "$DS" "$TAG" "$SEED")" ] && n=$((n+1))
  done
  SAY "进度 $n / ${#TASKS[@]}   live=$(NB)"
  sleep 600
done
SAY "所有子进程已退出"

# ------------------------------------------------------------------ verify
echo "==================== VERIFY ===================="
miss=0
for task in "${TASKS[@]}"; do
  IFS='|' read -r OUT DS TAG NSAC EPS RULE SEED <<< "$task"
  f=$(done_file "$OUT" "$DS" "$TAG" "$SEED")
  if [ ! -f "$f" ]; then
    miss=$((miss+1))
    echo "  [MISSING] $f"
    tail -n 10 "$LOG/${OUT##*/}_${DS}_${TAG}_s${SEED}.log" 2>/dev/null | sed 's/^/     | /'
  fi
done
echo "=================================================="
echo " results_alloc    : $(find results_alloc    -name results.json 2>/dev/null | wc -l) / 64"
echo " results_alloc_kr : $(find results_alloc_kr -name results.json 2>/dev/null | wc -l) / 40"
if [ "$miss" -eq 0 ]; then
  echo " [DONE] 全部完成。贴回两条命令的输出："
  echo "        bash seed678.sh analyze            # B + TOPUP 的 n=8 表"
  echo "        python analyze_alloc.py results_alloc"
  echo "        python analyze_alloc.py results_alloc_kr"
else
  echo " [PARTIAL] 缺 $miss 个。直接重跑本脚本即可（幂等，只补缺的）"
fi
echo "=================================================="

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
