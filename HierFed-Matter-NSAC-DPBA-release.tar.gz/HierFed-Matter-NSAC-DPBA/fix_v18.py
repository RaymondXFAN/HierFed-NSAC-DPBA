#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v18.py -- run_baselines.py 的结果目录名写死了 'iotid20'

WHY (gate_phase1 于 2026-10-13 抓到)
------------------------------------
闸门里 tii23_fedavg / tii23_topk_qsgd 判 FAIL（+0 results.json），日志却是
      📊 fedavg_iotid20_alpha0.5_seed1 Summary
—— 明明是 tii23，实验名却叫 iotid20。因为 run_baselines.py 里 'iotid20' 有 3 处：

    line 53  config['dataset_name'] = 'iotid20'          <- fix_v17 已改（数据加载正确）
    line 66  exp_name = f"{method}_iotid20_alpha..."     <- 未改！输出目录名
    line 112 exp_name = f"{method}_iotid20_alpha..."     <- 未改！聚合时读的目录名

后果：不同数据集的结果写进同一个目录、互相覆盖；且 results.json 自报"我是 iotid20"，
会污染任何按名字解析的下游聚合。

本脚本把 66 / 112 两行改成动态取数据集名，并把 dataset_name 写进 results['config']
（便于下游按字段校验，而不是猜目录名）。

  66 行(在 run_single 里, config 在作用域内) : config.get('dataset_name', 'iotid20')
  112 行(在 aggregate_all 里, 没有 config)  : os.environ.get('HIERFED_DATASET', 'iotid20')

对 iotid20 完全向后兼容（结果目录名不变）。run_epsilon_sweep.py 不动 —— 它靠
--output_dir 分数据集（run_multids.sh 就是这么调的），改其 exp_name 反而会废掉已有 results_eps。

Usage
    python fix_v18.py --check
    python fix_v18.py --apply
    python fix_v18.py --revert

--- EN ---
fix_v18.py -- run_baselines.py hard-codes the result directory name to 'iotid20'

WHY (caught by gate_phase1 on 2026-10-13)
------------------------------------
In the gate, tii23_fedavg / tii23_topk_qsgd are judged FAIL (+0 results.json), yet the log reads
      📊 fedavg_iotid20_alpha0.5_seed1 Summary
-- it is clearly tii23, but the experiment is named iotid20. Because 'iotid20' occurs in 3 places in run_baselines.py:

    line 53  config['dataset_name'] = 'iotid20'          <- already fixed by fix_v17 (data loading is correct)
    line 66  exp_name = f"{method}_iotid20_alpha..."     <- NOT fixed! the output directory name
    line 112 exp_name = f"{method}_iotid20_alpha..."     <- NOT fixed! the directory name read during aggregation

Consequence: results of different datasets are written into the same directory and overwrite each other; and results.json claims "I am iotid20",
which pollutes any downstream aggregation that parses by name.

This script changes lines 66 / 112 to take the dataset name dynamically, and writes dataset_name into results['config']
(so downstream can verify by field instead of guessing the directory name).

  line 66 (in run_single, config is in scope) : config.get('dataset_name', 'iotid20')
  line 112 (in aggregate_all, no config)      : os.environ.get('HIERFED_DATASET', 'iotid20')

Fully backward compatible with iotid20 (the result directory name is unchanged). run_epsilon_sweep.py is left untouched -- it separates datasets via
--output_dir (that is how run_multids.sh calls it); changing its exp_name would instead break the existing results_eps.

Usage
    python fix_v18.py --check
    python fix_v18.py --apply
    python fix_v18.py --revert
"""
import argparse
import py_compile
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
BAK = ".bak_v18"
TARGET = "run_baselines.py"

OLD_EXP = 'exp_name = f"{method}_iotid20_alpha{alpha}_seed{seed}"'
NEW_EXP_CFG = ("exp_name = f\"{method}_{config.get('dataset_name', 'iotid20')}"
               "_alpha{alpha}_seed{seed}\"  # [fix_v18]")
NEW_EXP_ENV = ("exp_name = f\"{method}_{os.environ.get('HIERFED_DATASET', 'iotid20')}"
               "_alpha{alpha}_seed{seed}\"  # [fix_v18]")

OLD_CFG = """    results['config'] = {
        'method': method,
        'alpha': alpha,
        'seed': seed,
        'oversample': False,
        'T': 50,
        'N': 20,
    }"""
NEW_CFG = """    results['config'] = {
        'method': method,
        'alpha': alpha,
        'seed': seed,
        'dataset_name': config.get('dataset_name', 'iotid20'),  # [fix_v18]
        'oversample': False,
        'T': 50,
        'N': 20,
    }"""


def log(m):
    print("  " + m)


def backup(p):
    b = p.with_name(p.name + BAK)
    if not b.exists():
        shutil.copy2(p, b)
        log(f"backup  {p.name} -> {p.name}{BAK}")


def check():
    p = ROOT / TARGET
    if not p.exists():
        log(f"[!!] 找不到 {TARGET} (cwd={ROOT})")
        return 1
    t = p.read_text(encoding="utf-8")
    n = t.count(OLD_EXP)
    log(f"{TARGET}: 旧 exp_name 出现 {n} 处（期望 2）")
    log(f"{TARGET}: results['config'] 锚点 {'在' if OLD_CFG in t else '不在'}")
    if "# [fix_v18]" in t:
        log("[ok] 已打过 fix_v18")
    return 0


def apply():
    p = ROOT / TARGET
    if not p.exists():
        log(f"[!!] 找不到 {TARGET}")
        return 1
    t = p.read_text(encoding="utf-8")
    if "# [fix_v18]" in t:
        log("[ok] fix_v18 已应用（幂等跳过）")
        return _verify()
    if t.count(OLD_EXP) < 2:
        log(f"[!!] 只找到 {t.count(OLD_EXP)} 处旧 exp_name（期望 2）—— 锚点不匹配，未改动")
        return 1
    backup(p)
    t = t.replace(OLD_EXP, NEW_EXP_CFG, 1)      # run_single  (config 在作用域内) | EN: run_single (config is in scope)
    t = t.replace(OLD_EXP, NEW_EXP_ENV, 1)      # aggregate_all (只用 env) | EN: aggregate_all (uses env only)
    if OLD_CFG in t:
        t = t.replace(OLD_CFG, NEW_CFG, 1)
        log("[done] results['config'] 增加 dataset_name")
    else:
        log("[??] results['config'] 锚点未命中（非致命）")
    p.write_text(t, encoding="utf-8")
    log(f"[done] {TARGET}: 2 处 exp_name 已改为动态数据集名")
    return _verify()


def _verify():
    p = ROOT / TARGET
    ok = True
    try:
        py_compile.compile(str(p), doraise=True)
        log("[ok] 编译通过")
    except Exception as e:
        log(f"[!!] 编译失败: {e}")
        return 1
    t = p.read_text(encoding="utf-8")
    for probe, why in (("config.get('dataset_name', 'iotid20')", "run_single"),
                       ("os.environ.get('HIERFED_DATASET', 'iotid20')", "aggregate_all")):
        if probe in t:
            log(f"[ok] {why}: 已使用动态数据集名")
        else:
            log(f"[!!] {why}: 未找到动态取值")
            ok = False
    if t.count("_iotid20_alpha{alpha}") > 0:
        log(f"[!!] 仍有 {t.count('_iotid20_alpha{alpha}')} 处硬编码 _iotid20_ 名字")
        ok = False
    log(f"[verify] {'ALL PASS' if ok else 'FAILED'}")
    return 0 if ok else 1


def revert():
    p = ROOT / TARGET
    b = p.with_name(p.name + BAK)
    if b.exists():
        shutil.copy2(b, p)
        log(f"[revert] {TARGET} 已还原")
    else:
        log(f"[--] 无 {p.name}{BAK}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    return check() if a.check else (apply() if a.apply else revert())


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
