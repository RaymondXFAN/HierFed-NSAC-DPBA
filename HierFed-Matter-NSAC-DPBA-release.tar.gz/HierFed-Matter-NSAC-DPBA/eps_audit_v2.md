==============================================================================
  privacy-budget audit (tree-aware, read-only)
  project root : /root/autodl-tmp/HierFed-Matter-NSAC-DPBA
==============================================================================

  current trees : ['results_baseline', 'results_v11gate', 'results_v11gate_base']
  stale/excluded: ['results_ablation_OLD_buggy', 'results_baseline_OLD_buggy', 'results_clip', 'results_eps_OLD_buggy', 'results_noise_sweep', 'results_precheck', 'results_probe', 'results_route_b', 'results_scale_OLD_buggy', 'results_v3', 'results_v7']

==============================================================================
  tree: results_baseline
==============================================================================
  method                 epsilon(config)             n  sigma (log)
  --------------------------------------------------------------------------------------------
  fedavg                 --                          8  

==============================================================================
  tree: results_v11gate
==============================================================================
  method                 epsilon(config)             n  sigma (log)
  --------------------------------------------------------------------------------------------
  proposed               399.0 x1                    1  RDP base σ=0.3592 (ε_total=399.0, T=50, q=1.000)

==============================================================================
  tree: results_v11gate_base
==============================================================================
  method                 epsilon(config)             n  sigma (log)
  --------------------------------------------------------------------------------------------
  topk_qsgd              --                          1  

==============================================================================
  verdict per tree -- do all methods share one privacy budget?
==============================================================================
  [results_baseline] MATCHED: epsilon = (unset)
  [results_v11gate] MATCHED: epsilon = 399.0
  [results_v11gate_base] MATCHED: epsilon = (unset)

  NOTE: a config value of 3.0 that coexists with a log sigma for 399
  means the config file is STALE (base.yaml says 3.0, the runs used 399).
  The sigma line in the job log is the ground truth -- trust it, and fix
  base.yaml so the paper's reproducibility section is not wrong.
