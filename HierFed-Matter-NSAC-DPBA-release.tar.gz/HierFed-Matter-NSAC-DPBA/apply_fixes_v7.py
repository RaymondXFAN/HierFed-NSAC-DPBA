#!/usr/bin/env python3
r"""
apply_fixes_v7.py -- MATCH THE DP NOISE TO EACH DEVICE'S OWN SENSITIVITY.

FINDING (evidence chain, all measured)
--------------------------------------
  eps=399, q=1, clip_norm=1.0  ->  sigma_base = 0.3592
  [DP-DEBUG] ||dw|| = 0.37  (d=7762, sqrt(d)=88.1)
      per-coordinate signal = 0.37/88.1 = 0.0042
      per-coordinate noise  = 0.359         -> SNR = 0.0117  (noise 86x signal)
  Same eps, sigma reduced ~9x (0.040)  ->  AUC 0.980
  adaptive_clip_dp, same eps, C_i~0.11 ->  sigma_i = 0.359*0.11 = 0.0395 -> AUC 0.981

Root cause: a SINGLE GLOBAL clip bound C=1.0 is ~9x larger than the typical
device's update norm.  Because sigma is proportional to C, every device is
noised as if it had the worst-case sensitivity, while smaller-C experiments
fail for the opposite reason (a global small C also crushes the few
large-norm, informative devices -> AUC 0.745 at C=0.1).

Fix: per-device adaptive clipping.  C_i = EMA(||dW_i||) clipped into
[C_min, C_max]; clip with C_i and scale the noise by C_i / clip_norm so the
sensitivity — and therefore the (eps, delta) guarantee — is exactly C_i.

Everything is idempotent, backs files up, and is checked for syntax.
Usage:  python apply_fixes_v7.py [root]
"""
import os
import re
import sys
import shutil
import argparse
import py_compile

CFG_KEYS = """                        <ANCHOR>
dp_clip_mode: per_device      # [v7] global | per_device  (per_device = match noise to each device)
adaptive_clip_beta: 0.2       # [v7] EMA rate for C_i
adaptive_clip_min: 0.05       # [v7] floor of C_i  (relative to clip_norm=1.0)
adaptive_clip_max: 3.0        # [v7] cap  of C_i
"""


def patch_simulator(path, dry=False):
    s = open(path, encoding="utf-8").read()
    if "dp_clip_mode" in s and "_dev_clip" in s:
        return "already", path

    anchor = "        self.clip_norm = float(config.get('clip_norm', 1.0))"
    if anchor not in s:
        return "anchor-missing", path

    add = anchor + "\n" + "\n".join([
        "        # [v7] per-device adaptive clipping: scale DP noise by each device's own",
        "        # sensitivity C_i = EMA(||dW_i||), instead of one global worst-case bound.",
        "        self.dp_clip_mode = str(config.get('dp_clip_mode', 'global')).lower()",
        "        self.adaptive_clip_beta = float(config.get('adaptive_clip_beta', 0.2))",
        "        self.adaptive_clip_min = float(config.get('adaptive_clip_min', 0.05))",
        "        self.adaptive_clip_max = float(config.get('adaptive_clip_max', 3.0))",
        "        self._dev_clip = {}",
    ])
    s = s.replace(anchor, add, 1)

    # indent-aware regex: tolerate any plausible leading whitespace
    pat = re.compile(
        r"( *)device_sigma = sigma_base \* float\(sigma_mult\[dev_id\]\)\n"
        r"( *)clipped = clip_gradient\(gradient, self\.clip_norm\)\n")
    m = pat.search(s)
    if not m:
        return "block-missing", path
    i = m.group(1)
    new = (
        f"{i}# [v7] per-device sensitivity matching\n"
        f"{i}if self.dp_clip_mode == 'per_device':\n"
        f"{i}    _raw_norm = float(gradient.norm())\n"
        f"{i}    _prev = self._dev_clip.get(dev_id, self.clip_norm)\n"
        f"{i}    _ema = (1.0 - self.adaptive_clip_beta) * _prev \\\n"
        f"{i}        + self.adaptive_clip_beta * _raw_norm\n"
        f"{i}    _C_i = float(min(max(_ema, self.adaptive_clip_min),\n"
        f"{i}                      self.adaptive_clip_max))\n"
        f"{i}    self._dev_clip[dev_id] = _C_i\n"
        f"{i}else:\n"
        f"{i}    _C_i = self.clip_norm\n"
        f"{i}# sigma_base was computed for sensitivity clip_norm -> rescale to C_i\n"
        f"{i}device_sigma = (sigma_base * float(sigma_mult[dev_id])\n"
        f"{i}                * (_C_i / max(self.clip_norm, 1e-12)))\n"
        f"{i}clipped = clip_gradient(gradient, _C_i)\n")
    s = s[:m.start()] + new + s[m.end():]

    if dry:
        return "dry-ok", path
    shutil.copy2(path, path + ".bak_v7")
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    return "ok", path


def patch_yaml(path):
    s = open(path, encoding="utf-8").read()
    if "dp_clip_mode" in s:
        return "already", path
    m = re.search(r"^clip_norm:.*$", s, flags=re.M)
    if not m:
        return "anchor-missing", path
    block = ("clip_norm: 1.0\n"
             "dp_clip_mode: per_device      # [v7] global | per_device\n"
             "adaptive_clip_beta: 0.2       # [v7] EMA rate for per-device C_i\n"
             "adaptive_clip_min: 0.05       # [v7] floor of C_i\n"
             "adaptive_clip_max: 3.0        # [v7] cap of C_i")
    s = s[:m.start()] + block + s[m.end():]
    shutil.copy2(path, path + ".bak_v7")
    with open(path, "w", encoding="utf-8") as f:
        f.write(s)
    return "ok", path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    print(f"[v7] root = {root}")

    n_ok = n_bad = 0
    for rel, fn in (("core/simulator.py", patch_simulator),
                    ("configs/base.yaml", patch_yaml)):
        p = os.path.join(root, rel)
        if not os.path.isfile(p):
            print(f"  [MISSING] {rel}")
            n_bad += 1
            continue
        if fn is patch_simulator:
            st, _ = fn(p, dry=args.dry_run)
        else:
            st, _ = fn(p)
        print(f"  [{st:>15}] {rel}")
        if st in ("ok", "dry-ok", "already"):
            n_ok += 0
        else:
            n_bad += 1

    sim = os.path.join(root, "core/simulator.py")
    if not args.dry_run and os.path.isfile(sim):
        try:
            py_compile.compile(sim, doraise=True, cfile="/tmp/_v7.pyc")
            print("  [py_compile OK] core/simulator.py")
        except Exception as e:
            print(f"  [py_compile FAIL] {e}")
            n_bad += 1
        src = open(sim, encoding="utf-8").read()
        checks = {
            "读取 dp_clip_mode": "self.dp_clip_mode =" in src,
            "初始化 _dev_clip": "self._dev_clip = {}" in src,
            "按 C_i 缩放噪声": "_C_i / max(self.clip_norm" in src,
            "用 C_i 裁剪": "clip_gradient(gradient, _C_i)" in src,
        }
        for k, v in checks.items():
            print(f"  [{'OK ' if v else 'FAIL'}] {k}")
            n_bad += 0 if v else 1

    print(f"\napply_fixes_v7: failed={n_bad}")
    print("下一步：bash run_v7_verify.sh        # 1 seed × 3 配置，约 30 分钟")
    sys.exit(1 if n_bad else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
