#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v12.py -- one consistent communication-accounting convention.

    python fix_v12.py            # DRY RUN: shows the exact edits + new numbers
    python fix_v12.py --apply    # patch core/nsac.py (backup .bak_v12)
    python fix_v12.py --revert   # restore

THE PROBLEM
-----------
Two conventions live in core/nsac.py:

  nsac_compress()                  bills  k*4 + k*(b//8)   <- indices counted (int32)
  compute_communication_stats()    bills  CR*d*4  with CR = k_ratio*b/32
                                          <- indices treated as FREE

The paper's headline "57.6x / 98.3%" comes from the second (optimistic) one,
while the per-run log (`total_compressed_bytes`) uses the first.  A reviewer
who knows top-k sparsification will ask where the positions go.

WHAT THIS DOES
--------------
1. nsac_compress(): bill positions as **2 bytes (uint16)** instead of 4 --
   d = 7762 < 65536, so a position needs 16 bits, not 32.  Also emits
   `CR_empirical = compressed_bytes/(d*4)`.
2. compute_communication_stats(): use the SAME formula, and keep the old number
   as `speedup_declared` so the paper can show one and the appendix the other.

Nothing that affects accuracy is touched: AUC is unchanged, this is a
reporting fix.  The old (optimistic) speedup stays available as a field.
"""
import argparse
import os
import py_compile
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
NSAC = os.path.join(HERE, "core", "nsac.py")
MARK = "[fix_v12]"

OLD_BYTES = ("    CR_actual = k_ratio_actual * b / 32.0\n"
             "    # Actual compressed bytes: indices (4 bytes each) + values (b/8 bytes each)\n"
             "    compressed_bytes = k * 4 + k * (b // 8)")
NEW_BYTES = ("    # [fix_v12] CR_actual becomes the EMPIRICAL, index-aware compression\n"
             "    # ratio so that every downstream number (latency, round_stats,\n"
             "    # avg_compression_ratio, the end-to-end speedup) uses one convention.\n"
             "    # The old indices-free value is kept as CR_declared.\n"
             "    CR_declared = k_ratio_actual * b / 32.0\n"
             "    index_bytes = 2 if d <= 65535 else 4\n"
             "    compressed_bytes = k * index_bytes + k * (b // 8)\n"
             "    CR_actual = compressed_bytes / (d * 4.0)")

NEW_COMM = '''def compute_communication_stats(
    d: int,
    N: int,
    M: int,
    T: int,
    slice_assignments: Dict[int, str],
    model_size_bytes: int = 31304,  # |w| ~ 30.6 KB (d=7762 x 4 bytes, lightweight)
) -> Dict:
    """
    Compute total communication statistics for one experiment run.

    [fix_v12] The compressed payload is now billed the SAME way nsac_compress()
    bills it: k = int(k_ratio*d) positions (2 bytes each, uint16, since
    d < 65536) + k quantised values (b//8 bytes each).  The previous formula
    `CR = k_ratio*b/32; payload = CR*d*4` treated the top-k positions as FREE,
    which overstates the compression by the index overhead.

    `speedup_declared` keeps the old, indices-free number for reference.
    """
    star_traffic = N * model_size_bytes * T  # Eq.(3)
    index_bytes = 2 if d <= 65535 else 4

    total_compressed_bytes_per_round = 0
    total_declared_bytes_per_round = 0
    for gw_id in range(M):
        slice_name = slice_assignments.get(gw_id, 'embb')  # default eMBB
        sc = SLICE_CONFIGS[slice_name]
        k = int(sc.k_ratio * d)
        total_compressed_bytes_per_round += k * index_bytes + k * (sc.b_bits // 8)
        total_declared_bytes_per_round += int((sc.k_ratio * sc.b_bits / 32.0) * d * 4)

    core_traffic = total_compressed_bytes_per_round * T      # Eq.(5) with compression
    core_declared = total_declared_bytes_per_round * T
    speedup = star_traffic / core_traffic if core_traffic > 0 else float('inf')

    # Edge traffic (local, doesn't traverse core)
    edge_traffic = N * model_size_bytes * T                  # Eq.(4)

    return {
        'star_traffic_MB': star_traffic / 1e6,
        'core_traffic_MB': core_traffic / 1e6,
        'edge_traffic_MB': edge_traffic / 1e6,
        'speedup': speedup,
        'reduction_pct': (1 - core_traffic / star_traffic) * 100,
        # --- transparency fields ---
        'index_bytes': index_bytes,
        'cr_empirical_avg': total_compressed_bytes_per_round / (M * d * 4),
        'core_traffic_declared_MB': core_declared / 1e6,
        'speedup_declared': (star_traffic / core_declared
                             if core_declared > 0 else float('inf')),
        'reduction_pct_declared': (1 - core_declared / star_traffic) * 100,
    }


'''

SPAN = re.compile(r"^def compute_communication_stats\(.*?(?=^def |\Z)", re.S | re.M)
BYTES_RE = re.compile(
    r"^(?P<i>[ \t]*)CR_actual = k_ratio_actual \* b / 32\.0\s*\n"
    r"\s*# Actual compressed bytes[^\n]*\n"
    r"\s*compressed_bytes = k \* 4 \+ k \* \(b // 8\)", re.M)


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def preview():
    import numpy as np
    bar("what the numbers become  (d=7762, N=20, M=4, T=50, slices = 2xembb + 2xurllc)")
    d, N, M, T = 7762, 20, 4, 50
    assign = {0: 'embb', 1: 'embb', 2: 'urllc', 3: 'urllc'}
    idx = 2
    full = d * 4
    tot_new = tot_old = 0
    print(f"  {'slice':6} {'k':>5} {'positions':>10} {'values':>8} {'new B':>8} "
          f"{'old B':>8}")
    for gw in range(M):
        sc = {'embb': (0.30, 16, 100), 'urllc': (0.10, 8, 10)}[assign[gw]]
        k = int(sc[0] * d)
        new = k * idx + k * (sc[1] // 8)
        old = int(sc[0] * sc[1] / 32.0 * full)
        tot_new += new; tot_old += old
        print(f"  {assign[gw]:6} {k:>5} {k*idx:>10} {k*(sc[1]//8):>8} {new:>8} {old:>8}")
    star = N * full * T
    bar("end-to-end")
    print(f"  {'convention':30} {'speedup':>9} {'reduction':>10} {'cr_avg':>8}")
    print("  " + "-" * 68)
    print(f"  {'declared (indices free)':30} {star/(tot_old*T):>8.1f}x "
          f"{(1-tot_old*T/star)*100:>9.1f}% {tot_old/(M*full):>8.4f}")
    print(f"  {'FIXED    (uint16 indices)':30} {star/(tot_new*T):>8.1f}x "
          f"{(1-tot_new*T/star)*100:>9.1f}% {tot_new/(M*full):>8.4f}")
    print("\n  17.4x under int32; 26.7x with the uint16 fix.  Both >> 1, so the")
    print("  hierarchy story survives -- only the headline number changes.")


def apply():
    bar("applying [fix_v12]")
    if not os.path.exists(NSAC):
        print("  !! core/nsac.py not found -- run me from the project root")
        return 1
    src = open(NSAC, encoding="utf-8").read()
    if MARK in src:
        print(f"  [skip] {MARK} already applied")
        return 0
    edits, notes = src, []

    # --- edit 1: compressed_bytes ---
    m = BYTES_RE.search(edits)
    if not m:
        print("  !! anchor 'compressed_bytes = k * 4 + k * (b // 8)' not found")
        return 1
    indent = m.group("i")
    repl = "\n".join(indent + l.strip() for l in NEW_BYTES.splitlines())
    edits = edits[:m.start()] + repl + edits[m.end():]
    notes.append("nsac_compress: index width 4 -> 2 B (uint16); "
                 "CR_actual now empirical")

    # --- edit 1b: expose CR_declared in the returned dict ---
    m1b = re.search(r"^(?P<i>[ \t]*)'CR_actual': CR_actual,", edits, re.M)
    if not m1b:
        print("  !! anchor \"'CR_actual': CR_actual,\" not found")
        return 1
    edits = (edits[:m1b.end()] + "\n" + m1b.group("i") + "'CR_declared': CR_declared,"
             + edits[m1b.end():])
    notes.append("nsac_compress: returns CR_declared alongside CR_actual")

    # --- edit 2: compute_communication_stats ---
    m2 = SPAN.search(edits)
    if not m2:
        print("  !! compute_communication_stats not found")
        return 1
    edits = edits[:m2.start()] + NEW_COMM + edits[m2.end():]
    notes.append("compute_communication_stats: honest payload + speedup_declared")

    bak = NSAC + ".bak_v12"
    if not os.path.exists(bak):
        shutil.copy2(NSAC, bak)
        print(f"  backup -> {os.path.relpath(bak, HERE)}")
    with open(NSAC, "w", encoding="utf-8") as f:
        f.write(edits)
    try:
        py_compile.compile(NSAC, doraise=True)
        print("  [ok] py_compile core/nsac.py")
    except Exception as e:
        print(f"  !! py_compile FAILED: {e}\n  restoring")
        shutil.copy2(bak, NSAC)
        return 1
    chk = open(NSAC, encoding="utf-8").read()
    for n in notes:
        print(f"    + {n}")
    print("  residual audit:")
    print("    marker present      :", MARK in chk)
    print("    uint16 index billed :", "index_bytes = 2 if d <= 65535 else 4" in chk)
    print("    CR_actual empirical :", "CR_actual = compressed_bytes / (d * 4.0)" in chk)
    print("    CR_declared kept    :", "CR_declared = k_ratio_actual" in chk)
    print("    speedup_declared    :", "speedup_declared" in chk)
    bar("NEXT")
    print("  python -c \"from core.nsac import compute_communication_stats as f;"
          "import json;print(json.dumps(f(7762,20,4,50,{0:'embb',1:'embb',2:'urllc',"
          "3:'urllc'}),indent=1))\"")
    print("  expect speedup ~26.7x  and  speedup_declared ~57.1x")
    return 0


def revert():
    bar("revert")
    bak = NSAC + ".bak_v12"
    if not os.path.exists(bak):
        print("  !! no .bak_v12 found")
        return 1
    shutil.copy2(bak, NSAC)
    print(f"  restored core/nsac.py from {os.path.relpath(bak, HERE)}")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  communication-accounting unification  [fix_v12]")
    print("=" * 78)
    if a.revert:
        return revert()
    if a.apply:
        return apply()
    preview()
    print("\n  (dry run -- nothing written.  --apply to patch, --revert to undo)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
