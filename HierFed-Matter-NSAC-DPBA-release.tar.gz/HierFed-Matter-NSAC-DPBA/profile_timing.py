"""
profile_timing.py -- locate the wall-clock bottleneck before the long run.

Measures, on the REAL dataset in data/processed/:
  1. data / partition loading
  2. one local_train() call per device   (e_local=5, several batch sizes)
  3. one FIM update sweep over all devices
  4. one evaluation pass (forward + F1 threshold search)
and then prints per-round / per-experiment / whole-suite time estimates.

Usage:
    cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA
    python profile_timing.py            # full probe (~3-5 min)
    python profile_timing.py --quick    # batch sweep only (~1 min)
"""
import os
import sys
import time
import json
import argparse
import numpy as np
import torch
import yaml

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ROOT)

from models.dnn import build_model                     # noqa: E402
from core.simulator import local_train, DEVICE         # noqa: E402
from core.dpba_fim import FIMTracker                   # noqa: E402


def timed(fn, repeat=1):
    t0 = time.time()
    out = None
    for _ in range(repeat):
        out = fn()
    return (time.time() - t0) / repeat, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true", help="skip the slow sub-probes")
    ap.add_argument("--batches", type=int, nargs="+", default=[32, 64, 128, 256, 512])
    args = ap.parse_args()

    print("=" * 72)
    print(" HierFed-Matter-NSAC-DPBA  timing probe")
    print("=" * 72)
    print(f"torch {torch.__version__} | device = {DEVICE}")
    if torch.cuda.is_available():
        p = torch.cuda.get_device_properties(0)
        vram = getattr(p, "total_memory", getattr(p, "total_mem", 0)) / 1e9
        print(f"GPU: {torch.cuda.get_device_name()} | VRAM={vram:.1f}GB")
    print()

    cfg = yaml.safe_load(open(os.path.join(ROOT, "configs", "base.yaml"), encoding="utf-8"))
    proc = os.path.join(ROOT, "data", "processed")
    alpha = float(cfg.get("alpha", 0.5))
    N = int(cfg.get("N", 20))
    T = int(cfg.get("T", 50))
    E = int(cfg.get("E_local", 5))
    eta = float(cfg.get("eta", 0.01))

    # ---------------- 1. loading ----------------
    def load_train():
        z = np.load(os.path.join(proc, "iotid20_train.npz"))
        return z["X"], z["y"]

    def load_test():
        z = np.load(os.path.join(proc, "iotid20_test.npz"))
        return z["X"], z["y"]

    t_tr, (X, y) = timed(load_train)
    t_te, (Xte, yte) = timed(load_test)
    print(f"[load] train {X.shape} {t_tr:.2f}s | test {Xte.shape} {t_te:.2f}s")

    pf = os.path.join(proc, f"iotid20_partitions_alpha{alpha}.json")
    with open(pf, encoding="utf-8") as f:
        parts = json.load(f)["device_indices"]
    sizes = [len(parts.get(str(i), [])) for i in range(N)]
    n_avg, n_max = int(np.mean(sizes)), max(sizes)
    print(f"[load] partition: N={N}, avg n_i={n_avg}, max n_i={n_max}\n")

    d_model = build_model(X.shape[1]).to(DEVICE)
    d = d_model.num_parameters
    print(f"[model] d = {d}\n")

    # ---------------- 2. local_train batch sweep ----------------
    idx = np.array(parts.get(str(int(np.argmax(sizes))), []) or list(range(min(n_avg * 2, len(y)))))
    Xd, yd = X[idx], y[idx]
    print(f"[bench] local_train on a device with {len(yd)} samples (E_local={E}):")
    results = {}
    for b in args.batches:
        m = build_model(X.shape[1]).to(DEVICE)
        sec, _ = timed(lambda: local_train(m, Xd, yd, num_epochs=E,
                                           batch_size=b, learning_rate=eta,
                                           oversample=False), repeat=1)
        results[b] = sec
        print(f"        batch={b:4d}  ->  {sec:6.2f} s/device"
              f"   ({len(yd)*E/b:.0f} optimizer steps)")
    best_b = min(results, key=results.get)
    print(f"        fastest batch = {best_b}  ({results[best_b]:.2f} s/device)\n")

    if args.quick:
        _summary(results, best_b, N, T, E, None, None)
        return

    # ---------------- 3. FIM sweep ----------------
    def fim_sweep():
        ft = FIMTracker(4, cfg.get("beta_F", 0.9))
        m = build_model(X.shape[1]).to(DEVICE)
        for dev in range(N):
            ii = parts.get(str(dev), [])
            if not ii:
                continue
            dt = torch.tensor(X[ii], dtype=torch.float32).to(DEVICE)
            lt = torch.tensor(y[ii], dtype=torch.long).to(DEVICE)
            ft.local_trace(m, dt, lt)
        return True

    t_fim, _ = timed(fim_sweep)
    print(f"[bench] FIM sweep over {N} devices: {t_fim:.2f} s"
          f"   (every {cfg.get('fim_every', 5)} rounds)\n")

    # ---------------- 4. evaluation ----------------
    from sklearn.metrics import f1_score, roc_auc_score

    def eval_once():
        m = build_model(X.shape[1]).to(DEVICE)
        Xt = torch.tensor(Xte, dtype=torch.float32).to(DEVICE)
        with torch.no_grad():
            out = m(Xt)
            probs = torch.softmax(out, dim=1)
        yp = probs[:, 1].cpu().numpy()
        best = 0.0
        for th in np.arange(0.05, 0.95, 0.05):
            f1_score(yte, (yp >= th).astype(int), zero_division=0)
        return best

    t_eval, _ = timed(eval_once)
    print(f"[bench] one full evaluation ({len(yte)} test samples "
          f"+ 18-point threshold search): {t_eval:.2f} s\n")

    _summary(results, best_b, N, T, E, t_fim, t_eval)


def _summary(results, best_b, N, T, E, t_fim, t_eval):
    print("=" * 72)
    print(" ESTIMATE")
    print("=" * 72)
    for b in results:
        per_round = N * results[b] + (t_eval or 0) + (t_fim / 5 if t_fim else 0)
        per_exp = per_round * T
        print(f"  batch={b:4d}: {per_round/60:5.2f} min/round "
              f"-> {per_exp/60:6.1f} min/experiment (T={T})")
    per_round = N * results[best_b] + (t_eval or 0) + (t_fim / 5 if t_fim else 0)
    per_exp = per_round * T
    suite = {"ablation(6x2x10)": 120, "weights(6x2x10)": 120,
             "baselines(9x2x10)": 180, "eps(7x2x10)": 140, "scale": 9}
    total = sum(suite.values())
    print()
    print(f"  chosen batch = {best_b}")
    print(f"  single experiment: {per_exp/60:.1f} min")
    print(f"  experiment count : {total}  (10 seeds, both alphas)")
    print(f"  >>> TOTAL (1 process): {per_exp*total/3600:.1f} h  "
          f"= {per_exp*total/86400:.1f} days")
    print(f"  >>> TOTAL (4 processes): {per_exp*total/3600/4:.1f} h")
    print("=" * 72)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
