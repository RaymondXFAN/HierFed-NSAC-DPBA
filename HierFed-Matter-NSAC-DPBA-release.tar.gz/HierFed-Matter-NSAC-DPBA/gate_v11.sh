#!/usr/bin/env bash
# gate_v11.sh -- precheck for [fix_v11].  Runs TWO seed-1 jobs at alpha=0.5, in
# two independent output dirs so nothing existing is touched:
#   A) proposed   (reference: results_ablation/proposed_iotid20_alpha0.5_seed1_*)
#   B) topk_qsgd  (reference: logs/jobs/topk_qsgd_iotid20_alpha0.5_seed1.log -> 0.8668)
# Then:  python check_v11_gate.py   (prints old vs new + verdict)
set -u
cd "$(dirname "$0")" || exit 1

[ -f core/nsac.py ] || {
  echo "!! core/nsac.py not found.  Copy this script into the project root first:"
  echo "   cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA"
  echo "   cp /tmp/hierfed_post_s2/gate_v11.sh /tmp/hierfed_post_s2/check_v11_gate.py ."
  exit 1
}
[ -f fix_v11.py ] && [ ! -f check_v11_gate.py ] && cp -v fix_v11.py /dev/null >/dev/null 2>&1

echo "== [1/3] is [fix_v11] applied ? =="
if grep -q "fix_v11" core/nsac.py; then
  echo "   yes -> core/nsac.py carries [fix_v11]"
else
  echo "   NOT applied.  Run first:  python fix_v11.py --apply"
  exit 1
fi

echo "== [2/3] launching 2 gate jobs (alpha=0.5, seed=1) =="
mkdir -p logs
nohup python -u run_experiment.py --dataset iotid20 --alpha 0.5 --seed 1 \
      --method proposed --tag v11gate --output_dir results_v11gate \
      > logs/v11_gate_proposed.log 2>&1 &
P1=$!
nohup python -u run_baselines.py --method topk_qsgd --alpha 0.5 --seeds 1 \
      --output_dir results_v11gate_base --skip_aggregate \
      > logs/v11_gate_topk.log 2>&1 &
P2=$!
echo "   proposed  pid=$P1   log=logs/v11_gate_proposed.log"
echo "   topk_qsgd pid=$P2   log=logs/v11_gate_topk.log"

echo "== [3/3] done launching.  Expected runtime ~18-20 min =="
cat <<'EOF'

-- 非阻塞监控（不要用 tail -f）--
  tail -n 5 logs/v11_gate_proposed.log
  tail -n 5 logs/v11_gate_topk.log
  pgrep -af "v11gate|method topk_qsgd" | grep -v pgrep || echo "两个都跑完了"

-- 跑完后（唯一判据）--
  python check_v11_gate.py

-- 判定 --
  proposed 从 0.928 往上 / topk 从 0.8668 往上  -> 全量重跑
  任意一个塌到 <0.80                          -> python fix_v11.py --revert
EOF
exit 0

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
