#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
recompute_comm.py -- rebuild the communication table under ONE convention.

    python recompute_comm.py              # scan the current result trees
    python recompute_comm.py --json out.json

WHY
---
`fix_v12` (uint16 positions + index-aware CR_actual) landed WHILE the S2 batch
was already running, so early jobs recorded an int32-era payload and later ones
a uint16-era payload.  Mixing them in one table would be wrong.

This script ignores the recorded CR fields and recomputes every row from
information that is invariant across the change:

  * proposed / hierarchical runs -> round_metrics[*].total_compressed_bytes
    (already the honest byte count; the per-round value is used, so the index
     width does not matter)
  * topk_qsgd (star)             -> recomputed from final_metrics.k_ratio_nominal
                                    and b_bits_nominal, with uint16 positions
  * everything else              -> uncompressed (CR = 1)

Convention: positions cost 2 bytes (uint16, d < 65536), values cost b//8 bytes,
dense fp32 costs 4 bytes/element.
"""
import argparse
import glob
import json
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))

# who transmits from where
HIER = {"proposed", "hierfed", "hierfed_dp", "hierfed_nsac_uni_dp",
        "full", "nsac_uni_dp", "no_nsac", "no_dp", "star"}
# NOTE: results_v11gate_base duplicates results_baseline/topk_qsgd -- excluded
CUR_TREES = ("results_baseline", "results_eps", "results_ablation",
             "results_v11gate", "results_epsgrid")


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def model_dim(cfg):
    dims = [cfg.get("input_dim_iotid20", cfg.get("feature_dim", 79))] + \
           list(cfg.get("hidden_dims", [64, 32, 16])) + [cfg.get("output_dim", 2)]
    return sum(dims[i] * dims[i + 1] + dims[i + 1] for i in range(len(dims) - 1))


def method_of(dirname):
    m = re.match(r"(epsweep_eps[\d.]+)_", dirname)
    if m:
        return "eps-sweep(proposed)"
    m = re.match(r"(.+?)_(iotid20|cicids2017|gotham|tii)", dirname)
    return m.group(1) if m else dirname


def is_hier(meth):
    """transmits from M gateways instead of N devices."""
    return any(t in meth for t in ("proposed", "hierfed")) or meth in HIER


def per_round_bytes(d, meth, cfg, fm, r1):
    """honest bytes transmitted per round, or None if we cannot tell."""
    if "total_compressed_bytes" in r1:
        return int(r1["total_compressed_bytes"])
    kr = fm.get("k_ratio_nominal")
    b = fm.get("b_bits_nominal")
    if kr is not None and b is not None:
        k = max(1, int(float(kr) * d))
        n_tx = cfg.get("N", 20)
        return int(n_tx * (k * 2 + k * (int(b) // 8)))
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default=None)
    a = ap.parse_args()
    print("=" * 78)
    print("  communication accounting -- unified recompute (read-only)")
    print(f"  project root : {HERE}")
    print("=" * 78)

    rows = []
    for tree in CUR_TREES:
        for p in sorted(glob.glob(os.path.join(HERE, tree, "*", "results.json"))):
            name = os.path.basename(os.path.dirname(p))
            try:
                dd = json.load(open(p, encoding="utf-8"))
            except Exception:
                continue
            cfg = dd.get("config") or {}
            fm = dd.get("final_metrics") or {}
            rm = dd.get("round_metrics") or []
            if not rm:
                continue
            d = model_dim(cfg)
            N = int(cfg.get("N", 20))
            M = int(cfg.get("M", 4))
            T = int(cfg.get("T", 50))
            meth = method_of(name)
            prb = per_round_bytes(d, meth, cfg, fm, rm[0])
            tx = M if is_hier(meth) else N
            if prb is None:
                prb = tx * d * 4                     # uncompressed
                conv = "assumed full"
            else:
                conv = "logged" if "total_compressed_bytes" in rm[0] else "nominal"
            full = tx * d * 4
            rows.append(dict(tree=tree, name=name, method=meth, alpha=cfg.get("alpha"),
                             seed=cfg.get("seed"), d=d, tx=tx, T=T,
                             per_round=prb, full_round=full,
                             cr=prb / full if full else float("nan"),
                             conv=conv,
                             eps=cfg.get("epsilon_total"),
                             auc=fm.get("auc_roc")))

    if not rows:
        print("\n  no result files found")
        return 1

    # ---- per (method, alpha) summary -----------------------------------
    agg = defaultdict(lambda: {"bytes": [], "cr": [], "auc": [], "eps": set(),
                               "d": set(), "N": set(), "M": set(), "T": set()})
    for r in rows:
        key = (r["method"], r["alpha"])
        g = agg[key]
        g["bytes"].append(r["per_round"])
        g["cr"].append(r["cr"])
        if r["auc"] is not None:
            g["auc"].append(r["auc"])
        if r["eps"] is not None:
            g["eps"].add(r["eps"])
        g["d"].add(r["d"]); g["N"].add(r["tx"]); g["T"].add(r["T"])

    bar("unified table   (positions = uint16; values = b/8 bytes)")
    print(f"  {'method':<24} {'alpha':>5} {'n':>3} {'per-msg CR':>11} "
          f"{'B/round':>11} {'end-to-end speedup':>19} {'eps':>7}")
    print("  " + "-" * 92)
    out = {}
    for key in sorted(agg, key=lambda k: (str(k[0]), k[1] if k[1] is not None else 0)):
        meth, alpha = key
        g = agg[key]
        n = len(g["bytes"])
        cr = sum(g["cr"]) / n
        per = sum(g["bytes"]) / n
        d = sorted(g["d"])[0]; N = sorted(g["N"])[0]; T = sorted(g["T"])[0]
        star = 20 * d * 4 * T            # reference topology (N=20 devices)
        core = per * T
        speed = star / core if core else float("inf")
        eps = ",".join(sorted(str(e) for e in g["eps"])) or "-"
        print(f"  {meth:<24} {str(alpha):>5} {n:>3} {cr:>11.4f} "
              f"{per:>11,.0f} {speed:>18.1f}x {eps:>7}")
        out[f"{meth}|{alpha}"] = dict(n=n, per_msg_cr=cr, bytes_per_round=per,
                                      speedup_vs_star=speed, eps=sorted(g["eps"]),
                                      auc_mean=(sum(g["auc"]) / len(g["auc"]))
                                      if g["auc"] else None)

    bar("rules")
    print("  * positions billed at 2 bytes (uint16) because d = 7762 < 65536;")
    print("    the old paper figure 57.6x assumed positions were FREE (int32 stored")
    print("    per element, 4 bytes).  This table is the defensible one.")
    print("  * hierarchical methods transmit from M gateways, star methods from N")
    print("    devices; the reference 'star' traffic is always N*d*4*T.")
    print("  * rows marked 'nominal' were recomputed analytically because they ran")
    print("    before [fix_v12]; rows marked 'logged' used the recorded byte count.")

    if a.json:
        json.dump(out, open(a.json, "w", encoding="utf-8"), indent=2)
        print(f"\n  wrote {a.json}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
