#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
diag_ablation.py -- is the ablation tree trustworthy?  Read-only, no re-runs.

It answers four questions with evidence from the files on disk:

  1 FRESHNESS.  run_ablation.py uses skip_existing=True, and our driver only
    checked that results.json EXISTS.  So any leftover file from BEFORE the
    fix_v* patches would have been silently kept.  We print each file's mtime
    and flag anything older than --since.

  2 'full' vs the main run.  'full' has an EMPTY override dict, so it must
    reproduce run_experiment --method proposed at the same eps.  We compare it
    seed by seed against results_eps/epsweep_eps400.

  3 ablation vs baseline tree.  'hierfed_uni_dp' (disable_nsac+disable_dpba_fim)
    should be the same thing as the hierfed_dp baseline.  We compare them.

  4 G-1 stability.  run_cr_match.sh bins runs by round-0 1/avg_compression_ratio,
    which produced 8 different CF values over 20 runs.  We print round-0 vs
    mean-over-rounds vs last-round so you can see which estimate is stable.

Usage
    python diag_ablation.py
    python diag_ablation.py --since "2026-10-09 06:00"
"""
import argparse
import glob
import json
import math
import os
import re
import time
from collections import Counter, defaultdict
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
ABL = "results_ablation"
CR = "results_crsweep"
COMPONENT = ["full", "hierfed_only", "hierfed_nsac", "hierfed_dpba",
             "hierfed_uni_dp", "hierfed_nsac_uni_dp"]


def head(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def read(p):
    try:
        return json.load(open(p, encoding="utf-8"))
    except Exception:
        return None


def stats(p):
    """everything we need from one results.json"""
    d = read(p)
    if d is None:
        return None
    fm = d.get("final_metrics") or {}
    rm = d.get("round_metrics") or []
    cfg = d.get("config") or {}
    crs = [r.get("avg_compression_ratio") for r in rm
           if isinstance(r, dict) and r.get("avg_compression_ratio")]
    return {
        "path": p,
        "mtime": os.path.getmtime(p),
        "auc": fm.get("auc_roc"),
        "f1m": fm.get("f1_macro"),
        "cr0": crs[0] if crs else None,
        "crmean": (sum(crs) / len(crs)) if crs else None,
        "crlast": crs[-1] if crs else None,
        "cf_emp": fm.get("compression_factor_empirical"),
        "eps": cfg.get("epsilon_total"),
        "T": cfg.get("T"),
        "rounds": len(rm),
        "cfg_keys": len(cfg),
    }


def ts(t):
    return datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M")


def find_tag(tag):
    """exact tag match -- '*_full' must NOT also pick up '..._w_full'"""
    out = []
    for p in glob.glob(os.path.join(HERE, ABL, "*", "results.json")):
        name = os.path.basename(os.path.dirname(p))
        m = re.match(r".+_alpha([\d.]+)_seed(\d+)_(.+)$", name)
        if not m or m.group(3) != tag:
            continue
        s = stats(p)
        if s:
            s["alpha"], s["seed"] = float(m.group(1)), int(m.group(2))
            out.append(s)
    return out


def find(pat):
    out = []
    for p in glob.glob(os.path.join(HERE, pat), recursive=True):
        s = stats(p)
        if s:
            out.append(s)
    return out


def m(a):
    v = [x for x in a if x is not None]
    return sum(v) / len(v) if v else float("nan")


# ---------------------------------------------------------------- 1 freshness
def sec_freshness(since):
    head("[1] freshness of results_ablation/  (the skip_existing trap)")
    print(f"  cutoff (--since): {ts(since)}\n")
    print(f"  {'tag':<22} {'n':>3} {'oldest file':>17} {'newest file':>17} {'stale':>6}")
    print("  " + "-" * 72)
    stale_total = 0
    for tag in COMPONENT:
        ps = find_tag(tag)
        if not ps:
            print(f"  {tag:<22} {0:>3} {'--':>17} {'--':>17}      --   <== NO FILES")
            continue
        mt = [s["mtime"] for s in ps]
        n_stale = sum(1 for t in mt if t < since)
        stale_total += n_stale
        flag = " <== STALE" if n_stale else ""
        print(f"  {tag:<22} {len(ps):>3} {ts(min(mt)):>17} {ts(max(mt)):>17} "
              f"{n_stale:>6}{flag}")
    print(f"\n  >>> {stale_total} file(s) predate the cutoff.")
    if stale_total:
        print("      skip_existing=True would have KEPT them, and our driver only")
        print("      checked that the file EXISTS.  Those rows must be deleted and")
        print("      re-run:")
        print("        rm -rf results_ablation/*_full      # <- the tag(s) flagged above")
        print("        SKIP_WAIT=1 SUITES=component bash run_rest_all.sh all")
    else:
        print("      every file was written after the cutoff -> they are fresh.")


# ---------------------------------------------------- 2 full vs the main run
def eps_sweep_stats(alpha, target_eps, tol=0.06):
    """{seed: stat} for the sweep point closest to target_eps (regex, not glob)."""
    cand = defaultdict(dict)
    for p in glob.glob(os.path.join(HERE, "results_eps", "*", "results.json")):
        nm = os.path.basename(os.path.dirname(p))
        m = re.match(r"epsweep_eps([\d.]+)_alpha([\d.]+)_seed(\d+)", nm)
        if not m:
            continue
        if abs(float(m.group(2)) - alpha) > 1e-9:
            continue
        s = stats(p)
        if s:
            cand[int(m.group(3))][float(m.group(1))] = s
    if not cand:
        return {}, []
    avail = sorted({e for v in cand.values() for e in v})
    near = [e for e in avail if abs(math.log(e / target_eps)) <= tol] or [avail[-1]]
    out = {}
    for sd, v in cand.items():
        e = min(near, key=lambda x: abs(math.log(x / target_eps)))
        out[sd] = v[e]
    return out, avail


def sec_full_vs_main():
    head("[2] does 'full' reproduce the main run?   'full' has an EMPTY override dict")
    a = [s for s in find_tag("full") if abs(s["alpha"] - 0.5) < 1e-9]
    if not a:
        print("  no results_ablation/*_full files found")
        return
    B, avail = eps_sweep_stats(0.5, 400.0)
    print(f"  (sweep eps available in results_eps: {[f'{e:g}' for e in avail]})")
    if not B:
        print("  no results_eps/epsweep_eps*_alpha0.5_seed* files found")
        return
    def key(s):
        mm = re.search(r"seed(\d+)", os.path.basename(os.path.dirname(s["path"])))
        return int(mm.group(1)) if mm else -1
    A = {key(s): s for s in a}
    print(f"\n  {'seed':>4} | {'full':>9} {'mtime':>16} | {'sweep':>9} {'eps':>6} "
          f"{'mtime':>16} | {'diff':>8}")
    print("  " + "-" * 80)
    diffs = []
    for sd in sorted(set(A) & set(B)):
        x, y = A[sd]["auc"], B[sd]["auc"]
        dv = (x - y) if (x is not None and y is not None) else float("nan")
        diffs.append(dv)
        print(f"  {sd:>4} | {x:>9.4f} {ts(A[sd]['mtime']):>16} | {y:>9.4f} "
              f"{B[sd].get('eps', 0) or 0:>6g} {ts(B[sd]['mtime']):>16} | {dv:>+8.4f}")
    af = [A[k]["auc"] for k in A]
    bf = [B[k]["auc"] for k in B]
    print(f"\n  mean full  = {m(af):.4f}  (sigma = {_sd(af):.4f})")
    print(f"  mean sweep = {m(bf):.4f}  (sigma = {_sd(bf):.4f})")
    print(f"  mean diff  = {m(diffs):+.4f}   (over {len(diffs)} paired seeds)")
    nbad = sum(1 for d in diffs if abs(d) > 0.01)
    print(f"  seeds differing by >0.01 AUC: {nbad}/{len(diffs)}")
    if nbad:
        print("\n  READ: same config, same seed, different AUC in two runs -> the")
        print("  simulator is NOT reproducible seed-for-seed.  That is a separate")
        print("  problem from the mtime issue; re-run the SAME config twice to")
        print("  confirm before quoting 5-seed means.")


def cfg_of(paths):
    """the most common config dict across these runs"""
    vals = defaultdict(list)
    for p in paths:
        d = read(p)
        if not d:
            continue
        for k, v in (d.get("config") or {}).items():
            vals[k].append(v)
    out = {}
    for k, v in vals.items():
        try:
            out[k] = Counter(map(str, v)).most_common(1)[0][0]
        except Exception:
            pass
    return out


# ------------------------------------------------- 3 ablation vs baseline tree
def cfg_diff(a_paths, b_paths, label_a, label_b, limit=26):
    ca, cb = cfg_of(a_paths), cfg_of(b_paths)
    keys = sorted(set(ca) | set(cb))
    both = [(k, ca[k], cb[k]) for k in keys if k in ca and k in cb
            and str(ca[k]) != str(cb[k])]
    only_a = [k for k in keys if k in ca and k not in cb]
    only_b = [k for k in keys if k in cb and k not in ca]
    print(f"\n    config recorded: {label_a} has {len(ca)} keys, "
          f"{label_b} has {len(cb)} keys")
    print(f"    keys present in BOTH but with DIFFERENT values: {len(both)}")
    for k, va, vb in both[:limit]:
        print(f"      {k:<26} {str(va)[:20]:>20} {str(vb)[:20]:>20}")
    print(f"    keys {label_b} does not record at all: {len(only_b)}")
    print(f"    keys {label_a} does not record at all: {len(only_a)}"
          + (f"  e.g. {', '.join(only_a[:8])}" if only_a else ""))
    if not both:
        print("    -> no shared key differs, so the gap is a CODE-PATH difference")
        print("       (or one side does not record enough config to tell).")


def sec_cross_tree():
    head("[3] ablation tree vs baseline tree for the SAME logical configuration")
    pairs = [("hierfed_uni_dp", "hierfed_dp", "uniform DP, no NSAC, no FIM"),
             ("hierfed_only", "hierfed", "no DP, no NSAC"),
             ("hierfed_nsac", None, "NSAC, no DP (no baseline counterpart)")]
    for abl_tag, base_m, what in pairs:
        a = [s for s in find_tag(abl_tag) if abs(s["alpha"] - 0.5) < 1e-9]
        if not a:
            print(f"\n  {abl_tag}: no files")
            continue
        print(f"\n  --- {what} ---")
        print(f"    ablation  {abl_tag:<20} AUC = {m([s['auc'] for s in a]):.4f} "
              f"(n={len(a)}, {ts(min(s['mtime'] for s in a))})")
        if base_m:
            b = find(os.path.join(HERE, "results_baseline", f"{base_m}_iotid20_alpha0.5_seed*",
                                  "results.json"))
            if b:
                print(f"    baseline  {base_m:<20} AUC = {m([s['auc'] for s in b]):.4f} "
                      f"(n={len(b)}, {ts(min(s['mtime'] for s in b))})")
                g = m([s['auc'] for s in a]) - m([s['auc'] for s in b])
                tagw = "  <<< INCONSISTENT" if abs(g) > 0.01 else "  (consistent)"
                print(f"    gap = {g:+.4f}{tagw}")
                cfg_diff([s["path"] for s in a], [s["path"] for s in b],
                         abl_tag, base_m)
            else:
                print(f"    baseline  {base_m:<20} NOT FOUND")


# ------------------------------------------------------------------ 4 G-1
def sec_cr():
    head("[4] G-1 compression factor: is it stable?")
    ps = find(os.path.join(CR, "**", "results.json"))
    if not ps:
        print("  no results_crsweep files")
        return
    print(f"  {len(ps)} run(s)\n")
    print(f"  {'tag':<26} {'seed':>4} | {'cr0':>7} {'cf0':>7} | {'cr_mean':>8} {'cf_mean':>8} | "
          f"{'AUC':>7}")
    print("  " + "-" * 78)
    buckets0 = defaultdict(list)
    bucketsm = defaultdict(list)
    for s in sorted(ps, key=lambda x: x["path"]):
        name = os.path.basename(os.path.dirname(s["path"]))
        seed = name.rsplit("seed", 1)[-1].split("_")[0]
        cf0 = 1.0 / s["cr0"] if s["cr0"] else float("nan")
        cfm = 1.0 / s["crmean"] if s["crmean"] else float("nan")
        buckets0[round(cf0, 2)].append(s["auc"])
        bucketsm[round(cfm, 2)].append(s["auc"])
        print(f"  {name:<26} {seed:>4} | {s['cr0'] or 0:>7.4f} {cf0:>7.2f} | "
              f"{s['crmean'] or 0:>8.4f} {cfm:>8.2f} | {s['auc']:>7.4f}")
    print("\n  binned by ROUND-0 (what run_cr_match.sh does):")
    for cf in sorted(buckets0):
        print(f"    CF={cf:6.2f}x  n={len(buckets0[cf])}  AUC={m(buckets0[cf]):.4f}")
    print("\n  binned by MEAN OVER ROUNDS (more stable):")
    for cf in sorted(bucketsm):
        print(f"    CF={cf:6.2f}x  n={len(bucketsm[cf])}  AUC={m(bucketsm[cf]):.4f}")
    print("\n  READ: if round-0 spreads the runs over many CF values with n=1,")
    print("  the anchor is noise.  Use the mean-over-rounds binning, or group by")
    print("  NSAC_CR_SCALE (which is deterministic) instead.")


ARM_KEYS = ["disable_nsac", "disable_dp", "disable_dpba_fim", "disable_hierfed",
            "alpha_s", "beta_s_coeff", "gamma_s", "delta_s", "clip_norm",
            "dp_clip_mode", "dp_noise_scale", "adaptive_clip_min",
            "adaptive_clip_max", "adaptive_k_down"]
LABELS = {
    "full": "HierFed + NSAC + DPBA-FIM (proposed)",
    "hierfed_only": "HierFed only (no NSAC, no DP)",
    "hierfed_nsac": "HierFed + NSAC (no DP)",
    "hierfed_dpba": "HierFed + DPBA-FIM (no NSAC)",
    "hierfed_uni_dp": "HierFed + UNIFORM DP C=1.0 (no NSAC, no FIM)",
    "hierfed_nsac_uni_dp": "HierFed + NSAC + UNIFORM DP C=1.0 (no FIM)",
}


def classify_arm(c):
    if str(c.get("disable_dp", "")).lower() in ("true", "1"):
        return "no DP", False
    def f(k):
        try:
            return float(c.get(k, 0) or 0)
        except Exception:
            return 0.0
    weight_sum = f("alpha_s") + f("beta_s_coeff") + f("gamma_s") + f("delta_s")
    clip_adapts = f("adaptive_clip_max") > f("adaptive_clip_min") > 0
    bound_adapts = weight_sum > 0 or clip_adapts
    if bound_adapts:
        why = []
        if weight_sum > 0:
            why.append(f"Eq.7 weights sum={weight_sum:.1f} (still per-device)")
        if clip_adapts:
            why.append(f"bound adapts in [{f('adaptive_clip_min'):g},"
                       f"{f('adaptive_clip_max'):g}]")
        return "ADAPTIVE per-device bound  (" + "; ".join(why) + ")", True
    return "uniform C=%.3g for every device" % f("clip_norm", 1.0), False


def sec_arm():
    head("[5] arm audit -- is each ablation arm really what its label claims?")
    lying = []
    for tag in COMPONENT:
        ps = find_tag(tag)
        if not ps:
            continue
        c = cfg_of([s["path"] for s in ps])
        verdict, adapts = classify_arm(c)
        print(f"\n  {tag}   label says: \"{LABELS.get(tag, '?')}\"")
        print(f"    actual clip policy : {verdict}")
        interesting = [k for k in ARM_KEYS if k in c]
        print("    config: " + ", ".join(f"{k}={c[k]}" for k in interesting))
        claims_uniform = "UNIFORM" in LABELS.get(tag, "").upper()
        if claims_uniform and adapts:
            lying.append((tag, verdict))
            print("    >>> MISLABELLED: the label says UNIFORM but the bound still adapts")
    print()
    if lying:
        print("  " + "=" * 74)
        print("  VERDICT: these arms are mislabelled --")
        for t, v in lying:
            print(f"      {t:<22} {v}")
        print("  -> they are NOT a uniform-DP control.  Their AUC (0.928 / 0.966) is")
        print("     therefore NOT comparable with a true C=1.0 baseline (0.850).")
        print("     Fix: add an arm that forces C_i = clip_norm for every device")
        print("     (weights 0,0,0,0 AND adaptive clipping off), then re-run.")
    else:
        print("  every arm's recorded config matches its label.")


def _sd(v):
    v = [x for x in v if x is not None]
    if len(v) < 2:
        return 0.0
    mu = sum(v) / len(v)
    return (sum((x - mu) ** 2 for x in v) / (len(v) - 1)) ** 0.5


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--since", default="2026-10-09 06:00",
                    help='flag files older than this "YYYY-MM-DD HH:MM"')
    a = ap.parse_args()
    try:
        since = time.mktime(datetime.strptime(a.since, "%Y-%m-%d %H:%M").timetuple())
    except Exception:
        since = 0.0
    print("=" * 78)
    print("  ablation / G-1 trustworthiness check")
    print("  " + HERE)
    print("=" * 78)
    for fn in (lambda: sec_freshness(since), sec_full_vs_main, sec_cross_tree,
               sec_cr, sec_arm):
        try:
            fn()
        except Exception as e:
            print(f"\n  !! section failed: {e}")
            import traceback
            traceback.print_exc()
    print("\n  done.  send me this whole output.\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
