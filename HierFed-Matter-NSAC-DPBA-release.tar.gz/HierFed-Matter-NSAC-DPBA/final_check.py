#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
final_check.py -- 一次性汇总 Phase 3 的判读数据（bw 与 k_ratio 两套放在一起看）

用法：
    python final_check.py results_alloc results_alloc_kr

输出：
  1) 每个 root 的 4 臂表（mean±std, n）
  2) 配对比较（A2-A1 / A3-A1 / A4-A1 / A4-A3）：均值差、配对 t p、Wilcoxon p、正号数
  3) 逐 seed 的 A3-A1 / A4-A1 差值表（看方向是否一致）

--- EN ---
final_check.py -- one-shot summary of the Phase 3 read-out data (bw and k_ratio looked at together)

Usage:
    python final_check.py results_alloc results_alloc_kr

Output:
  1) the 4-arm table for each root (mean±std, n)
  2) paired comparisons (A2-A1 / A3-A1 / A4-A1 / A4-A3): mean diff, paired-t p, Wilcoxon p, number of positives
  3) per-seed A3-A1 / A4-A1 difference table (to see whether the direction is consistent)
"""
import sys, os, re, json, glob
from collections import defaultdict
import numpy as np
try:
    from scipy import stats
    HAVE_SCIPY = True
except Exception:
    HAVE_SCIPY = False

ARMS = [
    ("A1", "cruniform_epsuniform"),
    ("A2", "crslice_epsuniform"),
    ("A3", "cruniform_epsslice"),
    ("A4", "crslice_epsslice"),
]
ARM_NAME = {"cruniform_epsuniform": "A1 均匀CR+均匀eps",
            "crslice_epsuniform":   "A2 切片CR+均匀eps",
            "cruniform_epsslice":   "A3 均匀CR+切片eps",
            "crslice_epsslice":     "A4 切片CR+切片eps"}
PAT = re.compile(r"proposed_(?P<ds>[a-z0-9]+)_alpha[\d.]+_seed(?P<seed>\d+)_(?P<arm>[a-z_]+)$")
DATASETS = ["gotham25", "iotid20"]


def load(root):
    """-> {ds: {arm: {seed: auc}}}"""
    data = defaultdict(lambda: defaultdict(dict))
    for p in glob.glob(os.path.join(root, "*", "*", "results.json")):
        d = os.path.basename(os.path.dirname(p))
        m = PAT.search(d)
        if not m:
            continue
        ds, seed, arm = m.group("ds"), int(m.group("seed")), m.group("arm")
        if arm not in ARM_NAME:
            continue
        try:
            j = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        fm = j.get("final_metrics") or {}
        v = fm.get("auc_roc")
        if v is None:
            continue
        data[ds][arm][seed] = float(v)
    return data


def paired(a1, a2, seeds):
    """a1, a2: {seed: val}; return (diffs, t_p, w_p, n_pos, n)"""
    common = [s for s in seeds if s in a1 and s in a2]
    if len(common) < 3:
        return None
    x = np.array([a2[s] for s in common])
    y = np.array([a1[s] for s in common])
    d = x - y
    tp = wp = float("nan")
    if HAVE_SCIPY:
        tp = stats.ttest_rel(x, y).pvalue
        try:
            wp = stats.wilcoxon(d).pvalue
        except Exception:
            wp = float("nan")
    return dict(seeds=common, diffs=d, tp=tp, wp=wp,
                n_pos=int((d > 0).sum()), n=int(len(d)))


def report(root):
    print("#" * 78)
    print(f"#  {root}")
    print("#" * 78)
    if not os.path.isdir(root):
        print("  (目录不存在)")
        return
    data = load(root)
    if not data:
        print("  (未解析到结果)")
        return
    # 该 root 可用的 seed 全集
    # EN: the full set of seeds available under this root
    all_seeds = sorted({s for ds in data for arm in data[ds] for s in data[ds][arm]})

    for ds in DATASETS:
        if ds not in data or not data[ds]:
            continue
        print(f"\n=== {ds}  (seeds={all_seeds}) ===")
        hdr = f"  {'臂':<24}{'mean±std':>20}{'n':>4}"
        print(hdr)
        for tag, arm in ARMS:
            vals = data[ds].get(arm, {})
            arr = [vals[s] for s in all_seeds if s in vals]
            if not arr:
                print(f"  {ARM_NAME[arm]:<24}{'--':>20}{0:>4}")
                continue
            m = np.mean(arr)
            sd = np.std(arr, ddof=1) if len(arr) > 1 else 0.0
            print(f"  {ARM_NAME[arm]:<24}{f'{m:.4f}±{sd:.4f}':>20}{len(arr):>4}")

        print(f"\n  -- 配对比较（正=后者>前者）--")
        pairs = [("A2-A1", "cruniform_epsuniform", "crslice_epsuniform"),
                 ("A3-A1", "cruniform_epsuniform", "cruniform_epsslice"),
                 ("A4-A1", "cruniform_epsuniform", "crslice_epsslice"),
                 ("A4-A3", "cruniform_epsslice", "crslice_epsslice")]
        for label, b, a in pairs:
            r = paired(data[ds].get(b, {}), data[ds].get(a, {}), all_seeds)
            if r is None:
                print(f"    {label:<8} --")
                continue
            flag = ""
            if r["wp"] == r["wp"] and r["wp"] < 0.05:
                flag = "  *W"
            if r["tp"] == r["tp"] and r["tp"] < 0.05:
                flag += "  *t"
            print(f"    {label:<8} Δ={r['diffs'].mean():+.4f}  "
                  f"t_p={r['tp']:.4f}  W_p={r['wp']:.4f}  "
                  f"正={r['n_pos']}/{r['n']}{flag}")

        # 逐 seed 表
        # EN: per-seed table
        print(f"\n  -- 逐 seed 差值 --")
        base = data[ds].get("cruniform_epsuniform", {})
        for label, arm in [("A3-A1", "cruniform_epsslice"), ("A4-A1", "crslice_epsslice")]:
            av = data[ds].get(arm, {})
            cells = []
            for s in all_seeds:
                if s in base and s in av:
                    cells.append(f"s{s}:{av[s]-base[s]:+.4f}")
                else:
                    cells.append(f"s{s}:--")
            print(f"    {label:<8} " + "  ".join(cells))
    print()


if __name__ == "__main__":
    roots = sys.argv[1:] or ["results_alloc", "results_alloc_kr"]
    if not HAVE_SCIPY:
        print("[warn] scipy 不可用，只出均值表\n")
    for r in roots:
        report(r)
    print("  记号：*W = Wilcoxon 双侧 p<0.05 ；*t = 配对 t 双侧 p<0.05")
    print("  注：n=8 时 Wilcoxon 双侧最小可达 p≈0.0078")

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
