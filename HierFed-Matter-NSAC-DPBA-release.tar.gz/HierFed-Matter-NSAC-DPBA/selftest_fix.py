#!/usr/bin/env python3
"""
selftest_fix.py -- verify the B1..B4 fixes WITHOUT needing torch/GPU.

Run from the project root:
    python selftest_fix.py

Checks
  1. NSAC round-trip gain ||rec||/||g|| is back to ~1 (was ~0.0097)
  2. RDP noise scale: sigma(eps=3,T=50,q=1)=12.006 -> sigma(q=M/N=0.2)=2.401
  3. no source file still carries the `except ValueError: auc = 0.0` sentinel
  4. core/simulator.py passes the subsampling rate to the accountant
  5. aggregate_supp.py pools the baseline table by primary tag
Exit code 0 iff everything passes.
"""
import os
import re
import sys
import math

import numpy as np

OK = "\u2705 PASS"
NG = "\u274c FAIL"
fails = []


def check(name, cond, detail=""):
    print(f"  {OK if cond else NG}  {name}" + (f"   {detail}" if detail else ""))
    if not cond:
        fails.append(name)


def source(rel):
    if not os.path.isfile(rel):
        return None
    with open(rel, "r", encoding="utf-8") as f:
        return f.read()


# ---------------------------------------------------------------- 1. NSAC gain
def nsac_gain(mode, d=7826, k_ratio=0.1, b=8, n=5):
    L = 2 ** (b - 1) - 1
    k = int(k_ratio * d)
    ratios = []
    for s in range(n):
        rng = np.random.default_rng(s)
        g = rng.standard_normal(d)
        idx = np.argsort(-np.abs(g))[:k]
        sp = g[idx]
        norm = np.linalg.norm(sp)
        scaled = sp * L / norm
        if mode == "buggy":
            q = np.sign(scaled) * np.floor(np.abs(scaled)) / L * (norm / L)
        else:
            q = np.sign(scaled) * np.floor(np.abs(scaled)) * norm / L
        rec = np.zeros(d)
        rec[idx] = q * (norm / np.sqrt(k))
        ratios.append(np.linalg.norm(rec) / np.linalg.norm(g))
    return float(np.mean(ratios))


print("[1] NSAC compress->decompress round-trip gain")
g_bug = nsac_gain("buggy")
g_new = nsac_gain("fixed")
check("old formula reproduces the ~104x attenuation", g_bug < 0.02,
      f"gain={g_bug:.4f} (expect ~0.0097)")
check("patched formula gains ~1.0", 0.5 <= g_new <= 2.0,
      f"gain={g_new:.4f} (expect ~1.23)")
src_nsac = source("core/nsac.py")
check("core/nsac.py no longer contains the double-division line",
      src_nsac is not None and "q_values = quantized * norm / levels" not in src_nsac)
check("core/nsac.py carries the corrected quantiser",
      src_nsac is not None
      and "q_values = torch.sign(scaled) * torch.floor(scaled.abs()) * norm / levels"
      in src_nsac)

# ---------------------------------------------------------------- 2. sigma
def sigma_rdp(eps_total, T, delta=1e-5, C=1.0, q=1.0):
    def eps_from(sig):
        if sig <= 0:
            return float("inf")
        best = float("inf")
        for a in range(2, 512):
            best = min(best, T * q ** 2 * a / (2 * sig ** 2)
                       + math.log(1.0 / delta) / (a - 1))
        return best
    lo, hi = 0.01, 500.0
    if eps_from(lo) < eps_total:
        return lo * C
    if eps_from(hi) > eps_total:
        hi = 5000.0
    mid = lo
    for _ in range(200):
        mid = (lo + hi) / 2.0
        if eps_from(mid) > eps_total:
            lo = mid
        else:
            hi = mid
    return mid * C


print("\n[2] RDP noise scale (re-implementation of compute_noise_scale_rdp)")
s_q1 = sigma_rdp(3.0, 50, q=1.0)
s_q02 = sigma_rdp(3.0, 50, q=0.2)
check("sigma(eps=3, T=50, q=1.0) == 12.006", abs(s_q1 - 12.006) < 0.01,
      f"sigma={s_q1:.4f}")
check("sigma(eps=3, T=50, q=0.2) == 2.401", abs(s_q02 - 2.401) < 0.01,
      f"sigma={s_q02:.4f}  ({s_q1 / s_q02:.1f}x smaller)")
check("noise norm >> update norm when q=1 (why eps<=2 diverged)",
      s_q1 * math.sqrt(7826) > 1e3,
      f"||noise|| ~ {s_q1 * math.sqrt(7826):.0f} vs ||dw|| ~ 1")

src_sim = source("core/simulator.py")
check("core/simulator.py passes subsampling_rate to the accountant",
      src_sim is not None and "subsampling_rate=self.dp_subsampling_rate" in src_sim)
check("core/simulator.py has the non-finite divergence guard",
      src_sim is not None and "torch.isfinite(new_params).all()" in src_sim)
check("core/simulator.py has the per-round DP-DEBUG print",
      src_sim is not None and "[DP-DEBUG]" in src_sim)

# ---------------------------------------------------------------- 3. sentinels
print("\n[3] the 'except ValueError: auc = 0.0' sentinel must be gone")
sentinel_files = ["core/simulator.py", "baselines/runner.py", "evaluate.py",
                  "run_focal_loss.py", "run_centralized.py"]
bad_pat = re.compile(r"except ValueError:\s*\n\s*auc\w*\s*=\s*0\.0")
for rel in sentinel_files:
    s = source(rel)
    if s is None:
        check(f"{rel}: present", False, "file missing")
        continue
    hits = bad_pat.findall(s)
    check(f"{rel}: sentinel removed", not hits,
          f"({len(hits)} leftover)" if hits else "")

# ---------------------------------------------------------------- 4. pooling
print("\n[4] aggregate_supp.py baseline table pooling")
s_agg = source("aggregate_supp.py")
check("pools by primary tag (and t == keep)",
      s_agg is not None and "and t == keep" in s_agg)
check("NaN-safe _clean() helper present", s_agg is not None and "def _clean(" in s_agg)
check("data-quality banner present",
      s_agg is not None and "non-finite (diverged) AUC" in s_agg)

# ---------------------------------------------------------------- 5. config
print("\n[5] configs/base.yaml")
s_cfg = source("configs/base.yaml")
check("dp_subsampling_rate present",
      s_cfg is not None and "dp_subsampling_rate" in s_cfg)

# ---------------------------------------------------------------- summary
print("\n" + "=" * 60)
if fails:
    print(f"{NG} {len(fails)} check(s) failed:")
    for f in fails:
        print("   -", f)
    sys.exit(1)
print(f"{OK}  ALL CHECKS PASSED -- patch applied correctly, safe to run.")
sys.exit(0)

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
