#!/usr/bin/env bash
# =============================================================================
# run_noise_sweep.sh -- find the DP noise scale that keeps `full` trainable.
#
#   bash run_noise_sweep.sh            # launch 4 runs in parallel (~20-25 min)
#   bash run_noise_sweep.sh --wait     # ...and print a summary when done
#
# Runs `full` (NSAC + DP, proposed) at 4 values of dp_noise_scale.
# 1.0 = the current behaviour (known broken); 0.01 = the theoretically
# correct DP-FL equivalent (noise added before the learning rate).
# =============================================================================
set -u

PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}
SCALES=${SCALES:-"1.0 0.1 0.01 0.001"}

cd "$PROJ" || { echo "ERROR: project not found: $PROJ"; exit 1; }
mkdir -p logs configs results_noise_sweep

for s in $SCALES; do
  cfg="configs/sweep_scale_${s}.yaml"
  cp configs/base.yaml "$cfg"
  # force the knob to exactly this value (replace if present, else append)
  if grep -q "^dp_noise_scale:" "$cfg"; then
    sed -i "s|^dp_noise_scale:.*|dp_noise_scale: ${s}|" "$cfg"
  else
    echo "dp_noise_scale: ${s}" >> "$cfg"
  fi
  grep "^dp_noise_scale:" "$cfg" | sed "s/^/  [cfg] /"
  echo "[sweep] launch dp_noise_scale=$s"
  nohup $PY -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
        --output_dir results_noise_sweep --tag "ns${s}" --config "$cfg" \
        > "logs/sweep_ns${s}.log" 2>&1 &
done

cat <<'EOF'

[sweep] 4 runs launched (T=50, ~20-25 min, 4-way parallel).
  轨迹: grep -E "DP-DEBUG|WARN" logs/sweep_ns0.01.log | head -12
  结果: grep -h "Final:" logs/sweep_ns*.log
EOF

if [ "${1:-}" = "--wait" ]; then
  wait
  echo
  echo "======================= NOISE SWEEP SUMMARY ======================="
  for s in $SCALES; do
    printf "  dp_noise_scale=%-6s  " "$s"
    grep -h "Final:" "logs/sweep_ns${s}.log" 2>/dev/null | tail -1 || echo "(no output)"
  done
  echo
  echo "  --- ||dw|| / ||noise|| at round 2 (before any explosion) ---"
  for s in $SCALES; do
    printf "  scale=%-6s  " "$s"
    grep -h "DP-DEBUG" "logs/sweep_ns${s}.log" 2>/dev/null | sed -n '2p'
  done
  echo "=================================================================="
  echo "Pick the largest scale whose AUC is clearly > 0.85 (keep it maximal:"
  echo "noise is what buys the privacy guarantee)."
fi

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
