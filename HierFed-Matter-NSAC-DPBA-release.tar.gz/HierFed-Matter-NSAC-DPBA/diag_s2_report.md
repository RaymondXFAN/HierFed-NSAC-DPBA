==============================================================================
  HierFed post-S2 diagnostics
==============================================================================

==============================================================================
  1. why did topk_qsgd alpha=0.1 fail?  (logs/jobs/)
==============================================================================
  found 10 child logs for 'topk_qsgd'

  --- topk_qsgd_iotid20_alpha0.1_seed1.log  (1167 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7609 bytes=176928
      [Top-k+QSGD] Round 30: F1=0.8044 bytes=176928
      [Top-k+QSGD] Round 40: F1=0.8407 bytes=176928
      [Top-k+QSGD] Round 50: F1=0.8417 bytes=176928
      [Top-k+QSGD] done: bytes=8846400 full=31048000 CF=3.51x  empty=50  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.1_seed1 Summary (elapsed=1115s):
         AUC = 0.9771  |  macro-F1 = 0.9157  |  F1 = 0.8417  |  thresh = 0.90

  --- topk_qsgd_iotid20_alpha0.1_seed2.log  (1167 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7436 bytes=176928
      [Top-k+QSGD] Round 30: F1=0.7938 bytes=176928
      [Top-k+QSGD] Round 40: F1=0.8120 bytes=176928
      [Top-k+QSGD] Round 50: F1=0.8339 bytes=176928
      [Top-k+QSGD] done: bytes=8846400 full=31048000 CF=3.51x  empty=50  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.1_seed2 Summary (elapsed=1104s):
         AUC = 0.9778  |  macro-F1 = 0.9115  |  F1 = 0.8339  |  thresh = 0.90

  --- topk_qsgd_iotid20_alpha0.1_seed3.log  (1167 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7527 bytes=176928
      [Top-k+QSGD] Round 30: F1=0.7982 bytes=176928
      [Top-k+QSGD] Round 40: F1=0.8392 bytes=176928
      [Top-k+QSGD] Round 50: F1=0.8505 bytes=176928
      [Top-k+QSGD] done: bytes=8846400 full=31048000 CF=3.51x  empty=50  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.1_seed3 Summary (elapsed=1108s):
         AUC = 0.9803  |  macro-F1 = 0.9205  |  F1 = 0.8505  |  thresh = 0.90

  --- topk_qsgd_iotid20_alpha0.1_seed4.log  (1167 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7515 bytes=176928
      [Top-k+QSGD] Round 30: F1=0.7975 bytes=176928
      [Top-k+QSGD] Round 40: F1=0.8333 bytes=176928
      [Top-k+QSGD] Round 50: F1=0.8388 bytes=176928
      [Top-k+QSGD] done: bytes=8846400 full=31048000 CF=3.51x  empty=50  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.1_seed4 Summary (elapsed=1108s):
         AUC = 0.9792  |  macro-F1 = 0.9143  |  F1 = 0.8388  |  thresh = 0.90

  --- topk_qsgd_iotid20_alpha0.1_seed5.log  (1167 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7429 bytes=176928
      [Top-k+QSGD] Round 30: F1=0.7943 bytes=176928
      [Top-k+QSGD] Round 40: F1=0.8142 bytes=176928
      [Top-k+QSGD] Round 50: F1=0.8415 bytes=176928
      [Top-k+QSGD] done: bytes=8846400 full=31048000 CF=3.51x  empty=50  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.1_seed5 Summary (elapsed=1127s):
         AUC = 0.9777  |  macro-F1 = 0.9156  |  F1 = 0.8415  |  thresh = 0.90

  --- topk_qsgd_iotid20_alpha0.5_seed1.log  (1166 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7721 bytes=186240
      [Top-k+QSGD] Round 30: F1=0.8109 bytes=186240
      [Top-k+QSGD] Round 40: F1=0.8310 bytes=186240
      [Top-k+QSGD] Round 50: F1=0.8425 bytes=186240
      [Top-k+QSGD] done: bytes=9312000 full=31048000 CF=3.33x  empty=0  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.5_seed1 Summary (elapsed=1114s):
         AUC = 0.9809  |  macro-F1 = 0.9164  |  F1 = 0.8425  |  thresh = 0.65

  --- topk_qsgd_iotid20_alpha0.5_seed2.log  (1166 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7535 bytes=186240
      [Top-k+QSGD] Round 30: F1=0.7950 bytes=186240
      [Top-k+QSGD] Round 40: F1=0.8218 bytes=186240
      [Top-k+QSGD] Round 50: F1=0.8424 bytes=186240
      [Top-k+QSGD] done: bytes=9312000 full=31048000 CF=3.33x  empty=0  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.5_seed2 Summary (elapsed=1149s):
         AUC = 0.9793  |  macro-F1 = 0.9163  |  F1 = 0.8424  |  thresh = 0.60

  --- topk_qsgd_iotid20_alpha0.5_seed3.log  (1166 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7706 bytes=186240
      [Top-k+QSGD] Round 30: F1=0.8067 bytes=186240
      [Top-k+QSGD] Round 40: F1=0.8300 bytes=186240
      [Top-k+QSGD] Round 50: F1=0.8463 bytes=186240
      [Top-k+QSGD] done: bytes=9312000 full=31048000 CF=3.33x  empty=0  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.5_seed3 Summary (elapsed=1116s):
         AUC = 0.9816  |  macro-F1 = 0.9182  |  F1 = 0.8463  |  thresh = 0.55

  --- topk_qsgd_iotid20_alpha0.5_seed4.log  (1166 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7606 bytes=186240
      [Top-k+QSGD] Round 30: F1=0.7919 bytes=186240
      [Top-k+QSGD] Round 40: F1=0.8271 bytes=186240
      [Top-k+QSGD] Round 50: F1=0.8384 bytes=186240
      [Top-k+QSGD] done: bytes=9312000 full=31048000 CF=3.33x  empty=0  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.5_seed4 Summary (elapsed=1108s):
         AUC = 0.9816  |  macro-F1 = 0.9140  |  F1 = 0.8384  |  thresh = 0.55

  --- topk_qsgd_iotid20_alpha0.5_seed5.log  (1166 B) ---
    (no error keyword; raw tail below)
      [Top-k+QSGD] Round 20: F1=0.7546 bytes=186240
      [Top-k+QSGD] Round 30: F1=0.7925 bytes=186240
      [Top-k+QSGD] Round 40: F1=0.8186 bytes=186240
      [Top-k+QSGD] Round 50: F1=0.8428 bytes=186240
      [Top-k+QSGD] done: bytes=9312000 full=31048000 CF=3.33x  empty=0  nonfinite=0
      
      📊 topk_qsgd_iotid20_alpha0.5_seed5 Summary (elapsed=1121s):
         AUC = 0.9795  |  macro-F1 = 0.9164  |  F1 = 0.8428  |  thresh = 0.60

==============================================================================
  2. what compression budget does topk_qsgd use?  (fairness check)
==============================================================================
  results_baseline/topk_qsgd_iotid20_alpha0.1_seed1/results.json
    config         : {"method": "topk_qsgd", "alpha": 0.1, "seed": 1, "oversample": false, "T": 50, "N": 20}
    final_metrics compression-ish : {'comm_bytes_total': 8846400, 'comm_bytes_full_fp32': 31048000, 'compression_ratio_empirical': 0.284926565318217, 'compression_factor_empirical': 3.509676252486887, 'cr_actual_last_round': 0.2999227003349652, 'k_ratio_nominal': 0.3, 'b_bits_nominal': 16, 'slice_used': 'eMBB', 'n_devices': 20, 'n_empty_device_rounds': 50}
    round_metrics keys: ['accuracy', 'accuracy_default', 'auc_roc', 'bytes_full_round', 'bytes_round', 'cr_round', 'f1', 'f1_default', 'f1_macro', 'optimal_threshold', 'round']

  --- run_topk_qsgd source (first 40 lines) ---
    def run_topk_qsgd(config: dict) -> Dict:
        """Top-k + QSGD: star-topology FL with uniform Top-k compression.
    
        [fix_v10]
          (a) every per-device update is moved to DEVICE before aggregation --
              nsac_decompress() returns a CPU tensor, which used to clash with the
              GPU zero-fill for empty partitions under extreme Dirichlet alpha;
          (b) empty / non-finite partitions are counted, never silently dropped;
          (c) the realised compression budget is recorded so that NSAC and this
              baseline can be compared at a matched compression ratio.
        """
        X_train, y_train, partitions = _load_partitioned_data(config)
        X_test, y_test = _load_test_data(config)
        input_dim = X_train.shape[1]
        model = build_model(input_dim).to(DEVICE)
        d = model.num_parameters
        N = config.get('N', 50)
        T = config.get('T', 100)
        eta = config.get('eta', 0.01)
    
        # Uniform compression: eMBB slice config (moderate budget)
        slice_config = SLICE_CONFIGS['embb']
        slice_name = getattr(slice_config, 'name', 'eMBB')
    
        bytes_full_round = N * d * 4      # fp32, all N devices, one round
        bytes_sent = 0
        n_empty = 0
        n_nonfinite = 0
        cr_last = float('nan')
    
        round_metrics = []
        for t in range(1, T + 1):
            bytes_round = 0
            device_gradients = {}
            for dev_id in range(N):
                idx_list = partitions.get(str(dev_id), [])
                if len(idx_list) == 0:
                    # no local data -> contributes a zero update (kept, not dropped)
                    device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                    n_empty += 1

==============================================================================
  3. epsilon curve SPLIT BY ALPHA
==============================================================================
  eps   |           0.1           0.5   |  pooled
  -----------------------------------------------
  20    |  0.5061(n=5)  0.5492(n=5)   |  0.5277
  50    |  0.6257(n=5)  0.6365(n=5)   |  0.6311
  100   |  0.8190(n=5)  0.9358(n=5)   |  0.8774
  200   |  0.9308(n=5)  0.9705(n=5)   |  0.9506
  400   |  0.9569(n=5)  0.9735(n=5)   |  0.9652
  800   |  0.9648(n=5)  0.9743(n=5)   |  0.9695
  1600  |  0.9705(n=5)  0.9747(n=5)   |  0.9726
  alpha=0.1: peak AUC 0.9705 at eps=1600
  alpha=0.5: peak AUC 0.9747 at eps=1600

==============================================================================
  4. baseline table SPLIT BY ALPHA
==============================================================================
  method                |             0.1             0.5
  ------------------------------------------------------------------
  hierfed               |  0.9788(n=5)  0.9809(n=5)
  fedavg                |  0.9788(n=5)  0.9809(n=5)
  topk_qsgd             |  0.9784(n=5)  0.9806(n=5)
  fedprox               |  0.9764(n=5)  0.9805(n=5)
  adaptive_clip_dp      |  0.9649(n=5)  0.9805(n=5)
  layer_adaptive_dp     |  0.9419(n=5)  0.9632(n=5)
  dpfed6g               |  0.9382(n=5)  0.9668(n=5)
  hierfed_dp            |  0.8624(n=5)  0.8501(n=5)
  dpfedavg              |  0.8623(n=5)  0.8497(n=5)
  safeliot              |  0.8604(n=5)  0.8579(n=5)
  fedprox_dp            |  0.8603(n=5)  0.8485(n=5)

  --- results_ablation dir names (first 15, for naming check) ---
    ... (0 total)

==============================================================================
  -> upload this whole output to Mihiro
==============================================================================
