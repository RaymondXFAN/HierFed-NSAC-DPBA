#!/usr/bin/env bash
# run_cr_match.sh -- G-1: the MATCHED-COMPRESSION control (fairness anchor).
#
# WHY (this is not optional)
#   After [fix_v11], topk_qsgd reaches AUC 0.9806 at CF 3.33x per message with
#   NO DP.  Our method reports CF 5.33x (CR_SCALE=1.0) at AUC 0.9735 with DP.
#   Those are DIFFERENT compression rates, so a reviewer can say "you merely
#   compress harder".  This script runs our method at the SAME per-message
#   compression as topk_qsgd, so the comparison becomes apples-to-apples.
#
#   CR_SCALE multiplies every slice's k_ratio, so CF ~ 1/k_ratio:
#     scale 1.0 -> CF 5.33x   (our headline, already in results_eps)
#     scale 1.6 -> CF 3.33x   <-- matches topk_qsgd exactly
#     scale 2.5 -> CF 2.13x   (looser than topk, for the trend line)
#
# Usage
#   bash run_cr_match.sh                 # gate, then launch (20 jobs, ~2.3 h)
#   CR_SCALES="1.6" SEEDS="1 2 3" bash run_cr_match.sh
#
# Requires: fix_v9 (NSAC_CR_SCALE), fix_v11, fix_v12 already applied.
set -u
cd "$(dirname "$0")" || exit 1

PY=${PY:-python}
PAR=${PAR:-4}
CR_SCALES=${CR_SCALES:-"1.6 2.5"}
ALPHAS=${ALPHAS:-"0.5 0.1"}
SEEDS=${SEEDS:-"1 2 3 4 5"}
OUT=${OUT:-results_crsweep}
TAGP=${TAGP:-crmatch}
LOG_DIR=logs/crmatch
mkdir -p "$LOG_DIR" "$OUT"

bar() { printf '%s\n' "-------------------------------------------------------------------------------"; }

bar
echo "[crmatch] preflight"
[ -f run_experiment.py ] || { echo "  !! run_experiment.py not found -- wrong dir"; exit 1; }
grep -q "NSAC_CR_SCALE" core/nsac.py || {
  echo "  !! core/nsac.py has no NSAC_CR_SCALE -- run fix_v9.py first"; exit 1; }
grep -q "fix_v11" core/nsac.py || {
  echo "  !! [fix_v11] not applied -- run python fix_v11.py --apply"; exit 1; }
echo "  [ok] fix_v9 (CR_SCALE) + fix_v11 (scale) present"

N=$(( $(echo $CR_SCALES | wc -w) * $(echo $ALPHAS | wc -w) * $(echo $SEEDS | wc -w) ))
echo "  plan: $N jobs  CR_SCALES=$CR_SCALES  alphas=$ALPHAS  seeds=$SEEDS  par=$PAR"
echo "        out=$OUT   est ~$(( N * 20 / PAR / 60 ))h"

# ------------------------------------------------------------------ gate
bar
echo "[crmatch] GATE: one T=2 run at CR_SCALE=1.6 -- must land near CF 3.33x"
GLOG="$LOG_DIR/gate.log"
NSAC_CR_SCALE=1.6 timeout 900 $PY -u run_experiment.py --dataset iotid20 \
    --alpha 0.5 --seed 1 --method proposed --tag "${TAGP}gate" --T 2 \
    --output_dir "$OUT/_gate" > "$GLOG" 2>&1
GJSON=$(ls "$OUT"/_gate/*/results.json 2>/dev/null | head -1)
if [ -z "$GJSON" ]; then
  echo "  !! GATE FAILED -- no results.json written"; tail -n 12 "$GLOG" | sed 's/^/     /'
  echo "  !! the sweep was NOT started."; exit 1
fi
$PY - "$GJSON" <<'PYEOF'
import json, sys
d = json.load(open(sys.argv[1]))
rm = d.get("round_metrics") or [{}]
cr = rm[0].get("avg_compression_ratio")
print(f"  [gate] avg_compression_ratio = {cr}")
if cr is None:
    print("  !! GATE FAILED -- no avg_compression_ratio recorded"); sys.exit(1)
cf = 1.0 / cr
ok = 2.8 <= cf <= 4.0
print(f"  [gate] CF = {cf:.2f}x   (target ~3.33x to match topk_qsgd)  "
      f"-> {'OK' if ok else 'OUT OF RANGE'}")
sys.exit(0 if ok else 1)
PYEOF
if [ $? -ne 0 ]; then
  echo "  !! GATE FAILED -- CR_SCALE=1.6 does not land near CF 3.33x."
  echo "     Try CR_SCALES=1.5 or 1.7 and send me the gate output."
  exit 1
fi
echo "  [ok] GATE PASSED -- the matched-compression point is reachable"
rm -rf "$OUT/_gate"

# ------------------------------------------------------------------ launch
bar
echo "[crmatch] launching $N jobs (throttled to $PAR) ..."
throttle() { while [ "$(jobs -rp | wc -l)" -ge "$PAR" ]; do sleep 10; done; }
for cs in $CR_SCALES; do
  for a in $ALPHAS; do
    for s in $SEEDS; do
      throttle
      tag="cr${cs}_a${a}_s${s}"
      NSAC_CR_SCALE="$cs" nohup $PY -u run_experiment.py --dataset iotid20 \
          --alpha "$a" --seed "$s" --method proposed \
          --tag "${TAGP}${cs}" --output_dir "$OUT" \
          > "$LOG_DIR/$tag.log" 2>&1 &
    done
  done
done
echo "  launched; waiting ..."
wait
echo "  [crmatch] all $N jobs finished"

# ------------------------------------------------------------------ report
bar
echo "[crmatch] the matched-compression comparison"
$PY - "$OUT" "$CR_SCALES" <<'PYEOF'
import glob, json, os, re, sys
from collections import defaultdict
root, scales = sys.argv[1], sys.argv[2].split()

def scan(pat):
    tab = defaultdict(lambda: defaultdict(list))
    for p in glob.glob(pat):
        try:
            d = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        cfg, rm, fm = d.get("config") or {}, d.get("round_metrics") or [], d.get("final_metrics") or {}
        if not rm or fm.get("auc_roc") is None:
            continue
        cr = rm[0].get("avg_compression_ratio")
        if cr is None:
            continue
        tab[round(1.0 / cr, 2)][cfg.get("alpha")].append(fm["auc_roc"])
    return tab

ours = scan(os.path.join(root, "**", "results.json"))
print("  --- proposed at matched compression (alpha split) ---")
for cf in sorted(ours):
    for a in sorted(ours[cf], key=str):
        v = ours[cf][a]
        print(f"    CF={cf:5.2f}x  alpha={a}  n={len(v)}  AUC={sum(v)/len(v):.4f}")
print("\n  --- reference: topk_qsgd (NO DP) ---")
ref = defaultdict(list)
for p in glob.glob("results_baseline/topk_qsgd_iotid20_alpha0.5_seed*/results.json"):
    d = json.load(open(p, encoding="utf-8"))
    fm, cfg = d.get("final_metrics") or {}, d.get("config") or {}
    if fm.get("compression_factor_empirical"):
        ref["all"].append(fm["auc_roc"])
print(f"    CF~3.33x (all seeds)  AUC={sum(ref['all'])/len(ref['all']):.4f}  "
      f"n={len(ref['all'])}")
print("\n  READ: pick the ours-row whose CF is closest to 3.33x and compare with")
print("  the topk_qsgd row.  The gap is the honest cost of adding DP at the SAME")
print("  per-message compression rate.")
PYEOF
cat <<'EOF'

  next: send me this output -- it becomes the fairness anchor of the main table.
EOF
exit 0

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
