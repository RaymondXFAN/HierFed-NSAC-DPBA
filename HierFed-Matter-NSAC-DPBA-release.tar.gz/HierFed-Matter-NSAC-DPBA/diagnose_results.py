"""
diagnose_results.py -- 看结果 + 抓异常（HierFed 补实验）

回答三件事：
  1) 每个方法/配置，5 个 seed 的 AUC / macro-F1 / accuracy 明细
  2) 哪些行是"崩溃"（AUC 恰好 = 0.000 且 std = 0）—— 这是 evaluate.py
     里 `except ValueError: auc_roc = 0.0` 的哨兵值，不是真实 AUC
  3) 日志里有没有 NaN / Traceback / ValueError

用法：
    python diagnose_results.py
    python diagnose_results.py --roots results_ablation results_baseline

--- EN ---
diagnose_results.py -- inspect results + catch anomalies (HierFed supplementary experiments)

Answers three things:
  1) For each method/config, the AUC / macro-F1 / accuracy detail across the 5 seeds
  2) Which rows are "collapsed" (AUC exactly = 0.000 and std = 0) -- this is the
     sentinel value of `except ValueError: auc_roc = 0.0` in evaluate.py, not a real AUC
  3) Whether the logs contain any NaN / Traceback / ValueError

Usage:
    python diagnose_results.py
    python diagnose_results.py --roots results_ablation results_baseline
"""
import os
import re
import json
import glob
import argparse
from collections import defaultdict

MAIN_RE = re.compile(
    r"(?P<method>.+?)_(?P<dataset>iotid20|cicids2017)_alpha(?P<alpha>[\d.]+)"
    r"_seed(?P<seed>\d+)(?:_(?P<tag>.+))?$")


def load(p):
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--roots", nargs="+", default=[
        "results_ablation", "results_baseline", "results_eps",
        "results_scale", "results"])
    args = ap.parse_args()

    groups = defaultdict(list)   # (method, alpha, tag) -> [(seed, fm)]
    first_keys = None
    allfiles = []

    for root in args.roots:
        if not os.path.isdir(root):
            continue
        for p in sorted(glob.glob(os.path.join(root, "*", "results.json"))):
            allfiles.append(p)
            r = load(p)
            if not r or "final_metrics" not in r:
                continue
            if first_keys is None:
                first_keys = list(r.keys())
            fm = r["final_metrics"]
            name = os.path.basename(os.path.dirname(p))
            m = MAIN_RE.match(name)
            if m:
                key = (m.group("method"), float(m.group("alpha")), m.group("tag") or "")
                groups[key].append((int(m.group("seed")), fm))
            else:
                groups[(name, 0.0, "_other")].append((0, fm))

    print(f"总 results.json 文件数: {len(allfiles)}")
    print(f"results.json 顶层键样例: {first_keys}\n")

    # ---------------- 分组明细 ----------------
    # EN: ---------------- group breakdown ----------------
    zero_rows, collapse_rows = [], []
    print("=" * 78)
    print("分组明细  (method / alpha / tag -> 每 seed AUC)")
    print("=" * 78)
    for key in sorted(groups, key=lambda k: (k[0], k[1], k[2])):
        method, alpha, tag = key
        items = sorted(groups[key])
        aucs = [fm.get("auc_roc") for _, fm in items]
        f1m = [fm.get("f1_macro") for _, fm in items]
        accs = [fm.get("accuracy") for _, fm in items]
        label = f"{method}/a{alpha}" + (f"/{tag}" if tag else "")
        auc_s = " ".join(f"{a:.3f}" if a is not None else " --- " for a in aucs)
        print(f"  {label:<42} n={len(items):<3} AUC: {auc_s}")
        # 恰好 0.000（哨兵值）
        # EN: exactly 0.000 (sentinel value)
        if all((a is not None and abs(a) < 1e-12) for a in aucs):
            zero_rows.append((label, len(items)))
        # 常数预测证据：accuracy ≈ macro_count/(1+...) 且 f1_macro 方差为 0
        # EN: constant-prediction evidence: accuracy ≈ macro_count/(1+...) and f1_macro variance is 0
        if len(f1m) >= 2 and max(f1m) - min(f1m) < 1e-9 and f1m[0] is not None:
            collapse_rows.append((label, len(items), f1m[0], accs[0] if accs else None))

    # ---------------- 危险信号 ----------------
    # EN: ---------------- danger signals ----------------
    print("\n" + "=" * 78)
    print("⚠️  信号 A：AUC 恰好 = 0.000（evaluate.py 的 except 哨兵值，非真实 AUC）")
    print("=" * 78)
    if zero_rows:
        for label, n in zero_rows:
            print(f"   {label:<42} n={n}")
        print("   → 这些行必须在论文表里剔除或标注，不能写成 'AUC 0.000±0.000'")
    else:
        print("   ✔ 没有")

    print("\n" + "=" * 78)
    print("⚠️  信号 B：macro-F1 跨 seed 完全不变（= 退化常数预测器）")
    print("=" * 78)
    if collapse_rows:
        for label, n, f1v, acc in collapse_rows:
            print(f"   {label:<42} n={n}  macroF1={f1v:.3f}  acc={acc}")
        print("   → 模型对所有样本输出同一类，等于没学到东西")
    else:
        print("   ✔ 没有")

    # ---------------- proposed 是否被混池 ----------------
    # EN: ---------------- is 'proposed' wrongly pooled ----------------
    print("\n" + "=" * 78)
    print("⚠️  信号 C：'proposed' 在各 tag 上的分布（检查是否被错误混池）")
    print("=" * 78)
    prop = defaultdict(int)
    for (method, alpha, tag), items in groups.items():
        if method == "proposed":
            prop[(alpha, tag)] += len(items)
    for k in sorted(prop):
        print(f"   alpha={k[0]}  tag={k[1] or '(none)':<20} n={prop[k]}")
    tot = sum(prop.values())
    if len([k for k in prop if k[1]]) > 1:
        print(f"   ⚠ 共 {len(prop)} 组 / {tot} 个 run → 汇总脚本若按 method 汇总会把它们"
              f"混成一个 n={tot} 的 'proposed' 行")

    # ---------------- 日志异常扫描 ----------------
    # EN: ---------------- log-anomaly scan ----------------
    print("\n" + "=" * 78)
    print("日志异常扫描 (logs/ 下 NaN / Traceback / ValueError)")
    print("=" * 78)
    hits = 0
    for pat in ("logs/**/*.log", "logs/*.log"):
        for lp in glob.glob(pat, recursive=True):
            try:
                txt = open(lp, encoding="utf-8", errors="ignore").read()
            except Exception:
                continue
            for kw in ("NaN", "nan", "Traceback", "ValueError", "RuntimeWarning"):
                if kw in txt:
                    hits += 1
                    print(f"   {lp}: 含 '{kw}'")
                    break
    if hits == 0:
        print("   （未扫描到 / 无异常关键字）")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
