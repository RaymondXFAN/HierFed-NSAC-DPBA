#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
# EN: audit_zh.py -- classify where the Chinese text actually lives in each script
# EN: categories: real `#` comment / inside a string literal (incl. docstring) / other
audit_zh.py -- 统计脚本里中文的分布：真注释 / 字符串（含 docstring）/ 其他

# EN: Usage: python audit_zh.py <dir>
用法：python audit_zh.py <目录>
"""
import glob
import io
import os
import sys
import tokenize


def has_zh(s):
    """# EN: True if the string contains any CJK ideograph / 是否含中文字符"""
    return any("\u4e00" <= c <= "\u9fff" for c in s)


def audit_py(path):
    """# EN: classify Chinese-bearing lines in a .py file / 对 .py 分类"""
    src = open(path, encoding="utf-8").read()
    lines = src.splitlines()
    marks = {}
    try:
        for t in tokenize.generate_tokens(io.StringIO(src).readline):
            if t.type == tokenize.COMMENT:
                marks.setdefault(t.start[0], set()).add("comment")
            elif t.type == tokenize.STRING:
                for ln in range(t.start[0], t.end[0] + 1):
                    marks.setdefault(ln, set()).add("string")
    except Exception:
        pass
    n_c = n_s = n_o = 0
    for i, l in enumerate(lines, 1):
        if not has_zh(l):
            continue
        k = marks.get(i, set())
        if "comment" in k:
            n_c += 1
        elif "string" in k:
            n_s += 1
        else:
            n_o += 1
    return n_c, n_s, n_o


def audit_sh(path):
    """# EN: classify Chinese-bearing lines in a .sh file / 对 .sh 分类（近似）"""
    n_c = n_o = 0
    for l in open(path, encoding="utf-8"):
        if not has_zh(l):
            continue
        if l.lstrip().startswith("#"):
            n_c += 1
        else:
            n_o += 1
    return n_c, n_o, 0


def main():
    """# EN: CLI entry / 命令行入口"""
    root = sys.argv[1] if len(sys.argv) > 1 else "."
    files = sorted(glob.glob(os.path.join(root, "*.py")) +
                   glob.glob(os.path.join(root, "*.sh")))
    tot = [0, 0, 0]
    print(f"{'file':<26}{'#注释':>7}{'字符串':>8}{'其他':>7}")
    print("-" * 48)
    for p in files:
        a, b, c = audit_py(p) if p.endswith(".py") else audit_sh(p)
        if a + b + c == 0:
            continue
        print(f"{os.path.basename(p):<26}{a:>7}{b:>8}{c:>7}")
        tot[0] += a
        tot[1] += b
        tot[2] += c
    print("-" * 48)
    print(f"{'TOTAL':<26}{tot[0]:>7}{tot[1]:>8}{tot[2]:>7}")


if __name__ == "__main__":
    main()
# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
