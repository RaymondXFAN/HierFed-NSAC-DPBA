# HierFed 修复包 v3 —— 客户端采样 + ε 自洽

> 前置：**v1、v2 必须已应用**。v3 是最后一块拼图。

## 一、为什么要 v3

RDP accountant 的"子采样放大"只有**协议真的采样客户端**时才成立。
但 `core/simulator.py` 里是 `for dev_id in range(self.N)` —— **20 台设备每轮全参与，q 实际是 1.0**。

结果：同一个噪声，两种口径差 **5 倍**：

| 噪声水平 | ε（q=0.2，有采样） | ε（q=1.0，无采样） |
|:--:|:--:|:--:|
| σ_eff = 0.3594 | **27** | **~397** |

所以不真的采样，就**不能**宣称 ε=27。v3 把采样做实。

## 二、v3 改了什么

| # | 文件 | 改动 |
|---|---|---|
| W1 | `core/simulator.py` | 新增 `client_sample_rate`：每轮用 `np.random`（已被 seed 固定）随机抽 `m = round(rate·N)` 台设备参与 |
| W2 | `core/simulator.py` | 若 `client_sample_rate != dp_subsampling_rate` 会打印 `[WARN]`（accountant 与协议必须一致） |
| W3 | `core/simulator.py` | `DP-DEBUG` 行增加 `n_part=4/20`，可直接确认采样生效 |
| W4 | `core/hierfed.py` | `edge_aggregate` 改为**按实际参与台数**归一化。否则采样会悄悄把更新缩小 m/K（等于偷改学习率） |
| W5 | `configs/base.yaml` | `client_sample_rate: 0.2`、`epsilon_total: 27.0`、`dp_noise_scale: 1.0` |

**ε 与 σ 现在完全自洽**：σ 由 `epsilon_total` 经 accountant 推出，不再靠外挂缩放。
已验证：σ_base(27, q=0.2) = **0.3594**，与实测最优点（scale 0.15 → σ_eff 0.360）一致。

## 三、使用步骤

```bash
cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA

# 解包后
python apply_fixes_v3.py      # 幂等，带 .bak_v3 备份
bash run_v3_verify.sh --wait  # 1 seed，约 20 分钟
```

**验证三条**：

| 期望 | 含义 |
|---|---|
| `n_part=4/20` | 采样真的发生了 |
| `RDP base σ=0.3594 (ε=27, q=0.200)` | ε 与 σ 自洽 |
| `AUC ≈ 0.96`（≥0.90 即可） | 效用恢复 |

三条全中 → 定稿配置，进入全量重跑。

## 四、全量重跑（先挪走旧结果！）

```bash
mv results_ablation results_ablation_OLD_buggy
mv results_baseline results_baseline_OLD_buggy
mv results_eps      results_eps_OLD_buggy
mv results_scale    results_scale_OLD_buggy

export OMP_NUM_THREADS=8
nohup python -u run_parallel.py --parallel 4 --seeds 1 2 3 4 5 \
      > logs/parallel_v3.log 2>&1 &
```

## 五、两点说明

1. **若 AUC 明显 <0.90**：采样变少导致方差上升。把 `client_sample_rate` 提到 `0.4`
   （同时 `dp_subsampling_rate: 0.4`）重试；ε 会相应变化，用 accountant 重算即可。
2. **实现比保证更保守**：代码是"每台各加 σC 噪声再平均"，聚合后噪声 = σC/√m；
   而理论所需是 σC/m。即实现多加了 √m 倍噪声 → **实际 ε 比标称更小**，隐私主张**成立且偏保守**。
   这是可优化项（能换更多效用），但不影响正确性。
3. **ε-sweep 要右移**：旧区间 {0.5,1,2,3,5,8,10} 全在"噪声过大"区，请改用
   ε ∈ {19, 24, 27, 33, 46, 60}。

## 六、回滚

```bash
for f in $(find . -name "*.bak_v3"); do mv "$f" "${f%.bak_v3}"; done
```
