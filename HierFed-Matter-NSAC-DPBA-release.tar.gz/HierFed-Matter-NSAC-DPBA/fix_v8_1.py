#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v8_1.py  --  second-stage fix for the 2026-10-06 batch (run AFTER fix_v8.py).

Symptom (caught by the run_s2.sh gate, T=2 smoke test):
    RuntimeError: mat1 and mat2 shapes cannot be multiplied (256x79 and 80x64)

Root cause (R7)
---------------
`baselines/runner.py` builds the MLP in every baseline.  8 of the 11 functions do it
correctly -- load the data first, then use its true width:

    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]
    model = build_model(input_dim).to(DEVICE)

Three later-added functions instead build the model *first*, from a hard-coded default:

    model = build_model(config.get('feature_dim', 80).to(DEVICE)).to(DEVICE)
                                              ^^ base.yaml has no feature_dim -> 80
                                                 but IoTID20 has 79 features

        run_safeliot    (was line 387)
        run_dpfed6g     (was line 444)
        run_fedprox_dp  (was line 500)

fix_v8.py made them *build* (int instead of .to); this script makes them build the
*right width*, by reordering them to match the other eight.

Usage
-----
    python fix_v8_1.py            # patch
    python fix_v8_1.py --check    # verify only, non-zero exit if wrong
"""
import argparse
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
REL = "baselines/runner.py"
BAK = ".bak_v8_1"
FUNCS = ["run_safeliot", "run_dpfed6g", "run_fedprox_dp"]

DATA_PAIR = ("    X_train, y_train, partitions = _load_partitioned_data(config)\n"
             "    X_test, y_test = _load_test_data(config)\n")
MODEL_RE = re.compile(r"^[ \t]*model = build_model\([^\n]*\)\.to\(DEVICE\)[ \t]*\n", re.M)


def block_bounds(src, fn):
    """[start, end) of the top-level function `fn`."""
    m = re.search(rf"^def {fn}\(", src, flags=re.M)
    if not m:
        return None
    nxt = re.search(r"^(?:def |# ={10,})", src[m.end():], flags=re.M)
    end = m.end() + nxt.start() if nxt else len(src)
    return m.start(), end


def audit(src, fn):
    a, b = block_bounds(src, fn)
    if a is None:
        return None
    blk = src[a:b]
    i_load = blk.find("_load_partitioned_data(config)")
    i_model = blk.find("build_model(")
    ln = lambda i: blk[:i].count("\n") + src[:a].count("\n") + 1 if i >= 0 else -1
    return {"load": i_load, "model": i_model,
            "load_ln": ln(i_load), "model_ln": ln(i_model),
            "ok": 0 <= i_load < i_model}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="verify only")
    args = ap.parse_args()

    p = os.path.join(ROOT, REL)
    if not os.path.exists(p):
        print(f"[fix_v8_1] !! {REL} not found -- run me from the project root")
        sys.exit(1)

    with open(p, encoding="utf-8") as f:
        src = f.read()

    print(f"[fix_v8_1] {REL}")
    print("  BEFORE:")
    bad = []
    for fn in FUNCS:
        a = audit(src, fn)
        if a is None:
            print(f"    {fn:16s} !! function not found")
            continue
        flag = "OK " if a["ok"] else "BAD"
        print(f"    {flag} {fn:16s} load@L{a['load_ln']:<5d} model@L{a['model_ln']}")
        if not a["ok"]:
            bad.append(fn)

    if args.check:
        # any hard-coded width still feeding build_model?
        hard = re.findall(r"build_model\(\s*int\(config\.get\('feature_dim'[^\n]*", src)
        for h in hard:
            print(f"    BAD hard-coded width: {h.strip()}")
        if bad or hard:
            print("\n[fix_v8_1] CHECK FAILED")
            sys.exit(1)
        print("\n[fix_v8_1] CHECK OK")
        sys.exit(0)

    if not bad:
        print("\n[fix_v8_1] nothing to do -- already correct")
        sys.exit(0)

    shutil.copy2(p, p + BAK) if not os.path.exists(p + BAK) else None

    out = src
    for fn in bad:
        a, b = block_bounds(out, fn)
        blk = out[a:b]
        if DATA_PAIR not in blk:
            print(f"  !! {fn}: data-load pair not found -- SKIPPED, check manually")
            continue
        m = MODEL_RE.search(blk)
        if not m:
            print(f"  !! {fn}: model line not found -- SKIPPED, check manually")
            continue
        blk2 = blk.replace(DATA_PAIR, "", 1)          # drop the late occurrence
        m = MODEL_RE.search(blk2)
        blk2 = (blk2[:m.start()]
                + DATA_PAIR
                + "    input_dim = X_train.shape[1]\n\n"
                + "    model = build_model(input_dim).to(DEVICE)\n"
                + blk2[m.end():])
        out = out[:a] + blk2 + out[b:]
        print(f"  [ok]  {fn}: data load hoisted above build_model(input_dim)")

    with open(p, "w", encoding="utf-8") as f:
        f.write(out)

    print("\n[fix_v8_1] AFTER:")
    with open(p, encoding="utf-8") as f:
        src2 = f.read()
    all_ok = True
    for fn in FUNCS:
        a = audit(src2, fn)
        if a is None or not a["ok"]:
            all_ok = False
            print(f"    BAD {fn}")
            continue
        print(f"    OK  {fn:16s} load@L{a['load_ln']:<5d} model@L{a['model_ln']}")

    r = subprocess.run([sys.executable, "-m", "py_compile", p], capture_output=True, text=True)
    print(f"  py_compile: {'[ok]' if r.returncode == 0 else '[FAIL]'}")
    if r.returncode:
        print(r.stderr)
        all_ok = False

    print(f"\n[fix_v8_1] {'ALL PATCHES OK' if all_ok else 'PROBLEM -- see above'}"
          f" (backup: {REL}{BAK})")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
