#!/usr/bin/env bash
# =============================================================================
# run_v7_verify.sh -- 验证 v7「按设备自身敏感度匹配噪声」是否把 DP 性能拉回来
# EN: run_v7_verify.sh -- verify whether v7 ("match noise to each device's own sensitivity") pulls DP performance back up
#
#   bash run_v7_verify.sh          # 3 个 run 并行，约 25~30 分钟（前台等待）
# EN:   bash run_v7_verify.sh          # 3 runs in parallel, ~25-30 min (wait in the foreground)
#
# 前置: python apply_fixes_v7.py .
# EN: Prerequisite: python apply_fixes_v7.py .
# 期望: 主臂 AUC 从 0.855 抬到 ~0.95+，且 sigma_i 明显小于 0.359
# EN: Expected: the main arm's AUC rises from 0.855 to ~0.95+, with sigma_i clearly below 0.359
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}
SEED=${SEED:-1}
ALPHA=${ALPHA:-0.5}
T=${T:-50}
OUT=${OUT:-results_v7}

cd "$PROJ" || { echo "ERROR: $PROJ 不存在"; exit 1; }
mkdir -p logs "$OUT"

n=$(pgrep -fc 'run_experiment|run_baselines|run_epsilon_sweep' 2>/dev/null || true)
if [ "${n:-0}" -gt 0 ]; then
  echo "!! 检测到 $n 个训练进程在跑，先等它们结束再启动 v7（避免抢显存）"
  exit 1
fi

launch() {                       # launch <tag> [额外参数...] | EN: launch <tag> [extra args ...]
  local tag=$1; shift
  echo "  [launch] $tag  $*"
  nohup $PY -u run_experiment.py --dataset iotid20 --alpha "$ALPHA" --seed "$SEED" \
      --T "$T" --tag "$tag" --output_dir "$OUT" "$@" > "logs/${tag}.log" 2>&1 &
}

echo "[v7] 启动 3 个配置（1 seed, alpha=$ALPHA, T=$T）"
launch v7_nsac_dp_dpba    --method proposed
launch v7_nsac_dp         --method proposed --disable_dpba_fim
launch v7_nodpnsac_perdev --method proposed --disable_dpba_fim --disable_nsac
wait

echo
echo "=================== v7 校验结果 ==================="
printf "%-24s %s\n" "配置" "Final"
for t in v7_nsac_dp_dpba v7_nsac_dp v7_nodpnsac_perdev; do
  printf "%-24s " "$t"
  grep -h "Final:" "logs/${t}.log" 2>/dev/null | tail -1 || echo "(失败)"
done

echo
echo "--- 噪声标度（关键：sigma_i 应明显 < 0.359，||noise|| 应从 31.6 降下来）---"
grep -m 1 "RDP base" logs/v7_nsac_dp.log 2>/dev/null
grep -m 3 "DP-DEBUG" logs/v7_nsac_dp.log 2>/dev/null

cat <<'EOF'

判读:
  v7_nsac_dp AUC >= 0.95   -> 修复成功: 我们的 DP 追平 adaptive_clip, 且额外带 98.3% 压缩
  v7_nsac_dp AUC ~= 0.85   -> 未生效, 发我上面的 DP-DEBUG 与 RDP base 两行
  对比 v7_nsac_dp vs v7_nodpnsac_perdev -> 新噪声下的"压缩 x 隐私"协同是否依然成立
====================================================
EOF

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
