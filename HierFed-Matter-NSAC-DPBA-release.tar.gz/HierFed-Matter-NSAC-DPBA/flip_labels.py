#!/usr/bin/env python3
r"""
flip_labels.py -- invert the binary label polarity of an existing dataset npz.

WHY
---
configs/base.yaml:69 states the IoTID20 convention explicitly:
    "标签映射: y==0=attack(93.6%), y==1=normal(6.4%)"
evaluate.py uses f1_score(...)/precision/recall with the default pos_label=1,
i.e. those metrics describe class 1 (= NORMAL).  Any second dataset must use the
SAME polarity, otherwise a cross-dataset table silently mixes "normal-class F1"
with "attack-class F1".

Gotham/TII were converted with the opposite convention (0=normal, 1=attack),
so they are flipped here:  y -> 1 - y.   Features and device_ids are untouched,
so NO raw-data re-read is needed (this takes milliseconds).

A marker file <name>_label_map.json is written so the flip can never be applied
twice by accident (idempotent, refuses double-flip unless --force).

Afterwards rebuild the partitions (they depend on y):
    python make_partitions.py --name gotham25 --alphas 0.5 0.1 --native-n 20 --ensure-attack
    python make_partitions.py --name tii23    --alphas 0.5 0.1

Usage:
    python flip_labels.py --names gotham25 tii23
    python flip_labels.py --names gotham25 --dry-run
"""
import os
import json
import argparse
import numpy as np


def flip_one(name, processed_dir, dry_run, force):
    marker = os.path.join(processed_dir, f"{name}_label_map.json")
    if os.path.exists(marker) and not force:
        with open(marker) as f:
            info = json.load(f)
        print(f"[flip] {name}: 已翻转（{info.get('mapping')}），跳过")
        return False
    out = {}
    for split in ("train", "test"):
        p = os.path.join(processed_dir, f"{name}_{split}.npz")
        if not os.path.exists(p):
            print(f"[flip] !! missing {p}")
            return False
        d = np.load(p)
        X, y = d["X"], d["y"]
        before = np.bincount(y, minlength=2).tolist()
        after = np.bincount(1 - y, minlength=2).tolist()
        out[split] = {"before": before, "after": after, "n": int(len(y))}
        print(f"[flip] {name}/{split}: {before} -> {after}")
        if not dry_run:
            np.savez(p, X=X, y=(1 - y).astype(y.dtype))
    if not dry_run:
        with open(marker, "w", encoding="utf-8") as f:
            json.dump({"mapping": "0=attack, 1=normal (IoTID20 convention)",
                       "inverted": True, "detail": out}, f, indent=2)
        print(f"[flip] {name}: 已写标记 {os.path.basename(marker)} —— 请重跑 make_partitions.py")
    return True


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--names", nargs="+", required=True)
    ap.add_argument("--processed-dir", default="data/processed")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--force", action="store_true",
                    help="flip even if a marker already exists (dangerous)")
    args = ap.parse_args()
    n = 0
    for name in args.names:
        n += flip_one(name, args.processed_dir, args.dry_run, args.force)
    print(f"[flip] done, {n} dataset(s) flipped")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
