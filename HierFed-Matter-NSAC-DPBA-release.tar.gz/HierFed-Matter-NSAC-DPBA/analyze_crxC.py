#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
analyze_crxC.py -- read the CR x C grid and print the go/no-go verdict.

    python analyze_crxC.py [results_v9_crxC]

The question P2 is designed to answer:
    does the OPTIMAL clipping bound C depend on the compression rate CR?
If yes  -> compression re-opens the clipping-threshold lever -> Direction A gains a
           second, genuinely new leg ("a design rule for jointly tuning CR and C").
If no   -> the over-noising story is CR-independent; keep the trade-off framing.

Pure stdlib; safe to run while the batch is still going (it just reports what exists).
"""
import glob
import json
import os
import re
import sys
from collections import defaultdict

NAME_RE = re.compile(r"proposed_iotid20_alpha(?P<alpha>[\d.]+)_seed(?P<seed>\d+)_"
                     r"crx_s(?P<scale>[\d.]+)_C(?P<c>[\d.]+)$")


def metric_of(d, keys):
    for k in keys:
        v = (d.get("final_metrics") or {}).get(k)
        if isinstance(v, (int, float)):
            return float(v)
    return None


def last_cr(d):
    rm = d.get("round_metrics") or []
    for r in reversed(rm):
        if isinstance(r, dict):
            for k in ("avg_compression_ratio", "compression_ratio"):
                v = r.get(k)
                if isinstance(v, (int, float)):
                    return float(v)
    return None


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else "results_v9_crxC"
    if not os.path.isdir(root):
        print(f"!! {root} not found")
        return 1

    cells = defaultdict(lambda: {"auc": [], "ap": [], "cr": []})
    for p in sorted(glob.glob(os.path.join(root, "*", "results.json"))):
        name = os.path.basename(os.path.dirname(p))
        m = NAME_RE.search(name)
        if not m:
            continue
        try:
            with open(p, encoding="utf-8") as f:
                d = json.load(f)
        except Exception:
            continue
        key = (float(m.group("scale")), float(m.group("c")))
        a = metric_of(d, ["auc_roc", "auc"])
        if a is not None:
            cells[key]["auc"].append(a)
        ap = metric_of(d, ["average_precision", "pr_auc", "ap", "auc_pr"])
        if ap is not None:
            cells[key]["ap"].append(ap)
        cr = last_cr(d)
        if cr is not None:
            cells[key]["cr"].append(cr)

    if not cells:
        print(f"!! no parsable results under {root}/ "
              f"(expected names like proposed_iotid20_alpha0.5_seed1_crx_s1.0_C0.2)")
        return 1

    scales = sorted({k[0] for k in cells})
    cs = sorted({k[1] for k in cells})
    seeds = max(len(v["auc"]) for v in cells.values())

    def mean(v):
        return sum(v) / len(v) if v else float("nan")

    print("=" * 78)
    print("  P2 : CR x C grid   (AUC ROC-AUC, mean over seeds)")
    print("=" * 78)
    print(f"  parsed {sum(len(v['auc']) for v in cells.values())} runs, "
          f"up to {seeds} seeds/cell\n")

    hdr = "  CR_SCALE \\ C | " + "".join(f"{c:>9g}" for c in cs)
    print(hdr)
    print("  " + "-" * (len(hdr) - 2))
    argmax = {}
    for s in scales:
        row = f"  {s:>11g} | "
        best, best_c = -1.0, None
        for c in cs:
            v = cells.get((s, c), {}).get("auc", [])
            if v:
                mu = mean(v)
                row += f"{mu:9.4f}"
                if mu > best:
                    best, best_c = mu, c
            else:
                row += f"{'--':>9}"
        print(row)
        argmax[s] = (best_c, best)

    print("\n  mean achieved compression ratio per CR_SCALE:")
    for s in scales:
        crs = [mean(cells[(s, c)]["cr"]) for c in cs if cells.get((s, c), {}).get("cr")]
        if crs:
            base = None
            for c in cs:
                v = cells.get((s, c), {}).get("cr")
                if v:
                    base = mean(v)
                    break
            print(f"    scale={s:<6g} ->  mean CR ≈ {sum(crs) / len(crs):.4f}")
        else:
            print(f"    scale={s:<6g} ->  (no compression-ratio field in results.json)")

    print("\n  argmax C per compression level:")
    for s in scales:
        c, v = argmax[s]
        print(f"    scale={s:<6g} -> best C = {c}  (AUC {v:.4f})")

    print("\n" + "=" * 78)
    good = [x[0] for x in argmax.values() if x[0] is not None]
    if len(good) < len(scales):
        print("  VERDICT: INCOMPLETE -- some CR levels have no results yet.")
        print("           re-run once the grid finishes.")
    elif len(set(good)) == 1:
        print(f"  VERDICT: NO INTERACTION -- the optimal C is {good[0]} at every")
        print("           compression level. The clipping lever is CR-independent")
        print("           -> keep the trade-off / allocation framing (P3 is the spine).")
    else:
        print(f"  VERDICT: INTERACTION PRESENT -- optimal C varies with CR: {argmax}")
        print("           -> compression DOES re-open the clipping lever.")
        print("           -> new design rule: jointly tune (CR, C); add as contribution.")
    print("=" * 78)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
