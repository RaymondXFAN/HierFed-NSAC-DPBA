#!/usr/bin/env bash
# =============================================================================
# run_s2.sh -- HierFed S2 batch, run AFTER fix_v8.py
#
#   Gate    : 5-min smoke test of the 3 previously-broken / never-run methods
#   Batch   : base (fills topk_qsgd / safeliot / dpfed6g / fedprox_dp)
#           + eps  (new, usable epsilon grid)
#
# Usage (from the project root):
#     python fix_v8.py          # once
#     bash run_s2.sh            # this script (starts the batch in the background)
#
# Overrides:  PAR=6 bash run_s2.sh        (concurrency, default 4)
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"

PAR="${PAR:-4}"
PY="${PY:-python}"
STAMP="$(date +%Y%m%d_%H%M)"
mkdir -p logs

bar() { printf '%s\n' "-------------------------------------------------------------------------------"; }

# ---------------------------------------------------------------------------
# 0) preflight -- the fixes must actually be in place
# ---------------------------------------------------------------------------
bar
printf '[S2] preflight\n'
for f in run_parallel.py run_baselines.py baselines/runner.py; do
  [ -f "$f" ] || { printf '  !! missing %s -- wrong directory?\n' "$f"; exit 1; }
done

BAD=$(grep -cE "config\.get\(\s*'[A-Za-z_]+'\s*,\s*[0-9]+\s*\)\.to\(DEVICE\)" baselines/runner.py || true)
if [ "$BAD" != "0" ]; then
  printf '  !! %s residual int/.to(DEVICE) site(s) -- run `python fix_v8.py` first\n' "$BAD"
  exit 1
fi
if ! grep -q "topk_qsgd" run_parallel.py; then
  printf '  !! topk_qsgd still absent from run_parallel.py -- run `python fix_v8.py` first\n'
  exit 1
fi
printf '  [ok] fixes present (0 residual crash sites, topk_qsgd registered)\n'

# feature-dim structural check (R7): data must be loaded BEFORE the model is built
if [ -f fix_v8_1.py ]; then
  CHECK_OUT="$($PY fix_v8_1.py --check 2>&1)"
  CHECK_RC=$?
  printf '%s\n' "$CHECK_OUT" | sed 's/^/  /'
  if [ "$CHECK_RC" != "0" ]; then
    printf '  !! R7 structural check failed -- run `python fix_v8_1.py` first\n'
    exit 1
  fi
else
  printf '  !! fix_v8_1.py missing -- the 3 methods will crash with a 79-vs-80 shape error\n'
  exit 1
fi

$PY - <<'PYEOF'
import re, sys
m = re.search(r"EPSILONS\s*=\s*\[[^\]]*\]", open('run_parallel.py', encoding='utf-8').read())
print("  [ok] grid:", m.group(0) if m else "<not found>")
PYEOF

printf '\n[S2] job plan (dry run, seeds 1..5, suites = base eps)\n'
$PY run_parallel.py --dry_run --suites base eps --seeds 1 2 3 4 5 2>&1 \
  | grep -E "^\[parallel\]" | sed 's/^/  /'

# ---------------------------------------------------------------------------
# 1) GATE -- 5-minute smoke test of the three suspects (T=2)
# ---------------------------------------------------------------------------
bar
printf '[S2] GATE: smoke-testing safeliot / dpfed6g / topk_qsgd with T=2 (a few minutes)\n'
SMOKE="smoke_v8_${STAMP}"
mkdir -p "$SMOKE"
GATE_FAIL=0
for m in safeliot dpfed6g topk_qsgd; do
  LOG="$SMOKE/${m}.log"
  printf '  ... %-11s ' "$m"
  if timeout 900 $PY -u run_baselines.py --method "$m" --alpha 0.5 --seeds 1 \
       --T 2 --skip_aggregate --output_dir "$SMOKE" > "$LOG" 2>&1; then
    RES="$SMOKE/${m}_iotid20_alpha0.5_seed1/results.json"
    OUT="$($PY "$HERE/gate_check.py" "$RES" 2>&1)"
    RC=$?
    printf '%s\n' "$OUT" | sed 's/^/       /'
    [ "$RC" = "0" ] || GATE_FAIL=1
  else
    printf 'FAIL (non-zero exit)\n'
    GATE_FAIL=1
  fi
  if [ "$GATE_FAIL" != "0" ]; then
    printf '  --- last 15 lines of %s ---\n' "$LOG"
    tail -n 15 "$LOG" | sed 's/^/  | /'
    break
  fi
done

if [ "$GATE_FAIL" != "0" ]; then
  bar
  printf '  !! GATE FAILED -- the full batch was NOT started.\n'
  printf '  !! Send Mihiro the block above (or %s/*.log).\n' "$SMOKE"
  exit 1
fi
printf '  [ok] GATE PASSED -- all three methods run and write results.json\n'
rm -rf "$SMOKE"

# ---------------------------------------------------------------------------
# 2) archive the obsolete epsilon grid, then launch
# ---------------------------------------------------------------------------
bar
if [ -d results_eps ]; then
  mkdir -p archive_pre_v8
  if [ -d archive_pre_v8/results_eps_oldgrid ]; then
    rm -rf archive_pre_v8/results_eps_oldgrid
  fi
  mv results_eps archive_pre_v8/results_eps_oldgrid
  printf '  [ok] results_eps (obsolete 0.5-10 grid) -> archive_pre_v8/results_eps_oldgrid\n'
else
  printf '  [skip] no results_eps to archive\n'
fi

printf '\n[S2] launching the S2 batch in the background ...\n'
nohup $PY -u run_parallel.py --parallel "$PAR" --seeds 1 2 3 4 5 \
      --suites base eps > logs/parallel_s2.log 2>&1 &
PID=$!
sleep 20
bar
printf '  pid    : %s\n' "$PID"
printf '  log    : logs/parallel_s2.log\n'
printf '  tail   :\n'
tail -n 8 logs/parallel_s2.log | sed 's/^/    /'
bar
cat <<'EOF'
  Monitor (non-blocking, safe to run any time):

    cd <project root>
    tail -n 8 logs/parallel_s2.log
    grep -c '] ok ' logs/parallel_s2.log ; grep -c 'FAIL' logs/parallel_s2.log
    ls logs/jobs | wc -l

  On failure the driver now prints the child's stderr inline, tagged '| '.

  After it finishes:  cat results_summary/TABLES.md
EOF

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
