#!/usr/bin/env python3
"""
apply_fixes_v4.py -- make the DPBA sensitivity allocation BUDGET-NEUTRAL.

Prerequisite: v1 + v2 + v3 already applied.

The bug
-------
core/simulator.py computes the per-device noise multiplier as

    device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])      # in [1.0, 1.4]

Uniform DP (`--disable_dpba_fim`) sets s_rel == 1, hence multiplier == 1.0.
DPBA spreads s_rel over [0, 1], so its multipliers average

    E[m^2] = integral_0^1 (1.4 - 0.4 s)^2 ds = 1.4533   ->  mean m = 1.2057

i.e. DPBA silently injects 20.6% MORE noise energy than the baseline it is
compared against.  Measured consequence (1 seed, T=50, oversampling on):

    eps=399 :  dpba 0.9593  vs  uniform 0.9634     (dpba -0.004)
    eps=108 :  dpba 0.6196  vs  uniform 0.8325     (dpba -0.213)
    no-dp   :  0.9147 (both levels, as expected)

and 0.719 * 1.2057 = 0.867 lands exactly on the measured 0.6196 point of the
noise/utility curve -- so the entire gap is the extra noise, not the strategy.

The fix
-------
Divide the multiplier vector by sqrt(mean(m^2)) so the mean noise ENERGY equals
the uniform case; only the *distribution* across devices changes.  Uniform DP
is unaffected (all multipliers are 1.0 -> norm is 1.0).

Usage:  python apply_fixes_v4.py [root]     (idempotent, writes *.bak_v4)
"""
import os
import sys
import shutil
import argparse

P = []

# Files the user may have hand-edited: a non-matching hunk is reported as INFO.
OPTIONAL_FILES = {"configs/base.yaml"}

# ---- H1: build the normalised multiplier vector ------------------------------
P.append(("core/simulator.py",
"""                s_rel = self.device_sensitivity / (self.device_sensitivity.max() + 1e-12)

            # --- [v3] client subsampling ---""",
"""                s_rel = self.device_sensitivity / (self.device_sensitivity.max() + 1e-12)

            # [v4] Budget-neutral allocation.
            # (1.4 - 0.4*s_rel) has mean-square 1.4533, so using it raw makes
            # DPBA inject ~20.6% more noise energy than uniform DP and lose a
            # comparison it should win.  Normalise so mean(m^2) == 1: only the
            # DISTRIBUTION of the noise across devices changes, not the total.
            _raw = 1.4 - 0.4 * s_rel
            if self.dpba_budget_neutral:
                _den = float(np.sqrt(np.mean(_raw ** 2))) or 1.0
                sigma_mult = _raw / _den
            else:
                sigma_mult = _raw

            # --- [v3] client subsampling ---"""))

# ---- H2: use the vector ------------------------------------------------------
P.append(("core/simulator.py",
"""                device_sigma = sigma_base * (1.4 - 0.4 * s_rel[dev_id])""",
"""                device_sigma = sigma_base * float(sigma_mult[dev_id])"""))

# ---- H3: config knob ---------------------------------------------------------
P.append(("core/simulator.py",
"""        self.client_sample_rate = float(config.get('client_sample_rate', 1.0))""",
"""        self.client_sample_rate = float(config.get('client_sample_rate', 1.0))
        # [v4] keep DPBA's total noise energy equal to uniform DP (fair compare)
        self.dpba_budget_neutral = bool(config.get('dpba_budget_neutral', True))"""))

# ---- H4: yaml ----------------------------------------------------------------
P.append(("configs/base.yaml",
"""dp_noise_scale: 1.0       # [A] σ 完全由 epsilon_total 推出""",
"""dp_noise_scale: 1.0       # [A] σ 完全由 epsilon_total 推出
dpba_budget_neutral: true # [v4] DPBA 分配保持噪声总能量不变（否则比 uniform 多 20.6%）"""))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--dry_run", action="store_true")
    args = ap.parse_args()
    root = os.path.abspath(args.root)

    per_file = {}
    for rel, old, new in P:
        per_file.setdefault(rel, []).append((old, new))

    n_ok = n_skip = n_fail = 0
    for rel in sorted(per_file):
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            print(f"  [MISSING] {rel}")
            n_fail += 1
            continue
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        todo = []
        for old, new in per_file[rel]:
            if new in src:
                continue
            if old not in src:
                if rel in OPTIONAL_FILES:
                    print(f"  [INFO] {rel}: 需手工添加 -> {new.splitlines()[0].strip()!r}")
                    continue
                print(f"  [FAIL] {rel}: pattern not found -> "
                      f"{old.splitlines()[0].strip()[:60]!r}")
                n_fail += 1
                todo = None
                break
            todo.append((old, new))
        if todo is None:
            continue
        if not todo:
            print(f"  [SKIP] {rel}: already patched (v4)")
            n_skip += 1
            continue
        out = src
        for old, new in todo:
            out = out.replace(old, new)
        if args.dry_run:
            print(f"  [DRY ] {rel}: {len(todo)} hunk(s)")
            continue
        bak = path + ".bak_v4"
        if not os.path.exists(bak):
            shutil.copy2(path, bak)
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"  [ OK ] {rel}: {len(todo)} hunk(s) applied")
        n_ok += 1

    print(f"\napply_fixes_v4: files_patched={n_ok}  already_ok={n_skip}  failed={n_fail}")
    sys.exit(1 if n_fail else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
