#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v16.py -- add the TRUE uniform-clip control arms, and let an ablation run
only a chosen subset of arms.

WHY
---
core/simulator.py:532-541 decides the per-device clipping bound:

    if self.dp_clip_mode == 'per_device':
        _prev = self._dev_clip.get(dev_id, self.clip_norm)
        _C_i  = clamp(EMA(||dw_i||), self.adaptive_clip_min, self.adaptive_clip_max)
    else:
        _C_i  = self.clip_norm
    # sigma is then rescaled by (_C_i / clip_norm)

So 'per_device' means ADAPTIVE and anything else means the fixed uniform bound.
The ablation's "uniform DP C=1.0" arms only set disable_dpba_fim=True, leaving
dp_clip_mode='per_device' and alpha_s/beta_s_coeff/gamma_s = 0.3/0.3/0.2 in
place -> they were ADAPTIVE, which is why they scored 0.928 where the genuine
uniform baseline scored 0.850.

This script adds two arms that force the bound to be uniform:

    hierfed_uni_dp_true       : disable_nsac + disable_dpba_fim + dp_clip_mode=global
    hierfed_nsac_uni_dp_true  : (same, with NSAC on)

The comparison that matters for the paper is
    full  (NSAC + adaptive DPBA)   vs   hierfed_nsac_uni_dp_true  (NSAC + uniform C)

WHAT IT DOES
  1 ablation_configs.py : append the two arms to COMPONENT_CONFIGS
  2 run_ablation.py     : add --arms (subset filter) and print [[fix_v16]] arms kept
  3 verify              : compile, tag presence, and that dp_clip_mode differs
                          between the *_uni_dp and *_uni_dp_true arms

Usage
    python fix_v16.py --check
    python fix_v16.py --apply
    python fix_v16.py --revert
"""
import argparse
import glob
import json
import os
import re
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
ABLC = ROOT / "ablation_configs.py"
ABLR = ROOT / "run_ablation.py"
BAK = ".bak_v16"

NEW_ARMS = '''    "hierfed_uni_dp_true": (
        "[CONTROL] HierFed + TRUE uniform DP: C_i = clip_norm for every device"
        " (dp_clip_mode=global), no NSAC, no FIM",
        {"disable_nsac": True, "disable_dpba_fim": True, "dp_clip_mode": "global"},
    ),
    "hierfed_nsac_uni_dp_true": (
        "[CONTROL] HierFed + NSAC + TRUE uniform DP: C_i = clip_norm for every"
        " device (dp_clip_mode=global), no FIM",
        {"disable_dpba_fim": True, "dp_clip_mode": "global"},
    ),
'''


def log(m):
    print("  " + m)


def find_dict_block(text, name):
    """return (start_idx_of_body, end_idx) for `NAME = { ... }`"""
    i = text.index(f"{name} = {{")
    j = text.index("{", i)
    depth, k = 0, j
    while k < len(text):
        if text[k] == "{":
            depth += 1
        elif text[k] == "}":
            depth -= 1
            if depth == 0:
                return j + 1, k
        k += 1
    raise ValueError(f"unbalanced braces for {name}")


def abl_edits(text):
    if "hierfed_uni_dp_true" in text:
        return text, 0
    body_start, body_end = find_dict_block(text, "COMPONENT_CONFIGS")
    # insert before the closing brace, keeping the blank-line style
    new = text[:body_end].rstrip() + "\n" + NEW_ARMS + text[body_end:]
    return new, 2


ARMS_ARG = '''    p.add_argument("--arms", nargs="+", default=None,
                   help="[fix_v16] run only these arms (keys of the suite dict)")
'''
SELECT_FN = '''    def _select(cfgs):                               # [fix_v16]
        if not args.arms:
            return cfgs
        want = set(args.arms)
        kept = {k: v for k, v in cfgs.items() if k in want}
        missing = sorted(want - set(cfgs))
        print(f"[[fix_v16]] arms kept: {sorted(kept)} of {sorted(cfgs)}", flush=True)
        if missing:
            print(f"[[fix_v16]] WARNING unknown arms ignored: {missing}", flush=True)
        return kept

'''


def ablr_edits(text):
    if "--arms" in text:
        return text, 0, None
    anchor = '    p.add_argument("--epsilon", type=float, default=None,'
    if anchor not in text:
        return text, 0, "anchor for --arms not found (run fix_v15 first)"
    text = text.replace(anchor, ARMS_ARG + anchor, 1)
    anchor2 = "    if args.epsilon is not None:                     # [fix_v15]"
    if anchor2 not in text:
        return text, 0, "anchor for _select not found"
    text = text.replace(anchor2, SELECT_FN + anchor2, 1)
    n = 0
    for suite, cfg in (("component", "COMPONENT_CONFIGS"), ("weights", "WEIGHT_CONFIGS")):
        pat = f'"{suite}", {cfg},'
        n += text.count(pat)                 # str.replace is global -> count first
        text = text.replace(pat, f'"{suite}", _select({cfg}),')
    if n != 4:
        return text, 0, f"expected 4 run_suite call sites, found {n}"
    return text, n, None


def effective_clip_mode(tag, dflt):
    """best evidence for what an arm ACTUALLY ran with.

    1st choice: an existing result on disk (authoritative -- that is the merged
    config that was really used).  Falls back to the yaml default.
    """
    for p in sorted(glob.glob(os.path.join(
            str(ROOT), "results_ablation", f"*_{tag}", "results.json"))):
        try:
            c = json.load(open(p, encoding="utf-8")).get("config") or {}
        except Exception:
            continue
        if "dp_clip_mode" in c:
            return str(c["dp_clip_mode"]).lower(), f"results_ablation/*_{tag}"
    return dflt, "yaml default"


def default_clip_mode():
    """the effective dp_clip_mode when an arm does NOT override it"""
    for f in ("configs/nsac.yaml", "configs/base.yaml"):
        p = ROOT / f
        if p.exists():
            m = re.search(r"^dp_clip_mode:\s*['\"]?([A-Za-z_]+)",
                          p.read_text(encoding="utf-8"), flags=re.M)
            if m:
                return m.group(1).lower(), f
    return "global", "(not found -> code default)"


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    print("=" * 78)
    print("  fix_v16 -- TRUE uniform-clip arms + --arms subset filter")
    print("=" * 78)
    for p in (ABLC, ABLR):
        if not p.exists():
            print(f"[abort] missing {p.name} (cwd={ROOT})")
            return 1
    if a.revert:
        for p in (ABLC, ABLR):
            b = p.with_name(p.name + BAK)
            if b.exists():
                shutil.copy2(b, p)
                log(f"restored {p.name}")
        return 0

    t, n1 = abl_edits(ABLC.read_text(encoding="utf-8"))
    log(f"ablation_configs.py : arms added = {n1}")
    t2, n2, err = ablr_edits(ABLR.read_text(encoding="utf-8"))
    log(f"run_ablation.py     : --arms edits = {n2}" + (f"  ERROR: {err}" if err else ""))
    if err:
        print("[abort] nothing written")
        return 1
    if a.check:
        print("\n  (check only -- nothing written)")
        return 0
    for p, new in ((ABLC, t), (ABLR, t2)):
        if p.read_text(encoding="utf-8") != new:
            b = p.with_name(p.name + BAK)
            if not b.exists():
                shutil.copy2(p, b)
                log(f"backup   {p.name} -> {p.name}{BAK}")
            p.write_text(new, encoding="utf-8")
            log(f"written  {p.name}")

    # ------------------------------------------------------------- verify
    print("\n" + "=" * 78)
    print("  verify")
    print("=" * 78)
    ok = True
    import py_compile
    for p in (ABLC, ABLR):
        try:
            py_compile.compile(str(p), doraise=True)
            log(f"[ok] {p.name} compiles")
        except Exception as e:
            log(f"[FAIL] {p.name}: {e}"); ok = False
    sys.path.insert(0, str(ROOT))
    import importlib.util
    spec = importlib.util.spec_from_file_location("ac_v16", ABLC)
    ac = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ac)
    C = ac.COMPONENT_CONFIGS
    log(f"[info] component arms now: {sorted(C)}")
    for t_ in ("hierfed_uni_dp_true", "hierfed_nsac_uni_dp_true"):
        if t_ in C:
            log(f"[ok] {t_} present -> {C[t_][1]}")
        else:
            log(f"[FAIL] {t_} missing"); ok = False
    dflt, where = default_clip_mode()
    log(f"[info] yaml default dp_clip_mode = '{dflt}' (from {where})")
    for a_, b_ in (("hierfed_uni_dp", "hierfed_uni_dp_true"),
                   ("hierfed_nsac_uni_dp", "hierfed_nsac_uni_dp_true")):
        if a_ in C and b_ in C:
            ma, src_a = effective_clip_mode(a_, str(C[a_][1].get("dp_clip_mode", dflt)))
            mb = str(C[b_][1].get("dp_clip_mode", dflt))
            log(f"[info] {a_}: effective='{ma}' (from {src_a}), "
                f"{b_}: override='{mb}'")
            determined = ("results_ablation" in src_a) or ("not found" not in where)
            if not determined:
                log(f"[warn] {a_}: cannot tell what it ran with (no result on disk"
                    f" and no yaml key) -- re-check after the re-run"); continue
            if ma == "per_device" and mb != "per_device":
                log(f"[ok] {a_} effective={ma} (inherited) vs {b_} effective={mb}"
                    f" -> the control arm really is uniform")
            else:
                log(f"[FAIL] effective clip modes do not differ:"
                    f" {a_}={ma}, {b_}={mb}"); ok = False
    if "--arms" in ABLR.read_text(encoding="utf-8"):
        log("[ok] run_ablation.py accepts --arms")
    else:
        log("[FAIL] --arms missing"); ok = False
    print("\n  " + ("ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED"))
    if ok:
        print("""
  re-run (8 component arms now):
     mv results_ablation results_ablation_old
     ABL_EPS=399 SKIP_WAIT=1 SUITES="component" bash run_rest_all.sh all
  or just the two control arms:
     ABL_ARMS="hierfed_uni_dp_true hierfed_nsac_uni_dp_true" ABL_EPS=399 \\
       SKIP_WAIT=1 SUITES="component" bash run_rest_all.sh all
""")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
