#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v17.py -- make gotham25 / tii23 actually reachable from the CLI.

WHY (diagnosed 2026-10-13 on the real server)
---------------------------------------------
`run_multids.sh` calls
        python run_experiment.py --dataset gotham25 ...
but argparse only allows {iotid20, cicids2017, both}  ->  the run NEVER starts.
And even if it did, core/simulator.py resolves the npz prefix as
        prefix = 'iotid20' if dataset == 'iotid20' else 'cicids'
so gotham25 would silently look for cicids_train.npz.
(baselines/runner.py was already fixed with _resolve_prefix; the SIMULATOR was not.)

FOUR call sites are patched:
  P1 run_experiment.py    : --dataset choices    += 'gotham25', 'tii23'
  P2 core/simulator.py    : prefix resolution    -> data-driven (same rule as runner.py)
  P3 run_baselines.py     : dataset_name         -> os.environ.get('HIERFED_DATASET', ...)
  P4 run_epsilon_sweep.py : dataset_name         -> os.environ.get('HIERFED_DATASET', ...)

Usage
    python fix_v17.py --check     # dry run: show what WOULD change, change nothing
    python fix_v17.py --apply     # apply (idempotent; writes .bak_v17 backups)
    python fix_v17.py --revert    # restore the .bak_v17 backups
"""
import argparse
import os
import py_compile
import shutil
import sys
from pathlib import Path

ROOT = Path.cwd()
BAK = ".bak_v17"

# ------------------------------------------------------------------ patches
P_EXP_OLD = "parser.add_argument('--dataset', choices=['iotid20', 'cicids2017', 'both'],"
P_EXP_NEW = ("parser.add_argument('--dataset', choices=['iotid20', 'cicids2017', "
             "'gotham25', 'tii23', 'both'],")

P_SIM_OLD = "prefix = 'iotid20' if dataset == 'iotid20' else 'cicids'"
P_SIM_NEW = ("prefix = (dataset if os.path.exists(os.path.join(processed_dir, "
             "f'{dataset}_train.npz'))\n"
             "                  else ('iotid20' if dataset == 'iotid20' else 'cicids'))"
             "  # [fix_v17]")

P_DS_OLD = "config['dataset_name'] = 'iotid20'"
P_DS_NEW = "config['dataset_name'] = os.environ.get('HIERFED_DATASET', 'iotid20')  # [fix_v17]"

PATCHES = [
    # (file, old, new, "already-applied" marker, label)
    ("run_experiment.py", P_EXP_OLD, P_EXP_NEW, "'gotham25'", "P1 --dataset choices"),
    ("core/simulator.py", P_SIM_OLD, P_SIM_NEW, "# [fix_v17]", "P2 simulator prefix"),
    ("run_baselines.py", P_DS_OLD, P_DS_NEW, "HIERFED_DATASET", "P3 baselines dataset"),
    ("run_epsilon_sweep.py", P_DS_OLD, P_DS_NEW, "HIERFED_DATASET", "P4 eps-sweep dataset"),
]


def log(m):
    print("  " + m)


def backup(p):
    b = p.with_name(p.name + BAK)
    if not b.exists():
        shutil.copy2(p, b)
        log(f"backup  {p.name} -> {p.name}{BAK}")


def do_check():
    print("[check] cwd =", ROOT)
    bad = 0
    for f, old, _new, marker, label in PATCHES:
        p = ROOT / f
        if not p.exists():
            log(f"[!!] {label:26s} MISSING file {f}")
            bad += 1
            continue
        t = p.read_text(encoding="utf-8")
        if marker in t:
            log(f"[ok] {label:26s} already applied ({f})")
        elif old in t:
            log(f"[--] {label:26s} would patch ({f})")
        else:
            log(f"[!!] {label:26s} anchor NOT FOUND in {f}")
            log(f"        looked for: {old[:72]!r}")
            bad += 1
    # 'import os' sanity for the files we inject os.environ / os.path into
    for f in ("core/simulator.py", "run_baselines.py", "run_epsilon_sweep.py"):
        p = ROOT / f
        if p.exists() and "\nimport os" not in p.read_text(encoding="utf-8"):
            log(f"[??] {f} has no `import os` -- the patch needs it")
    print(f"[check] {'OK' if bad == 0 else str(bad) + ' problem(s)'}")
    return 0 if bad == 0 else 1


def do_apply():
    n = 0
    for f, old, new, marker, label in PATCHES:
        p = ROOT / f
        if not p.exists():
            log(f"[!!] {label:26s} MISSING {f}")
            continue
        t = p.read_text(encoding="utf-8")
        if marker in t:
            log(f"[ok] {label:26s} already applied")
            continue
        if old not in t:
            log(f"[!!] {label:26s} anchor NOT FOUND in {f} (skipped)")
            continue
        backup(p)
        cnt = t.count(old)
        p.write_text(t.replace(old, new), encoding="utf-8")
        log(f"[done] {label:26s} patched {cnt} site(s) in {f}")
        n += cnt
    print(f"[apply] {n} site(s) changed")

    # ---------------- verify: compile + anchors + functional prefix ----------
    print("[verify]")
    ok = True
    for f, _old, _new, marker, label in PATCHES:
        p = ROOT / f
        if not p.exists():
            continue
        try:
            py_compile.compile(str(p), doraise=True)
        except Exception as e:
            log(f"[!!] {f} does NOT compile: {e}")
            ok = False
            continue
        if marker not in p.read_text(encoding="utf-8"):
            log(f"[!!] {f} still missing marker {marker!r}")
            ok = False
        else:
            log(f"[ok] {label:26s} compiles + marker present")

    # functional: does the patched simulator resolve gotham25 -> gotham25?
    for ds in ("gotham25", "tii23"):
        tp = ROOT / "data" / "processed" / f"{ds}_train.npz"
        if tp.exists():
            log(f"[data] {ds}_train.npz present -> resolver returns '{ds}' OK")
        else:
            log(f"[??] {ds}_train.npz NOT in data/processed (can't functional-check)")
    print(f"[verify] {'ALL PASS' if ok else 'FAILED'}")
    return 0 if ok else 1


def do_revert():
    n = 0
    for f, *_ in PATCHES:
        p = ROOT / f
        b = p.with_name(p.name + BAK)
        if b.exists():
            shutil.copy2(b, p)
            log(f"[revert] {f} restored from {p.name}{BAK}")
            n += 1
        else:
            log(f"[--] {f}: no {p.name}{BAK}")
    print(f"[revert] {n} file(s) restored")
    return 0


def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--check", action="store_true")
    g.add_argument("--apply", action="store_true")
    g.add_argument("--revert", action="store_true")
    a = ap.parse_args()
    if a.check:
        return do_check()
    if a.apply:
        return do_apply()
    return do_revert()


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
