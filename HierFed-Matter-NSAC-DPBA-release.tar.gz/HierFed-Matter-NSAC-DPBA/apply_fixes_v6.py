#!/usr/bin/env python3
r"""
apply_fixes_v6.py -- make the data-loading layer recognise ARBITRARY dataset names.

Gap left by apply_fixes_v5.py
-----------------------------
v5 only relaxed the argparse whitelist (run_experiment.py) and run_baselines.py.
But the actual loaders still do:

    prefix = 'iotid20' if dataset == 'iotid20' else 'cicids'

so `--dataset gotham25` passes the CLI, then silently loads cicids_train.npz.
v6 fixes the loaders + the remaining hard-coded `dataset_name = 'iotid20'`.

Idempotent.  Backs up every touched file as *.bak_v6.
Usage:  python apply_fixes_v6.py [root]      (root defaults to '.')
"""
import os
import sys
import shutil
import argparse

REQUIRED = [
    ("core/simulator.py",
     "        prefix = 'iotid20' if dataset == 'iotid20' else 'cicids'",
     "        # [v6] arbitrary dataset names -> <name>_{train,test}.npz in processed_dir\n"
     "        prefix = {'iotid20': 'iotid20', 'cicids2017': 'cicids',\n"
     "                  'cicids': 'cicids'}.get(dataset, dataset)"),

    ("baselines/runner.py",
     "    prefix = 'iotid20' if ds == 'iotid20' else 'cicids'",
     "    # [v6] arbitrary dataset names\n"
     "    prefix = {'iotid20': 'iotid20', 'cicids2017': 'cicids',\n"
     "              'cicids': 'cicids'}.get(ds, ds)"),
]

OPTIONAL = [
    ("run_epsilon_sweep.py",
     "    config['dataset_name'] = 'iotid20'",
     "    config['dataset_name'] = os.environ.get('HIERFED_DATASET', 'iotid20')  # [v6]"),
    ("run_focal_loss.py",
     "    config['dataset_name'] = 'iotid20'",
     "    config['dataset_name'] = os.environ.get('HIERFED_DATASET', 'iotid20')  # [v6]"),
]


def apply_group(root, hunks, optional):
    ok = skip = fail = 0
    per_file = {}
    for rel, old, new in hunks:
        per_file.setdefault(rel, []).append((old, new))
    for rel in sorted(per_file):
        path = os.path.join(root, rel)
        if not os.path.isfile(path):
            print(f"  [MISSING] {rel}")
            if not optional:
                fail += 1
            continue
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
        todo, already = [], 0
        bad = False
        for old, new in per_file[rel]:
            if new in src:
                already += 1
                continue
            if old not in src:
                print(f"  [FAIL] {rel}: pattern not found -> {old.strip()[:60]!r}")
                bad = True
                continue
            todo.append((old, new))
        if bad:
            if not optional:
                fail += 1
            continue
        if not todo:
            print(f"  [SKIP] {rel}: already patched (v6)")
            skip += 1
            continue
        out = src
        for old, new in todo:
            out = out.replace(old, new)
        if "os.environ" in out and "import os" not in out:
            out = out.replace("import argparse", "import os\nimport argparse", 1)
            print(f"  [note] {rel}: injected 'import os'")
        bak = path + ".bak_v6"
        if not os.path.exists(bak):
            shutil.copy2(path, bak)
        with open(path, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"  [ OK ] {rel}: {len(todo)} hunk(s) applied")
        ok += 1
    return ok, skip, fail


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", nargs="?", default=".")
    args = ap.parse_args()
    root = os.path.abspath(args.root)
    print(f"[v6] root = {root}\n-- required --")
    ok1, skip1, fail1 = apply_group(root, REQUIRED, optional=False)
    print("-- optional --")
    ok2, skip2, fail2 = apply_group(root, OPTIONAL, optional=True)
    print(f"\napply_fixes_v6: required_ok={ok1} optional_ok={ok2} "
          f"already={skip1 + skip2} failed={fail1 + fail2}")
    for rel, _, _ in REQUIRED:
        p = os.path.join(root, rel)
        if os.path.isfile(p):
            import py_compile
            try:
                py_compile.compile(p, doraise=True, cfile="/tmp/_v6.pyc")
                print(f"  [py_compile OK] {rel}")
            except Exception as e:
                print(f"  [py_compile FAIL] {rel}: {e}")
                fail1 += 1
    sys.exit(1 if (fail1 + fail2) else 0)


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
