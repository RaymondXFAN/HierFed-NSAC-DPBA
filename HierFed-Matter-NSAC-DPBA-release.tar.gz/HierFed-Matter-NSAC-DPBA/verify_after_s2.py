#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_after_s2.py  --  one-command health check + summary for the S2 batch.

Run it from the project root once `run_parallel.py --suites base eps` has finished:

    python verify_after_s2.py

It answers, in one screen:
  1. is the batch still running?
  2. did every job report `ok` (and is that `ok` real)?
  3. are the 4 new/repaired baselines complete (2 alphas x 5 seeds each)?
  4. is the new epsilon grid complete (7 epsilons x 2 alphas x 5 seeds)?
  5. any sentinel / malformed metric?
  6. what does the comparison actually look like  (incl. topk_qsgd's CR)?
  7. VERDICT: can we go to S3, or what is still missing?
"""
import glob
import json
import os
import re
import subprocess
import sys
from collections import defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(ROOT, "logs", "parallel_s2.log")
NEW_METHODS = ["topk_qsgd", "safeliot", "dpfed6g", "fedprox_dp"]
ALPHAS = [0.5, 0.1]
SEEDS = [1, 2, 3, 4, 5]
EPS_OLD = {0.5, 1.0, 2.0, 3.0, 5.0, 8.0, 10.0}


def bar(c="-"):
    print(c * 78)


def load_result(path):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None


def auc_of(d):
    fm = (d or {}).get("final_metrics") or {}
    a = fm.get("auc_roc")
    return float(a) if isinstance(a, (int, float)) else None


def f1_of(d):
    fm = (d or {}).get("final_metrics") or {}
    v = fm.get("f1_macro")
    return float(v) if isinstance(v, (int, float)) else None


def find_cr(d):
    """Hunt for a compression-ratio / communication field anywhere in the record."""
    hits = {}

    def walk(o, pre=""):
        if isinstance(o, dict):
            for k, v in o.items():
                kl = str(k).lower()
                # NOTE: do not use a bare "cr" -- "f1_macro" contains "cr"
                if any(t in kl for t in ("compress", "ratio", "reduction", "empty",
                                         "speedup", "bytes", "bits", "b_bits", "cr_")):
                    if not isinstance(v, (dict, list)):
                        hits[f"{pre}{k}"] = v
                walk(v, f"{pre}{k}.")
        elif isinstance(o, list) and o and not isinstance(o[0], (dict, list)):
            pass
    walk(d or {})
    return hits


def main():
    os.chdir(ROOT)
    problems = []

    bar("=")
    print("  HierFed -- S2 post-batch verification")
    bar("=")

    # 1 -------------------------------------------------------------------
    # look for ANY driver, not just run_parallel.py -- a manually re-launched
    # `run_baselines.py --method X --seeds 4` would otherwise be invisible
    ps_raw = subprocess.run(
        "pgrep -af 'run_parallel.py|run_baselines.py|run_experiment.py|"
        "run_epsilon_sweep.py|run_ablation.py|run_scale_test.py'",
        shell=True, capture_output=True, text=True).stdout
    # drop the pgrep process itself (and this verifier) -- they match their own
    # command line and used to fake a "STILL RUNNING" verdict
    ps = [l for l in ps_raw.splitlines()
          if l.strip() and "pgrep" not in l and "verify_after_s2" not in l]
    print(f"\n[1] python experiment process : {'STILL RUNNING' if ps else 'none'}")
    if ps:
        for l in ps:
            print(f"    {l.strip()[:130]}")
        problems.append(f"{len(ps)} experiment process(es) still running")

    # 2 -------------------------------------------------------------------
    print("\n[2] driver log")
    if not os.path.exists(LOG):
        print(f"    !! {LOG} not found")
        problems.append("driver log missing")
    else:
        txt = open(LOG, encoding="utf-8", errors="replace").read()
        ok = txt.count("] ok ")
        fails = re.findall(r"\[\s*\d+/\d+\] FAIL\s+([\d.]+)min\s+(\S+)", txt)
        m = re.search(r"total jobs=(\d+)\s+already done=(\d+)\s+to run=(\d+)", txt)
        if m:
            print(f"    plan: total={m.group(1)}  done={m.group(2)}  to run={m.group(3)}")
        print(f"    ok={ok}   FAIL={len(fails)}")
        # the driver log is a HISTORY: a job that failed then was re-run
        # successfully still appears here.  Cross-check against the result files.
        recovered, still = [], []
        for dt, name in fails:
            hits = glob.glob(os.path.join(ROOT, "**", name, "results.json"),
                             recursive=True)
            (recovered if hits else still).append((dt, name, hits[:1]))
        for dt, name, _ in still[:10]:
            print(f"      FAIL {dt}min  {name}")
        if recovered:
            print(f"    ... of the {len(fails)} logged FAILs, {len(recovered)} "
                  f"are now RECOVERED (result file exists):")
            for dt, name, hp in recovered:
                print(f"      ok   {name}  -> {os.path.relpath(hp[0], ROOT)}")
        if still:
            problems.append(f"{len(still)} job(s) still missing a result file")

    # 3 -------------------------------------------------------------------
    print("\n[3] the 4 new/repaired baselines (expect 2x5 = 10 each)")
    for meth in NEW_METHODS:
        got, aucs = [], []
        for a in ALPHAS:
            for s in SEEDS:
                p = os.path.join("results_baseline", f"{meth}_iotid20_alpha{a}_seed{s}",
                                 "results.json")
                if os.path.exists(p):
                    got.append(p)
                    aucs.append(auc_of(load_result(p)))
        print(f"    {meth:12s} {len(got):2d}/10   AUC {_fmt(aucs)}")
        if len(got) < 10:
            problems.append(f"{meth}: only {len(got)}/10 results")
        # compression ratio -- essential for an apples-to-apples claim
        if meth == "topk_qsgd" and got:
            d = load_result(got[0]) or {}
            cr = find_cr(d)
            print(f"      top-level keys : {sorted(d)[:12]}")
            if cr:
                for k, v in list(cr.items())[:8]:
                    print(f"      CR-ish {k} = {v}")
            else:
                print("      !! no CR/communication field found -- check how topk_qsgd "
                      "records its budget (must be matched to NSAC's CR~=0.088)")
                problems.append("topk_qsgd: no compression-ratio field found")

    # 4 -------------------------------------------------------------------
    print("\n[4] epsilon sweep (expect 7 epsilons x 2 alphas x 5 seeds = 70)")
    by_eps = defaultdict(list)
    old_grid = []
    for dname in sorted(glob.glob(os.path.join("results_eps", "*"))):
        m = re.match(r"epsweep_eps([\d.]+)_alpha([\d.]+)_seed(\d+)$",
                     os.path.basename(dname))
        if not m:
            continue
        e = float(m.group(1))
        p = os.path.join(dname, "results.json")
        if os.path.exists(p):
            by_eps[e].append(auc_of(load_result(p)))
        if e in EPS_OLD:
            old_grid.append(e)
    for e in sorted(by_eps):
        print(f"    eps={e:<7g} n={len(by_eps[e]):2d}   AUC {_fmt(by_eps[e])}")
    if old_grid:
        problems.append(f"obsolete epsilon values still present: {sorted(set(old_grid))}")
    if len(by_eps) < 7:
        problems.append(f"epsilon sweep: only {len(by_eps)}/7 epsilons present")

    # 5 -------------------------------------------------------------------
    print("\n[5] sentinel scan on every new result file")
    bad = []
    for pat in ("results_baseline/*/results.json", "results_eps/*/results.json",
                "results_ablation/*/results.json"):
        for p in glob.glob(os.path.join(ROOT, pat)):
            d = load_result(p)
            if d is None:
                bad.append((p, "unreadable json"))
                continue
            a = auc_of(d)
            if a is None:
                bad.append((p, "final_metrics.auc_roc missing/not numeric"))
            elif a <= 0.0 or a > 1.0:
                bad.append((p, f"auc_roc={a}"))
    if bad:
        for p, why in bad[:12]:
            print(f"    !! {os.path.relpath(p, ROOT)}  <- {why}")
        problems.append(f"{len(bad)} malformed/sentinel result file(s)")
    else:
        print("    clean (no missing / 0.0 / out-of-range auc_roc)")

    # 6 -------------------------------------------------------------------
    print("\n[6] baseline table, from results_baseline/  (both alphas)")
    by_a = defaultdict(lambda: defaultdict(list))
    for dname in sorted(glob.glob(os.path.join("results_baseline", "*"))):
        if not os.path.isdir(dname):
            continue
        m = re.match(r"(.+)_iotid20_alpha([\d.]+)_seed(\d+)$", os.path.basename(dname))
        if not m:
            continue
        p = os.path.join(dname, "results.json")
        if os.path.exists(p):
            by_a[float(m.group(2))][m.group(1)].append(auc_of(load_result(p)))
    alphas = sorted(by_a)
    ref = max(alphas, key=lambda a: sum(len(v) for v in by_a[a].values())) if alphas else None
    meths = sorted({m for a in alphas for m in by_a[a]},
                   key=lambda m: -(sum(x for x in by_a[ref][m] if x is not None)
                                   / max(1, len([x for x in by_a[ref][m] if x is not None]))))
    print("    %-20s" % "method" + "".join(f"{'alpha=' + str(a):>20}" for a in alphas))
    for meth in meths:
        line = "    %-20s" % meth
        for a in alphas:
            v = [x for x in by_a[a].get(meth, []) if x is not None]
            line += (f"{sum(v)/len(v):>10.4f}(n={len(v)})" if v else f"{'--':>20}")
        print(line)

    # 7 -------------------------------------------------------------------
    print("\n[7] tables file")
    tp = os.path.join("results_summary", "TABLES.md")
    if os.path.exists(tp):
        txt = open(tp, encoding="utf-8", errors="replace").read()
        tbd = [ln.strip() for ln in txt.splitlines() if "TBD" in ln]
        # the sensitivity-weight ablation (| w_*) is intentionally skipped -> info only
        tbd_w = [ln for ln in tbd if ln.startswith("| w_")]
        tbd_hard = [ln for ln in tbd if not ln.startswith("| w_")]
        print(f"    TBD rows: {len(tbd)}  (of which {len(tbd_w)} are the intentionally "
              f"skipped weight-ablation rows)")
        for ln in tbd_hard[:6]:
            print(f"    !! {ln[:70]}")
        if len(tbd_hard) > 6:
            print(f"    !! ... and {len(tbd_hard) - 6} more")
        if tbd_hard:
            problems.append(f"TABLES.md still has {len(tbd_hard)} real TBD row(s)")
    else:
        problems.append("results_summary/TABLES.md missing")

    bar("=")
    if problems:
        print("  VERDICT: NOT READY -- fix these first:")
        for p in dict.fromkeys(problems):
            print(f"    - {p}")
    else:
        print("  VERDICT: S2 CLEAN -- every required cell is present,")
        print("           no sentinels, no obsolete epsilon values.")
        print("           -> next: seed 6-7 for the key tables, then Gotham + TII.")
    bar("=")
    return 1 if problems else 0


def _fmt(vals):
    vals = [v for v in vals if v is not None]
    if not vals:
        return "(none)"
    mu = sum(vals) / len(vals)
    if len(vals) == 1:
        return f"{mu:.4f}"
    sd = (sum((v - mu) ** 2 for v in vals) / len(vals)) ** 0.5
    return f"{mu:.4f}+-{sd:.4f} (n={len(vals)})"


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
