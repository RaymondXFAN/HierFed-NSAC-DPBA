#!/usr/bin/env bash
# =============================================================================
# run_multids.sh -- 多数据集（Gotham 2025 / TII-SSRC-23）一键实验
# EN: run_multids.sh -- one-click experiment across multiple datasets (Gotham 2025 / TII-SSRC-23)
#
#   bash run_multids.sh smoke  gotham25     # 5 分钟预检：数据+算法+存盘（前台，看输出） | EN: 5-minute pre-check: data + algorithm + saving to disk (foreground, watch the output)
#   bash run_multids.sh eps    gotham25     # ε 扫描（1 seed，用来定标噪声档位） | EN: ε sweep (1 seed, to calibrate the noise level)
#   bash run_multids.sh main   gotham25     # 主实验：proposed 5 seed + 基线 5 seed | EN: main experiment: proposed 5 seeds + baselines 5 seeds
#   bash run_multids.sh native gotham25     # 原生设备分区（仅 Gotham 有） | EN: native device partition (Gotham only)
#   bash run_multids.sh status              # 非阻塞查看进度 | EN: non-blocking progress check
#
# 环境变量: PROJ / PY / PARALLEL(默认4) / SEEDS / ALPHA / EPS_LIST / SKIP_GUARD
# EN: Env vars: PROJ / PY / PARALLEL (default 4) / SEEDS / ALPHA / EPS_LIST / SKIP_GUARD
# 幂等: 每个 task 成功后写 logs/.done_<tag>，重跑自动跳过。
# EN: Idempotent: each task writes logs/.done_<tag> on success, and reruns skip it automatically.
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
PARALLEL=${PARALLEL:-4}
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-8}
SEEDS=${SEEDS:-"1 2 3 4 5"}
ALPHA=${ALPHA:-0.5}
EPS_LIST=${EPS_LIST:-"100 200 300 400 700 1500"}
OUT=${OUT:-results_mds}

cd "$PROJ" || { echo "ERROR: 项目目录不存在: $PROJ"; exit 1; }
mkdir -p logs "$OUT"

n_run() {
  pgrep -f 'run_experiment\.py|run_baselines\.py|run_epsilon_sweep\.py' 2>/dev/null \
    | grep -vx -e "$$" -e "${PPID:-0}" | wc -l
}

guard() {
  [ "${SKIP_GUARD:-0}" = "1" ] && { echo "[guard] SKIP_GUARD=1，跳过检查"; return; }
  local n; n=$(n_run)
  if [ "$n" -gt 0 ]; then
    echo "!! 检测到 $n 个训练进程正在运行（很可能是 IoTID20 的 289 批次）"
    echo "   为避免抢显存，先等它结束；急用可加 SKIP_GUARD=1 强制启动。"
    echo "   当前进度："
    tail -n 3 logs/parallel_A2.log 2>/dev/null || echo "   (找不到 logs/parallel_A2.log)"
    exit 1
  fi
  echo "[guard] GPU 空闲 ✓"
}

throttle() { while [ "$(n_run)" -ge "$PARALLEL" ]; do sleep 20; done; }

run_one() {                       # run_one <tag> <command ...>
  local tag="$1"; shift
  if [ -f "logs/.done_${tag}" ]; then echo "  [skip] $tag (已完成)"; return 0; fi
  throttle
  echo "  [launch] $tag"
  nohup bash -c "$*; rc=\$?; if [ \$rc -eq 0 ]; then touch logs/.done_${tag}; fi; \
      echo \"[\$(date +%F_%H:%M)] exit=\$rc ${tag}\" >> logs/mds_progress.log" \
      > "logs/${tag}.log" 2>&1 &
}

summary() {
  echo
  echo "==================== 完成情况 ===================="
  echo "  已跑完 task : $(ls logs/.done_* 2>/dev/null | wc -l)"
  echo "  运行中进程 : $(n_run)"
  echo "  results.json: $(find "$OUT" -name results.json 2>/dev/null | wc -l)"
  echo "  最近记录    :"
  tail -n 8 logs/mds_progress.log 2>/dev/null | sed 's/^/    /' || echo "    (暂无)"
  echo "  单任务日志  : logs/<tag>.log   （如 logs/gotham25_prop_s1.log）"
  echo "================================================="
}

case "${1:-}" in
  smoke)
    DS=${2:?用法: bash run_multids.sh smoke <dataset>}
    guard
    echo "[smoke] $DS  T=5 / e_local=1 / seed=1  —— 约 3~5 分钟，前台运行看输出"
    $PY -u run_experiment.py --dataset "$DS" --alpha "$ALPHA" --seed 1 \
        --method proposed --T 5 --e_local 1 --tag smoke --output_dir "${OUT}/${DS}_smoke"
    echo "[smoke] 结束。若上面出现 Final: AUC=... 且 results 目录有 metrics.json → 通过 ✓"
    ;;

  eps)
    DS=${2:?用法: bash run_multids.sh eps <dataset>}; guard
    for e in $EPS_LIST; do
      run_one "${DS}_eps${e}" "HIERFED_DATASET=$DS $PY -u run_epsilon_sweep.py \
        --alpha $ALPHA --seeds 1 --epsilons $e --output_dir ${OUT}/${DS}_eps"
    done
    summary
    ;;

  main)
    DS=${2:?用法: bash run_multids.sh main <dataset>}; guard
    for s in $SEEDS; do
      run_one "${DS}_prop_s${s}" "$PY -u run_experiment.py --dataset $DS --alpha $ALPHA \
        --seed $s --method proposed --tag full --output_dir ${OUT}/${DS}"
    done
    for s in $SEEDS; do
      run_one "${DS}_base_s${s}" "HIERFED_DATASET=$DS $PY -u run_baselines.py \
        --alpha $ALPHA --seeds $s --output_dir ${OUT}/${DS}"
    done
    summary
    ;;

  native)
    DS=${2:?用法: bash run_multids.sh native <dataset>}; guard
    NAT="data/processed/${DS}_partitions_native.json"
    [ -f "$NAT" ] || { echo "!! 找不到 $NAT（该数据集没有原生设备分区）"; exit 1; }
    cp "$NAT" "data/processed/${DS}_partitions_alpha9.0.json"
    echo "[native] 已把原生设备分区伪装成 alpha=9.0"
    for s in $SEEDS; do
      run_one "${DS}_native_s${s}" "$PY -u run_experiment.py --dataset $DS --alpha 9.0 \
        --seed $s --method proposed --tag native --output_dir ${OUT}/${DS}"
    done
    summary
    ;;

  status)
    summary
    ;;

  *)
    sed -n '3,12p' "$0"
    ;;
esac

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
