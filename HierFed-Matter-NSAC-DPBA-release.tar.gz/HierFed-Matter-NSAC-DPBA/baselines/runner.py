"""
Baseline methods for experimental comparison (Table 3):

1. FedAvg      - Standard star-topology FL, no DP, no compression
2. FedProx     - Proximal-regularized FL (μ parameter for non-IID)
3. HierFed     - Hierarchical FL (same topology as proposed, no DP/NSAC)
4. DP-FedAvg   - Star-topology FL with uniform DP noise (ε=3)
5. DP-Fed6G    - Star-topology FL with adaptive DP (ε=3)
6. Top-k+QSGD  - Star-topology FL with uniform Top-k compression
7. SAFEL-IoT   - Star-topology FL with adaptive DP + explainability
8. FedProx-DP  - FedProx + uniform DP (ε=3)
9. HierFed+DP  - Hierarchical FL + uniform DP (ε=3) — key baseline for isolating DPBA-FIM
"""

import os
import json
import math

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List
from models.dnn import build_model
from core.hierfed import star_aggregate, edge_aggregate, core_aggregate
from core.nsac import SLICE_CONFIGS, nsac_compress, nsac_decompress
from core.dpba_fim import clip_gradient, inject_dp_noise, inject_dp_noise_rdp, compute_noise_scale_rdp

# ============================================================
# GPU Support
# ============================================================
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
if torch.cuda.is_available():
    print(f"[GPU] Using {torch.cuda.get_device_name()} | "
          f"VRAM={torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB")
else:
    print("[GPU] No GPU available, running on CPU")


# ============================================================
# FedAvg (standard star-topology, no DP)
# ============================================================
def run_fedavg(config: dict) -> Dict:
    """FedAvg baseline: star-topology, no DP, no compression."""
    # Load data first to get correct feature_dim
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    model = model.to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 20)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    E_local = config.get('E_local', 5)
    batch_size = config.get('batch_size', 32)
    oversample = config.get('oversample_minority', False)

    round_metrics = []
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    E_local, batch_size, eta, oversample=oversample)
            device_gradients[dev_id] = gradient

        # Star aggregation
        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[FedAvg] Round {t}: AUC={metrics['auc_roc']:.4f}, macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[FedAvg] Final: AUC={final['auc_roc']:.4f}, macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# FedProx (proximal-regularized)
# ============================================================
def run_fedprox(config: dict, mu: float = 0.01) -> Dict:
    """FedProx: adds proximal term μ/2 × ‖w - w_global‖² to local loss."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    model = model.to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 20)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    oversample = config.get('oversample_minority', False)

    round_metrics = []
    for t in range(1, T + 1):
        global_params = _get_flat_params(model)
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train_fedprox(
                model, X_train[idx_list], y_train[idx_list],
                global_params, mu, config, oversample=oversample
            )
            device_gradients[dev_id] = gradient

        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[FedProx] Round {t}: AUC={metrics['auc_roc']:.4f}, macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[FedProx] Final: AUC={final['auc_roc']:.4f}, macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


def _local_train_fedprox(model, X, y, global_params, mu, config, oversample=False):
    """Local train with proximal regularization."""
    initial_params = _get_flat_params(model)
    E = config.get('E_local', 5)
    bs = config.get('batch_size', 32)
    eta = config.get('eta', 0.01)

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=eta)
    X_t = torch.tensor(X, dtype=torch.float32).to(DEVICE)
    y_t = torch.tensor(y, dtype=torch.long).to(DEVICE)

    # Store global params per layer for proximal gradient addition
    global_params_per_layer = [p.data.clone() for p in model.parameters()]

    model.train()
    for epoch in range(E):
        indices = torch.randperm(len(y_t))
        for start in range(0, len(y_t), bs):
            batch_x = X_t[indices[start:start+bs]]
            batch_y = y_t[indices[start:start+bs]]
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            # Proximal gradient: add μ × (w - w_global) to each parameter's grad
            # This is the CORRECT implementation — previous version used flat params
            # with .data.clone().flatten() which disconnected the compute graph,
            # making the proximal term have zero effect on gradients.
            for p, gp in zip(model.parameters(), global_params_per_layer):
                if p.grad is not None:
                    p.grad += mu * (p.data - gp.to(DEVICE))
            optimizer.step()

    final_params = _get_flat_params(model)
    # Reset model to global params
    _set_flat_params(model, global_params)
    return final_params - initial_params


# ============================================================
# DP-FedAvg (uniform DP, ε=3)
# ============================================================
def run_dpfedavg(config: dict) -> Dict:
    """DP-FedAvg: star-topology + uniform DP noise at ε=3."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 20)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    eps = float(config.get('epsilon_total', 3.0))
    delta = float(config.get('delta', 1e-5))
    C = float(config.get('clip_norm', 1.0))
    oversample = config.get('oversample_minority', False)

    # RDP composition: compute σ from total ε, T, δ (not naive ε/T)
    # σ≈12 for ε=3, T=50 → model still fails → supports our "uniform DP fails" narrative
    sigma = compute_noise_scale_rdp(eps, T, delta, C)
    print(f"[DP-FedAvg] RDP σ={sigma:.2f} (ε={eps}, T={T}, δ={delta})")
    round_metrics = []

    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta, oversample=oversample)
            # Uniform DP via RDP composition: same σ for all devices
            clipped = clip_gradient(gradient, C)
            noise = torch.randn_like(clipped) * sigma
            noisy = clipped + noise
            device_gradients[dev_id] = noisy

        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[DP-FedAvg] Round {t}: AUC={metrics['auc_roc']:.4f}, macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[DP-FedAvg] Final: AUC={final['auc_roc']:.4f}, macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# HierFed (hierarchical, no DP/NSAC)
# ============================================================
def run_hierfed(config: dict) -> Dict:
    """HierFed: hierarchical aggregation, no DP, no NSAC compression."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 20)
    M = config.get('M', 4)
    K = config.get('K', 5)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    oversample = config.get('oversample_minority', False)

    cluster_map = {gw: list(range(gw*K, min(gw*K+K, N))) for gw in range(M)}

    round_metrics = []
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta, oversample=oversample)
            device_gradients[dev_id] = gradient

        global_params = _get_flat_params(model)
        # Hierarchical aggregation without compression
        edge_updates = edge_aggregate(device_gradients, cluster_map,
                                       global_params, eta)
        new_params = core_aggregate(edge_updates, global_params)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[HierFed] Round {t}: AUC={metrics['auc_roc']:.4f}, macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[HierFed] Final: AUC={final['auc_roc']:.4f}, macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# HierFed + uniform DP (ε=3) — key ablation baseline
# ============================================================
def run_hierfed_dp(config: dict) -> Dict:
    """HierFed + uniform DP: isolates DPBA-FIM's contribution."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N, M, K = config.get('N', 20), config.get('M', 4), config.get('K', 5)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    eps = float(config.get('epsilon_total', 3.0))
    delta = float(config.get('delta', 1e-5))
    C = float(config.get('clip_norm', 1.0))
    oversample = config.get('oversample_minority', False)

    cluster_map = {gw: list(range(gw*K, min(gw*K+K, N))) for gw in range(M)}
    # RDP composition: compute σ from total ε, T, δ (not naive ε/T)
    # σ≈12 for ε=3, T=50 → hierarchical + uniform DP still fails
    sigma = compute_noise_scale_rdp(eps, T, delta, C)
    print(f"[HierFed+DP] RDP σ={sigma:.2f} (ε={eps}, T={T}, δ={delta})")
    round_metrics = []
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta, oversample=oversample)
            # Uniform DP via RDP composition (same σ for all devices, no FIM weighting)
            clipped = clip_gradient(gradient, C)
            noise = torch.randn_like(clipped) * sigma
            noisy = clipped + noise
            device_gradients[dev_id] = noisy

        global_params = _get_flat_params(model)
        edge_updates = edge_aggregate(device_gradients, cluster_map,
                                       global_params, eta)
        new_params = core_aggregate(edge_updates, global_params)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[HierFed+DP] Round {t}: AUC={metrics['auc_roc']:.4f}, macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[HierFed+DP] Final: AUC={final['auc_roc']:.4f}, macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}
def run_topk_qsgd(config: dict) -> Dict:
    """Top-k + QSGD: star-topology FL with uniform Top-k compression.

    [fix_v10]
      (a) every per-device update is moved to DEVICE before aggregation --
          nsac_decompress() returns a CPU tensor, which used to clash with the
          GPU zero-fill for empty partitions under extreme Dirichlet alpha;
      (b) empty / non-finite partitions are counted, never silently dropped;
      (c) the realised compression budget is recorded so that NSAC and this
          baseline can be compared at a matched compression ratio.
    """
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]
    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 50)
    T = config.get('T', 100)
    eta = config.get('eta', 0.01)

    # Uniform compression: eMBB slice config (moderate budget)
    slice_config = SLICE_CONFIGS['embb']
    slice_name = getattr(slice_config, 'name', 'eMBB')

    bytes_full_round = N * d * 4      # fp32, all N devices, one round
    bytes_sent = 0
    n_empty = 0
    n_nonfinite = 0
    cr_last = float('nan')

    round_metrics = []
    for t in range(1, T + 1):
        bytes_round = 0
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                # no local data -> contributes a zero update (kept, not dropped)
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                n_empty += 1
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta)
            if not bool(torch.isfinite(gradient).all()):
                n_nonfinite += 1
                print(f"  [Top-k+QSGD][warn] round {t} dev {dev_id}: non-finite "
                      f"gradient (n_local={len(idx_list)}) -> zeroed")
                gradient = torch.nan_to_num(gradient, nan=0.0, posinf=0.0, neginf=0.0)

            try:
                compressed = nsac_compress(gradient, slice_config, adaptive_down=False)
                decompressed = nsac_decompress(compressed, d)
            except Exception as exc:
                raise RuntimeError(
                    f"run_topk_qsgd: compress/decompress failed at round {t}, "
                    f"device {dev_id} (n_local={len(idx_list)}, "
                    f"grad_shape={tuple(gradient.shape)}, "
                    f"grad_norm={float(gradient.norm()):.6g}, slice={slice_name}): "
                    f"{type(exc).__name__}: {exc}"
                ) from exc

            bytes_round += int(compressed.get('compressed_bytes', 0))
            cr_last = float(compressed.get('CR_actual', float('nan')))
            # (a) force onto DEVICE so the whole dict is device-consistent
            device_gradients[dev_id] = decompressed.to(DEVICE).float()

        bytes_sent += bytes_round
        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t,
                              'bytes_round': bytes_round,
                              'bytes_full_round': bytes_full_round,
                              'cr_round': (bytes_round / bytes_full_round)
                              if bytes_full_round else float('nan'),
                              **metrics})

        if t % 10 == 0:
            print(f"[Top-k+QSGD] Round {t}: F1={metrics['f1']:.4f} "
                  f"bytes={bytes_round}")

    final = _evaluate(model, X_test, y_test)
    full_total = bytes_full_round * T
    final.update({
        # --- (c) auditable compression budget ---
        'comm_bytes_total': bytes_sent,
        'comm_bytes_full_fp32': full_total,
        'compression_ratio_empirical': (bytes_sent / full_total) if full_total else float('nan'),
        'compression_factor_empirical': (full_total / bytes_sent) if bytes_sent else float('nan'),
        'cr_actual_last_round': cr_last,
        'k_ratio_nominal': slice_config.k_ratio,
        'b_bits_nominal': slice_config.b_bits,
        'slice_used': slice_name,
        'n_devices': N,
        'n_empty_device_rounds': n_empty,
        'n_nonfinite_device_rounds': n_nonfinite,
    })
    cf = (full_total / bytes_sent) if bytes_sent else float('nan')
    print(f"[Top-k+QSGD] done: bytes={bytes_sent} full={full_total} "
          f"CF={cf:.2f}x  empty={n_empty}  nonfinite={n_nonfinite}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# SAFEL-IoT (simplified: adaptive DP without FIM)
# ============================================================
def run_safeliot(config: dict) -> Dict:
    """SAFEL-IoT: adaptive DP (not FIM-weighted), star-topology."""
    # Simplified implementation: adaptive noise based on data sensitivity
    # but uniform across layers (no FIM weighting)
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 50)
    T = config.get('T', 100)
    eta = config.get('eta', 0.01)
    eps = config.get('epsilon_total', 3.0)
    delta = config.get('delta', 1e-5)
    C = config.get('clip_norm', 1.0)


    # Adaptive DP via RDP composition: compute base σ for total ε, then
    # scale per-device σ by data sensitivity (more sensitive → less noise)
    sigma_map = {'camera': 1.0, 'thermostat': 0.3, 'bulb': 0.1}
    sigma_base = compute_noise_scale_rdp(float(eps), T, float(delta), float(C))

    round_metrics = []

    # --- budget-neutral sensitivity rescale -------------------------------
    _fac = []
    for _d in range(N):
        _n = len(partitions.get(str(_d), []))
        _fac.append(1.0 - 0.5 * min(_n, 200) / 200.0)
    _rms = (sum(_f * _f for _f in _fac) / max(1, len(_fac))) ** 0.5
    _sens_rescale = (1.0 / _rms) if _rms > 0 else 1.0
    print(f"[SAFEL-IoT] sigma_base={sigma_base:.4f} sens_rescale={_sens_rescale:.3f} "
          f"(mean sigma^2 normalised to sigma_base^2)")
    # ---------------------------------------------------------------------
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta)
            # Adaptive σ: scale by device data sensitivity
            n_i = len(idx_list)
            # More sensitive devices → less noise (smaller σ multiplier)
            sensitivity_factor = 1.0 - 0.5 * min(n_i, 200) / 200
            device_sigma = sigma_base * sensitivity_factor * _sens_rescale
            clipped = clip_gradient(gradient, C)
            noise = torch.randn_like(clipped) * device_sigma
            noisy = clipped + noise
            device_gradients[dev_id] = noisy

        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[SAFEL-IoT] Round {t}: F1={metrics['f1']:.4f}")

    final = _evaluate(model, X_test, y_test)
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# DP-Fed6G (adaptive DP for 6G)
# ============================================================
def run_dpfed6g(config: dict) -> Dict:
    """DP-Fed6G: adaptive DP with convergence-aware budget, star-topology."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 50)
    T = config.get('T', 100)
    eta = config.get('eta', 0.01)
    eps = config.get('epsilon_total', 3.0)
    delta = config.get('delta', 1e-5)
    C = config.get('clip_norm', 1.0)


    # Convergence-aware RDP composition: compute base σ for total ε,
    # then scale per-round σ by convergence factor (early rounds → more noise)
    sigma_base = compute_noise_scale_rdp(float(eps), T, float(delta), float(C))
    round_metrics = []

    # --- budget-neutral convergence-aware schedule -----------------------
    # raw weight w_t = 1/decay(t), rescaled so mean(w_t^2) == 1, i.e. the total
    # RDP budget is the same as the flat sigma_base this nominal epsilon implies.
    _raw = []
    for _t in range(1, T + 1):
        _dec = max(1e-3, min(1.0, _t / (T * 0.3)))
        _raw.append(1.0 / _dec)
    _scale = (sum(_x * _x for _x in _raw) / len(_raw)) ** 0.5
    _sigma_sched = [sigma_base * (_x / _scale) for _x in _raw]
    print(f"[DP-Fed6G] sigma_base={sigma_base:.4f} schedule_rescale={_scale:.2f} "
          f"sigma[1]={_sigma_sched[0]:.4f} sigma[T]={_sigma_sched[-1]:.4f}")
    # --------------------------------------------------------------------
    for t in range(1, T + 1):
        # Convergence-aware σ: early rounds need more noise (less budget),
        # later rounds get less noise (more budget).
        device_sigma = _sigma_sched[t - 1]

        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta)
            clipped = clip_gradient(gradient, C)
            noise = torch.randn_like(clipped) * device_sigma
            noisy = clipped + noise
            device_gradients[dev_id] = noisy

        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[DP-Fed6G] Round {t}: F1={metrics['f1']:.4f}")

    final = _evaluate(model, X_test, y_test)
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# FedProx-DP (FedProx + uniform DP)
# ============================================================
def run_fedprox_dp(config: dict, mu: float = 0.01) -> Dict:
    """FedProx-DP: FedProx with uniform DP noise."""
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 50)
    T = config.get('T', 100)
    eta = config.get('eta', 0.01)
    eps = config.get('epsilon_total', 3.0)
    delta = config.get('delta', 1e-5)
    C = config.get('clip_norm', 1.0)


    # RDP composition: compute σ from total ε over T rounds (same as DP-FedAvg)
    sigma = compute_noise_scale_rdp(float(eps), T, float(delta), float(C))
    round_metrics = []

    for t in range(1, T + 1):
        global_params = _get_flat_params(model)
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train_fedprox(model, X_train[idx_list],
                                            y_train[idx_list],
                                            global_params, mu, config)
            clipped = clip_gradient(gradient, C)
            noise = torch.randn_like(clipped) * sigma
            noisy = clipped + noise
            device_gradients[dev_id] = noisy

        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})

        if t % 10 == 0:
            print(f"[FedProx-DP] Round {t}: F1={metrics['f1']:.4f}")

    final = _evaluate(model, X_test, y_test)
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# Adaptive-clipping DP (AdaClip-style) — modern adaptive-DP baseline
# ============================================================
def run_adaptive_clip_dp(config: dict) -> Dict:
    """
    Adaptive-clipping DP-FedAvg (Andrew et al., 2021 style).

    Each device maintains an EMA of its own update norm and clips with a
    device-specific bound C_i = clip(EMA_i, C_min, C_max); Gaussian noise is then
    scaled by C_i. This adapts the *clipping* to the data (unlike DPBA-FIM, which
    adapts noise via Fisher information) and is a strong adaptive-DP baseline.
    """
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 20)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    eps = float(config.get('epsilon_total', 3.0))
    delta = float(config.get('delta', 1e-5))
    C = float(config.get('clip_norm', 1.0))
    oversample = config.get('oversample_minority', False)

    beta_clip = float(config.get('adaptive_clip_beta', 0.2))
    C_min, C_max = 0.1 * C, 3.0 * C
    # noise per unit clipping norm, via RDP composition
    sigma_mult = compute_noise_scale_rdp(eps, T, delta, 1.0)
    print(f"[AdaptiveClip-DP] sigma(per unit C)={sigma_mult:.3f}, C in [{C_min:.2f},{C_max:.2f}]")

    dev_clip = {i: C for i in range(N)}
    round_metrics = []
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta, oversample=oversample)
            raw_norm = float(gradient.norm())
            dev_clip[dev_id] = (1 - beta_clip) * dev_clip[dev_id] + beta_clip * raw_norm
            C_i = float(min(max(dev_clip[dev_id], C_min), C_max))
            clipped = clip_gradient(gradient, C_i)
            noise = torch.randn_like(clipped) * (sigma_mult * C_i)
            device_gradients[dev_id] = clipped + noise

        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})
        if t % 10 == 0:
            _cm = sum(dev_clip.values())/len(dev_clip)
            print(f"[C-i] Round {t}: mean_C_i={_cm:.4f} min={min(dev_clip.values()):.4f} max={max(dev_clip.values()):.4f}")
            print(f"[AdaptiveClip-DP] Round {t}: AUC={metrics['auc_roc']:.4f}, "
                  f"macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[AdaptiveClip-DP] Final: AUC={final['auc_roc']:.4f}, "
          f"macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# Layer-adaptive DP (per-layer clipping / budget) — adaptive-DP baseline
# ============================================================
def run_layer_adaptive_dp(config: dict) -> Dict:
    """
    Layer-adaptive DP-FedAvg (per-layer clipping + per-layer noise).

    The flat gradient is split into its parameter tensors; each group is clipped
    with C/sqrt(L) and perturbed with per-layer Gaussian noise. This shares
    DPBA-FIM's "not all parameters are equally important" motivation but uses no
    Fisher information (i.e. it is layer- but not information-aware).
    """
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]

    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    shapes = [p.numel() for p in model.parameters()]
    L = len(shapes)
    N = config.get('N', 20)
    T = config.get('T', 50)
    eta = config.get('eta', 0.01)
    eps = float(config.get('epsilon_total', 3.0))
    delta = float(config.get('delta', 1e-5))
    C = float(config.get('clip_norm', 1.0))
    oversample = config.get('oversample_minority', False)

    C_layer = C / math.sqrt(L)
    sigma_layer = compute_noise_scale_rdp(eps, T, delta, C_layer)
    print(f"[LayerAdaptive-DP] L={L}, C_layer={C_layer:.4f}, sigma_layer={sigma_layer:.3f}")

    round_metrics = []
    for t in range(1, T + 1):
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta, oversample=oversample)
            off = 0
            segs = []
            for size in shapes:
                seg = gradient[off:off + size]
                off += size
                seg = clip_gradient(seg, C_layer)
                segs.append(seg + torch.randn_like(seg) * sigma_layer)
            device_gradients[dev_id] = torch.cat(segs)

        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t, **metrics})
        if t % 10 == 0:
            print(f"[LayerAdaptive-DP] Round {t}: AUC={metrics['auc_roc']:.4f}, "
                  f"macro-F1={metrics['f1_macro']:.4f}")

    final = _evaluate(model, X_test, y_test)
    print(f"\n[LayerAdaptive-DP] Final: AUC={final['auc_roc']:.4f}, "
          f"macro-F1={final['f1_macro']:.4f}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


# ============================================================
# Helper functions
# ============================================================
def _get_flat_params(model):
    return torch.cat([p.data.clone().flatten() for p in model.parameters()])

def _set_flat_params(model, flat_params):
    idx = 0
    with torch.no_grad():
        for p in model.parameters():
            size = p.numel()
            p.data.copy_(flat_params[idx:idx+size].reshape(p.shape))
            idx += size

def _local_train(model, X, y, E_local, batch_size, lr, oversample=False):
    """Standard local training returning gradient (Δw). oversample defaults to False for baselines."""
    from core.simulator import local_train
    return local_train(model, X, y, E_local, batch_size, lr, oversample=oversample)

def _evaluate(model, X_test, y_test):
    """Full evaluation on test set with threshold optimization (matches simulator)."""
    from sklearn.metrics import f1_score, accuracy_score, roc_auc_score
    model.eval()
    X_t = torch.tensor(X_test, dtype=torch.float32).to(DEVICE)
    with torch.no_grad():
        outputs = model(X_t)
        probs = torch.softmax(outputs, dim=1)
        preds_default = outputs.argmax(dim=1).cpu().numpy()

    y_true = y_test
    y_prob = probs[:, 1].cpu().numpy()  # P(class=1)

    # Threshold optimization: find threshold that maximizes F1
    best_f1 = 0.0
    best_thresh = 0.5
    for thresh in np.arange(0.05, 0.95, 0.05):
        preds_t = (y_prob >= thresh).astype(int)
        f1_t = f1_score(y_true, preds_t, zero_division=0)
        if f1_t > best_f1:
            best_f1 = f1_t
            best_thresh = thresh

    preds_optimal = (y_prob >= best_thresh).astype(int)
    f1_optimal = best_f1
    acc_optimal = accuracy_score(y_true, preds_optimal)

    f1_default = f1_score(y_true, preds_default, zero_division=0)
    acc_default = accuracy_score(y_true, preds_default)

    f1_macro = f1_score(y_true, preds_optimal, average='macro', zero_division=0)

    try:
        auc = roc_auc_score(y_true, y_prob)
    except ValueError:
        # [FIX B3] NaN sentinel instead of a fake 0.0 (see README_FIX.md)
        auc = float('nan')

    return {
        'f1': f1_optimal,
        'f1_default': f1_default,
        'f1_macro': f1_macro,
        'accuracy': acc_optimal,
        'accuracy_default': acc_default,
        'auc_roc': auc,
        'optimal_threshold': best_thresh,
    }

def _resolve_prefix(processed_dir, ds):
    """Map a dataset name to the prefix of its npz files.

    The historical code used `'iotid20' if ds == 'iotid20' else 'cicids'`, which
    sends every other dataset (gotham25, tii23, ...) looking for cicids_*.npz.
    Prefer the dataset's own name when such a file exists.
    """
    if os.path.exists(os.path.join(processed_dir, f'{ds}_test.npz')):
        return ds
    if os.path.exists(os.path.join(processed_dir, f'{ds}_train.npz')):
        return ds
    return 'iotid20' if ds == 'iotid20' else 'cicids'


def _load_partitioned_data(config):
    """Load train data and Dirichlet partition for current α and N (matches simulator logic)."""
    import json
    from data.preprocess import dirichlet_partition

    processed_dir = config.get('processed_dir', 'data/processed')
    ds = config.get('dataset_name', 'iotid20')
    alpha = config.get('alpha', 0.5)
    N = config.get('N', 20)
    prefix = _resolve_prefix(processed_dir, ds)
    train = np.load(os.path.join(processed_dir, f'{prefix}_train.npz'))
    X_train = train['X']
    y_train = train['y']

    # Try per-α partition file first (same logic as simulator.py)
    per_alpha_file = os.path.join(processed_dir, f'{prefix}_partitions_alpha{alpha}.json')
    generic_file = os.path.join(processed_dir, f'{prefix}_partitions.json')

    partitions = None
    if os.path.exists(per_alpha_file):
        with open(per_alpha_file, 'r', encoding='utf-8') as f:
            part_data = json.load(f)
        partitions = part_data['device_indices']
        print(f"[Partition] Loaded per-α file: α={alpha}")
    elif os.path.exists(generic_file):
        with open(generic_file, 'r', encoding='utf-8') as f:
            part_data = json.load(f)
        file_alpha = part_data.get('alpha', None)
        if file_alpha == alpha:
            partitions = part_data['device_indices']
            print(f"[Partition] Loaded generic file (α matches: {alpha})")
        else:
            print(f"[Partition] ⚠ Generic file α={file_alpha} ≠ config α={alpha}, regenerating...")

    if partitions is None:
        # Generate using dirichlet_partition with fixed seed=1 (same as simulator)
        partition_seed = 1
        partitions = dirichlet_partition(y_train, N, alpha, partition_seed)
        # Convert to string keys for JSON compatibility
        partitions = {str(k): v for k, v in partitions.items()}
        # Save per-α file for reuse
        save_data = {
            'N': N, 'alpha': alpha, 'seed': partition_seed,
            'device_indices': partitions,
        }
        os.makedirs(processed_dir, exist_ok=True)
        with open(per_alpha_file, 'w', encoding='utf-8') as f:
            json.dump(save_data, f, indent=2)
        print(f"[Partition] Saved new per-α file: {per_alpha_file}")

    return X_train, y_train, partitions

def _load_test_data(config):
    processed_dir = config.get('processed_dir', 'data/processed')
    ds = config.get('dataset_name', 'iotid20')
    prefix = _resolve_prefix(processed_dir, ds)
    test = np.load(os.path.join(processed_dir, f'{prefix}_test.npz'))
    return test['X'], test['y']


# ============================================================
# Baseline runner dispatcher
# ============================================================
METHOD_MAP = {
    'fedavg': run_fedavg,
    'fedprox': run_fedprox,
    'dpfedavg': run_dpfedavg,
    'hierfed': run_hierfed,
    'hierfed_dp': run_hierfed_dp,
    'topk_qsgd': run_topk_qsgd,
    'safeliot': run_safeliot,
    'dpfed6g': run_dpfed6g,
    'fedprox_dp': run_fedprox_dp,
    'adaptive_clip_dp': run_adaptive_clip_dp,
    'layer_adaptive_dp': run_layer_adaptive_dp,
}

def run_baseline(method: str, config: dict) -> dict:
    """Run a baseline method by name."""
    if method not in METHOD_MAP:
        raise ValueError(f"Unknown baseline method: {method}. "
                         f"Available: {list(METHOD_MAP.keys())}")
    return METHOD_MAP[method](config)


# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
