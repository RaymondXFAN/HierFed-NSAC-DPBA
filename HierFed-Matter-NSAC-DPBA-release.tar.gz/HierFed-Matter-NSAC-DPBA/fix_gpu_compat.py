"""
fix_gpu_compat.py -- make the HierFed codebase CUDA-safe (idempotent).

The original code was only ever executed on CPU and contains a few GPU-unsafe
spots that surface the moment `torch.cuda.is_available()` is True:

  1. `.numpy()` called directly on a CUDA tensor          -> insert `.cpu()`
  2. `nsac_decompress()` builds its output on the CPU     -> honour input device
  3. aggregation mixes CPU (decompressed) and CUDA tensors -> cast to model device

Usage:
    python fix_gpu_compat.py [/root/autodl-tmp/HierFed-Matter-NSAC-DPBA]
"""
import os
import re
import sys

root = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else ".")
SKIP_DIRS = {".git", "__pycache__", ".ipynb_checkpoints"}
SELF = "fix_gpu_compat.py"
n_numpy = 0
n_struct = 0


# ---- 1) `.numpy()` on a CUDA tensor  ->  `.cpu().numpy()` -------------------
# negative lookbehind keeps already-correct `.cpu().numpy()` untouched
NP_RE = re.compile(r"(?<!\.cpu\(\))\.numpy\(\)")
# `model = build_model(...)` that never got moved to the compute device
BM_RE = re.compile(r"(= build_model\([^)]*\))(?!\s*\.to\()")
n_numpy = n_model = 0

for dp, dns, fns in os.walk(root):
    dns[:] = [d for d in dns if d not in SKIP_DIRS and not d.startswith("results")]
    for fn in fns:
        if not fn.endswith(".py") or fn == SELF:
            continue
        p = os.path.join(dp, fn)
        try:
            s = open(p, encoding="utf-8").read()
        except (UnicodeDecodeError, OSError):
            continue
        orig = s
        k_np = k_bm = 0
        if ".numpy()" in s:
            s, k_np = NP_RE.subn(".cpu().numpy()", s)
        # only files that already know about DEVICE (so models/dnn.py __main__ is safe)
        if "DEVICE" in s:
            s, k_bm = BM_RE.subn(r"\1.to(DEVICE)", s)
        if s != orig:
            open(p, "w", encoding="utf-8").write(s)
            n_numpy += k_np
            n_model += k_bm
            print(f"  [gpu] {os.path.relpath(p, root)}"
                  f"   numpy={k_np} model_to_device={k_bm}")


# ---- 2) + 3) targeted device fixes ----------------------------------------
def edit(rel, pairs):
    global n_struct
    p = os.path.join(root, rel)
    if not os.path.isfile(p):
        print(f"  [skip] missing {rel}")
        return
    s = open(p, encoding="utf-8").read()
    o = s
    for a, b in pairs:
        # `b not in s` makes each substitution idempotent: once applied, skip it
        if a in s and b not in s:
            s = s.replace(a, b)
    if s != o:
        open(p, "w", encoding="utf-8").write(s)
        n_struct += 1
        print(f"  [device] {rel}")


edit("core/nsac.py", [
    # nsac_decompress: add a `device` parameter
    ("def nsac_decompress(\n    compressed: Dict,\n    d: int,\n) -> torch.Tensor:",
     "def nsac_decompress(\n    compressed: Dict,\n    d: int,\n    device=None,\n) -> torch.Tensor:"),
    # build the reconstruction on the requested device
    ("    reconstructed = torch.zeros(d, dtype=torch.float32)",
     "    _dev = device if device is not None else torch.device('cpu')\n"
     "    reconstructed = torch.zeros(d, dtype=torch.float32, device=_dev)"),
    ("    reconstructed[indices] = torch.tensor(q_values) * scale",
     "    reconstructed[indices] = torch.as_tensor(\n"
     "        q_values, dtype=torch.float32, device=reconstructed.device) * scale"),
    # keep the degenerate-norm fallback on the gradient's device
    ("        norm = torch.tensor(1.0)",
     "        norm = torch.tensor(1.0, device=gradient.device)"),
])

edit("core/hierfed.py", [
    # decompress onto the same device as the edge update
    ("            decompressed = nsac_decompress(compressed, d)",
     "            decompressed = nsac_decompress(compressed, d, device=delta_w_m.device)"),
    # edge phase: pin to the model device
    ("        delta_w_m = avg_grad",
     "        delta_w_m = avg_grad.to(global_model_params.device)"),
    # core phase: never mix devices
    ("        weighted_sum += K_m * delta_w_m",
     "        weighted_sum += K_m * delta_w_m.to(weighted_sum.device)"),
    # star aggregation safety net
    ("    w_next = global_model_params + avg_grad",
     "    w_next = global_model_params + avg_grad.to(global_model_params.device)"),
])

print(f"[fix_gpu_compat] .numpy() fixes: {n_numpy}   model->device fixes: {n_model}"
      f"   device-graph fixes: {n_struct} file(s) under {root}")
if n_numpy == 0 and n_model == 0 and n_struct == 0:
    print("[fix_gpu_compat] nothing to do (already CUDA-safe)")

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
