"""
run_parallel.py -- parallel driver for the whole supplementary suite (S3).

Runs every experiment as an isolated subprocess, throttled to `--parallel`
concurrent jobs, skipping any job whose results.json already exists (idempotent).
After all jobs finish it rebuilds every aggregate table.

Usage
-----
    python run_parallel.py --parallel 4 --seeds 1 2 3 4 5
    python run_parallel.py --parallel 4 --suites abl base --seeds 1 2 3
    nohup python -u run_parallel.py --parallel 4 > logs/parallel.log 2>&1 &
    python run_parallel.py --dry_run            # list the jobs, run nothing

Why subprocesses (not threads/multiprocess): each job gets a clean CUDA context
and its own memory, and a crash in one job never kills the others.
"""
import os
import sys
import time
import json
import shutil
import argparse
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable

sys.path.insert(0, ROOT)
from ablation_configs import COMPONENT_CONFIGS, WEIGHT_CONFIGS  # noqa: E402

BASELINE_METHODS = [
    "fedavg",
    "fedprox",
    "dpfedavg",
    "hierfed",
    "hierfed_dp",
    "topk_qsgd",
    "safeliot",
    "dpfed6g",
    "fedprox_dp",
    "adaptive_clip_dp",
    "layer_adaptive_dp",
]
EPSILONS = [20.0, 50.0, 100.0, 200.0, 400.0, 800.0, 1600.0]
SCALE_NS = [20, 50, 100]


def ov_to_flags(ov: dict):
    """Turn an override dict into run_experiment.py CLI flags."""
    f = []
    for k, flag in [("disable_dpba_fim", "--disable_dpba_fim"),
                    ("disable_nsac", "--disable_nsac"),
                    ("disable_hierfed", "--disable_hierfed"),
                    ("disable_dp", "--disable_dp")]:
        if ov.get(k):
            f.append(flag)
    for k, flag in [("alpha_s", "--as"), ("beta_s_coeff", "--bs"),
                    ("gamma_s", "--gs"), ("delta_s", "--ds")]:
        if k in ov:
            f += [flag, str(ov[k])]
    return f


def build_jobs(suites, alphas, seeds, T=None, e_local=None):
    jobs = []  # (name, cwd-relative out dir, cmd list, done-relpath)
    exp_extra = []
    if T is not None:
        exp_extra += ["--T", str(T)]
    if e_local is not None:
        exp_extra += ["--e_local", str(e_local)]
    base_T = ["--T", str(T)] if T is not None else []

    if "abl" in suites:
        for tag, (_label, ov) in COMPONENT_CONFIGS.items():
            for a in alphas:
                for s in seeds:
                    name = f"proposed_iotid20_alpha{a}_seed{s}_{tag}"
                    jobs.append((
                        name,
                        [PY, "-u", "run_experiment.py", "--method", "proposed",
                         "--alpha", str(a), "--seed", str(s), "--tag", tag,
                         "--output_dir", "results_ablation"] + ov_to_flags(ov) + exp_extra,
                        os.path.join("results_ablation", name, "results.json")))

    if "weights" in suites:
        for tag, (_label, ov) in WEIGHT_CONFIGS.items():
            for a in alphas:
                for s in seeds:
                    name = f"proposed_iotid20_alpha{a}_seed{s}_{tag}"
                    jobs.append((
                        name,
                        [PY, "-u", "run_experiment.py", "--method", "proposed",
                         "--alpha", str(a), "--seed", str(s), "--tag", tag,
                         "--output_dir", "results_ablation"] + ov_to_flags(ov) + exp_extra,
                        os.path.join("results_ablation", name, "results.json")))

    if "base" in suites:
        for m in BASELINE_METHODS:
            for a in alphas:
                for s in seeds:
                    name = f"{m}_iotid20_alpha{a}_seed{s}"
                    jobs.append((
                        name,
                        [PY, "-u", "run_baselines.py", "--method", m,
                         "--alpha", str(a), "--seeds", str(s), "--skip_aggregate",
                         "--output_dir", "results_baseline"] + base_T,
                        os.path.join("results_baseline", name, "results.json")))

    if "eps" in suites:
        for e in EPSILONS:
            for a in alphas:
                for s in seeds:
                    name = f"epsweep_eps{e}_alpha{a}_seed{s}"
                    jobs.append((
                        name,
                        [PY, "-u", "run_epsilon_sweep.py", "--epsilons", str(e),
                         "--alpha", str(a), "--seeds", str(s), "--skip_aggregate",
                         "--output_dir", "results_eps"],
                        os.path.join("results_eps", name, "results.json")))

    if "scale" in suites:
        # scaling is expensive (N=100); cap at the first 3 seeds
        for N in SCALE_NS:
            for s in seeds[:3]:
                name = f"scale_N{N}_alpha0.5_seed{s}"
                jobs.append((
                    name,
                    [PY, "-u", "run_scale_test.py", "--N", str(N),
                     "--alpha", "0.5", "--seeds", str(s), "--skip_aggregate",
                     "--output_dir", "results_scale"],
                    os.path.join("results_scale", name, "results.json")))
    return jobs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--parallel", type=int, default=4,
                    help="concurrent jobs (default 4; try 6-8 if GPU/CPU idle)")
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    ap.add_argument("--alphas", type=float, nargs="+", default=[0.5, 0.1])
    ap.add_argument("--suites", nargs="+",
                    default=["abl", "weights", "base", "eps", "scale"],
                    choices=["abl", "weights", "base", "eps", "scale"])
    ap.add_argument("--T", type=int, default=None, help="override FL rounds (smoke tests)")
    ap.add_argument("--e_local", type=int, default=None, help="override local epochs")
    ap.add_argument("--dry_run", action="store_true")
    ap.add_argument("--no_aggregate", action="store_true")
    args = ap.parse_args()

    jobs = build_jobs(args.suites, args.alphas, args.seeds,
                      T=args.T, e_local=args.e_local)
    todo = [j for j in jobs if not os.path.exists(j[2])]
    done = len(jobs) - len(todo)

    print(f"[parallel] suites={args.suites} alphas={args.alphas} seeds={args.seeds}")
    print(f"[parallel] total jobs={len(jobs)}  already done={done}  to run={len(todo)}"
          f"  concurrency={args.parallel}")
    if args.dry_run:
        for n, _c, d in todo[:40]:
            print(f"    {n}   -> {d}")
        print(f"    ... ({len(todo)} total)")
        return
    if not todo:
        print("[parallel] nothing to do")
    os.makedirs("logs/jobs", exist_ok=True)

    env = dict(os.environ)
    env.setdefault("OMP_NUM_THREADS", "4")

    def run_job(job):
        name, cmd, done_path = job
        log = os.path.join("logs", "jobs", f"{name}.log")
        t0 = time.time()
        try:
            with open(log, "w", encoding="utf-8") as fh:
                r = subprocess.run(cmd, cwd=ROOT, env=env,
                                   stdout=fh, stderr=subprocess.STDOUT)
            rc = r.returncode
        except Exception as e:  # noqa: BLE001
            rc = -1
            print(f"  !! launch failed for {name}: {e}")
        if rc == 0 and not os.path.exists(os.path.join(ROOT, done_path)):
            rc = -2  # exited 0 but wrote nothing -> silent failure
        return name, rc, time.time() - t0, log

    t_start = time.time()
    ok = fail = 0
    with ThreadPoolExecutor(max_workers=args.parallel) as ex:
        futs = {ex.submit(run_job, j): j[0] for j in todo}
        for i, fut in enumerate(as_completed(futs), 1):
            name, rc, dt, log = fut.result()
            if rc == 0:
                ok += 1
                tag = "ok  "
            else:
                fail += 1
                tag = "FAIL"
            elapsed = time.time() - t_start
            eta = (elapsed / i) * (len(todo) - i)
            print(f"[{i:3d}/{len(todo)}] {tag} {dt/60:5.1f}min  {name}"
                  f"   (elapsed {elapsed/60:.0f}min, ETA {eta/60:.0f}min)")
            if rc != 0:
                print(f"         -> see {log}")
                try:  # child log tail
                    _t = open(log, encoding='utf-8', errors='replace').read()
                    for _l in _t.strip().splitlines()[-12:]:
                        print(f"            | {_l}")
                except Exception:
                    pass

    print(f"\n[parallel] finished: {ok} ok, {fail} failed, "
          f"total {(time.time()-t_start)/3600:.2f} h")

    if not args.no_aggregate:
        print("[parallel] rebuilding aggregate tables ...")
        for d in ("results_ablation", "results_baseline", "results_eps",
                  "results_scale", "results_summary"):
            os.makedirs(d, exist_ok=True)
        for cmd in (
            [PY, "run_epsilon_sweep.py", "--aggregate_only", "--output_dir", "results_eps"],
            [PY, "run_baselines.py", "--aggregate_only", "--output_dir", "results_baseline"],
            [PY, "run_scale_test.py", "--aggregate_only", "--output_dir", "results_scale"],
            [PY, "-u", "aggregate_supp.py", "--roots", "results_ablation",
             "results_baseline", "results_eps", "results_scale", "results",
             "--out_dir", "results_summary"],
        ):
            subprocess.run(cmd, cwd=ROOT)
        print("[parallel] aggregates -> results_summary/TABLES.md")


if __name__ == "__main__":
    main()

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
