#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fix_v10.py -- repairs `run_topk_qsgd` in baselines/runner.py and makes its
compression budget auditable.

    python fix_v10.py            # DIAGNOSE ONLY (no file is touched)
    python fix_v10.py --apply    # splice the repaired function (writes .bak_v10)
    python fix_v10.py --selftest # prove the CPU/GPU device-mix bug exists

Why
---
S2 left 5 identical failures, all `topk_qsgd_iotid20_alpha0.1_seed1..5`, each
dying in ~0.5 min.  Two independent defects are addressed here:

  (1) DEVICE MIX.  `run_topk_qsgd` builds its per-device update as
        device_gradients[dev_id] = nsac_decompress(...)
      and nsac_decompress() always returns a **CPU** tensor (device=None),
      while the "empty partition" branch fills
        torch.zeros(d, device=DEVICE)
      i.e. a **GPU** tensor.  Under alpha=0.1 the Dirichlet partition hands
      several of the N devices an empty index list, so the dict ends up mixing
      CPU and GPU tensors and `star_aggregate`'s torch.stack(...) raises
      "Expected all tensors to be on the same device".  At alpha=0.5 no device
      is empty, so the bug stays hidden.  That is exactly the observed pattern.

  (2) NO COMPRESSION FORENSICS.  `run_topk_qsgd` never records how many bytes
      it actually shipped, so the Top-k+QSGD baseline cannot be compared with
      NSAC at a matched compression ratio -- the reviewer's first objection.
      The repaired version records bytes / empirical compression ratio / factor
      into `final_metrics`.

Additionally: empty and non-finite partitions are counted (not silently
dropped), and a compress/decompress failure now raises with device id, local
sample count, gradient shape and norm instead of a bare traceback.
"""
import argparse
import glob
import os
import py_compile
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
RUNNER = os.path.join(ROOT, "baselines", "runner.py")
MARK = "[fix_v10]"

NEW_SRC = '''def run_topk_qsgd(config: dict) -> Dict:
    """Top-k + QSGD: star-topology FL with uniform Top-k compression.

    [fix_v10]
      (a) every per-device update is moved to DEVICE before aggregation --
          nsac_decompress() returns a CPU tensor, which used to clash with the
          GPU zero-fill for empty partitions under extreme Dirichlet alpha;
      (b) empty / non-finite partitions are counted, never silently dropped;
      (c) the realised compression budget is recorded so that NSAC and this
          baseline can be compared at a matched compression ratio.
    """
    X_train, y_train, partitions = _load_partitioned_data(config)
    X_test, y_test = _load_test_data(config)
    input_dim = X_train.shape[1]
    model = build_model(input_dim).to(DEVICE)
    d = model.num_parameters
    N = config.get('N', 50)
    T = config.get('T', 100)
    eta = config.get('eta', 0.01)

    # Uniform compression: eMBB slice config (moderate budget)
    slice_config = SLICE_CONFIGS['embb']
    slice_name = getattr(slice_config, 'name', 'eMBB')

    bytes_full_round = N * d * 4      # fp32, all N devices, one round
    bytes_sent = 0
    n_empty = 0
    n_nonfinite = 0
    cr_last = float('nan')

    round_metrics = []
    for t in range(1, T + 1):
        bytes_round = 0
        device_gradients = {}
        for dev_id in range(N):
            idx_list = partitions.get(str(dev_id), [])
            if len(idx_list) == 0:
                # no local data -> contributes a zero update (kept, not dropped)
                device_gradients[dev_id] = torch.zeros(d, device=DEVICE)
                n_empty += 1
                continue
            gradient = _local_train(model, X_train[idx_list], y_train[idx_list],
                                    config.get('E_local', 5),
                                    config.get('batch_size', 32), eta)
            if not bool(torch.isfinite(gradient).all()):
                n_nonfinite += 1
                print(f"  [Top-k+QSGD][warn] round {t} dev {dev_id}: non-finite "
                      f"gradient (n_local={len(idx_list)}) -> zeroed")
                gradient = torch.nan_to_num(gradient, nan=0.0, posinf=0.0, neginf=0.0)

            try:
                compressed = nsac_compress(gradient, slice_config, adaptive_down=False)
                decompressed = nsac_decompress(compressed, d)
            except Exception as exc:
                raise RuntimeError(
                    f"run_topk_qsgd: compress/decompress failed at round {t}, "
                    f"device {dev_id} (n_local={len(idx_list)}, "
                    f"grad_shape={tuple(gradient.shape)}, "
                    f"grad_norm={float(gradient.norm()):.6g}, slice={slice_name}): "
                    f"{type(exc).__name__}: {exc}"
                ) from exc

            bytes_round += int(compressed.get('compressed_bytes', 0))
            cr_last = float(compressed.get('CR_actual', float('nan')))
            # (a) force onto DEVICE so the whole dict is device-consistent
            device_gradients[dev_id] = decompressed.to(DEVICE).float()

        bytes_sent += bytes_round
        global_params = _get_flat_params(model)
        new_params = star_aggregate(device_gradients, global_params, eta)
        _set_flat_params(model, new_params)

        metrics = _evaluate(model, X_test, y_test)
        round_metrics.append({'round': t,
                              'bytes_round': bytes_round,
                              'bytes_full_round': bytes_full_round,
                              'cr_round': (bytes_round / bytes_full_round)
                              if bytes_full_round else float('nan'),
                              **metrics})

        if t % 10 == 0:
            print(f"[Top-k+QSGD] Round {t}: F1={metrics['f1']:.4f} "
                  f"bytes={bytes_round}")

    final = _evaluate(model, X_test, y_test)
    full_total = bytes_full_round * T
    final.update({
        # --- (c) auditable compression budget ---
        'comm_bytes_total': bytes_sent,
        'comm_bytes_full_fp32': full_total,
        'compression_ratio_empirical': (bytes_sent / full_total) if full_total else float('nan'),
        'compression_factor_empirical': (full_total / bytes_sent) if bytes_sent else float('nan'),
        'cr_actual_last_round': cr_last,
        'k_ratio_nominal': slice_config.k_ratio,
        'b_bits_nominal': slice_config.b_bits,
        'slice_used': slice_name,
        'n_devices': N,
        'n_empty_device_rounds': n_empty,
        'n_nonfinite_device_rounds': n_nonfinite,
    })
    cf = (full_total / bytes_sent) if bytes_sent else float('nan')
    print(f"[Top-k+QSGD] done: bytes={bytes_sent} full={full_total} "
          f"CF={cf:.2f}x  empty={n_empty}  nonfinite={n_nonfinite}")
    return {'final_metrics': final, 'round_metrics': round_metrics}


'''

SPAN = re.compile(r"^def run_topk_qsgd\(.*?(?=^def |^# ={20,})", re.S | re.M)


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def diagnose():
    bar("A. the 5 failing child logs (logs/jobs/topk_qsgd*alpha0.1*)")
    seen = False
    for p in sorted(glob.glob(os.path.join(ROOT, "logs", "jobs", "topk_qsgd*alpha0.1*.log"))) \
            or sorted(glob.glob(os.path.join(ROOT, "logs", "jobs", "topk_qsgd*.log"))):
        txt = open(p, encoding="utf-8", errors="replace").read()
        print(f"\n  --- {os.path.basename(p)} ({len(txt)} B) ---")
        tail = txt.strip().splitlines()
        for l in tail[-30:]:
            print("    " + l[:160])
        dev_hit = re.search(r"(same device|Expected all tensors|device type|cuda|CUDA)", txt)
        print("    >> device-related keyword :", "YES" if dev_hit else "no")
        seen = True
        break
    if not seen:
        print("  (no log found -- check the path, or the driver stored logs elsewhere)")

    bar("B. current run_topk_qsgd in baselines/runner.py")
    if not os.path.exists(RUNNER):
        print("  !! baselines/runner.py not found -- run me from the project root")
        return
    src = open(RUNNER, encoding="utf-8").read()
    m = SPAN.search(src)
    if not m:
        print("  !! run_topk_qsgd not found")
        return
    if MARK in m.group(0):
        print(f"  already patched ({MARK} present) -- nothing to do")
    for l in m.group(0).splitlines():
        print("    " + l[:150])
    print("\n  VERDICT: the empty-partition branch fills device=DEVICE (GPU) while")
    print("           nsac_decompress(...) returns CPU -> mixed-device torch.stack")
    print("           under alpha=0.1.  Run with --apply to repair.")


def selftest():
    bar("C. selftest: does a mixed CPU/GPU dict really break torch.stack?")
    try:
        import torch
    except Exception as e:
        print(f"  torch unavailable ({e}) -- skipped")
        return 0
    d = 8
    cpu = torch.zeros(d)
    if torch.cuda.is_available():
        gpu = torch.zeros(d, device='cuda')
        try:
            torch.stack([cpu, gpu]).mean(dim=0)
            print("  [UNEXPECTED] mixed stack succeeded")
        except Exception as e:
            print(f"  [repro ] mixed CPU/GPU stack -> {type(e).__name__}: {str(e)[:110]}")
        print("  [ok   ] same-device stack ->",
              tuple(torch.stack([gpu, gpu]).mean(dim=0).shape))
    else:
        print("  no CUDA here; the CPU/CPU path is trivially fine -- the bug is")
        print("  only observable on a GPU box, which is exactly why it slipped through")
    print("  [selftest] PASS")
    return 0


def apply():
    bar("D. applying patch")
    if not os.path.exists(RUNNER):
        print("  !! baselines/runner.py not found")
        return 1
    src = open(RUNNER, encoding="utf-8").read()
    m = SPAN.search(src)
    if not m:
        print("  !! anchor 'def run_topk_qsgd' not found -- aborting")
        return 1
    if MARK in m.group(0):
        print(f"  [skip] {MARK} already applied")
        return 0
    bak = RUNNER + ".bak_v10"
    if not os.path.exists(bak):
        shutil.copy2(RUNNER, bak)
        print(f"  backup -> {os.path.relpath(bak, ROOT)}")
    else:
        print(f"  backup already exists -> {os.path.relpath(bak, ROOT)}")
    new = src[:m.start()] + NEW_SRC + src[m.end():]
    with open(RUNNER, "w", encoding="utf-8") as f:
        f.write(new)
    try:
        py_compile.compile(RUNNER, doraise=True)
        print("  [ok] py_compile baselines/runner.py")
    except Exception as e:
        print(f"  !! py_compile FAILED: {e}\n  restoring backup")
        shutil.copy2(bak, RUNNER)
        return 1
    chk = open(RUNNER, encoding="utf-8").read()
    print("  residual audit:")
    print("    marker present      :", MARK in chk)
    print("    .to(DEVICE) present :", "decompressed.to(DEVICE)" in chk)
    print("    bytes accounting    :", "compression_ratio_empirical" in chk)
    print("\n  [fix_v10] DONE -- re-run the 5 failed jobs:")
    print("    python run_baselines.py --method topk_qsgd --alpha 0.1 "
          "--seeds 1 2 3 4 5 --output_dir results_baseline")
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="actually write the patch")
    ap.add_argument("--selftest", action="store_true", help="device-mix demonstration")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.apply:
        return apply()
    diagnose()
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
