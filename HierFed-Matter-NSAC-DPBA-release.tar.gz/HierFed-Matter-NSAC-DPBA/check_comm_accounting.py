#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_comm_accounting.py -- READ-ONLY audit of the communication accounting.

    python check_comm_accounting.py                       # newest proposed run
    python check_comm_accounting.py path/to/results.json

WHY
---
`core/nsac.py::compute_communication_stats` computes the compression ratio as

        CR = k_ratio * b_bits / 32          ->  payload = CR * d * 4

i.e. the top-k INDEX cost is treated as free.  But `nsac_compress` bills the
payload as `k*4 + k*(b//8)` -- with int32 indices.  Two different conventions
live in the same file, and the headline "communication reduction" of the paper
uses the optimistic one.

This script prints both, plus the more defensible uint16 variant (d = 7762 <
65536, so a position needs only 2 bytes), and auto-detects which slices were
assigned by matching the recorded avg_compression_ratio.
"""
import glob
import itertools
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SLICES = {"urllc": (0.10, 8), "embb": (0.30, 16), "mmtc": (0.05, 8)}


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def model_dim(cfg):
    """d = sum of all weight and bias entries from input_dim + hidden_dims."""
    dims = [cfg.get("input_dim_iotid20", 79)] + list(cfg.get("hidden_dims", [64, 32, 16])) \
           + [cfg.get("output_dim", 2)]
    return sum(dims[i] * dims[i + 1] + dims[i + 1] for i in range(len(dims) - 1)), dims


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else None
    if not path:
        cands = sorted(glob.glob(os.path.join(HERE, "results_ablation", "proposed_*",
                                              "results.json")), key=os.path.getmtime)
        cands += sorted(glob.glob(os.path.join(HERE, "results*", "**", "proposed_*",
                                               "results.json"), recursive=True),
                        key=os.path.getmtime)
        cands = [c for c in cands if "communication_stats" in open(c, encoding="utf-8").read()]
        if not cands:
            print("  !! no proposed run with communication_stats found")
            return 1
        path = cands[-1]
    print("=" * 78)
    print("  communication accounting audit  (read-only)")
    print(f"  file : {os.path.relpath(path, HERE)}")
    print("=" * 78)

    d0 = json.load(open(path, encoding="utf-8"))
    cfg = d0.get("config") or {}
    N = int(cfg.get("N", 20)); M = int(cfg.get("M", 4)); T = int(cfg.get("T", 50))
    d, dims = model_dim(cfg)
    print(f"  architecture {dims}  ->  d = {d} parameters ({d*4} B dense fp32)")
    print(f"  N={N} devices, M={M} gateways, T={T} rounds")

    rm = d0.get("round_metrics") or []
    if not rm:
        print("  !! round_metrics missing")
        return 1
    r1 = rm[0]
    honest = r1.get("total_compressed_bytes")
    decl_avg = r1.get("avg_compression_ratio")
    print(f"\n  recorded in round 1:")
    print(f"    total_compressed_bytes  = {honest}   <- billed WITH int32 indices")
    print(f"    avg_compression_ratio   = {decl_avg}   <- declared CR, indices FREE")
    if honest is None or decl_avg is None:
        print("  !! this run predates the [fix_v10] accounting -- re-run to get it")
        return 1

    # ---- auto-detect the slice assignment -------------------------------
    target = round(float(decl_avg), 6)
    match = None
    for combo in itertools.combinations_with_replacement(sorted(SLICES), M):
        cr = sum(SLICES[s][0] * SLICES[s][1] / 32.0 for s in combo) / M
        if abs(cr - target) < 5e-4:
            match = combo
    print(f"\n  slice assignment reverse-solved from avg_compression_ratio={target}: "
          f"{list(match) if match else 'NOT FOUND'}")

    bar("per-slice payload, three accounting conventions")
    print(f"  {'slice':7} {'k':>5} {'declared':>10} {'int32 idx':>11} {'uint16 idx':>11}")
    rows = match or tuple(SLICES.keys())[:M]
    tot = {"decl": 0, "i32": 0, "u16": 0}
    for s in rows:
        kr, b = SLICES[s]
        k = int(kr * d)
        decl = int(kr * b / 32.0 * d * 4)
        i32 = k * 4 + k * (b // 8)
        u16 = k * 2 + k * (b // 8)
        tot["decl"] += decl; tot["i32"] += i32; tot["u16"] += u16
        print(f"  {s:7} {k:>5} {decl:>10,} {i32:>11,} {u16:>11,}")
    print(f"  {'SUM':7} {'':>5} {tot['decl']:>10,} {tot['i32']:>11,} {tot['u16']:>11,}  "
          f"(per round, all {M} gateways)")

    star = N * d * 4 * T
    bar("end-to-end communication reduction")
    print(f"  star (no hierarchy, no compression) = N*d*4*T = {star:,} B")
    print(f"\n  {'convention':34} {'core bytes':>14} {'speedup':>9} {'reduction':>10}")
    print("  " + "-" * 72)
    for lab, per_round in (("declared  (indices free)  <- PAPER", tot["decl"]),
                           ("honest    (int32 indices)", tot["i32"]),
                           ("honest    (uint16 indices)", tot["u16"])):
        core = per_round * T
        print(f"  {lab:34} {core:>14,} {star/core:>8.1f}x "
              f"{(1 - core/star)*100:>9.1f}%")

    bar("cross-check against the file")
    cs = d0.get("communication_stats") or {}
    print(f"  communication_stats.speedup = {cs.get('speedup')}")
    print(f"  communication_stats         = {json.dumps(cs, ensure_ascii=False)}")
    print(f"  round-1 sum of the slices   = {tot['i32']}  (should equal "
          f"total_compressed_bytes = {honest})")
    if abs(tot["i32"] - honest) <= 1:
        print("  -> MATCH: the per-run byte log is the honest one")
    else:
        print("  -> MISMATCH: send me this output")
    print("\n  the two speedups differ by the index overhead -- decide once, then")
    print("  use the SAME convention in every table of the paper.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
