#!/usr/bin/env bash
# =============================================================================
# collect.sh -- ONE command. Produces the two files Mihiro needs:
#                   post_s2_report.md   (status + verify + tables)
#                   probe.md            (the code regions needed for C-2/C-3)
#
# Usage (from the PROJECT ROOT, after copying the scripts there):
#     bash collect.sh
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1
PY="${PY:-python}"
STAMP="$(date '+%Y-%m-%d %H:%M:%S')"

echo "=============================================================="
echo "  HierFed collect   $STAMP"
echo "=============================================================="

# --- 0. sanity: are we in the project root? --------------------------------
for f in core/nsac.py core/simulator.py run_parallel.py configs/base.yaml; do
  if [ ! -e "$f" ]; then
    echo "  !! '$f' not found -> this is NOT the project root."
    echo "     cd /root/autodl-tmp/HierFed-Matter-NSAC-DPBA  然后重新运行"
    exit 1
  fi
done
echo "  [ok] project root detected: $(pwd)"

# --- 1. write the combined report -----------------------------------------
REP=post_s2_report.md
{
  echo "# HierFed post-S2 report"
  echo
  echo "_generated $STAMP by collect.sh_"
  echo
  echo '## 0. scripts present in the project root'
  echo '```'
  ls -l *.py *.sh 2>/dev/null | awk '{print $5"\t"$9}'
  echo '```'
  echo
  echo '## 1. status_project.py'
  echo '```'
  $PY status_project.py 2>&1 || echo "(status_project.py missing -- copy it here)"
  echo '```'
  echo
  echo '## 2. verify_after_s2.py'
  echo '```'
  $PY verify_after_s2.py 2>&1 || echo "(verify_after_s2.py missing -- copy it here)"
  echo '```'
  echo
  echo '## 3. results_summary/TABLES.md'
  echo '```'
  cat results_summary/TABLES.md 2>&1
  echo '```'
  echo
  echo '## 4. counts'
  echo '```'
  echo "results.json total      : $(find . -name results.json | wc -l)"
  echo "results_baseline dirs   : $(ls results_baseline 2>/dev/null | wc -l)"
  echo "results_eps dirs        : $(ls results_eps 2>/dev/null | wc -l)"
  echo "results_ablation dirs   : $(ls results_ablation 2>/dev/null | wc -l)"
  echo "-- newest results.json --"
  find . -name results.json -printf '%TY-%Tm-%Td %TH:%TM  %p\n' 2>/dev/null | sort | tail -5
  echo '```'
  echo
  echo '## 5. log tail (parallel_s2.log)'
  echo '```'
  tail -n 15 logs/parallel_s2.log 2>&1
  echo '```'
  echo
  echo '## 6. FORBIDDEN-VALUE SCAN (ghost numbers must not survive)'
  echo '```'
  for v in 0.461 'epsweep_eps0.5' 'epsweep_eps1.0' 'epsweep_eps10.0'; do
    printf '%-22s : %s hits\n' "$v" "$(grep -rl "$v" results_summary results_eps 2>/dev/null | wc -l)"
  done
  echo '```'
} > "$REP" 2>&1

echo "  [ok] wrote $REP"

# --- 2. the probe (no GPU needed) ------------------------------------------
if [ -f fix_v9.py ]; then
  $PY fix_v9.py --probe > probe.md 2>&1
  echo "  [ok] wrote probe.md  ($(wc -l < probe.md) lines)"
else
  echo "  !! fix_v9.py not in this directory -- probe.md NOT produced"
  echo "     (copy fix_v9.py here, then: python fix_v9.py --probe > probe.md 2>&1)"
fi

# --- 3. echo the head of the report ---------------------------------------
echo
echo "=============================================================="
sed -n '1,60p' "$REP"
echo "=============================================================="
echo
echo "  下一步：把 post_s2_report.md 和 probe.md 拖进对话发给 Mihiro"
echo "  （如果 fix_v9.py 还没打过补丁，先运行："
echo "     python fix_v9.py && python fix_v9.py --selftest && python fix_v9.py --probe > probe.md 2>&1 ）"

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
