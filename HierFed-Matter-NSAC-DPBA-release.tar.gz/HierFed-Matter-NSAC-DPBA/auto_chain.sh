#!/usr/bin/env bash
# =============================================================================
# auto_chain.sh -- 看门狗：B（seed678.sh）跑完自动启动 C（run_p3_k_ratio.sh）
# EN: auto_chain.sh -- watchdog: after B (seed678.sh) finishes, automatically start C (run_p3_k_ratio.sh)
#
# 用法：
# EN: Usage:
#   nohup bash auto_chain.sh > logs/auto_chain.log 2>&1 &
#   sleep 10; tail -n 20 logs/auto_chain.log      # 确认看门狗在跑
# EN:   sleep 10; tail -n 20 logs/auto_chain.log      # confirm the watchdog is running
#   tail -n 5 logs/auto_chain.log                  # 后续随时看（每 60s/300s 心跳）
# EN:   tail -n 5 logs/auto_chain.log                  # check anytime later (heartbeat every 60s/300s)
#
# 行为：
# EN: Behavior:
#   1) 每 60s 检查 results_alloc/ 里 B 阶段的 12 个目标文件
# EN:   1) every 60s check the 12 target files of phase B under results_alloc/
#   2) 12/12 齐全（最多等 90 min）→ 自动启动 C
# EN:   2) once 12/12 are complete (wait at most 90 min) → automatically start C
#   3) C 启动后每 5 min 心跳一次（40/0..40）
# EN:   3) after C starts, heartbeat every 5 min (40/0..40)
#   4) C 进程退出后做最终核对 + 提示下一步 analyze 命令
# EN:   4) after the C process exits, do a final check + print the next analyze command
#   5) 任何环节失败都打印清楚
# EN:   5) any failing step is printed clearly
#
# 终止：
# EN: Termination:
#   - 想手动停：kill $(pgrep -f auto_chain.sh)
# EN:   - to stop manually: kill $(pgrep -f auto_chain.sh)
#   - 想跳过 B 直接跑 C：kill 看门狗后手动 bash run_p3_k_ratio.sh
# EN:   - to skip B and run C directly: kill the watchdog, then manually run bash run_p3_k_ratio.sh
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
SEEDS_B=${SEEDS_B:-"6 7 8"}
ARMS_B=${ARMS_B:-"cruniform_epsslice crslice_epsslice"}
DS_LIST=${DS_LIST:-"iotid20 gotham25"}
ALPHA=${ALPHA:-0.5}
LOG=${LOG:-logs/auto_chain.log}
MAX_WAIT_B_MIN=${MAX_WAIT_B_MIN:-90}    # B 阶段最多等 90 min | EN: wait at most 90 min in phase B
POLL_B_SEC=${POLL_B_SEC:-60}            # B 轮询间隔 | EN: B polling interval
POLL_C_SEC=${POLL_C_SEC:-300}           # C 心跳间隔 | EN: C heartbeat interval

ARMS_C="cruniform_epsuniform crslice_epsuniform cruniform_epsslice crslice_epsslice"
SEEDS_C="1 2 3 4 5"
EXPECTED_C=40

cd "$PROJ" || { echo "ERROR: $PROJ 不存在"; exit 1; }
mkdir -p logs
mkdir -p results_alloc_kr || true       # 提早建好，避免后续 race | EN: create it early to avoid a later race

ts(){ date +"%Y-%m-%d %H:%M:%S"; }
say(){ echo "[$(ts)] $*" | tee -a "$LOG"; }

# 通用：数指定 ROOT / arms / seeds 的 results.json
# EN: generic: count results.json for the given ROOT / arms / seeds
count_done(){
  local ROOT="$1" ARMS="$2" SEEDS="$3"
  local n=0
  for ds in $DS_LIST; do
    for arm in $ARMS; do
      for s in $SEEDS; do
        f="$ROOT/$ds/proposed_${ds}_alpha${ALPHA}_seed${s}_${arm}/results.json"
        [ -f "$f" ] && n=$((n+1))
      done
    done
  done
  echo "$n"
}

# 启动时的 sanity
# EN: startup sanity check
[ -f seed678.sh ]         || { say "[!!] 缺 seed678.sh，请先 curl 拉"; exit 1; }
[ -f run_p3_k_ratio.sh ]  || { say "[!!] 缺 run_p3_k_ratio.sh，请先 curl 拉"; exit 1; }
[ -f core/slice_alloc.py ] || say "[!!] 缺 core/slice_alloc.py"
[ -d results_alloc ]      || { say "[!!] results_alloc/ 还不存在（先跑 seed678.sh）"; exit 1; }
[ -f core/simulator.py ]  || { say "[!!] core/simulator.py 缺"; exit 1; }

n_b_now=$(count_done results_alloc "$ARMS_B" "$SEEDS_B")
say "auto_chain 启动  当前 B 进度 $n_b_now / 12  阈值: 等满 12 后启动 C"
say "B 阶段 ARMS=$ARMS_B  SEEDS=$SEEDS_B"
say "C 阶段 EXPECTED=$EXPECTED_C  ARMS=$ARMS_C  SEEDS=$SEEDS_C"

# ---- Phase 1: 等 B ----
# EN: ---- Phase 1: wait for B ----
elapsed_min=0
while [ "$elapsed_min" -lt "$MAX_WAIT_B_MIN" ]; do
  n_b=$(count_done results_alloc "$ARMS_B" "$SEEDS_B")
  say "B 进度 $n_b / 12  (已等 ${elapsed_min} min)"
  if [ "$n_b" -eq 12 ]; then
    say "B 阶段全部完成 → 启动 C"
    break
  fi
  sleep "$POLL_B_SEC"
  elapsed_min=$((elapsed_min + POLL_B_SEC/60))
done

if [ "$n_b" -lt 12 ]; then
  say "[abort] B 阶段 ${MAX_WAIT_B_MIN}min 内未完成（$n_b/12），请检查 seed678.sh 状态"
  say "         修复后手动: bash run_p3_k_ratio.sh"
  exit 1
fi

# ---- Phase 2: 启动 C ----
# EN: ---- Phase 2: start C ----
# 先做轻量 sanity：GPU 占用率不能 100% 占死（避免 seed678.sh 还有残尸）
# EN: do a quick sanity check first: GPU utilization must not be pinned at 100% (in case seed678.sh still has leftovers)
n_live=$(pgrep -f "run_experiment\.py" 2>/dev/null | wc -l)
if [ "$n_live" -gt 0 ]; then
  say "[wait] B 残存 run_experiment.py 还有 $n_live 个，等 30s 收尾"
  for _ in 1 2 3 4 5 6; do
    n_live=$(pgrep -f "run_experiment\.py" 2>/dev/null | wc -l)
    [ "$n_live" -eq 0 ] && break
    sleep 5
  done
fi

say "启动 C: nohup bash run_p3_k_ratio.sh > logs/p3_kr_boot.log 2>&1 &"
nohup bash run_p3_k_ratio.sh > logs/p3_kr_boot.log 2>&1 &
CPID=$!
say "C PID=$CPID"

# ---- Phase 3: 心跳 C ----
# EN: ---- Phase 3: heartbeat C ----
last_n=0
stuck=0
while kill -0 "$CPID" 2>/dev/null; do
  n_c=$(count_done results_alloc_kr "$ARMS_C" "$SEEDS_C")
  n_live=$(pgrep -f "run_experiment\.py" 2>/dev/null | wc -l)
  say "C 进度 $n_c / $EXPECTED_C  live=$n_live  (心跳每 ${POLL_C_SEC}s)"
  # 卡 30 min 没进展 → 提示
  # EN: stuck for 30 min with no progress → warn
  if [ "$n_c" -eq "$last_n" ]; then
    stuck=$((stuck+POLL_C_SEC/60))
    if [ "$stuck" -ge 30 ]; then
      say "[warn] C 已 ${stuck} min 无进展，必要时手动: bash run_p3_k_ratio.sh status"
    fi
  else
    stuck=0
    last_n=$n_c
  fi
  sleep "$POLL_C_SEC"
done

wait "$CPID" 2>/dev/null
exit_code=$?
say "C 进程已退出 (exit=$exit_code)"

# ---- Phase 4: 最终核对 ----
# EN: ---- Phase 4: final check ----
n_c=$(count_done results_alloc_kr "$ARMS_C" "$SEEDS_C")
say "C 最终: $n_c / $EXPECTED_C"
if [ "$n_c" -eq "$EXPECTED_C" ]; then
  say "================================================================"
  say " [DONE] B+C 全部完成"
  say "  B 分析: bash seed678.sh analyze"
  say "  C 分析: python analyze_alloc.py results_alloc_kr"
  say "  贴回给我下一步判定"
  say "================================================================"
else
  say "================================================================"
  say " [PARTIAL] C 仅完成 $n_c / $EXPECTED_C"
  say "  看缺哪些: ls results_alloc_kr/*/*/results.json | wc -l"
  say "  手动续跑（幂等，缺什么补什么）: bash run_p3_k_ratio.sh"
  say "================================================================"
fi

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
