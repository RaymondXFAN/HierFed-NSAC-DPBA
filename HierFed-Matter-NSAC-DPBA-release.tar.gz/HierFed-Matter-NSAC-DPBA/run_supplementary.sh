#!/usr/bin/env bash
# =============================================================================
# run_supplementary.sh — ONE-CLICK supplementary experiments (paper revision)
#
#   HierFed-Matter-NSAC-DPBA
#   Phases: precheck -> ablation(component+weights) -> baselines -> eps-sweep
#           -> scaling -> aggregate tables
#
# Usage (on the GPU machine, inside the project directory):
#   bash run_supplementary.sh precheck        # ~5 min sanity check FIRST
#   nohup bash run_supplementary.sh all > logs/boot.log 2>&1 &
#   bash run_supplementary.sh status          # non-blocking progress
#   cat logs/P1_SUMMARY.txt                   # one-page final summary
#
# Env overrides:
#   SEEDS="1 2 3 4 5 6 7 8 9 10"  ALPHAS="0.5 0.1"
# =============================================================================
set -u
cd "$(dirname "$0")" || exit 1

# libgomp prints "Invalid value for environment variable OMP_NUM_THREADS" when the
# variable is empty or non-numeric. Normalise it to a sane default.
case "${OMP_NUM_THREADS:-}" in ''|*[!0-9]*) export OMP_NUM_THREADS=8 ;; esac

SEEDS=${SEEDS:-"1 2 3 4 5"}
ALPHAS=${ALPHAS:-"0.5 0.1"}
PARALLEL=${PARALLEL:-4}

ABL_DIR=results_ablation
BASE_DIR=results_baseline
EPS_DIR=results_eps
SCALE_DIR=results_scale
SUM_DIR=results_summary
PRECHECK_DIR=results_precheck
mkdir -p logs "$ABL_DIR" "$BASE_DIR" "$EPS_DIR" "$SCALE_DIR" "$SUM_DIR"

PHASE=${1:-all}
ts(){ date "+%F %T"; }
log(){ echo "[$(ts)] $*" | tee -a logs/runner.log; }
count_json(){ find "$1" -name results.json 2>/dev/null | wc -l; }

# ----------------------------------------------------------------- precheck
precheck(){
  log "== PRECHECK  (T=3, e_local=1, 1 seed) =="
  python -u run_experiment.py --method proposed --alpha 0.5 --seed 1 \
      --T 3 --e_local 1 --output_dir "$PRECHECK_DIR" > logs/precheck_proposed.log 2>&1
  python -u run_baselines.py --method dpfedavg --alpha 0.5 --seeds 1 \
      --T 3 --output_dir "$PRECHECK_DIR" > logs/precheck_dpfedavg.log 2>&1
  n=$(count_json "$PRECHECK_DIR")
  if [ "$n" -ge 2 ]; then
    log "PRECHECK OK: $n result files written to $PRECHECK_DIR/"
    grep -h "Final:" logs/precheck_proposed.log | tail -1
    return 0
  fi
  log "PRECHECK FAILED -> see logs/precheck_*.log"; return 1
}

# ----------------------------------------------------------------- ablation
phase_abl(){
  if [ -f "$ABL_DIR/ablation_table_component.json" ] && \
     [ -f "$ABL_DIR/ablation_table_weights.json" ]; then
    log "SKIP ablation (tables already exist)"; return 0
  fi
  log "== ABLATION  suite=both  seeds=[$SEEDS] alphas=[$ALPHAS] =="
  python -u run_ablation.py --suite both --alpha $ALPHAS --seeds $SEEDS \
      --output_dir "$ABL_DIR" 2>&1 | tee -a logs/ablation.log
}

# ----------------------------------------------------------------- baselines
phase_base(){
  log "== BASELINES (incl. adaptive DP)  alpha=[$ALPHAS] =="
  python -u run_baselines.py --method all --alpha $ALPHAS --seeds $SEEDS \
      --output_dir "$BASE_DIR" 2>&1 | tee -a logs/baselines.log
}

# ----------------------------------------------------------------- eps-sweep
phase_eps(){
  if [ -f "$EPS_DIR/privacy_utility_curve.json" ]; then
    log "SKIP eps-sweep (curve already exists)"
  else
    log "== EPS-SWEEP  alpha=[$ALPHAS] seeds=[$SEEDS] =="
    python -u run_epsilon_sweep.py --alpha $ALPHAS --seeds $SEEDS \
        --output_dir "$EPS_DIR" 2>&1 | tee -a logs/eps_sweep.log
  fi
  log "eps-sweep done -> $EPS_DIR/  ($(count_json "$EPS_DIR") runs)"
}

# ----------------------------------------------------------------- scaling
phase_scale(){
  if [ -f "$SCALE_DIR/scale_summary.json" ]; then
    log "SKIP scaling (summary already exists)"
  else
    log "== SCALING  N=20 50 100  alpha=0.5  seeds=1 2 3 =="
    python -u run_scale_test.py --N 20 50 100 --alpha 0.5 --seeds 1 2 3 \
        --output_dir "$SCALE_DIR" 2>&1 | tee -a logs/scale.log
  fi
}

# ----------------------------------------------------------------- parallel
phase_par(){
  log "== PARALLEL SUITE  concurrency=$PARALLEL  seeds=[$SEEDS] alphas=[$ALPHAS] =="
  python -u run_parallel.py --parallel "$PARALLEL" --seeds $SEEDS --alphas $ALPHAS \
      2>&1 | tee -a logs/parallel.log
}

# ----------------------------------------------------------------- aggregate
phase_agg(){
  log "== AGGREGATE  -> $SUM_DIR/ =="
  python -u aggregate_supp.py \
      --roots "$ABL_DIR" "$BASE_DIR" "$EPS_DIR" "$SCALE_DIR" results \
      --out_dir "$SUM_DIR" 2>&1 | tee -a logs/aggregate.log
  {
    echo "=============================================================="
    echo " HierFed-Matter-NSAC-DPBA  —  supplementary run summary"
    echo " finished: $(ts)"
    echo " result files: ablation=$(count_json "$ABL_DIR") \
baselines=$(count_json "$BASE_DIR") eps=$(count_json "$EPS_DIR") \
scale=$(count_json "$SCALE_DIR")"
    echo "--------------------------------------------------------------"
    [ -f "$SUM_DIR/TABLES.md" ] && cat "$SUM_DIR/TABLES.md"
    echo "=============================================================="
  } > logs/P1_SUMMARY.txt
  log "summary written -> logs/P1_SUMMARY.txt"
}

# ----------------------------------------------------------------- status
status_now(){
  echo "=== $(ts) ==="
  echo "ablation runs : $(count_json "$ABL_DIR")"
  echo "baseline runs : $(count_json "$BASE_DIR")"
  echo "eps runs      : $(count_json "$EPS_DIR")"
  echo "scale runs    : $(count_json "$SCALE_DIR")"
  echo "--- alive python processes ---"
  pgrep -af "python -u run_" | head -5 || true
  echo "--- GPU ---"
  command -v nvidia-smi >/dev/null && nvidia-smi --query-gpu=utilization.gpu,memory.used \
        --format=csv,noheader || echo "nvidia-smi not available"
  echo "--- last log lines ---"
  tail -n 5 logs/runner.log 2>/dev/null || true
}

# ----------------------------------------------------------------- dispatch
case "$PHASE" in
  precheck) precheck ;;
  abl)      phase_abl ;;
  base)     phase_base ;;
  eps)      phase_eps ;;
  scale)    phase_scale ;;
  par)      phase_par ;;
  agg)      phase_agg ;;
  status)   status_now ;;
  all)
    log "START full supplementary suite (SEEDS='$SEEDS' ALPHAS='$ALPHAS' PARALLEL='$PARALLEL')"
    precheck || { log "aborting: precheck failed"; exit 1; }
    phase_par
    phase_agg
    log "ALL DONE"
    ;;
  *) echo "usage: bash run_supplementary.sh {precheck|abl|base|eps|scale|agg|status|all}"; exit 1 ;;
esac

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
