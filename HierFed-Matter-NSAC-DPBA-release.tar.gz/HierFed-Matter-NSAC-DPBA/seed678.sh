#!/usr/bin/env bash
# =============================================================================
# seed678.sh -- Phase 3 补救：只补 A3/A4 的 seed 6,7,8（12 run, ~50 min）
# EN: seed678.sh -- Phase 3 remediation: only fill in seeds 6,7,8 for A3/A4 (12 runs, ~50 min)
#
# 目标：
# EN: Goal:
#   Gotham25 上 A3 = A1 +0.0012（5/5 正）是否在 n=8 时仍成立（Wilcoxon 下限 0.0078）
# EN: whether A3 = A1 +0.0012 on Gotham25 (5/5 positive) still holds at n=8 (Wilcoxon lower bound 0.0078)
#   A4 的 headline 一锤定音 —— 若 8 seed 后仍一致地 A4 < A1，接受 negative 转 A。
# EN: settle A4's headline once and for all -- if A4 < A1 still holds consistently after 8 seeds, accept the negative and pivot to A.
#
#   bash seed678.sh                # 后台跑 + 核验
# EN: bash seed678.sh                # run in the background + verify
#   bash seed678.sh status         # 非阻塞看进度
# EN: bash seed678.sh status         # non-blocking progress check
#   bash seed678.sh analyze        # 跑 n=5 + n=8 合并分析
# EN: bash seed678.sh analyze        # run the merged n=5 + n=8 analysis
#
# 前置：fix_v17/18/20 已 apply、core/slice_alloc.py 已就位、Phase 3 40 run 已落盘
# EN: Prerequisite: fix_v17/18/20 applied, core/slice_alloc.py in place, the 40 Phase 3 runs already written to disk
# =============================================================================
set -u
PROJ=${PROJ:-/root/autodl-tmp/HierFed-Matter-NSAC-DPBA}
PY=${PY:-python}
SEEDS=${SEEDS:-"6 7 8"}
DS_LIST=${DS_LIST:-"iotid20 gotham25"}
ARMS_RUN=${ARMS_RUN:-"cruniform_epsslice:uniform:slice crslice_epsslice:slice:slice"}
ALPHA=${ALPHA:-0.5}
T=${T:-50}
RULE=${RULE:-bw}
SLICE_MAP=${SLICE_MAP:-ranked}
OUT=${OUT:-results_alloc}
LOG=${LOG:-logs/p3_s678}
TIMEOUT=${TIMEOUT:-5400}

cd "$PROJ" || { echo "ERROR: $PROJ 不存在"; exit 1; }
mkdir -p "$LOG"

cmd_run(){                  # cmd_run <label> <pid_out>
  "$@" > "$2" 2>&1 &
  echo $! > "$2.pid"
}

run_one(){
  local DS="$1" TAG="$2" S="$3"
  local f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${S}_${TAG}/results.json"
  if [ -f "$f" ]; then echo "  [skip] $DS $TAG s$S 已有"; return 0; fi
  echo "  [run] $DS $TAG s$S"
  NSAC_MODE=uniform EPSILON_MODE=slice SLICE_WEIGHT_RULE=$RULE SLICE_MAP=$SLICE_MAP \
    HIERFED_DATASET=$DS timeout "$TIMEOUT" $PY -u run_experiment.py --method proposed \
    --dataset "$DS" --alpha "$ALPHA" --seed "$S" --tag "$TAG" --T "$T" \
    --output_dir "$OUT/$DS" > "$LOG/${DS}_${TAG}_s${S}.log" 2>&1
}

# --------------------------------------------------------------- status
status(){
  echo "=== seed 6-8 进度 ==="
  local n=0 total=0
  for DS in $DS_LIST; do
    for spec in $ARMS_RUN; do
      TAG="${spec%%:*}"
      for S in $SEEDS; do
        total=$((total+1))
        f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${S}_${TAG}/results.json"
        [ -f "$f" ] && n=$((n+1))
      done
    done
  done
  echo "  完成 $n / $total   在跑 $(pgrep -f 'run_experiment\.py' | wc -l)"
}

# --------------------------------------------------------------- analyze (n=5 + n=8 合并)
# EN: analyze (n=5 + n=8 merged)
analyze(){
  $PY - <<EOF
import json, glob, os, re, numpy as np
from collections import defaultdict
try:
    from scipy import stats; HAVE=True
except Exception: HAVE=False

ALL_SEEDS = [1,2,3,4,5,6,7,8]
ARMS = ["cruniform_epsuniform","crslice_epsuniform","cruniform_epsslice","crslice_epsslice"]
PAT = re.compile(r"alpha([\d.]+)_seed(\d+)_(cruniform_epsuniform|crslice_epsuniform|cruniform_epsslice|crslice_epsslice)\$")

data = defaultdict(lambda: defaultdict(lambda: defaultdict(dict)))
for p in glob.glob("$OUT/*/*/results.json"):
    m = PAT.search(os.path.basename(os.path.dirname(p)))
    if not m: continue
    seed = int(m.group(2)); arm = m.group(3); ds = os.path.basename(os.path.dirname(os.path.dirname(p)))
    try:
        d = json.load(open(p, encoding="utf-8"))
    except: continue
    fm = d.get("final_metrics") or {}
    if fm.get("auc_roc") is None: continue
    data[ds][arm][seed] = float(fm["auc_roc"])

for ns in (5, 8):
    seeds = ALL_SEEDS[:ns]
    print("=" * 70)
    print(f"  n={ns} (seeds {seeds})")
    print("=" * 70)
    print(f" {'arm':<28}{'Gotham25':>14}{'IoTID20':>14}")
    for arm in ARMS:
        g = [data["gotham25"][arm][s] for s in seeds if s in data["gotham25"][arm]]
        i = [data["iotid20"][arm][s]  for s in seeds if s in data["iotid20"][arm]]
        gs = f"{np.mean(g):.4f}±{np.std(g,ddof=1) if len(g)>1 else 0:.4f}(n={len(g)})" if g else "--"
        ist = f"{np.mean(i):.4f}±{np.std(i,ddof=1) if len(i)>1 else 0:.4f}(n={len(i)})" if i else "--"
        print(f" {arm:<28}{gs:>14}    {ist:>14}")
    # A3-A1, A4-A1 paired
    for label, ta in [("A3-A1", "cruniform_epsslice"), ("A4-A1 (headline)", "crslice_epsslice")]:
        line = f" {label:<20}"
        for ds in ("gotham25","iotid20"):
            a1 = {s: data[ds]["cruniform_epsuniform"].get(s) for s in seeds}
            ta_v = {s: data[ds][ta].get(s) for s in seeds}
            common = [s for s in seeds if a1[s] is not None and ta_v[s] is not None]
            if len(common) < 3: line += f"{'  --':<14}"; continue
            d = np.array([ta_v[s]-a1[s] for s in common])
            tp = stats.wilcoxon(d).pvalue if (HAVE and np.any(d)) else float('nan')
            tp2 = stats.ttest_rel([ta_v[s] for s in common],[a1[s] for s in common]).pvalue if HAVE else float('nan')
            star = " *" if (tp==tp and tp<0.05) else ""
            line += f"{d.mean():+.4f} p={tp:.3f}{star:<3}"
        print(line)
    print()
print("  * = Wilcoxon 单侧 p<0.05（n=8 时下限 0.0078）")
EOF
}

# --------------------------------------------------------------- main
case "${1:-run}" in
  status) status ;;
  analyze) analyze ;;
  run|"")
    # preflight（与 run_p3_alloc 相同）
    # EN: preflight (same as run_p3_alloc)
    pre=0
    grep -q "'gotham25'" run_experiment.py 2>/dev/null || { echo "[!!] fix_v17 未打"; pre=1; }
    grep -q "\[fix_v20\]" core/simulator.py 2>/dev/null || { echo "[!!] fix_v20 未打"; pre=1; }
    [ -f core/slice_alloc.py ] || { echo "[!!] 缺 core/slice_alloc.py"; pre=1; }
    [ "$pre" -eq 0 ] && echo "[preflight] OK" || exit 1

    # 1 gate（1 个 T=2 冒烟，验开关——用 A3）
    # EN: 1) gate (one T=2 smoke test, verify the switches -- using A3)
    echo "[gate] T=2 A3 冒烟（gotham25 即可，验开关）"
    g="$LOG/gate_A3_gotham25.log"
    NSAC_MODE=uniform EPSILON_MODE=slice SLICE_WEIGHT_RULE=$RULE SLICE_MAP=$SLICE_MAP \
      HIERFED_DATASET=gotham25 timeout 1200 $PY -u run_experiment.py --method proposed \
      --dataset gotham25 --alpha "$ALPHA" --seed 1 --tag cruniform_epsslice \
      --T 2 --e_local 1 --output_dir "$OUT/_gate" > "$g" 2>&1
    gj=$(find "$OUT/_gate" -name results.json 2>/dev/null | head -1)
    if [ -z "$gj" ]; then
      echo "  [FAIL] gate 未写出 results.json"; tail -n 12 "$g" | sed 's/^/     | /'; exit 1
    fi
    span=$(grep -oE "span=[0-9.]+" "$g" | head -1)
    cov=$(grep -oE "coverage=[0-9]+" "$g" | head -1)
    echo "  [ok] gate 通过  $span  $cov"
    rm -rf "$OUT/_gate"

    # 2 launch（后台）
    # EN: 2) launch (in the background)
    echo "[launch] 12 run（par=4）..."
    for DS in $DS_LIST; do
      for spec in $ARMS_RUN; do
        TAG="${spec%%:*}"
        for S in $SEEDS; do
          f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${S}_${TAG}/results.json"
          [ -f "$f" ] && continue
          # 简单限流：<=4 个 run_experiment.py
          # EN: simple throttling: <= 4 run_experiment.py processes
          while [ "$(pgrep -f 'run_experiment\.py' | wc -l)" -ge 4 ]; do sleep 20; done
          nohup bash -c "
            NSAC_MODE=uniform EPSILON_MODE=slice SLICE_WEIGHT_RULE=$RULE SLICE_MAP=$SLICE_MAP \
            HIERFED_DATASET=$DS timeout $TIMEOUT $PY -u run_experiment.py --method proposed \
            --dataset $DS --alpha $ALPHA --seed $S --tag $TAG --T $T \
            --output_dir $OUT/$DS
          " > "$LOG/${DS}_${TAG}_s${S}.log" 2>&1 &
          echo "  [bg] $DS $TAG s$S"
        done
      done
    done

    # 3 wait
    echo "[wait] 等所有后台 run 收工..."
    while [ "$(pgrep -f 'run_experiment\.py' | wc -l)" -gt 0 ]; do sleep 30; done

    # 4 核验
    # EN: 4) verification
    echo "[verify] 逐 run 按文件核验（结果导向，不看 exit code）"
    miss=0
    for DS in $DS_LIST; do
      for spec in $ARMS_RUN; do
        TAG="${spec%%:*}"
        for S in $SEEDS; do
          f="$OUT/$DS/proposed_${DS}_alpha${ALPHA}_seed${S}_${TAG}/results.json"
          [ -f "$f" ] || { miss=$((miss+1)); echo "  [MISSING] $f"; tail -n 8 "$LOG/${DS}_${TAG}_s${S}.log" 2>/dev/null | sed 's/^/     | /'; }
        done
      done
    done

    echo "================================================================"
    status
    [ "$miss" -eq 0 ] && echo " [OK] 全部补完 -> bash seed678.sh analyze  贴回给我" \
                       || echo " [FAIL] 缺 $miss 个，按上面日志恢复后重跑（幂等）"
    echo "================================================================"
    ;;
  *) echo "用法: $0 [run|status|analyze]"; exit 1 ;;
esac

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
