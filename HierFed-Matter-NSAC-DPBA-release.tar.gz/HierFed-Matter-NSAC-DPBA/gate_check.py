#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""gate_check.py <results.json> -- sanity-check one smoke-test result.

exit 0 : PASS   (file present, final_metrics.auc_roc finite and in (0, 1])
exit 1 : FAIL   (missing / malformed) -- the gate then aborts the batch
"""
import json
import os
import sys


def main():
    if len(sys.argv) != 2:
        print("usage: gate_check.py <results.json>")
        return 1
    path = sys.argv[1]
    if not os.path.exists(path):
        print(f"FAIL (exit 0 but results.json MISSING: {path})")
        return 1
    try:
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception as e:  # noqa: BLE001
        print(f"FAIL (results.json unreadable: {e!r})")
        return 1
    fm = d.get("final_metrics") or {}
    a = fm.get("auc_roc")
    if not isinstance(a, (int, float)) or not (0.0 < float(a) <= 1.0):
        print(f"FAIL (bad final_metrics.auc_roc={a!r}; keys={sorted(fm)[:8]})")
        return 1
    f1 = fm.get("f1_macro")
    print(f"PASS (results.json ok | T=2 auc={float(a):.4f} macro-F1={f1})")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
