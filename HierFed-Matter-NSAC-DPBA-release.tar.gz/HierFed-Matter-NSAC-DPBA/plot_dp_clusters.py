#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plot_dp_clusters.py -- the "two-colour divergence" figure for the DP family.

    python plot_dp_clusters.py                 # collect, print the data table, draw
    python plot_dp_clusters.py --table-only    # just the numbers (no figure)
    python plot_dp_clusters.py --demo          # LAYOUT PREVIEW (placeholder data)
    python plot_dp_clusters.py --outdir figs_dp

WHAT IT SHOWS
-------------
At the SAME privacy budget the DP family splits into two clusters:

    adaptive clipping   (C_i from the measured update norm)   AUC ~0.96-0.98
    uniform clip C=1.0  (one global bound for every device)   AUC ~0.85

Two colours, one per cluster; our method in a third.  x = epsilon (log), y = AUC,
one panel per Dirichlet alpha.

THREE THINGS THAT WOULD SILENTLY CORRUPT THIS FIGURE
----------------------------------------------------
1. eps=399 (results_baseline) and eps=400 (results_epsgrid) are the SAME operating
   point -- drawing both as separate markers invents a kink.  They are snapped
   together (see --merge-tol) and the merge is reported.
2. A family "mean" line is only comparable if the SAME methods feed it at every
   epsilon.  Members with a single epsilon point are therefore drawn as isolated
   markers and excluded from the mean; the members that feed each curve are
   printed.
3. Our own sweep runs to eps=1600 while the baselines stop at 400, so the two
   families are only directly comparable on eps in [100, 400].

Mechanism: the split is a CLIPPING-BIAS effect, not a noise effect -- all methods
share sigma (eps=399 -> sigma=0.359), but C/||dw|| is ~0.56 for the uniform family
(||dw|| ~ 1.8 measured) versus ~1.0 for the adaptive family.
"""
import argparse
import glob
import json
import math
import os
import re
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))

# --- theme: use the shared skill library if present, else a local fallback ----
SKILL = os.environ.get(
    "MO_THEME_DIR", "/sandbox/workspace/skills/academic-figure-style/scripts")
_HAS_SKILL = os.path.isdir(SKILL)
if _HAS_SKILL:
    sys.path.insert(0, SKILL)
    try:
        from mo_theme import apply_theme, save_fig          # type: ignore
        from palettes import get_scheme                     # type: ignore
    except Exception:
        _HAS_SKILL = False

if not _HAS_SKILL:
    _MORANDI = {
        "nickname": "morandi",
        "main": ["#6E8CA0", "#B0868A", "#8BA37F", "#9C8CA8",
                 "#C39B72", "#6FA0A0", "#C8B48E", "#8A8A93"],
        "light": ["#C3D0DA", "#DFCBCB", "#CBD8C4", "#D2CBD9",
                  "#E4D2BE", "#C2D6D6", "#E4DBC9", "#D2D2D8"],
        "seq": ["#EDF1F4", "#C3D0DA", "#93AEC0", "#6E8CA0", "#4E6B80"],
        "div": ["#5B7A99", "#8FA9BF", "#C9D3DB", "#EFEAE4",
                "#DFC3BC", "#C39D97", "#A6756D"],
        "sem": {"pos": "#8BA37F", "neg": "#B0868A",
                "ref": "#5A6672", "hl": "#C0724E", "text": "#1f1f1f"},
    }

    def get_scheme(_name="morandi"):
        return _MORANDI

    def apply_theme(font="serif", base_size=16, scheme="morandi",
                    grid=True, frame="open"):
        import matplotlib
        fam = (["Times New Roman", "Nimbus Roman", "Nimbus Roman No9 L",
                "Liberation Serif", "DejaVu Serif"] if font == "serif"
               else ["DejaVu Sans"])
        matplotlib.rcParams.update({
            "font.family": "serif" if font == "serif" else "sans-serif",
            "font.serif": fam, "font.sans-serif": fam,
            "mathtext.fontset": "stix" if font == "serif" else "dejavusans",
            "font.size": base_size, "axes.titlesize": base_size,
            "axes.labelsize": base_size, "xtick.labelsize": base_size - 1,
            "ytick.labelsize": base_size - 1, "legend.fontsize": base_size - 1,
            "text.color": "#1f1f1f", "axes.labelcolor": "#1f1f1f",
            "axes.edgecolor": "#5A6672", "xtick.color": "#5A6672",
            "ytick.color": "#5A6672", "xtick.direction": "out",
            "ytick.direction": "out", "axes.linewidth": 1.1,
            "axes.grid": grid, "grid.color": "#DDDDDD",
            "grid.linewidth": 0.7, "grid.alpha": 0.8,
            "axes.spines.top": frame != "open",
            "axes.spines.right": frame != "open",
            "figure.facecolor": "white", "savefig.facecolor": "white",
        })

    def save_fig(fig, name, outdir=".", formats=("pdf", "png"),
                 dpi=300, tight=True, verbose=True):
        os.makedirs(outdir, exist_ok=True)
        paths = []
        for fmt in formats:
            p = os.path.join(outdir, f"{name}.{fmt}")
            kw = dict(dpi=dpi) if fmt in ("png", "jpg", "jpeg", "tif") else {}
            if tight:
                fig.savefig(p, format=fmt, bbox_inches="tight",
                            pad_inches=0.05, **kw)
            else:
                fig.savefig(p, format=fmt, **kw)
            paths.append(p)
        if verbose:
            print("[save_fig] " + "  |  ".join(paths))
        return paths

import matplotlib                                            # noqa: E402
matplotlib.use("Agg")                                        # headless-safe
import matplotlib.pyplot as plt                              # noqa: E402
from matplotlib.lines import Line2D                          # noqa: E402
from matplotlib.ticker import NullLocator, NullFormatter     # noqa: E402

# --------------------------------------------------------------------- config
ANCHORS = [20.0, 50.0, 100.0, 200.0, 400.0, 800.0, 1600.0]
ADAPT = ["adaptive_clip_dp", "layer_adaptive_dp", "dpfed6g"]
UNIF = ["hierfed_dp", "dpfedavg", "safeliot", "fedprox_dp"]
PLOT_FAMILY = ADAPT + UNIF
ALPHAS = [0.5, 0.1]
EPS_BASE_FALLBACK = 399.0
TEXT = "#1f1f1f"
GAMMA_UNIF = 0.56            # C/||dw|| with C=1.0, ||dw||~1.8 (measured)
LABEL = {0.5: r"$\alpha=0.5$  (moderate heterogeneity)",
         0.1: r"$\alpha=0.1$  (extreme heterogeneity)"}


def bar(t):
    print("\n" + "=" * 78)
    print("  " + t)
    print("=" * 78)


def snap(x, anchors=ANCHORS, tol=0.05):
    """Snap epsilon onto an anchor when within tol (log ratio). 399 -> 400."""
    for a in anchors:
        if abs(math.log(x / a)) <= tol:
            return float(a), a != float(x)
    return float(x), False


def auc_of(p):
    try:
        d = json.load(open(p, encoding="utf-8"))
    except Exception:
        return None, None
    fm = d.get("final_metrics") or {}
    a = fm.get("auc_roc")
    cfg = d.get("config") or {}
    return (float(a) if isinstance(a, (int, float)) else None), cfg


def eps_from_log(method, alpha):
    for d in ("logs/jobs", "logs/epsgrid", "logs"):
        for p in sorted(glob.glob(os.path.join(
                HERE, d, f"{method}_iotid20_alpha{alpha}_seed*.log")))[:1]:
            try:
                txt = open(p, encoding="utf-8", errors="replace").read()
            except Exception:
                continue
            m = re.search(r"ε\s*=\s*([\d.]+)", txt) or \
                re.search(r"ε_total\s*=\s*([\d.]+)", txt)
            if m:
                return float(m.group(1)), os.path.relpath(p, HERE)
    return None, None


def collect(merge_tol=0.05):
    """{(method, alpha): {eps: [auc, ...]}}  + merge report + source report"""
    tab = defaultdict(lambda: defaultdict(list))
    merged = defaultdict(int)
    src = defaultdict(int)
    base_reps = set()

    def add(meth, alpha, eps, auc, where, base=False):
        e2, did = snap(eps, tol=merge_tol)
        if did:
            merged[f"{eps:g} -> {e2:g}"] += 1
        tab[(meth, alpha)][e2].append(auc)
        src[where] += 1
        if base:
            base_reps.add(e2)

    for p in sorted(glob.glob(os.path.join(HERE, "results_baseline", "*", "results.json"))):
        name = os.path.basename(os.path.dirname(p))
        m = re.match(r"(.+)_iotid20_alpha([\d.]+)_seed(\d+)$", name)
        if not m:
            continue
        meth, alpha = m.group(1), float(m.group(2))
        a, cfg = auc_of(p)
        if a is None:
            continue
        eps = cfg.get("epsilon_total")
        if eps is None:
            add(meth, alpha, EPS_BASE_FALLBACK, a,
                "results_baseline (eps not recorded -> 399)", base=True)
            continue
        add(meth, alpha, float(eps), a, "results_baseline", base=True)

    for p in glob.glob(os.path.join(HERE, "results_epsgrid", "eps*", "*", "results.json")):
        name = os.path.basename(os.path.dirname(p))
        m = re.match(r"(.+)_iotid20_alpha([\d.]+)_seed(\d+)$", name)
        if not m:
            continue
        meth, alpha = m.group(1), float(m.group(2))
        a, cfg = auc_of(p)
        if a is None:
            continue
        eps = cfg.get("epsilon_total")
        if eps is None:
            em = re.search(r"eps([\d.]+)$",
                           os.path.basename(os.path.dirname(os.path.dirname(p))))
            eps = float(em.group(1)) if em else None
        if eps is not None:
            add(meth, alpha, float(eps), a, "results_epsgrid")

    for p in glob.glob(os.path.join(HERE, "results_eps", "epsweep_eps*", "results.json")):
        name = os.path.basename(os.path.dirname(p))
        m = re.match(r"epsweep_eps([\d.]+)_alpha([\d.]+)_seed(\d+)$", name)
        if not m:
            continue
        a, _ = auc_of(p)
        if a is not None:
            add("proposed", float(m.group(2)), float(m.group(1)), a, "results_eps (ours)")

    return tab, merged, src, sorted(base_reps)


def summarise(series):
    """{eps: [vals]} -> [(eps, mean, lo, hi, n), ...] sorted by eps"""
    out = []
    for e in sorted(series):
        v = [x for x in series[e] if x is not None]
        if v:
            out.append((e, sum(v) / len(v), min(v), max(v), len(v)))
    return out


def sd(v):
    if len(v) < 2:
        return 0.0
    mu = sum(v) / len(v)
    return math.sqrt(sum((x - mu) ** 2 for x in v) / (len(v) - 1))


def members(tab, alpha, fam):
    """split a family into (swept members with >=2 eps, single-eps members)"""
    swept, single = [], []
    for meth in fam:
        s = tab.get((meth, alpha), {})
        if not s:
            continue
        (swept if len(s) >= 2 else single).append(meth)
    return swept, single


def print_table(tab):
    hdr = f"  {'method':<20} {'alpha':>5}  {'eps':>7}  {'AUC mean':>9} {'sd':>7} {'n':>3}"
    for fam_name, fam in (("adaptive clipping  (C_i from measured ||dw_i||)", ADAPT),
                          ("uniform clip  C=1.0  (C/||dw|| ~ %.2f)" % GAMMA_UNIF, UNIF)):
        bar(fam_name)
        print(hdr)
        print("  " + "-" * 76)
        for meth in fam:
            for alpha in ALPHAS:
                s = summarise(tab.get((meth, alpha), {}))
                if not s:
                    print(f"  {meth:<20} {alpha:>5}  {'--':>7}  {'no data':>9}")
                    continue
                for (e, mu, lo, hi, n) in s:
                    vals = [x for x in tab[(meth, alpha)][e] if x is not None]
                    print(f"  {meth:<20} {alpha:>5}  {e:>7g}  {mu:>9.4f} "
                          f"{sd(vals):>7.4f} {n:>3}")
    # ours
    bar("ours -- hier.+NSAC+DP")
    print(hdr)
    print("  " + "-" * 76)
    for alpha in ALPHAS:
        for (e, mu, lo, hi, n) in summarise(tab.get(("proposed", alpha), {})):
            vals = [x for x in tab[("proposed", alpha)][e] if x is not None]
            print(f"  {'proposed':<20} {alpha:>5}  {e:>7g}  {mu:>9.4f} "
                  f"{sd(vals):>7.4f} {n:>3}")


def print_diagnosis(tab):
    bar("figure diagnostics  (what the two coloured curves can be built from)")
    for alpha in ALPHAS:
        print(f"\n  --- alpha = {alpha} ---")
        for fam_name, fam in (("adaptive", ADAPT), ("uniform ", UNIF)):
            swept, single = members(tab, alpha, fam)
            print(f"    {fam_name}: curve members = {swept or 'NONE'}")
            print(f"              single-eps   = {single or 'none'}")
            if swept:
                eps_sets = [set(tab[(m, alpha)]) for m in swept]
                common = set.intersection(*eps_sets) if len(eps_sets) > 1 else eps_sets[0]
                print(f"              common eps   = {sorted(common)}")
    print("\n  A curve is drawn only for the 'curve members'.  A family with ONE")
    print("  curve member is a single method, not a family average -- extend the")
    print("  sweep (run_baseline_eps_sweep.sh with METHODS=...) before quoting it.")


def demo_data():
    """Layout preview data.  eps=100/200 are PLACEHOLDERS; eps=400 values are the
    real measured ones; only 3 methods are swept, exactly like the server tree."""
    tab = defaultdict(lambda: defaultdict(list))
    swept = {
        0.5: {"adaptive_clip_dp": {100: .905, 200: .958, 400: .9805},
              "dpfed6g": {100: .889, 200: .948, 400: .9668},
              "hierfed_dp": {100: .760, 200: .826, 400: .8501}},
        0.1: {"adaptive_clip_dp": {100: .858, 200: .934, 400: .9649},
              "dpfed6g": {100: .842, 200: .921, 400: .9382},
              "hierfed_dp": {100: .752, 200: .822, 400: .8624}},
    }
    single = {0.5: {"layer_adaptive_dp": .9632, "dpfedavg": .8497,
                    "safeliot": .8579, "fedprox_dp": .8485},
              0.1: {"layer_adaptive_dp": .9419, "dpfedavg": .8623,
                    "safeliot": .8604, "fedprox_dp": .8603}}
    ours = {0.5: {20: .5492, 50: .6365, 100: .9358, 200: .9705, 400: .9735,
                  800: .9743, 1600: .9747},
            0.1: {20: .5061, 50: .6257, 100: .8190, 200: .9308, 400: .9569,
                  800: .9648, 1600: .9705}}
    for alpha in ALPHAS:
        for meth, d in swept[alpha].items():
            for e, mu in d.items():
                tab[(meth, alpha)][float(e)] = [mu - 0.002, mu, mu + 0.002,
                                                mu - 0.001, mu + 0.001]
        for meth, mu in single[alpha].items():
            tab[(meth, alpha)][400.0] = [mu - 0.002, mu, mu + 0.002,
                                         mu - 0.001, mu + 0.001]
        for e, mu in ours[alpha].items():
            tab[("proposed", alpha)][float(e)] = [mu] * 5
    return tab


def draw(tab, outdir, tag="", eps_rep=400.0, eps_raw=None, with_slice=False,
         slice_alpha=0.5):
    sch = get_scheme("morandi")
    C_ADAPT, C_UNIF, C_OUR = sch["main"][0], sch["main"][1], sch["sem"]["hl"]
    L_ADAPT, L_UNIF = sch["light"][0], sch["light"][1]
    apply_theme(font="serif", base_size=16, scheme="morandi", grid=True, frame="open")

    if with_slice:
        fig, axes = plt.subplots(1, 3, figsize=(19.4, 5.9),
                                 gridspec_kw={"width_ratios": [1.0, 1.0, 0.95]})
    else:
        fig, axes = plt.subplots(1, 2, figsize=(13.6, 5.6), sharey=True)

    for ax, alpha in zip(axes[:2], ALPHAS):
        drawn_any = False
        for fam, color, lcolor in ((ADAPT, C_ADAPT, L_ADAPT), (UNIF, C_UNIF, L_UNIF)):
            swept, single = members(tab, alpha, fam)
            if not swept:
                continue
            drawn_any = True
            for meth in swept:
                s = summarise(tab[(meth, alpha)])
                ax.plot([x[0] for x in s], [x[1] for x in s], color=color, lw=1.5,
                        alpha=0.40, marker="o", ms=5, zorder=2)
            eps_set = sorted(set.intersection(*[set(tab[(m, alpha)]) for m in swept]))
            means, los, his = [], [], []
            for e in eps_set:
                vals = [x for m in swept for x in tab[(m, alpha)][e] if x is not None]
                means.append(sum(vals) / len(vals)); los.append(min(vals)); his.append(max(vals))
            ax.plot(eps_set, means, color=color, lw=2.8, marker="s", ms=8,
                    markeredgecolor="white", markeredgewidth=1.2, zorder=4)
            if len(swept) > 1:
                ax.fill_between(eps_set, los, his, color=lcolor, alpha=0.45,
                                zorder=1, linewidth=0)
            for meth in single:                      # above the thick line, zorder=6
                s = summarise(tab[(meth, alpha)])
                ax.plot([x[0] for x in s], [x[1] for x in s], ls="none", marker="o",
                        ms=11, mfc="white", mec=color, mew=2.0, zorder=6)
        s = summarise(tab.get(("proposed", alpha), {}))
        if s:
            drawn_any = True
            ax.plot([x[0] for x in s], [x[1] for x in s], color=C_OUR, lw=3.6,
                    marker="D", ms=8, markeredgecolor="white", markeredgewidth=1.2,
                    zorder=5)
        if drawn_any:
            ax.axvline(eps_rep, color=sch["sem"]["ref"], lw=1.0, ls=(0, (4, 4)),
                       alpha=0.6, zorder=0)
        ax.set_xscale("log")
        ax.set_xticks([20, 50, 100, 200, 400, 800, 1600])
        ax.set_xticklabels(["20", "50", "100", "200", "400", "800", "1600"])
        ax.xaxis.set_minor_locator(NullLocator())
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.set_xlim(15, 2100)
        ax.set_ylim(0.45, 1.0)
        ax.set_xlabel(r"privacy budget $\varepsilon$   (log scale)")
        ax.set_title(LABEL[alpha], fontsize=16, pad=8)
        if drawn_any:
            am = family_mean_at(tab, alpha, ADAPT, eps_rep)
            um = family_mean_at(tab, alpha, UNIF, eps_rep)
            if am is not None and um is not None:
                tag_raw = (f"\n(baselines at {eps_raw:g})"
                           if eps_raw and abs(eps_raw - eps_rep) > 1e-9 else "")
                ax.text(0.030, 0.965,
                        rf"$\Delta$AUC = {am - um:+.3f}" "\n"
                        rf"@ $\varepsilon$={eps_rep:g}, equal $\sigma$" + tag_raw,
                        transform=ax.transAxes, va="top", ha="left", fontsize=16,
                        color=TEXT, zorder=8)
        if not drawn_any:
            ax.text(0.5, 0.5, "no data yet", transform=ax.transAxes,
                    ha="center", va="center", fontsize=16, color="#8A8A93")
    axes[0].set_ylabel("AUC")
    if not with_slice:
        axes[1].set_ylim(axes[0].get_ylim())

    if with_slice:
        slice_panel(axes[2], tab, slice_alpha, eps_rep, C_ADAPT, C_UNIF, sch)

    handles = [
        Line2D([], [], color=C_ADAPT, lw=2.8, marker="s", ms=8,
               markeredgecolor="white",
               label=r"adaptive clipping   ($C_i\!\approx\!\|\Delta w_i\|$)"),
        Line2D([], [], color=C_UNIF, lw=2.8, marker="s", ms=8,
               markeredgecolor="white",
               label=r"uniform clip $C=1.0$   ($C/\|\Delta w\|\!\approx\!%.2f$)" % GAMMA_UNIF),
        Line2D([], [], color=sch["main"][7], lw=0, marker="o", ms=11, mfc="white",
               mec=sch["main"][7], mew=2.0,
               label=rf"family members not swept (open circles, $\varepsilon$={eps_rep:g})"),
        Line2D([], [], color=C_OUR, lw=3.6, marker="D", ms=8,
               markeredgecolor="white",
               label=r"ours -- hier.+NSAC+DP   ($26.7\times$ less traffic)"),
    ]
    fig.legend(handles=handles, loc="lower center", ncol=2, frameon=False,
               bbox_to_anchor=(0.5, -0.015), fontsize=16,
               handletextpad=0.8, columnspacing=2.0)
    fig.tight_layout(rect=(0, 0.12, 1, 1))
    name = f"fig_dp_clusters{'_with_slice' if with_slice else ''}{tag}"
    paths = save_fig(fig, name, outdir=outdir)
    plt.close(fig)
    return paths


def slice_panel(ax, tab, alpha, eps, c_ad, c_un, sch):
    """the eps=eps slice: every family member, grouped, as a lollipop."""
    rows = []
    for fam, color in ((ADAPT, c_ad), (UNIF, c_un)):
        for meth in fam:
            v = family_mean_at(tab, alpha, [meth], eps)
            if v is not None:
                rows.append((meth, v, color, fam is ADAPT))
    if not rows:
        ax.text(0.5, 0.5, "no slice data", transform=ax.transAxes, ha="center",
                va="center", fontsize=16, color="#8A8A93")
        return
    n_ad = sum(1 for r in rows if r[3])
    ypos = []
    y = 0
    for i, r in enumerate(rows):
        if i == n_ad:
            y -= 0.75                      # gap between the two clusters
        ypos.append(y)
        y -= 1
    for (meth, v, color, _), yy in zip(rows, ypos):
        ax.plot([0.80, v], [yy, yy], color=color, lw=2.2, alpha=0.75, zorder=2,
                solid_capstyle="round")
        ax.plot([v], [yy], marker="o", ms=11, color=color, mec="white", mew=1.5,
                zorder=3)
        ax.text(v + 0.004, yy, f"{v:.3f}", va="center", ha="left", fontsize=16,
                color=color)
    for fam, color in ((ADAPT, c_ad), (UNIF, c_un)):
        mv = family_mean_at(tab, alpha, fam, eps)
        if mv is not None:
            ax.axvline(mv, color=color, lw=1.6, ls=(0, (5, 3)), alpha=0.8, zorder=1)
    ax.set_yticks(ypos)
    ax.set_yticklabels([r[0] for r in rows], fontsize=16)
    ax.set_ylim(min(ypos) - 0.9, max(ypos) + 0.9)
    ax.set_xlim(0.80, 1.02)
    ax.set_xlabel("AUC")
    ax.set_title("the same budget, every member\n"
                 rf"$\alpha={alpha}$,  $\varepsilon$={eps:g}", fontsize=16, pad=8)
    ax.grid(axis="x", color="#DDDDDD", lw=0.7)
    ax.grid(axis="y", visible=False)

def family_mean_at(tab, alpha, fam, eps, tol=0.05):
    vals = []
    for meth in fam:
        for e, v in tab.get((meth, alpha), {}).items():
            if abs(math.log(e / eps)) <= tol:
                vals += [x for x in v if x is not None]
    return sum(vals) / len(vals) if vals else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true",
                    help="layout preview with placeholder data")
    ap.add_argument("--table-only", action="store_true", help="print numbers, no figure")
    ap.add_argument("--with-slice", action="store_true",
                    help="add a third panel: every family member at the shared budget")
    ap.add_argument("--merge-tol", type=float, default=0.05,
                    help="snap eps together when within this log ratio (default 0.05)")
    ap.add_argument("--outdir", default=os.path.join(HERE, "figs_dp"))
    a = ap.parse_args()

    print("=" * 78)
    print("  DP family: two-colour divergence figure")
    print("=" * 78)
    print(f"  theme : {'skill library -> ' + SKILL if _HAS_SKILL else 'built-in fallback'}")
    print(f"  cwd   : {os.getcwd()}")
    print(f"  outdir: {a.outdir}")

    if a.demo:
        print("\n  [!] DEMO MODE -- LAYOUT REVIEW ONLY.")
        print("      eps=100/200 are placeholders; eps=400 uses the real measured")
        print("      values; only 3 methods are swept, like the server tree.")
        paths = draw(demo_data(), a.outdir, tag="_LAYOUT_PREVIEW",
                     with_slice=a.with_slice)
        print(f"\n  preview written: {paths}")
        return 0

    tab, merged, src, base_reps = collect(a.merge_tol)
    print(f"\n  sources: " + " | ".join(f"{k}={v}" for k, v in sorted(src.items())))
    if merged:
        print("  eps snapped together (same operating point): "
              + ", ".join(f"{k} x{v}" for k, v in sorted(merged.items())))
    eps_raw = base_reps[0] if len(base_reps) == 1 else None
    eps_rep = eps_raw if eps_raw is not None else EPS_BASE_FALLBACK
    print(f"  baselines sit at eps = "
          + (f"{eps_rep:g}" if eps_raw is not None
             else f"{base_reps} (ambiguous -- using {eps_rep:g})"))
    print(f"\n  collected {len([k for k, v in tab.items() if v])} (method, alpha) series")
    print_table(tab)
    print_diagnosis(tab)

    if a.table_only:
        return 0
    bar("figure")
    paths = draw(tab, a.outdir, eps_rep=eps_rep, eps_raw=eps_raw,
                 with_slice=a.with_slice)
    print(f"  written: {paths}")
    warns = []
    for alpha in ALPHAS:
        for fam_name, fam in (("adaptive", ADAPT), ("uniform", UNIF)):
            swept, _ = members(tab, alpha, fam)
            if len(swept) < 2:
                warns.append(f"alpha={alpha} {fam_name}: only {len(swept)} swept "
                             f"member(s) {swept} -- the coloured line is ONE method, "
                             f"not a family average")
    if warns:
        print("\n  WARNINGS (fix before quoting this figure):")
        for w in warns:
            print("   * " + w)
    return 0


if __name__ == "__main__":
    sys.exit(main())

# -----------------------------------------------------------------------------
# AI Usage Declaration  |  AI 使用声明
# -----------------------------------------------------------------------------
# EN: The author's native language is Chinese. The English comments, docstrings
#     and translations in this file were produced with the assistance of an AI
#     writing assistant (ima.copilot, Tencent; 2026-10). All code logic,
#     experiment design and scientific conclusions are the author's own.
# 中文：作者母语为中文。本文件中的英文注释、文档字符串与译文由 AI 写作助手
#       （ima.copilot，腾讯；2026-10）协助生成。所有代码逻辑、实验设计与科学
#       结论均为作者本人所有。
# -----------------------------------------------------------------------------
